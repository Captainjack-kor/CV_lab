#!/bin/sh
xcrun stapler staple "$1"

