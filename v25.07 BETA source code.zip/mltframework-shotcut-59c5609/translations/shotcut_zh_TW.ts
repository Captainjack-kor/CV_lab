<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>AbstractJob</name>
    <message>
        <location filename="../src/jobs/abstractjob.cpp" line="53"/>
        <source>Pause This Job</source>
        <translation>暫停此工作</translation>
    </message>
    <message>
        <location filename="../src/jobs/abstractjob.cpp" line="56"/>
        <source>Resume This Job</source>
        <translation>繼續此工作</translation>
    </message>
</context>
<context>
    <name>ActionsDialog</name>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="238"/>
        <source>Actions and Shortcuts</source>
        <translation>指令與快速鍵</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="246"/>
        <source>search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="260"/>
        <source>Clear search</source>
        <translation>清除搜尋</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="295"/>
        <source>Click on the selected shortcut to show the editor</source>
        <translation>按一下選取的快速鍵以顯示編輯器</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="301"/>
        <source>Reserved shortcuts can not be edited</source>
        <translation>無法編輯保留快速鍵</translation>
    </message>
</context>
<context>
    <name>ActionsModel</name>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="188"/>
        <source>Shortcut %1 is used by %2</source>
        <translation>快速鍵 %1 為「%2」所使用</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="198"/>
        <source>Shortcut %1 is reserved for use by %2</source>
        <translation>快速鍵 %1 已保留供「%2」使用</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="233"/>
        <source>Action</source>
        <translation>指令</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="235"/>
        <source>Shortcut 1</source>
        <translation>快速鍵 1</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="237"/>
        <source>Shortcut 2</source>
        <translation>快速鍵 2</translation>
    </message>
</context>
<context>
    <name>AddEncodePresetDialog</name>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>對話方塊</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="25"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="52"/>
        <source>File name extension</source>
        <translation>檔案副檔名</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="59"/>
        <source>for example, mp4</source>
        <translation>例如 mp4</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="84"/>
        <source>Make final changes to the preset including removing items you do not want to include, or copy/paste the clipboard.</source>
        <translation>對預設設定進行最後修改，包含移除不想包含的項目，或從剪貼簿複製／貼上。</translation>
    </message>
</context>
<context>
    <name>AlignAudioDialog</name>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="234"/>
        <source>Reference audio track</source>
        <translation>參考音訊軌道</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="251"/>
        <source>Speed adjustment range</source>
        <translation>速度調整範圍</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="254"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="255"/>
        <source>Narrow</source>
        <translation>窄</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="257"/>
        <source>Normal</source>
        <translation>標準</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="259"/>
        <source>Wide</source>
        <translation>寬</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="260"/>
        <source>Very wide</source>
        <translation>非常寬</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="303"/>
        <source>Process</source>
        <translation>處理</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="306"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="309"/>
        <source>Process + Apply</source>
        <translation>處理＋套用</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="347"/>
        <source>This clip will be skipped because it is on the reference track.</source>
        <translation>此短片位於參考軌道上，將跳過此短片。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="353"/>
        <source>This item can not be aligned.</source>
        <translation>不能對齊此項目。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="365"/>
        <source>Align Audio</source>
        <translation>對齊音訊</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="482"/>
        <source>Analyze Reference Track</source>
        <translation>分析參考軌道</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="490"/>
        <source>Analyze Clips</source>
        <translation>分析短片</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="500"/>
        <source>Alignment not found.</source>
        <translation>找不到對齊點。</translation>
    </message>
</context>
<context>
    <name>AlignClipsModel</name>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="202"/>
        <source>Clip</source>
        <translation>短片</translation>
    </message>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="204"/>
        <source>Offset</source>
        <translation>位移</translation>
    </message>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="206"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
</context>
<context>
    <name>AlsaWidget</name>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="26"/>
        <source>ALSA Audio</source>
        <translation>ALSA 音訊</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="54"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="61"/>
        <source>PCM Device</source>
        <translation>PCM 裝置</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="71"/>
        <source>default</source>
        <translation>預設</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="78"/>
        <source>Channels</source>
        <translation>聲道</translation>
    </message>
</context>
<context>
    <name>AttachedFiltersModel</name>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="236"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="238"/>
        <source>Time</source>
        <translation>時間</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="240"/>
        <source>GPU</source>
        <translation>GPU</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="242"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="491"/>
        <source>This file has B-frames, which is not supported by %1.</source>
        <translation>此檔案含有 B 影格，不被 %1 支援。</translation>
    </message>
</context>
<context>
    <name>AudioLoudnessScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="85"/>
        <source>Momentary Loudness</source>
        <translation>瞬時響度</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="88"/>
        <source>Short Term Loudness</source>
        <translation>短期響度</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="91"/>
        <source>Integrated Loudness</source>
        <translation>整體響度</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="94"/>
        <source>Loudness Range</source>
        <translation>響度範圍</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="97"/>
        <source>Peak</source>
        <translation>峰值</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="100"/>
        <source>True Peak</source>
        <translation>真實峰值</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="106"/>
        <source>Configure Graphs</source>
        <translation>設定圖表</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="114"/>
        <source>Reset</source>
        <translation>重設</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="115"/>
        <source>Reset the measurement.</source>
        <translation>重設測量。</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="122"/>
        <source>Time Since Reset</source>
        <translation>重設後經過時間</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="178"/>
        <source>Audio Loudness</source>
        <translation>音訊響度</translation>
    </message>
</context>
<context>
    <name>AudioPeakMeterScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="90"/>
        <source>Audio Peak Meter</source>
        <translation>音訊峰值計</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="107"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="107"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>LF</source>
        <translation>LF</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>Ls</source>
        <translation>Ls</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>Rs</source>
        <translation>Rs</translation>
    </message>
</context>
<context>
    <name>AudioSpectrumScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiospectrumscopewidget.cpp" line="217"/>
        <source>Audio Spectrum</source>
        <translation>音訊頻譜</translation>
    </message>
</context>
<context>
    <name>AudioSurroundScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="70"/>
        <source>Audio Surround</source>
        <translation>環繞音訊</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="252"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="265"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="279"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="293"/>
        <source>LS</source>
        <translation>LS</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="306"/>
        <source>RS</source>
        <translation>RS</translation>
    </message>
</context>
<context>
    <name>AudioVectorScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="90"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="91"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="99"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="100"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="93"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="95"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="94"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="96"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="103"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="105"/>
        <source>Ls</source>
        <translation>Ls</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="104"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="106"/>
        <source>Rs</source>
        <translation>Rs</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="110"/>
        <source>LFE</source>
        <translation>LFE</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="215"/>
        <source>Audio Vector</source>
        <translation>音訊向量</translation>
    </message>
</context>
<context>
    <name>AudioWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="181"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="182"/>
        <source>-inf</source>
        <translation>-∞</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="265"/>
        <source>Sample: %1
</source>
        <translation>採樣：%1
</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="273"/>
        <source>Ch: %1: %2 (%3 dBFS)</source>
        <translation>聲道：%1: %2（%3 dBFS）</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="298"/>
        <source>Audio Waveform</source>
        <translation>音訊波形</translation>
    </message>
</context>
<context>
    <name>AvformatProducerWidget</name>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="60"/>
        <source>Comments:</source>
        <translation>註解：</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="174"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="120"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="289"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="569"/>
        <source>Broadcast Limited (MPEG)</source>
        <translation>有限廣播 (MPEG)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="574"/>
        <source>Full (JPEG)</source>
        <translation>完整 (JPEG)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="472"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="697"/>
        <source>Track</source>
        <translation>軌道</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="460"/>
        <source>Aspect ratio</source>
        <translation>外觀比例</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="525"/>
        <source>:</source>
        <translation>：</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="295"/>
        <source>Scan mode</source>
        <translation>掃描模式</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="600"/>
        <source>Interlaced</source>
        <translation>交錯式</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="605"/>
        <source>Progressive</source>
        <translation>漸進式</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="374"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="414"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="783"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="813"/>
        <source>Codec</source>
        <translation>編碼器</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="184"/>
        <source>Timeline</source>
        <translation>時間軸</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="199"/>
        <source>Speed Presets</source>
        <translation>速度預設設定</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="251"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="258"/>
        <source>Apply pitch compensation when the speed is changed.</source>
        <translation>當速度改變時套用音高補償。</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="261"/>
        <source>Pitch Compensation</source>
        <translation>音高補償</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="315"/>
        <source>Rotation</source>
        <translation>旋轉</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="379"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="419"/>
        <source>Resolution</source>
        <translation>解析度</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="384"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="424"/>
        <source>Frame rate</source>
        <translation>影格播放速率</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="389"/>
        <source>Pixel format</source>
        <translation>像素格式</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="394"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="434"/>
        <source>Color space</source>
        <translation>色彩空間</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="399"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="439"/>
        <source>Color transfer</source>
        <translation>色彩轉換</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="404"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="803"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="943"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="409"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="808"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="948"/>
        <source>Value</source>
        <translation>數值</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="429"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="798"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="828"/>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="614"/>
        <source>Bottom Field First</source>
        <translation>下圖場優先</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="619"/>
        <source>Top Field First</source>
        <translation>上圖場優先</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="645"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="650"/>
        <source>90</source>
        <translation>90</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="655"/>
        <source>180</source>
        <translation>180</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="660"/>
        <source>270</source>
        <translation>270</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="668"/>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="691"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="788"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="818"/>
        <source>Channels</source>
        <translation>聲道</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="793"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="823"/>
        <source>Sample rate</source>
        <translation>採樣速率</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="836"/>
        <source>Adjust the audio/video synchronization. The center position is equivalent to no alteration.</source>
        <translation>調整音訊／視訊同步速率。中心位置相當於不作任何調整。</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="855"/>
        <source>Sync</source>
        <translation>同步</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="880"/>
        <source> ms</source>
        <translation> 毫秒</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="909"/>
        <source>Metadata</source>
        <translation>中繼資料</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="979"/>
        <source>Properties Menu</source>
        <translation>「屬性」功能表</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1032"/>
        <source>Show In Folder</source>
        <translation>在資料夾中顯示</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1062"/>
        <source>Extract Subtitles...</source>
        <translation>擷取字幕…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1095"/>
        <source>Reset</source>
        <translation>重設</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1100"/>
        <source>Set Equirectangular...</source>
        <translation>設定等距長方投影…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1105"/>
        <source>Measure Video Quality...</source>
        <translation>測量視訊品質…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1113"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1116"/>
        <source>Export GPX</source>
        <translation>匯出 GPX</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1121"/>
        <source>View Bitrate...</source>
        <translation>檢視位元速率…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1124"/>
        <source>View Bitrate</source>
        <translation>檢視位元速率</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1129"/>
        <source>Show In Files</source>
        <translation>在「檔案」中顯示</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1000"/>
        <source>Convert to Edit-friendly</source>
        <translation>轉換為易於剪輯的格式</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="305"/>
        <source>Color range</source>
        <translation>色彩範圍</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1003"/>
        <source>Convert...</source>
        <translation>轉換…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1037"/>
        <source>Copy Full File Path</source>
        <translation>複製完整檔案路徑</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1042"/>
        <source>More Information...</source>
        <translation>更多資訊…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1047"/>
        <source>Start Integrity Check Job</source>
        <translation>啟動完整性檢查作業</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1052"/>
        <source>Convert to Edit-friendly...</source>
        <translation>轉換為易於剪輯的格式…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1067"/>
        <source>Set Creation Time...</source>
        <translation>設定建立時間…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1075"/>
        <source>Disable Proxy</source>
        <translation>停用代理素材</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1080"/>
        <source>Make Proxy</source>
        <translation>製作代理素材</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1085"/>
        <source>Delete Proxy</source>
        <translation>刪除代理素材</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1090"/>
        <source>Copy Hash Code</source>
        <translation>複製雜湊碼</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="993"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="861"/>
        <source>Reverse...</source>
        <translation>反轉…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1057"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1127"/>
        <source>Extract Sub-clip...</source>
        <translation>擷取子短片…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="347"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="418"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="376"/>
        <source>unknown (%1)</source>
        <translation>未知 (%1)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="452"/>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="498"/>
        <source>(PROXY)</source>
        <translation>（代理）</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="541"/>
        <source>(variable)</source>
        <translation>（可變）</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1010"/>
        <source>Proxy</source>
        <translation>代理素材</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="134"/>
        <source> Do you want to convert it to an edit-friendly format?

If yes, choose a format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, it automatically replaces clips, or you can double-click the job to open it.
</source>
        <translation>要轉換成易於剪輯的格式嗎？

如果是，請在下方選擇一種格式，然後按下「確定」來選擇檔案名稱，並建立相對應的工作。當轉檔工作完成時，短片將自動被取代；亦可按兩下工作以開啟轉換後的檔案。
</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="781"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="856"/>
        <source>Choose an edit-friendly format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, double-click the job to open it.
</source>
        <translation>請在下方選擇一種易於剪輯的格式，然後按下「確定」以選擇檔案名稱，並建立相對應的工作。當工作完成時，按兩下以打開轉換後的檔案。
</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="970"/>
        <source>MP4 (*.mp4);;All Files (*)</source>
        <translation>MP4 (*.mp4);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1015"/>
        <source>MOV (*.mov);;All Files (*)</source>
        <translation>MOV (*.mov);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1032"/>
        <source>MKV (*.mkv);;All Files (*)</source>
        <translation>MKV (*.mkv);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1085"/>
        <source>Convert %1</source>
        <translation>轉換 %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1036"/>
        <source>Reversed</source>
        <translation>已反轉</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1066"/>
        <source>Reverse canceled</source>
        <translation>已取消反轉</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1095"/>
        <source>Reverse %1</source>
        <translation>反轉 %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1464"/>
        <source>Choose the Other Video</source>
        <translation>選擇另一部視訊</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1517"/>
        <source>Measure %1</source>
        <translation>測量 %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1126"/>
        <source>Sub-clip</source>
        <translation>子短片</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1128"/>
        <source>%1 (*.%2);;All Files (*)</source>
        <translation>%1 (*.%2);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1200"/>
        <source>Extract sub-clip %1</source>
        <translation>擷取子短片 %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1219"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1269"/>
        <source>Track %1</source>
        <translation>軌道 %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1221"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1271"/>
        <source>Track %1 (%2)</source>
        <translation>軌道 %1（%2）</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1225"/>
        <source>Export Subtitles...</source>
        <translation>匯出字幕…</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1227"/>
        <source>No subtitles found</source>
        <translation>未找到任何字幕</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1286"/>
        <source>Extract subtitles %1</source>
        <translation>擷取字幕 %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1399"/>
        <source>The hash code below is already copied to your clipboard:

</source>
        <translation>已經將下列雜湊碼複製到剪貼簿：

</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1443"/>
        <source>Set Equirectangular Projection</source>
        <translation>設定等距長方投影</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1455"/>
        <source>Successfully wrote %1</source>
        <translation>成功寫入 %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1457"/>
        <source>An error occurred saving the projection.</source>
        <translation>儲存投影時發生錯誤。</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1577"/>
        <source>Bitrate %1</source>
        <translation>位元速率 %1</translation>
    </message>
</context>
<context>
    <name>AvfoundationProducerWidget</name>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="26"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="107"/>
        <source>Audio/Video Device</source>
        <translation>音訊／視訊裝置</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="39"/>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="58"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="83"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="84"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="90"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="99"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="47"/>
        <source>Video Input</source>
        <translation>視訊輸入</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="66"/>
        <source>Audio Input</source>
        <translation>音訊輸入</translation>
    </message>
</context>
<context>
    <name>BitrateDialog</name>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="48"/>
        <source>Bitrate Viewer</source>
        <translation>位元速率檢視器</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="66"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="74"/>
        <source>Average</source>
        <translation>平均</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="135"/>
        <source>Bitrates for %1 ~~ Avg. %2 Min. %3 Max. %4 Kb/s</source>
        <translation>%1 的位元速率 ~~ 平均 %2 最低 %3 最高 %4 Kb/s</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="179"/>
        <source>Save Bitrate Graph</source>
        <translation>儲存位元速率圖表</translation>
    </message>
</context>
<context>
    <name>BitrateViewerJob</name>
    <message>
        <location filename="../src/jobs/bitrateviewerjob.cpp" line="34"/>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
</context>
<context>
    <name>BlipProducerWidget</name>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="26"/>
        <source>Blip Flash</source>
        <translation>光點閃爍</translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>頻率</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/widgets/blipproducerwidget.cpp" line="67"/>
        <source> second(s)</source>
        <translation>
            <numerusform> 秒</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.cpp" line="89"/>
        <source>Period: %1s</source>
        <translation>週期：%1s</translation>
    </message>
</context>
<context>
    <name>ClockSpinner</name>
    <message>
        <location filename="../src/qml/filters/timer/ClockSpinner.qml" line="121"/>
        <source>Decrement</source>
        <translation>減少</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ClockSpinner.qml" line="150"/>
        <source>Increment</source>
        <translation>增加</translation>
    </message>
</context>
<context>
    <name>ColorBarsWidget</name>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="26"/>
        <source>Color Bars</source>
        <translation>彩條信號</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="38"/>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="55"/>
        <source>100% PAL color bars</source>
        <translation>100% PAL 彩條信號</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="60"/>
        <source>100% PAL color bars with red</source>
        <translation>100% PAL 帶紅色彩條信號</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="65"/>
        <source>95% BBC PAL color bars</source>
        <translation>95% BBC PAL 彩條信號</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="70"/>
        <source>75% EBU color bars</source>
        <translation>75% EBU 彩條信號</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="75"/>
        <source>SMPTE color bars</source>
        <translation>SMPTE 彩條信號</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="80"/>
        <source>Philips PM5544</source>
        <translation>Philips PM5544</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="85"/>
        <source>FuBK</source>
        <translation>FuBK</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="90"/>
        <source>Simplified FuBK</source>
        <translation>簡化 FuBK</translation>
    </message>
</context>
<context>
    <name>ColorPicker</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="58"/>
        <source>Click to open color dialog</source>
        <translation>按一下開啟色彩對話方塊</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="89"/>
        <source>Pick a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation>挑取螢幕上的色彩。按下滑鼠按鈕並拖曳，便能選取螢幕上的一個區塊，並取得其平均色。</translation>
    </message>
</context>
<context>
    <name>ColorProducerWidget</name>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="20"/>
        <source>Color</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="30"/>
        <source>Comments:</source>
        <translation>註解：</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="61"/>
        <source>Color...</source>
        <translation>色彩…</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="74"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="58"/>
        <source>black</source>
        <translation>黑色</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="60"/>
        <source>transparent</source>
        <translation>透明</translation>
    </message>
</context>
<context>
    <name>CopyFiltersDialog</name>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="44"/>
        <source>Copy Filters</source>
        <translation>複製濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="57"/>
        <source>Enter a name to save a filter set, or
leave blank to use the clipboard:</source>
        <translation>輸入名稱以儲存濾鏡集，或
留空以使用剪貼簿。</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="64"/>
        <source>optional</source>
        <translation>選填</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="84"/>
        <source>OK</source>
        <translation>確定</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="89"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>CountProducerWidget</name>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="26"/>
        <source>Count</source>
        <translation>計數</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="41"/>
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="74"/>
        <source>Style</source>
        <translation>樣式</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="107"/>
        <source>Sound</source>
        <translation>音效</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="110"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Silent - No sound&lt;/p&gt;&lt;p&gt;2-Pop - A 1kHz beep exactly two seconds before the out point&lt;/p&gt;&lt;p&gt;Frame 0 - A 1kHz beep at frame 0 of every second&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;靜音：無音效&lt;/p&gt;&lt;p&gt;2-Pop：在結束前 2 秒發出一次 1kHz 嗶聲&lt;/p&gt;&lt;p&gt;Frame 0：在每秒的第 0 畫面各發出一次 1kHz 嗶聲&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="143"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="146"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;None - No background&lt;/p&gt;&lt;p&gt;Clock  - Film style clock animation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;無：無背景&lt;/p&gt;&lt;p&gt;時鐘：電影風格時鐘動畫&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="179"/>
        <source>Drop Frame</source>
        <translation>漏格</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="182"/>
        <source>Use SMPTE style drop-frame counting for non-integer frame rates. The clock and timecode will advance two frames every minute if necessary to keep time with wall clock time.</source>
        <translation>對非整數的影格播放速率以 SMPTE 方式計算漏格。在必要時，時鐘與時間碼將每分鐘加計 2 個畫面，以與實際時間保持同步。</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="189"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="41"/>
        <source>Down</source>
        <translation>向下</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="42"/>
        <source>Up</source>
        <translation>向上</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="45"/>
        <source>Seconds</source>
        <translation>秒數</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="46"/>
        <source>Seconds + 1</source>
        <translation>秒數 + 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="47"/>
        <source>Frames</source>
        <translation>影格數</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="48"/>
        <source>Timecode</source>
        <translation>時間碼</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="49"/>
        <location filename="../src/widgets/countproducerwidget.cpp" line="57"/>
        <source>Clock</source>
        <translation>時鐘</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="52"/>
        <source>2-Pop</source>
        <translation>2-Pop</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="53"/>
        <source>Silent</source>
        <translation>靜音</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="54"/>
        <source>Frame 0</source>
        <translation>Frame 0</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="58"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="225"/>
        <source>Count: %1 %2</source>
        <translation>計數：%1 %2</translation>
    </message>
</context>
<context>
    <name>CurveComboBox</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="36"/>
        <source>Natural</source>
        <translation>自然</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="40"/>
        <source>S-Curve</source>
        <translation>S型曲線</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="44"/>
        <source>Fast-Slow</source>
        <translation>快–慢</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="48"/>
        <source>Slow-Fast</source>
        <translation>慢–快</translation>
    </message>
</context>
<context>
    <name>CustomProfileDialog</name>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="14"/>
        <source>Add Custom Video Mode</source>
        <translation>新增自訂視訊模式</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="29"/>
        <source>Colorspace</source>
        <translation>色彩空間</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="58"/>
        <source>ITU-R BT.2020</source>
        <translation>ITU-R BT.2020</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="81"/>
        <source>Resolution</source>
        <translation>解析度</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="112"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="182"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="201"/>
        <source>Interlaced</source>
        <translation>交錯式</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="206"/>
        <source>Progressive</source>
        <translation>漸進式</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="229"/>
        <source>Aspect ratio</source>
        <translation>外觀比例</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="260"/>
        <source>x</source>
        <translation>×</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="348"/>
        <source>Frames/sec</source>
        <translation>影格／秒</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="449"/>
        <source>Scan mode</source>
        <translation>掃描模式</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="481"/>
        <source>&lt;small&gt;(Leave Name blank to skip saving a preset and use a temporary or project-specific Video Mode.)&lt;/small&gt;</source>
        <translation>&lt;small&gt;（將「名稱」留空以使用暫時或專案特定的視訊模式，而不儲存成預設設定。）&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.cpp" line="134"/>
        <source>Video Mode Frames/sec</source>
        <translation>視訊模式影格／秒</translation>
    </message>
</context>
<context>
    <name>DecklinkProducerWidget</name>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="26"/>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="85"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="57"/>
        <source>Device</source>
        <translation>裝置</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="67"/>
        <source>Signal mode</source>
        <translation>訊號模式</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="85"/>
        <source>Please be aware that not every card model supports automatic signal detection, and not all cards support all of the signal modes.</source>
        <translation>請注意，並不是所有顯示卡型號都支援自動訊號偵測或是所有的訊號模式。</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="31"/>
        <source>Detect Automatically</source>
        <translation>自動偵測</translation>
    </message>
</context>
<context>
    <name>DirectShowVideoWidget</name>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="26"/>
        <location filename="../src/widgets/directshowvideowidget.cpp" line="166"/>
        <source>Audio/Video Device</source>
        <translation>音訊／視訊裝置</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="52"/>
        <location filename="../src/widgets/directshowvideowidget.ui" line="81"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="60"/>
        <source>Video Input</source>
        <translation>視訊輸入</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="70"/>
        <source>Audio Input</source>
        <translation>音訊輸入</translation>
    </message>
</context>
<context>
    <name>DurationDialog</name>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="17"/>
        <source>Set Duration</source>
        <translation>設定長度</translation>
    </message>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="25"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
</context>
<context>
    <name>EditMarkerDialog</name>
    <message>
        <location filename="../src/dialogs/editmarkerdialog.cpp" line="31"/>
        <source>Edit Marker</source>
        <translation>編輯標記點</translation>
    </message>
</context>
<context>
    <name>EditMarkerWidget</name>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="46"/>
        <source>Set the name for this marker.</source>
        <translation>設定此標記點的名稱。</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="49"/>
        <source>Color...</source>
        <translation>色彩…</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="57"/>
        <source>Start</source>
        <translation>開始</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="62"/>
        <source>Set the start time for this marker.</source>
        <translation>設定此標記點的開始時間。</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="69"/>
        <source>End</source>
        <translation>結束</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="74"/>
        <source>Set the end time for this marker.</source>
        <translation>設定此標記點的結束時間。</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="78"/>
        <source>Duration:</source>
        <translation>長度：</translation>
    </message>
</context>
<context>
    <name>EncodeDock</name>
    <message>
        <location filename="../src/docks/encodedock.ui" line="18"/>
        <source>Export</source>
        <translation>匯出</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="45"/>
        <source>&lt;b&gt;Presets&lt;/b&gt;</source>
        <translation>&lt;b&gt;預設設定&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="58"/>
        <source>search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="89"/>
        <source>Add current settings as a new custom preset</source>
        <translation>將目前設定存成新的預設設定</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="103"/>
        <source>Delete currently selected preset</source>
        <translation>刪除目前選取的預設設定</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="169"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Export Help&lt;/span&gt;&lt;/p&gt;&lt;p&gt;The defaults create a H.264/AAC MP4 file, which is suitable for most users and purposes. Choose a &lt;span style=&quot; font-weight:600;&quot;&gt;Preset&lt;/span&gt; at the left before deciding to use the &lt;span style=&quot; font-weight:600;&quot;&gt;Advanced&lt;/span&gt; mode. The &lt;span style=&quot; font-weight:600;&quot;&gt;Advanced&lt;/span&gt; mode does not prevent creating an invalid combination of options!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;匯出說明&lt;/span&gt;&lt;/p&gt;&lt;p&gt;預設會建立適合多數使用者與用途的 H.264/AAC MP4 檔案。先從左側挑選一項&lt;span style=&quot; font-weight:600;&quot;&gt;預設設定&lt;/span&gt;，再決定是否使用&lt;span style=&quot; font-weight:600;&quot;&gt;進階&lt;/span&gt;模式：&lt;span style=&quot; font-weight:600;&quot;&gt;進階&lt;/span&gt;模式不會阻止建立出無效的選項組合！&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="187"/>
        <source>From</source>
        <translation>來源</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="217"/>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="253"/>
        <source>Use hardware encoder</source>
        <translation>使用硬體編碼器</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="260"/>
        <source>Configure...</source>
        <translation>設定…</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="294"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="485"/>
        <source>Interpolation</source>
        <translation>內插補點</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="539"/>
        <source>Field order</source>
        <translation>圖場順序</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="549"/>
        <source>Aspect ratio</source>
        <translation>外觀比例</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="723"/>
        <source>x</source>
        <translation>×</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="579"/>
        <source>Scan mode</source>
        <translation>掃描模式</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="664"/>
        <source>Interlaced</source>
        <translation>交錯式</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="669"/>
        <source>Progressive</source>
        <translation>漸進式</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="617"/>
        <source>Resolution</source>
        <translation>解析度</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="569"/>
        <source>Frames/sec</source>
        <translation>影格／秒</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="916"/>
        <source>:</source>
        <translation>：</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="824"/>
        <source>Bottom Field First</source>
        <translation>下圖場優先</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="829"/>
        <source>Top Field First</source>
        <translation>上圖場優先</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="858"/>
        <source>One Field (fast)</source>
        <translation>單一圖場（快）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="863"/>
        <source>Linear Blend (fast)</source>
        <translation>線性混合（快）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="868"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF－僅時域（良好）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="559"/>
        <source>Deinterlacer</source>
        <translation>反交錯處理</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="501"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>最接近像素（快）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="506"/>
        <source>Bilinear (good)</source>
        <translation>雙線性（良好）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="511"/>
        <source>Bicubic (better)</source>
        <translation>雙立方（較佳）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="811"/>
        <source>Use preview scaling</source>
        <translation>使用預覽縮放</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="599"/>
        <source>This enables multiple image processing threads.
Sometimes, this can be a problem, and you can
test if turning this off helps. For example, some
interlaced AVCHD in conjunction with the YADIF
deinterlacer has been reported as problematic
with parallel processing enabled.</source>
        <translation>啟用多重影像處理執行緒。
發生問題時，可以試試看停用此功能。例如在啟用
平行處理的情況下，合併使用交錯式的 AVCHD 與
YADIF 反交錯處理就曾被回報過有問題。</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="330"/>
        <source>Reframe</source>
        <translation>重新編碼影格</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="589"/>
        <source>Color range</source>
        <translation>色彩範圍</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="607"/>
        <source>Parallel processing</source>
        <translation>平行處理</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="630"/>
        <source>Broadcast Limited (MPEG)</source>
        <translation>有限廣播 (MPEG)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="635"/>
        <source>Full (JPEG)</source>
        <translation>完整 (JPEG)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="873"/>
        <source>YADIF - temporal + spatial (better)</source>
        <translation>YADIF－時域＋空間（較佳）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="878"/>
        <source>BWDIF (best)</source>
        <translation>BWDIF（最佳）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="955"/>
        <location filename="../src/docks/encodedock.ui" line="964"/>
        <location filename="../src/docks/encodedock.ui" line="1647"/>
        <source>Codec</source>
        <translation>編碼器</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="994"/>
        <source>GOP</source>
        <translation>GOP</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1006"/>
        <source>GOP = group of pictures, which is the maximum key frame interval</source>
        <translation>GOP：圖像群，即關鍵影格之間的最長間隔</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1019"/>
        <source>frames</source>
        <translation>影格</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1039"/>
        <source>A fixed GOP means that keyframes will
not be inserted at detected scene changes.</source>
        <translation>固定的 GOP 代表在偵測到場景變動時，
將不會主動插入關鍵影格。</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1043"/>
        <source>Fixed</source>
        <translation>固定</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1067"/>
        <location filename="../src/docks/encodedock.ui" line="1689"/>
        <source>The average bit rate</source>
        <translation>平均位元速率</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1220"/>
        <location filename="../src/docks/encodedock.ui" line="1772"/>
        <source>b/s</source>
        <translation>位元／秒</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1242"/>
        <source>Disable video</source>
        <translation>停用視訊</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1249"/>
        <source>Dual pass</source>
        <translation>雙階段編碼</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1256"/>
        <source>B frames</source>
        <translation>B 影格</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1268"/>
        <source>B frames are the bidirectional &quot;delta&quot; pictures
in temporal compression</source>
        <translation>B 影格是在時域壓縮過程中的雙向「疊影」</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1307"/>
        <source>Codec threads</source>
        <translation>編碼器執行緒</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1322"/>
        <source>(0 = auto)</source>
        <translation>（0：自動）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1344"/>
        <location filename="../src/docks/encodedock.ui" line="1814"/>
        <source>Rate control</source>
        <translation>速率控制</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1357"/>
        <location filename="../src/docks/encodedock.ui" line="1827"/>
        <source>Average Bitrate</source>
        <translation>平均位元速率</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1362"/>
        <location filename="../src/docks/encodedock.ui" line="1832"/>
        <source>Constant Bitrate</source>
        <translation>固定位元速率 (CBR)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1367"/>
        <location filename="../src/docks/encodedock.ui" line="1837"/>
        <source>Quality-based VBR</source>
        <translation>以品質為主的 VBR</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1372"/>
        <source>Constrained VBR</source>
        <translation>限制式 VBR</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1395"/>
        <source>Buffer size</source>
        <translation>緩衝區大小</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1417"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1439"/>
        <location filename="../src/docks/encodedock.ui" line="1860"/>
        <source>Quality</source>
        <translation>品質</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1451"/>
        <location filename="../src/docks/encodedock.ui" line="1872"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1467"/>
        <location filename="../src/docks/encodedock.ui" line="1888"/>
        <source>TextLabel</source>
        <translation>文字標籤</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1489"/>
        <location filename="../src/docks/encodedock.ui" line="1677"/>
        <source>Bitrate</source>
        <translation>位元速率</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1500"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1509"/>
        <source>Channels</source>
        <translation>聲道</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1521"/>
        <source>The number of audio channels in the output.</source>
        <translation>輸出的音訊聲道數量。</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1525"/>
        <source>1 (mono)</source>
        <translation>1（單聲道）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1530"/>
        <source>2 (stereo)</source>
        <translation>2（立體聲）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1535"/>
        <source>4 (quad/Ambisonics)</source>
        <translation>4（Quad/Ambisonics）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1540"/>
        <source>6 (5.1 surround)</source>
        <translation>6（5.1 環繞音效）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1615"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1637"/>
        <source>Sample rate</source>
        <translation>採樣速率</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1794"/>
        <source>Disable audio</source>
        <translation>停用音訊</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1911"/>
        <source>Other</source>
        <translation>其他</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1927"/>
        <source>Disable subtitles</source>
        <translation>停用字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1960"/>
        <location filename="../src/docks/encodedock.cpp" line="1328"/>
        <location filename="../src/docks/encodedock.cpp" line="1839"/>
        <location filename="../src/docks/encodedock.cpp" line="2331"/>
        <source>Export File</source>
        <translation>匯出至檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1970"/>
        <source>Reset options to defaults</source>
        <translation>重設選項至預設值</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1973"/>
        <source>Reset</source>
        <translation>重設</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1980"/>
        <source>Advanced</source>
        <translation>進階</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1990"/>
        <source>Always start in Advanced mode</source>
        <translation>永遠以「進階」模式啟動</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="2000"/>
        <location filename="../src/docks/encodedock.cpp" line="2035"/>
        <location filename="../src/docks/encodedock.cpp" line="2042"/>
        <location filename="../src/docks/encodedock.cpp" line="2154"/>
        <source>Stream</source>
        <translation>串流</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="2027"/>
        <location filename="../src/docks/encodedock.cpp" line="1822"/>
        <location filename="../src/docks/encodedock.cpp" line="1923"/>
        <location filename="../src/docks/encodedock.cpp" line="1933"/>
        <source>Stop Capture</source>
        <translation>停止擷取</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="135"/>
        <source>Automatic from extension</source>
        <translation>依副檔名自動偵測</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="143"/>
        <location filename="../src/docks/encodedock.cpp" line="153"/>
        <source>Default for format</source>
        <translation>作為格式預設值</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="465"/>
        <source>Timeline</source>
        <translation>時間軸</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="472"/>
        <location filename="../src/docks/encodedock.cpp" line="478"/>
        <source>Source</source>
        <translation>來源</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="483"/>
        <location filename="../src/docks/encodedock.cpp" line="490"/>
        <source>Marker</source>
        <translation>標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="501"/>
        <source>You must enter numeric values using &apos;%1&apos; as the decimal point.</source>
        <translation>必須以「%1」為小數點輸入數值。</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="510"/>
        <location filename="../src/docks/encodedock.cpp" line="1769"/>
        <location filename="../src/docks/encodedock.cpp" line="1770"/>
        <source>Custom</source>
        <translation>自訂</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="546"/>
        <source>Stock</source>
        <translation>內建</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="549"/>
        <source>Default</source>
        <translation>預設</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1395"/>
        <source>You cannot write to a file that is in your project.
Try again with a different folder or file name.</source>
        <translation>無法寫入到已經存在專案裡的檔案。
請選擇其他資料夾或檔名再試。</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1493"/>
        <source>Shotcut found filters that require analysis jobs that have not run.
Do you want to run the analysis jobs now?</source>
        <translation>Shotcut 發現有需要尚未執行之分析作業的濾鏡。
是否現在執行分析作業？</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1839"/>
        <location filename="../src/docks/encodedock.cpp" line="2333"/>
        <source>Capture File</source>
        <translation>擷取檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1841"/>
        <source>Export Files</source>
        <translation>匯出檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1856"/>
        <source>%1 (*.%2);;All Files (*)</source>
        <translation>%1 (*.%2);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1858"/>
        <source>Determined by Export (*)</source>
        <translation>由「匯出」決定 (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2030"/>
        <location filename="../src/docks/encodedock.cpp" line="2052"/>
        <source>Stop Stream</source>
        <translation>停止串流</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2044"/>
        <source>Enter the network protocol scheme, address, port, and parameters as an URL:</source>
        <translation>以 URL 形式輸入網路通訊協定、位置、連接埠與參數：</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2087"/>
        <source>Add Export Preset</source>
        <translation>新增匯出預設設定</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2131"/>
        <source>Delete Preset</source>
        <translation>刪除預設設定</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2132"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>確定要刪除 %1？</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2260"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2315"/>
        <source>KiB (%1s)</source>
        <translation>KiB (%1s)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2463"/>
        <source>Detect</source>
        <translation>偵測</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2520"/>
        <source>(auto)</source>
        <translation>（自動）</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2566"/>
        <source>Detecting hardware encoders...</source>
        <translation>正在偵測硬體編碼器…</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2623"/>
        <source>Nothing found</source>
        <translation>未找到任何項目</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2625"/>
        <source>Found %1</source>
        <translation>找到 %1</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2848"/>
        <source>Your project is missing some files.

Save your project, close it, and reopen it.
Shotcut will attempt to repair your project.</source>
        <translation>專案有部分檔案遺失。

請儲存專案後將其關閉再重新開啟，
Shotcut 會嘗試修復專案。</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2897"/>
        <source>Aspect ratio does not match project Video Mode, which causes black bars.</source>
        <translation>專案視訊模式與選取的外觀比例不一致，將會產生黑邊。</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2935"/>
        <source>Frame rate is higher than project Video Mode, which causes frames to repeat.</source>
        <translation>專案視訊模式較選取的影格播放速率為低，將會導致影格重複播放。</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2461"/>
        <source>Configure Hardware Encoding</source>
        <translation>設定硬體編碼</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="468"/>
        <source>Current Playlist Bin</source>
        <translation>目前播放清單列表</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="469"/>
        <source>Each Playlist Bin Item</source>
        <translation>播放清單列表中的每個項目</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1842"/>
        <source>Export Each Playlist Bin Item</source>
        <translation>匯出播放清單列表中的每個項目</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1887"/>
        <source>Export canceled</source>
        <translation>匯出已取消</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2485"/>
        <source>Export Frames/sec</source>
        <translation>匯出影格／秒</translation>
    </message>
</context>
<context>
    <name>EncodeJob</name>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="46"/>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="48"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>在 Shotcut 播放器開啟輸出檔案</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="52"/>
        <location filename="../src/jobs/encodejob.cpp" line="53"/>
        <source>Show In Files</source>
        <translation>在「檔案」中顯示</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="57"/>
        <location filename="../src/jobs/encodejob.cpp" line="58"/>
        <source>Show In Folder</source>
        <translation>在資料夾中顯示</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="62"/>
        <source>Measure Video Quality...</source>
        <translation>測量視訊品質…</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="66"/>
        <source>Set Equirectangular...</source>
        <translation>設定等距長方投影…</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="75"/>
        <source>Video Quality Report</source>
        <translation>視訊品質報表</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="76"/>
        <source>Text Documents (*.txt);;All Files (*)</source>
        <translation>文字文件 (*.txt);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="138"/>
        <source>Set Equirectangular Projection</source>
        <translation>設定等距長方投影</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="152"/>
        <source>Successfully wrote %1</source>
        <translation>成功寫入 %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="154"/>
        <source>An error occurred saving the projection.</source>
        <translation>儲存投影時發生錯誤。</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="182"/>
        <source>Export job failed; trying again without Parallel processing.</source>
        <translation>匯出作業失敗；請在沒有「並行處理」的情況下重新嘗試。</translation>
    </message>
</context>
<context>
    <name>FfmpegJob</name>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="43"/>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="48"/>
        <source>Check %1</source>
        <translation>檢查 %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="77"/>
        <source>FFmpeg Log</source>
        <translation>FFmpeg 記錄</translation>
    </message>
</context>
<context>
    <name>FfprobeJob</name>
    <message>
        <location filename="../src/jobs/ffprobejob.cpp" line="52"/>
        <source>More Information</source>
        <translation>更多資訊</translation>
    </message>
</context>
<context>
    <name>FileDateDialog</name>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="46"/>
        <source>%1 File Date</source>
        <translation>%1 檔案日期</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="102"/>
        <source>Current Value</source>
        <translation>目前值</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="106"/>
        <source>Now</source>
        <translation>現在</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="112"/>
        <source>System - Modified</source>
        <translation>系統－修改日期</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="113"/>
        <source>System - Created</source>
        <translation>系統－建立日期</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="123"/>
        <source>Metadata - Creation Time</source>
        <translation>中繼資料－建立時間</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="130"/>
        <source>Metadata - QuickTime date</source>
        <translation>中繼資料－QuickTime 日期</translation>
    </message>
</context>
<context>
    <name>FilesDock</name>
    <message>
        <location filename="../src/docks/filesdock.ui" line="18"/>
        <location filename="../src/docks/filesdock.cpp" line="597"/>
        <source>Files</source>
        <translation>檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="61"/>
        <source>Location</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="90"/>
        <source>Add the current folder to the saved locations</source>
        <translation>將目前的資料夾新增至儲存的位置</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="110"/>
        <source>Remove the selected location</source>
        <translation>移除選取的位置</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="502"/>
        <source>Home</source>
        <comment>The user&apos;s home folder in the file system</comment>
        <translation>主目錄</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="503"/>
        <source>Current Project</source>
        <translation>目前專案</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="504"/>
        <source>Documents</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="509"/>
        <source>Movies</source>
        <comment>The system-provided videos folder called Movies on macOS</comment>
        <translation>影片</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="513"/>
        <source>Music</source>
        <translation>音樂</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="516"/>
        <source>Pictures</source>
        <comment>The system-provided photos folder</comment>
        <translation>圖片</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="520"/>
        <source>Volumes</source>
        <comment>The macOS file system location where external drives and network shares are mounted</comment>
        <translation>卷宗</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="525"/>
        <source>Videos</source>
        <translation>影片</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="607"/>
        <source>Select</source>
        <translation>選取</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="611"/>
        <source>Files Controls</source>
        <translation>「檔案」控制項</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="616"/>
        <source>Files Menu</source>
        <translation>「檔案」功能表</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="642"/>
        <location filename="../src/docks/filesdock.cpp" line="652"/>
        <source>Files Filters</source>
        <translation>「檔案」篩選器</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="675"/>
        <source>Only show files whose name contains some text</source>
        <translation>只顯示檔名含有特定文字的檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="676"/>
        <source>search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="785"/>
        <source>Tiles</source>
        <translation>並排</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="786"/>
        <source>View as tiles</source>
        <translation>並排檢視</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="798"/>
        <source>Icons</source>
        <translation>圖示</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="799"/>
        <source>View as icons</source>
        <translation>圖示檢視</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="811"/>
        <source>Details</source>
        <translation>詳細資料</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="812"/>
        <source>View as details</source>
        <translation>詳細資料檢視</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="824"/>
        <source>Open In Shotcut</source>
        <translation>於 Shotcut 開啟</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="825"/>
        <source>Open the clip in the Source player</source>
        <translation>在「來源」播放器開啟短片</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="833"/>
        <source>System Default</source>
        <translation>系統預設</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="847"/>
        <source>Other...</source>
        <translation>其他…</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="855"/>
        <source>Remove...</source>
        <translation>移除…</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="863"/>
        <source>Show In File Manager</source>
        <translation>在檔案總管中顯示</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="873"/>
        <source>Update Thumbnails</source>
        <translation>更新縮圖</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="881"/>
        <source>Select All</source>
        <translation>全選</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="892"/>
        <source>Select None</source>
        <translation>取消選取</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="903"/>
        <source>Open Previous</source>
        <translation>開啟前一項</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="915"/>
        <source>Open Next</source>
        <translation>開啟後一項</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="927"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="928"/>
        <source>Show or hide video files</source>
        <translation>顯示或隱藏視訊檔</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="933"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="934"/>
        <source>Show or hide audio files</source>
        <translation>顯示或隱藏音訊檔</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="939"/>
        <source>Image</source>
        <translation>影像</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="940"/>
        <source>Show or hide image files</source>
        <translation>顯示或隱藏影像檔</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="945"/>
        <source>Other</source>
        <translation>其他</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="946"/>
        <source>Show or hide other kinds of files</source>
        <translation>顯示或隱藏其他檔案格式</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="951"/>
        <source>Folders</source>
        <translation>資料夾</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="952"/>
        <source>Hide or show the list of folders</source>
        <translation>顯示或隱藏資料夾清單</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="963"/>
        <source>Go Up</source>
        <translation>回到上一層</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="964"/>
        <source>Show the parent folder</source>
        <translation>顯示上層資料夾</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="982"/>
        <source>Refresh Folders</source>
        <translation>重新整理資料夾</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1003"/>
        <source>Search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1027"/>
        <source>Open With</source>
        <translation>開啟檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1279"/>
        <source>Executable Files (*.exe);;All Files (*)</source>
        <translation>可執行檔 (*.exe);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1284"/>
        <source>Choose Executable</source>
        <translation>選擇可執行檔</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1308"/>
        <source>Remove From Open With</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/filesdock.cpp" line="1329"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n 個項目</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1371"/>
        <source>Add Location</source>
        <translation>新增位置</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1372"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1390"/>
        <source>Delete Location</source>
        <translation>刪除位置</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1391"/>
        <source>Are you sure you want to remove %1?</source>
        <translation>確定要移除 %1？</translation>
    </message>
</context>
<context>
    <name>FilesModel</name>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="238"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="239"/>
        <source>Image</source>
        <translation>影像</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="240"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="241"/>
        <source>Other</source>
        <translation>其他</translation>
    </message>
</context>
<context>
    <name>FilesTileDelegate</name>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="412"/>
        <source>Date: %1</source>
        <translation>日期：%1</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="421"/>
        <source>Size: %1</source>
        <translation>大小：%1</translation>
    </message>
</context>
<context>
    <name>FilterController</name>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="119"/>
        <source>(DEPRECATED)</source>
        <translation>（已過時）</translation>
    </message>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="342"/>
        <source>Only one %1 filter is allowed.</source>
        <translation>只允許一個「%1」濾鏡。</translation>
    </message>
</context>
<context>
    <name>FilterMenu</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="77"/>
        <source>search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="121"/>
        <source>Clear search</source>
        <translation>清除搜尋</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="177"/>
        <source>Show favorite filters</source>
        <translation>顯示收藏濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="200"/>
        <source>Show GPU video filters</source>
        <translation>顯示 GPU 視訊濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="221"/>
        <source>Show video filters</source>
        <translation>顯示視訊濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="242"/>
        <source>Show audio filters</source>
        <translation>顯示音訊濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="253"/>
        <source>Time</source>
        <translation>時間</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="264"/>
        <source>Show time filters</source>
        <translation>顯示時間濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="274"/>
        <source>Sets</source>
        <translation>集合</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="285"/>
        <source>Show filter sets</source>
        <translation>顯示濾鏡集</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="140"/>
        <source>Close menu</source>
        <translation>關閉功能表</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="371"/>
        <source>Delete a custom filter set by right-clicking it.</source>
        <translation>按一下右鍵以刪除自訂濾鏡集。</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="165"/>
        <source>Favorite</source>
        <translation>收藏</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="210"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="231"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
</context>
<context>
    <name>FilterMenuDelegate</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="112"/>
        <source>Delete Filter Set</source>
        <translation>刪除濾鏡集</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="124"/>
        <source>Are you sure you want to delete this?
%1</source>
        <translation>確定要刪除此項目？
%1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="139"/>
        <source>OK</source>
        <translation>確定</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="149"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>FiltersDock</name>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="49"/>
        <source>Filters</source>
        <translation>濾鏡</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="214"/>
        <source>Add</source>
        <translation>新增</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="216"/>
        <source>Choose a filter to add</source>
        <translation>選擇要新增的濾鏡</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="228"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="230"/>
        <source>Remove selected filter</source>
        <translation>移除選取的濾鏡</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="237"/>
        <source>Copy Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="238"/>
        <source>Copy checked filters to the clipboard</source>
        <translation>複製核取的濾鏡至剪貼簿</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="245"/>
        <source>Copy Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="246"/>
        <source>Copy current filter to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="253"/>
        <source>Copy All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="254"/>
        <source>Copy all filters to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="261"/>
        <source>Paste Filters</source>
        <translation>貼上濾鏡</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="262"/>
        <source>Paste the filters from the clipboard</source>
        <translation>由剪貼簿貼上濾鏡</translation>
    </message>
</context>
<context>
    <name>FrameRateWidget</name>
    <message>
        <location filename="../src/widgets/frameratewidget.cpp" line="74"/>
        <source>Convert Frames/sec</source>
        <translation>轉換影格／秒</translation>
    </message>
</context>
<context>
    <name>GlaxnimateIpcServer</name>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="642"/>
        <source>Preparing Glaxnimate preview....</source>
        <translation>正在準備 Glaxnimate 預覽…</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="695"/>
        <source>The Glaxnimate program was not found.

Click OK to open a file dialog to choose its location.
Click Cancel if you do not have Glaxnimate.</source>
        <translation>找不到 Glaxnimate 應用程式。

按一下「確認」以開啟檔案對話方塊並選擇其安裝的位置。
若未安裝 Glaxnimate，請按一下「取消」。</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="705"/>
        <source>Find Glaxnimate</source>
        <translation>尋找 Glaxnimate</translation>
    </message>
</context>
<context>
    <name>GlaxnimateProducerWidget</name>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="20"/>
        <source>Animation</source>
        <translation>動畫</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="30"/>
        <source>Comments:</source>
        <translation>註解：</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="61"/>
        <source>Background color...</source>
        <translation>背景色彩…</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="76"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="103"/>
        <source>Edit...</source>
        <translation>編輯…</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="110"/>
        <source>Reload</source>
        <translation>重新載入</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="132"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="71"/>
        <source>black</source>
        <translation>黑色</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="73"/>
        <source>transparent</source>
        <translation>透明</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="204"/>
        <source>animation</source>
        <translation>動畫</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="205"/>
        <source>Glaxnimate (*.rawr);;All Files (*)</source>
        <translation>Glaxnimate (*.rawr);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="207"/>
        <source>New Animation</source>
        <translation>新增動畫</translation>
    </message>
</context>
<context>
    <name>GoPro2GpxJob</name>
    <message>
        <location filename="../src/jobs/gopro2gpxjob.cpp" line="34"/>
        <source>Export GPX</source>
        <translation>匯出 GPX</translation>
    </message>
</context>
<context>
    <name>GradientControl</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="122"/>
        <source>Color #%1</source>
        <translation>色彩 #%1</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="128"/>
        <source>Color: %1
Click to change</source>
        <translation>色彩：%1
按一下以修改</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="178"/>
        <source>colors</source>
        <comment>gradient control</comment>
        <translation> 種色彩</translation>
    </message>
</context>
<context>
    <name>ImageProducerWidget</name>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="27"/>
        <source>Comments:</source>
        <translation>註解：</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="61"/>
        <source>Resolution</source>
        <translation>解析度</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="70"/>
        <source>x</source>
        <translation>×</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="82"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="134"/>
        <source>Pixel aspect ratio</source>
        <translation>像素外觀比例</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="165"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="193"/>
        <source>Image sequence</source>
        <translation>影像序列</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="200"/>
        <source>Repeat</source>
        <translation>重複</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="218"/>
        <source> frames</source>
        <translation> 影格</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="234"/>
        <source>per picture</source>
        <translation>每張圖片</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="261"/>
        <source>Properties Menu</source>
        <translation>「屬性」功能表</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="303"/>
        <source>Copy Full File Path</source>
        <translation>複製完整檔案路徑</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="308"/>
        <source>Show In Folder</source>
        <translation>在資料夾中顯示</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="341"/>
        <source>Show In Files</source>
        <translation>在「檔案」中顯示</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="313"/>
        <source>Set Creation Time...</source>
        <translation>設定建立時間…</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="321"/>
        <source>Disable Proxy</source>
        <translation>停用代理素材</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="326"/>
        <source>Make Proxy</source>
        <translation>製作代理素材</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="331"/>
        <source>Delete Proxy</source>
        <translation>刪除代理素材</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="336"/>
        <source>Copy Hash Code</source>
        <translation>複製雜湊碼</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="122"/>
        <source>Make the current duration value the default value</source>
        <translation>將目前長度數值設成預設值</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="125"/>
        <source>Set Default</source>
        <translation>設為預設</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="247"/>
        <source>Reset</source>
        <translation>重設</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="99"/>
        <source>(PROXY)</source>
        <translation>（代理）</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="288"/>
        <source>Getting length of image sequence...</source>
        <translation>正在取得影像序列長度…</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="311"/>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="333"/>
        <source>Reloading image sequence...</source>
        <translation>正在重新載入影像序列…</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="466"/>
        <source>The hash code below is already copied to your clipboard:

</source>
        <translation>已經將下列雜湊碼複製到了剪貼簿：

</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="254"/>
        <source>Proxy</source>
        <translation>代理素材</translation>
    </message>
</context>
<context>
    <name>IsingWidget</name>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="26"/>
        <source>Ising Model</source>
        <translation>易辛 (Ising) 模型</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="41"/>
        <source>Noise Temperature</source>
        <translation>雜訊溫度</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="106"/>
        <source>Border Growth</source>
        <translation>邊際成長</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="174"/>
        <source>Spontaneous Growth</source>
        <translation>自發成長</translation>
    </message>
</context>
<context>
    <name>JobQueue</name>
    <message>
        <location filename="../src/jobqueue.cpp" line="59"/>
        <source>pending</source>
        <translation>等待中</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="63"/>
        <source>Estimated Hours:Minutes:Seconds</source>
        <translation>估計所需時:分:秒</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="92"/>
        <source>paused</source>
        <translation>已暫停</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="120"/>
        <source>Elapsed Hours:Minutes:Seconds</source>
        <translation>已經耗用時:分:秒</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="123"/>
        <source>stopped</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="126"/>
        <source>failed</source>
        <translation>失敗</translation>
    </message>
</context>
<context>
    <name>JobsDock</name>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="18"/>
        <source>Jobs</source>
        <translation>工作</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="115"/>
        <source>Stop automatically processing the next pending job in
the list. This does not stop a currently running job. Right-
-click a job to open a menu to stop a currently running job.</source>
        <translation>停止自動處理清單中下一個等候中的工作。
並不會停止目前正在執行的工作。
在工作上按一下右鍵，便可以開啟功能表以停止目前正在執行的工作。</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="130"/>
        <source>Remove all of the completed and failed jobs from the list</source>
        <translation>移除清單中所有完成或失敗的工作</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="133"/>
        <source>Clean</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="104"/>
        <source>Jobs Menu</source>
        <translation>「工作」功能表</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="120"/>
        <source>Pause Queue</source>
        <translation>暫停佇列</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="156"/>
        <source>Stop This Job</source>
        <translation>停止這個工作</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="159"/>
        <source>Stop the currently selected job</source>
        <translation>停止選取的工作</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="164"/>
        <source>View Log</source>
        <translation>檢視記錄</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="167"/>
        <source>View the messages of MLT and FFmpeg </source>
        <translation>檢視 MTL 與 FFmpeg 的訊息</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="172"/>
        <source>Run</source>
        <translation>執行</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="175"/>
        <source>Restart a stopped job</source>
        <translation>重新啟動停止的工作</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="180"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="185"/>
        <location filename="../src/docks/jobsdock.ui" line="188"/>
        <source>Remove Finished</source>
        <translation>移除已完成的項目</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.cpp" line="153"/>
        <source>Job Log</source>
        <translation>作業紀錄</translation>
    </message>
</context>
<context>
    <name>KeyframeClip</name>
    <message>
        <location filename="../src/qml/views/keyframes/KeyframeClip.qml" line="245"/>
        <source>Confirm Removing Advanced Keyframes</source>
        <translation>確認移除進階關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/KeyframeClip.qml" line="246"/>
        <source>This will remove all advanced keyframes to enable simple keyframes.&lt;p&gt;Do you still want to do this?</source>
        <translation>將移除所有進階關鍵影格以啟用簡易關鍵影格。&lt;p&gt;確定要繼續嗎？</translation>
    </message>
</context>
<context>
    <name>KeyframesButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="58"/>
        <source>Use Keyframes for this parameter</source>
        <translation>在此參數使用關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="45"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>按住 %1 以限制在垂直方向拖曳關鍵影格，或 %2 以限制在水平方向</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="64"/>
        <source>Confirm Removing Keyframes</source>
        <translation>確認移除關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="65"/>
        <source>This will remove all keyframes for this parameter.&lt;p&gt;Do you still want to do this?</source>
        <translation>將移除此參數的所有關鍵影格。&lt;p&gt;確定要繼續嗎？</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="80"/>
        <source>Confirm Removing Simple Keyframes</source>
        <translation>確認移除簡易關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="81"/>
        <source>This will remove all simple keyframes for all parameters.&lt;p&gt;Simple keyframes will be converted to advanced keyframes.&lt;p&gt;Do you still want to do this?</source>
        <translation>將移除所有參數的簡易關鍵影格。&lt;p&gt;簡易關鍵影格將轉換為進階關鍵影格。&lt;p&gt;確定要繼續嗎？</translation>
    </message>
</context>
<context>
    <name>KeyframesDock</name>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="48"/>
        <location filename="../src/docks/keyframesdock.cpp" line="62"/>
        <source>Keyframes</source>
        <translation>關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="71"/>
        <source>View</source>
        <translation>檢視</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="78"/>
        <source>Keyframe</source>
        <translation>關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="79"/>
        <source>From Previous</source>
        <translation>由前一項</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="84"/>
        <source>Ease Out</source>
        <translation>漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="101"/>
        <source>To Next</source>
        <translation>至後一項</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="106"/>
        <source>Ease In</source>
        <translation>漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="121"/>
        <source>Ease In/Out</source>
        <translation>漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="141"/>
        <source>Keyframes Clip</source>
        <translation>關鍵影格短片</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="149"/>
        <source>Keyframes Controls</source>
        <translation>「關鍵影格」控制項</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="153"/>
        <source>Keyframes Menu</source>
        <translation>「關鍵影格」功能表</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="223"/>
        <source>Set Filter Start</source>
        <translation>設定濾鏡起點</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="242"/>
        <source>Set Filter End</source>
        <translation>設定濾鏡終點</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="261"/>
        <source>Set First Simple Keyframe</source>
        <translation>設定第一簡易關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="280"/>
        <source>Set Second Simple Keyframe</source>
        <translation>設定第二簡易關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="299"/>
        <source>Scrub While Dragging</source>
        <translation>拖曳時刮盤播放</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="312"/>
        <source>Zoom Keyframes Out</source>
        <translation>拉遠關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="323"/>
        <source>Zoom Keyframes In</source>
        <translation>拉近關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="334"/>
        <source>Zoom Keyframes To Fit</source>
        <translation>縮放關鍵影格至適當比例</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="350"/>
        <location filename="../src/docks/keyframesdock.cpp" line="596"/>
        <source>Hold</source>
        <translation>保持不變</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="367"/>
        <location filename="../src/docks/keyframesdock.cpp" line="613"/>
        <source>Linear</source>
        <translation>線性</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="384"/>
        <location filename="../src/docks/keyframesdock.cpp" line="630"/>
        <source>Smooth</source>
        <translation>平滑</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="406"/>
        <source>Ease Out Sinusoidal</source>
        <translation>正弦漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="423"/>
        <source>Ease Out Quadratic</source>
        <translation>平方漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="440"/>
        <source>Ease Out Cubic</source>
        <translation>立方漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="457"/>
        <source>Ease Out Quartic</source>
        <translation>四次方漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="474"/>
        <source>Ease Out Quintic</source>
        <translation>五次方漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="491"/>
        <source>Ease Out Exponential</source>
        <translation>指數漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="508"/>
        <source>Ease Out Circular</source>
        <translation>圓弧漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="525"/>
        <source>Ease Out Back</source>
        <translation>回彈漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="550"/>
        <source>Ease Out Elastic</source>
        <translation>彈性漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="575"/>
        <source>Ease Out Bounce</source>
        <translation>彈跳漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="652"/>
        <source>Ease In Sinusoidal</source>
        <translation>正弦漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="668"/>
        <source>Ease In Quadratic</source>
        <translation>平方漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="684"/>
        <source>Ease In Cubic</source>
        <translation>立方漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="700"/>
        <source>Ease In Quartic</source>
        <translation>四次方漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="716"/>
        <source>Ease In Quintic</source>
        <translation>五次方漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="732"/>
        <source>Ease In Exponential</source>
        <translation>指數漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="748"/>
        <source>Ease In Circular</source>
        <translation>圓弧漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="764"/>
        <source>Ease In Back</source>
        <translation>回彈漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="788"/>
        <source>Ease In Elastic</source>
        <translation>彈性漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="812"/>
        <source>Ease In Bounce</source>
        <translation>彈跳漸入</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="828"/>
        <source>Ease In/Out Sinusoidal</source>
        <translation>正弦漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="845"/>
        <source>Ease In/Out Quadratic</source>
        <translation>平方漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="862"/>
        <source>Ease In/Out Cubic</source>
        <translation>立方漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="879"/>
        <source>Ease In/Out Quartic</source>
        <translation>四次方漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="896"/>
        <source>Ease In/Out Quintic</source>
        <translation>五次方漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="913"/>
        <source>Ease In/Out Exponential</source>
        <translation>指數漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="930"/>
        <source>Ease In/Out Circular</source>
        <translation>圓弧漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="947"/>
        <source>Ease In/Out Back</source>
        <translation>回彈漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="972"/>
        <source>Ease In/Out Elastic</source>
        <translation>彈性漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="997"/>
        <source>Ease In/Out Bounce</source>
        <translation>彈跳漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1014"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1025"/>
        <source>Rebuild Audio Waveform</source>
        <translation>重建音訊波形</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1037"/>
        <source>Seek Previous Keyframe</source>
        <translation>移至前一關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1053"/>
        <source>Seek Next Keyframe</source>
        <translation>移至後一關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1069"/>
        <source>Toggle Keyframe At Playhead</source>
        <translation>於播放點切換關鍵影格</translation>
    </message>
</context>
<context>
    <name>KeyframesModel</name>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="74"/>
        <source>Hold</source>
        <translation>延持</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="71"/>
        <source>Linear</source>
        <translation>線性</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="80"/>
        <location filename="../src/models/keyframesmodel.cpp" line="174"/>
        <source>Smooth</source>
        <translation>平滑</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="83"/>
        <source>Ease In Sinusoidal</source>
        <translation>正弦漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="86"/>
        <source>Ease Out Sinusoidal</source>
        <translation>正弦漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="89"/>
        <source>Ease In/Out Sinusoidal</source>
        <translation>正弦漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="92"/>
        <source>Ease In Quadratic</source>
        <translation>平方漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="95"/>
        <source>Ease Out Quadratic</source>
        <translation>平方漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="98"/>
        <source>Ease In/Out Quadratic</source>
        <translation>平方漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="101"/>
        <source>Ease In Cubic</source>
        <translation>立方漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="104"/>
        <source>Ease Out Cubic</source>
        <translation>立方漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="107"/>
        <source>Ease In/Out Cubic</source>
        <translation>立方漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="110"/>
        <source>Ease In Quartic</source>
        <translation>四次方漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="113"/>
        <source>Ease Out Quartic</source>
        <translation>四次方漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="116"/>
        <source>Ease In/Out Quartic</source>
        <translation>四次方漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="119"/>
        <source>Ease In Quintic</source>
        <translation>五次方漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="122"/>
        <source>Ease Out Quintic</source>
        <translation>五次方漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="125"/>
        <source>Ease In/Out Quintic</source>
        <translation>五次方漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="128"/>
        <source>Ease In Exponential</source>
        <translation>指數漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="131"/>
        <source>Ease Out Exponential</source>
        <translation>指數漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="134"/>
        <source>Ease In/Out Exponential</source>
        <translation>指數漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="137"/>
        <source>Ease In Circular</source>
        <translation>圓弧漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="140"/>
        <source>Ease Out Circular</source>
        <translation>圓弧漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="143"/>
        <source>Ease In/Out Circular</source>
        <translation>圓弧漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="146"/>
        <source>Ease In Back</source>
        <translation>回彈漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="149"/>
        <source>Ease Out Back</source>
        <translation>回彈漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="152"/>
        <source>Ease In/Out Back</source>
        <translation>回彈漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="155"/>
        <source>Ease In Elastic</source>
        <translation>彈性漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="158"/>
        <source>Ease Out Elastic</source>
        <translation>彈性漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="161"/>
        <source>Ease In/Out Elastic</source>
        <translation>彈性漸入／漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="164"/>
        <source>Ease In Bounce</source>
        <translation>彈跳漸入</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="167"/>
        <source>Ease Out Bounce</source>
        <translation>彈跳漸出</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="170"/>
        <source>Ease In/Out Bounce</source>
        <translation>彈跳漸入／漸出</translation>
    </message>
</context>
<context>
    <name>LissajousWidget</name>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="26"/>
        <source>Lissajous</source>
        <translation>利薩如 (Lissajous) 圖形</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="41"/>
        <source>X Ratio</source>
        <translation>X 比率</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="106"/>
        <source>Y Ratio</source>
        <translation>Y 比率</translation>
    </message>
</context>
<context>
    <name>ListSelectionDialog</name>
    <message>
        <location filename="../src/dialogs/listselectiondialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>對話方塊</translation>
    </message>
</context>
<context>
    <name>LumaMixTransition</name>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="25"/>
        <source>Transition</source>
        <translation>轉場效果</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="351"/>
        <source>Preview</source>
        <translation>預覽</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="360"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="92"/>
        <source>Dissolve</source>
        <translation>溶解</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="97"/>
        <source>Cut</source>
        <translation>剪裁</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="107"/>
        <source>Bar Horizontal</source>
        <translation>水平抹除</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="112"/>
        <source>Bar Vertical</source>
        <translation>垂直抹除</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="117"/>
        <source>Barn Door Horizontal</source>
        <translation>水平對開</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="122"/>
        <source>Barn Door Vertical</source>
        <translation>垂直對開</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="127"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>斜角對開－左下至右上</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="132"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>斜角對開－左上至右下</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="137"/>
        <source>Diagonal Top Left</source>
        <translation>對角左上</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="142"/>
        <source>Diagonal Top Right</source>
        <translation>對角右上</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="147"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>水平矩陣</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="152"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>垂直矩陣</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="157"/>
        <source>Matrix Snake Horizontal</source>
        <translation>水平矩陣－蛇形</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="162"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>水平矩陣－蛇形對消</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="167"/>
        <source>Matrix Snake Vertical</source>
        <translation>垂直矩陣－蛇形</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="172"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>垂直矩陣－蛇形對消</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="177"/>
        <source>Barn V Up</source>
        <translation>V 字對開</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="182"/>
        <source>Iris Circle</source>
        <translation>虹膜</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="187"/>
        <source>Double Iris</source>
        <translation>雙瞳</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="192"/>
        <source>Iris Box</source>
        <translation>矩形</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="197"/>
        <source>Box Bottom Right</source>
        <translation>消去－右下</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="202"/>
        <source>Box Bottom Left</source>
        <translation>消去－左下</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="207"/>
        <source>Box Right Center</source>
        <translation>消去－右中</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="212"/>
        <source>Clock Top</source>
        <translation>順時針</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="370"/>
        <source>Get custom transitions on our Web site.</source>
        <translation>從網站上取得自訂轉場效果。</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="102"/>
        <source>Custom...</source>
        <translation>自訂…</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="243"/>
        <source>TextLabel</source>
        <translation>文字標籤</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="341"/>
        <source>Swap the appearance of the A and B clips</source>
        <translation>對換前後短片的外觀</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="344"/>
        <source>Invert Wipe</source>
        <translation>反轉擦除方向</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="39"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="234"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="240"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="261"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="265"/>
        <source>Softness</source>
        <translation>柔邊</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="52"/>
        <source>Change the softness of the edge of the wipe</source>
        <translation>調整擦除畫面時的柔邊程度</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="68"/>
        <location filename="../src/widgets/lumamixtransition.ui" line="311"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="222"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="232"/>
        <source>Save the custom transition as a favorite</source>
        <translation>將自訂轉場效果儲存至收藏</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="252"/>
        <source>Automatically fade-out the audio of clip A
and fade-in the audio of clip B over the
duration of the transition.</source>
        <translation>在轉場效果持續期間自動淡出前短片的音訊，
並淡入後短片的音訊。</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="257"/>
        <source>Cross-fade</source>
        <translation>交互淡化</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="271"/>
        <source>Do not alter the audio levels during the
course of the transition. Instead, set a
fixed mixing level, or choose only clip A&apos;s
audio (0%) or clip B&apos;s audio (100%).</source>
        <translation>在轉場效果期間不調整音量，而是設定固定
的混音音量，或只單獨使用前短片 (0%) 或
後短片 (100%) 的音訊。</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="277"/>
        <source>Mix:</source>
        <translation>混合：</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="287"/>
        <source>A</source>
        <translation>前</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="304"/>
        <source>B</source>
        <translation>後</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="64"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="237"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="106"/>
        <source>Preview Not Available</source>
        <translation>無法預覽</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="247"/>
        <source>Open File</source>
        <translation>開啟檔案</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Shotcut</source>
        <translation>Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>&amp;File</source>
        <translation>檔案(&amp;F)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>&amp;View</source>
        <translation>檢視(&amp;V)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Layout</source>
        <translation>版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>&amp;Edit</source>
        <translation>編輯(&amp;E)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>&amp;Help</source>
        <translation>說明(&amp;H)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="145"/>
        <source>Audio Channels</source>
        <translation>音訊聲道</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="246"/>
        <source>Deinterlacer</source>
        <translation>反交錯處理</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="256"/>
        <source>Interpolation</source>
        <translation>內插補點</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="154"/>
        <source>Video Mode</source>
        <translation>視訊模式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="265"/>
        <source>External Monitor</source>
        <translation>外部顯示器</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="160"/>
        <source>Language</source>
        <translation>語言</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="165"/>
        <source>Theme</source>
        <translation>佈景主題</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="173"/>
        <source>Display Method</source>
        <translation>顯示方式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="199"/>
        <source>App Data Directory</source>
        <translation>應用程式資料目錄</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="206"/>
        <source>Preview Scaling</source>
        <translation>預覽縮放</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="224"/>
        <source>Proxy</source>
        <translation>代理素材</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Storage</source>
        <translation>儲存空間</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Toolbar</source>
        <translation>工具列</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="378"/>
        <source>&amp;Open File...</source>
        <translation>開啟檔案(&amp;O)…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>E&amp;xit</source>
        <translation>結束(&amp;X)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="395"/>
        <source>Quit the application</source>
        <translation>結束應用程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <source>&amp;About Shotcut</source>
        <translation>關於 Shotcut (&amp;A)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>About Qt</source>
        <translation>關於 Qt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="419"/>
        <source>Open Other...</source>
        <translation>開啟其他…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="422"/>
        <source>Open a device, stream or generator</source>
        <translation>開啟裝置、串流或產生器</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="437"/>
        <source>&amp;Save</source>
        <translation>儲存(&amp;S)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <source>Save project as a MLT XML file</source>
        <translation>將專案儲存為 MLT XML 檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>Save &amp;As...</source>
        <translation>另存新檔(&amp;A)…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="454"/>
        <source>Save project to a different MLT XML file</source>
        <translation>將專案儲存至不同的 MLT XML 檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="51"/>
        <location filename="../src/mainwindow.ui" line="466"/>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Export</source>
        <translation>匯出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Job Priority</source>
        <translation>工作優先程度</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="478"/>
        <source>&amp;Undo</source>
        <translation>復原(&amp;U)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="487"/>
        <source>&amp;Redo</source>
        <translation>重做(&amp;R)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="492"/>
        <source>Forum...</source>
        <translation>論壇…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="497"/>
        <source>FAQ...</source>
        <translation>常見問題集…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="506"/>
        <location filename="../src/mainwindow.cpp" line="3922"/>
        <source>Enter Full Screen</source>
        <translation>進入全螢幕模式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="518"/>
        <source>Peak Meter</source>
        <translation>峰值計</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="530"/>
        <location filename="../src/mainwindow.cpp" line="401"/>
        <location filename="../src/mainwindow.cpp" line="2408"/>
        <source>Properties</source>
        <translation>屬性</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <location filename="../src/mainwindow.cpp" line="2417"/>
        <source>Recent</source>
        <translation>最近使用</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <location filename="../src/mainwindow.ui" line="548"/>
        <source>Playlist</source>
        <translation>播放清單</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <source>History</source>
        <translation>歷程記錄</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="568"/>
        <source>Realtime (frame dropping)</source>
        <translation>即時（漏格）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="579"/>
        <source>Progressive</source>
        <translation>漸進式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="587"/>
        <source>GPU Effects (unstable)</source>
        <translation>GPU 效果（不穩定）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="590"/>
        <source>Use GPU filters</source>
        <translation>使用 GPU 濾鏡</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="601"/>
        <source>1 (mono)</source>
        <translation>1（單聲道）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="609"/>
        <source>2 (stereo)</source>
        <translation>2（立體聲）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="636"/>
        <source>One Field (fast)</source>
        <translation>單一圖場（快）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="644"/>
        <source>Linear Blend (fast)</source>
        <translation>線性混合（快）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="652"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF－僅時域（良好）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>最接近像素（快）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="687"/>
        <source>Bilinear (good)</source>
        <translation>雙線性（良好）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="695"/>
        <source>Bicubic (better)</source>
        <translation>雙立方（較佳）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="714"/>
        <location filename="../src/mainwindow.ui" line="847"/>
        <location filename="../src/mainwindow.cpp" line="2613"/>
        <source>Automatic</source>
        <translation>自動</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="725"/>
        <location filename="../src/mainwindow.ui" line="1191"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="733"/>
        <source>Use JACK Audio</source>
        <translation>使用 JACK 音訊</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="742"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <source>Filters</source>
        <translation>濾鏡</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <source>Add...</source>
        <translation>新增…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="758"/>
        <source>System</source>
        <translation>系統</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="761"/>
        <source>Use the user or platform style, colors, and icons.</source>
        <translation>使用使用者指定或作業系統預設的樣式、色彩與圖示。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="769"/>
        <source>Fusion Dark</source>
        <translation>Fusion 深色</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="777"/>
        <source>Fusion Light</source>
        <translation>Fusion 淺色</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="782"/>
        <source>Tutorials...</source>
        <translation>教學課程…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <location filename="../src/mainwindow.ui" line="791"/>
        <location filename="../src/mainwindow.cpp" line="2427"/>
        <source>Timeline</source>
        <translation>時間軸</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="796"/>
        <location filename="../src/mainwindow.ui" line="799"/>
        <source>Restore Default Layout</source>
        <translation>還原預設版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="807"/>
        <source>Show Title Bars</source>
        <translation>顯示標題列</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="815"/>
        <source>Show Toolbar</source>
        <translation>顯示工具列</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="820"/>
        <source>Upgrade...</source>
        <translation>升級…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="825"/>
        <source>Open MLT XML As Clip...</source>
        <translation>開啟 MLT XML 作為短片…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="828"/>
        <source>Open a MLT XML project file as a virtual clip</source>
        <translation>開啟 MLT XML 專案檔作為虛擬短片</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="836"/>
        <source>Scrub Audio</source>
        <translation>刮盤播放音訊</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="871"/>
        <source>Software (Mesa)</source>
        <extracomment>Do not translate &quot;Mesa&quot;</extracomment>
        <translation>軟體 (Mesa)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>Low</source>
        <translation>低</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="887"/>
        <source>Normal</source>
        <translation>標準</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="897"/>
        <source>Application Log...</source>
        <translation>應用程式記錄檔…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="905"/>
        <location filename="../src/mainwindow.ui" line="996"/>
        <location filename="../src/mainwindow.ui" line="999"/>
        <source>Project</source>
        <translation>專案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="1329"/>
        <source>Player</source>
        <translation>播放器</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="913"/>
        <source>User Interface</source>
        <translation>使用者介面</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="921"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1144"/>
        <source>Notes</source>
        <translation>筆記</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1358"/>
        <source>Markers as Chapters...</source>
        <translation>標記點轉為章節…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1361"/>
        <location filename="../src/mainwindow.ui" line="1364"/>
        <location filename="../src/mainwindow.cpp" line="5861"/>
        <source>Export Chapters</source>
        <translation>匯出章節</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1369"/>
        <source>Audio/Video Device...</source>
        <translation>音訊／視訊裝置…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="971"/>
        <location filename="../src/mainwindow.ui" line="1269"/>
        <source>Set...</source>
        <translation>設定…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Other Versions</source>
        <translation>其他版本</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>&amp;Player</source>
        <translation>播放器(&amp;P)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="141"/>
        <source>&amp;Settings</source>
        <translation>設定(&amp;S)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Time Format</source>
        <translation>時間格式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Backup</source>
        <translation>備份</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="381"/>
        <source>Open a video, audio, image, or project file</source>
        <translation>開啟視訊、音訊、影像或專案檔</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="521"/>
        <source>Audio Peak Meter</source>
        <translation>音訊峰值計</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="617"/>
        <source>4 (quad/Ambisonics)</source>
        <translation>4（Quad/Ambisonics）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="625"/>
        <source>6 (5.1 surround)</source>
        <translation>6（5.1 環繞音效）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="660"/>
        <source>YADIF - temporal + spatial (better)</source>
        <translation>YADIF－時域＋空間（較佳）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="668"/>
        <source>BWDIF (best)</source>
        <translation>BWDIF（最佳）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Lanczos (best)</source>
        <translation>Lanczos（最佳）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="892"/>
        <source>Resources...</source>
        <translation>資源…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="976"/>
        <location filename="../src/mainwindow.ui" line="1277"/>
        <source>Show...</source>
        <translation>顯示…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="979"/>
        <source>Show</source>
        <translation>顯示</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="988"/>
        <location filename="../src/mainwindow.ui" line="991"/>
        <source>Keyframes</source>
        <translation>關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>New</source>
        <translation>新增</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1002"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1018"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1021"/>
        <source>Switch to the audio layout</source>
        <translation>切換至音訊版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1024"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1032"/>
        <source>Logging</source>
        <translation>記錄</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1035"/>
        <source>Switch to the logging layout</source>
        <translation>切換至記錄版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1038"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1046"/>
        <source>Editing</source>
        <translation>剪輯</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1049"/>
        <source>Switch to the editing layout</source>
        <translation>切換至剪輯版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1052"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1060"/>
        <source>FX</source>
        <translation>特效</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <source>Switch to the effects layout</source>
        <translation>切換至效果版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1066"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <source>New Generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1135"/>
        <source>Markers</source>
        <translation>標記點</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1153"/>
        <source>Subtitles</source>
        <translation>字幕</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1183"/>
        <source>1080p</source>
        <translation type="unfinished">1080p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Timecode (Drop-Frame)</source>
        <translation>時間碼（漏格）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1221"/>
        <source>Frames</source>
        <translation>影格數</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1229"/>
        <source>Clock</source>
        <translation>時鐘</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1237"/>
        <source>Timecode (Non-Drop Frame)</source>
        <translation>時間碼（非漏格）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1242"/>
        <source>Topics</source>
        <translation>說明主題</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1250"/>
        <source>Synchronization...</source>
        <translation>同步…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1253"/>
        <source>Synchronization</source>
        <translation>同步</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Use Proxy</source>
        <translation>使用代理素材</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1272"/>
        <source>Set the proxy storage folder</source>
        <translation>設定存放代理素材的資料夾</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1280"/>
        <source>Show the proxy storage folder</source>
        <translation>顯示存放代理素材的資料夾</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1291"/>
        <source>Use Project Folder</source>
        <translation>使用專案資料夾</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1294"/>
        <source>Store proxies in the project folder if defined</source>
        <translation>若有設定，則將代理素材存放在專案資料夾中</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1302"/>
        <source>Use Hardware Encoder</source>
        <translation>使用硬體編碼器</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1307"/>
        <source>Configure Hardware Encoder...</source>
        <translation>設定硬體編碼器…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1318"/>
        <source>Switch to the color layout</source>
        <translation>切換至色彩版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1321"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1332"/>
        <source>Switch to the player only layout</source>
        <translation>切換至僅播放器版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1335"/>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1348"/>
        <source>Playlist Project</source>
        <translation>播放清單專案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1353"/>
        <source>Clip-only Project</source>
        <translation>僅含短片的專案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1374"/>
        <source>Reset...</source>
        <translation>重設…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1379"/>
        <location filename="../src/mainwindow.ui" line="1382"/>
        <source>Backup and Save</source>
        <translation>備份並儲存</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1393"/>
        <source>Manually</source>
        <translation>手動</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1401"/>
        <source>Hourly</source>
        <translation>每小時</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1409"/>
        <source>Daily</source>
        <translation>每日</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1420"/>
        <source>Weekly</source>
        <translation>每週</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1425"/>
        <source>Show Project in Folder</source>
        <translation>在資料夾中顯示專案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1436"/>
        <source>Pause After Seek</source>
        <translation>搜尋後暫停</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1445"/>
        <source>Files</source>
        <translation>檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1076"/>
        <location filename="../src/mainwindow.ui" line="1081"/>
        <source>Remove...</source>
        <translation>移除…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="509"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="932"/>
        <source>EDL...</source>
        <translation>EDL…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="943"/>
        <source>Frame...</source>
        <translation>影格…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <source>Video...</source>
        <translation>視訊…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="960"/>
        <location filename="../src/mainwindow.ui" line="963"/>
        <source>Export Video</source>
        <translation>匯出視訊</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1007"/>
        <source>Actions and Shortcuts...</source>
        <translation>指令與快速鍵…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <source>Clear Recent on Exit</source>
        <translation>結束時清除最近開啟的項目</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <source>Show Text Under Icons</source>
        <translation>在圖示下顯示文字</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1117"/>
        <source>Show Small Icons</source>
        <translation>顯示小圖示</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1126"/>
        <source>Jobs</source>
        <translation>工作</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1161"/>
        <source>540p</source>
        <translation>540p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1172"/>
        <source>720p</source>
        <translation>720p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1202"/>
        <source>360p</source>
        <translation>360p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <source>Error: This program requires the SDL 2 library.

Please install it using your package manager. It may be named libsdl2-2.0-0, SDL2, or similar.</source>
        <translation>錯誤：此程式需要 SDL 2 函式庫。

請透過套件管理員完成安裝。套件名稱可能為 libsdl2-2.0-0、SDL2 或類似的名稱。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1162"/>
        <source>Screen %1 (%2 x %3 @ %4 Hz)</source>
        <translation>螢幕 %1 (%2 × %3 @ %4 Hz)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1198"/>
        <source>Off</source>
        <translation>關</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1201"/>
        <source>Internal</source>
        <translation>內部</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1204"/>
        <source>External</source>
        <translation>外部</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1227"/>
        <source>DeckLink Keyer</source>
        <translation>DeckLink Keyer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1315"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Color</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1491"/>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1498"/>
        <source>Animation</source>
        <translation>動畫</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1503"/>
        <source>Noise</source>
        <translation>雜訊</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1508"/>
        <source>Color Bars</source>
        <translation>彩條</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1513"/>
        <source>Audio Tone</source>
        <translation>音訊音調</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1518"/>
        <source>Count</source>
        <translation>計數</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1523"/>
        <source>Blip Flash</source>
        <translation>光點閃爍</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1548"/>
        <location filename="../src/mainwindow.cpp" line="1550"/>
        <location filename="../src/mainwindow.cpp" line="1988"/>
        <location filename="../src/mainwindow.cpp" line="1996"/>
        <location filename="../src/mainwindow.cpp" line="2019"/>
        <location filename="../src/mainwindow.cpp" line="2079"/>
        <location filename="../src/mainwindow.cpp" line="4659"/>
        <location filename="../src/mainwindow.cpp" line="4672"/>
        <location filename="../src/mainwindow.cpp" line="5637"/>
        <source>Failed to open </source>
        <translation>無法開啟</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1583"/>
        <source>The file you opened uses GPU effects, but GPU effects are not enabled.</source>
        <translation>所開啟的檔案使用了 GPU 效果，但目前並未啟用 GPU 效果。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1595"/>
        <source>The file you opened uses CPU effects that are incompatible with GPU effects, but GPU effects are enabled.
Do you want to disable GPU effects and restart?</source>
        <translation>所開啟的檔案使用了 CPU 效果，與目前啟用的 GPU 效果並不相容。
要停用 GPU 效果並重新啟動程式嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1618"/>
        <source>Repaired</source>
        <translation>已修復</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1619"/>
        <source>Save Repaired XML</source>
        <translation>儲存修復後的 XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1656"/>
        <source>Repairing the project failed.</source>
        <translation>修復專案失敗。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1669"/>
        <source>Shotcut noticed some problems in your project.
Do you want Shotcut to try to repair it?

If you choose Yes, Shotcut will create a copy of your project
with &quot;- Repaired&quot; in the file name and open it.</source>
        <translation>Shotcut 在專案中發現了一些問題，要嘗試修復嗎？

如果選擇「是」，Shotcut 將建立一份以「－已修復」
命名的專案副本，並開啟該檔案。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1704"/>
        <source>Auto-saved files exist. Do you want to recover them now?</source>
        <translation>有自動儲存的檔案。要復原嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1776"/>
        <source>You cannot add a project to itself!</source>
        <translation>不能把專案加進其本身！</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1814"/>
        <source>There was an error saving. Please try again.</source>
        <translation>儲存時發生錯誤，請重試。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1899"/>
        <source>This project file requires a newer version!

It was made with version </source>
        <translation>此專案檔需要以較新版本的 Shotcut 來開啟！

它是由這個版本製作的： </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1930"/>
        <source>You are running low on available memory!

Please close other applications or web browser tabs and retry.
Or save and restart Shotcut.</source>
        <translation>可用記憶體不足！

請關閉其他應用程式或瀏覽器分頁後重試，
或於存檔後重新啟動 Shotcut。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1982"/>
        <source>Opening %1</source>
        <translation>正在開啟 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2121"/>
        <location filename="../src/mainwindow.cpp" line="4646"/>
        <source>Open File</source>
        <translation>開啟檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2123"/>
        <source>All Files (*);;MLT XML (*.mlt)</source>
        <translation>所有檔案 (*);;MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2391"/>
        <source>Preferences</source>
        <translation>偏好設定</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2401"/>
        <source>Rename Clip</source>
        <translation>重新命名短片</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2410"/>
        <source>Find</source>
        <translation>尋找</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2419"/>
        <source>Reload</source>
        <translation>重新載入</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2429"/>
        <source>Rerun Filter Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="2443"/>
        <source>This will start %n analysis job(s). Continue?</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2461"/>
        <source>No filters to analyze.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2602"/>
        <source>Untitled</source>
        <translation>未命名</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2607"/>
        <source>%1x%2 %3fps %4ch</source>
        <translation>%1×%2 %3fps %4ch</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2634"/>
        <source>About %1</source>
        <translation>關於 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2763"/>
        <source>Non-Broadcast</source>
        <translation>非廣播</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2768"/>
        <source>DVD Widescreen NTSC</source>
        <translation>DVD 寬螢幕 NTSC</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2769"/>
        <source>DVD Widescreen PAL</source>
        <translation>DVD 寬螢幕 PAL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2780"/>
        <source>Square 1080p 30 fps</source>
        <translation>正方形 1080p 30 fps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2781"/>
        <source>Square 1080p 60 fps</source>
        <translation>正方形 1080p 60 fps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2782"/>
        <source>Vertical HD 30 fps</source>
        <translation>直向 HD 30 fps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2783"/>
        <source>Vertical HD 60 fps</source>
        <translation>直向 HD 60 fps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2784"/>
        <source>Custom</source>
        <translation>自訂</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2815"/>
        <location filename="../src/mainwindow.cpp" line="3110"/>
        <source>Saved %1</source>
        <translation>已儲存 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3101"/>
        <location filename="../src/mainwindow.cpp" line="3124"/>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <source>Save XML</source>
        <translation>儲存 XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3220"/>
        <source>Timeline is not loaded</source>
        <translation>未載入時間軸</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3230"/>
        <source>Range marker not found under the timeline cursor</source>
        <translation>時間軸游標目前的位置上沒有任何範圍標記點</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3295"/>
        <source>There are incomplete jobs.
Do you still want to exit?</source>
        <translation>有未完成的工作。
確定要結束嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3307"/>
        <source>An export is in progress.
Do you still want to exit?</source>
        <translation>匯出仍在進行中。
確定要結束嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4448"/>
        <source>Saved backup %1</source>
        <translation>已儲存備份 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3186"/>
        <source>Do you also want to change the Video Mode to %1 x %2?</source>
        <translation>要同時將視訊模式變更為 %1 × %2 嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4101"/>
        <source>Opened Files</source>
        <translation>開啟的文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4183"/>
        <source>GPU effects are experimental and do not work good on all computers. Plan to do some testing after turning this on.
At this time, a project created with GPU effects cannot be converted to a CPU-only project later.

Do you want to enable GPU effects and restart Shotcut?</source>
        <translation>GPU 效果仍是實驗性功能，無法於所有系統上正常運作。啟用後請安排進行測試。
使用 GPU 效果建立的專案將無法於事後切換回僅使用 CPU 效果。

要啟用 GPU 效果並重新啟動 Shotcut 嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5281"/>
        <source>Add To Timeline</source>
        <translation>新增至時間軸</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5837"/>
        <source>Include ranges (Duration &gt; 1 frame)?</source>
        <translation>包含範圍（長度 &gt; 1 影格）？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5848"/>
        <source>Choose Markers</source>
        <translation>選擇標記點</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5865"/>
        <source>Text (*.txt);;All Files (*)</source>
        <translation>文字 (*.txt);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5920"/>
        <source>Failed to open export-chapters.js</source>
        <translation>無法開啟 export-chapters.js</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5961"/>
        <source>This will reset &lt;b&gt;all&lt;/b&gt; settings, and Shotcut must restart afterwards.
Do you want to reset and restart now?</source>
        <translation>將重設&lt;b&gt;所有&lt;/b&gt; 設定並重新啟動 Shotcut。
要立即重設並重新啟動嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1623"/>
        <location filename="../src/mainwindow.cpp" line="3128"/>
        <source>MLT XML (*.mlt)</source>
        <translation>MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <source>View Mode</source>
        <translation>檢視模式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3268"/>
        <source>The project has been modified.
Do you want to save your changes?</source>
        <translation>專案已修改。要儲存變更嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3925"/>
        <source>Exit Full Screen</source>
        <translation>結束全螢幕模式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <source>Turn Proxy On</source>
        <translation>啟用代理素材</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <source>Turn Proxy Off</source>
        <translation>停用代理素材</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5601"/>
        <source>Converting</source>
        <translation>正在轉換</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5617"/>
        <source>Do you want to create missing proxies for every file in this project?

You must reopen your project after all proxy jobs are finished.</source>
        <translation>要為專案裡的每個檔案重新建立遺失的代理素材嗎？

您必須在所有代理素材工作完成後重新開啟專案。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5655"/>
        <source>Proxy Folder</source>
        <translation>代理素材資料夾</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5673"/>
        <source>Do you want to move all files from the old folder to the new folder?</source>
        <translation>要將舊資料夾的所有檔案移至新資料夾嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5681"/>
        <source>Moving Files</source>
        <translation>移動檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3937"/>
        <source>GPU effects are not supported</source>
        <translation>不支援 GPU 效果</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>Set Loop Range</source>
        <translation>設定迴圈範圍</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="474"/>
        <source>Thumbnails</source>
        <translation>縮圖</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <source>Scrolling</source>
        <translation>捲動</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1043"/>
        <source>Audio API</source>
        <translation>音訊 API</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1064"/>
        <source>default</source>
        <translation>預設</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1071"/>
        <source>You must restart Shotcut to change the audio API.
Do you want to restart now?</source>
        <translation>必須重新啟動 Shotcut 才能變更音訊 API。
要立刻重新啟動嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1189"/>
        <source>SDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>HLG HDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>DeckLink Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3957"/>
        <source>Click here to check for a new version of Shotcut.</source>
        <translation>按一下這裡以檢查 Shotcut 的新版本</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4072"/>
        <source>Open Files</source>
        <translation>開啟檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4131"/>
        <source>You must restart Shotcut to switch to the new language.
Do you want to restart now?</source>
        <translation>必須重新啟動 Shotcut 才能切換至新的語言。
要立刻重新啟動嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4174"/>
        <source>Failed to connect to JACK.
Please verify that JACK is installed and running.</source>
        <translation>連接 JACK 失敗。
請確認 JACK 已經安裝並且正在執行。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4203"/>
        <source>Shotcut must restart to disable GPU effects.

Disable GPU effects and restart?</source>
        <translation>Shortcut 必須重新啟動以停用 GPU 效果。

要停用 GPU 效果並重新啟動程式嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4425"/>
        <source>You must restart %1 to switch to the new theme.
Do you want to restart now?</source>
        <translation>必須重新啟動 %1 才能切換至新的佈景主題。
要立刻重新啟動嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4468"/>
        <source>&lt;p&gt;Please review your entire project after making this change.&lt;/p&gt;&lt;p&gt;Shotcut does not automatically adjust things that are sensitive to size and position if you change resolution or aspect ratio.&lt;/p&lt;br&gt;The timing of edits and keyframes may be slightly different if you change frame rate.&lt;/p&gt;&lt;p&gt;It is a good idea to use &lt;b&gt;File &gt; Backup and Save&lt;/b&gt; before or after this operation.&lt;/p&gt;&lt;p&gt;Do you want to change the &lt;b&gt;Video Mode&lt;/b&gt; now?&lt;/p&gt;</source>
        <translation>&lt;p&gt;請在作成變更後全面檢查專案。&lt;/p&gt;&lt;p&gt;若變更了解析度或外觀比例，Shotcut 將不會自動調整任何涉及尺寸或位置的屬性。&lt;/p&lt;br&gt;若變更了影格播放速率，剪輯與關鍵影格的時序可能會略有差異。&lt;/p&gt;&lt;p&gt;建議在進行此操作前後善用&lt;b&gt;「檔案」→「備份並儲存」&lt;/b&gt; 進行備份。&lt;/p&gt;&lt;p&gt;要立即變更&lt;b&gt;「視訊模式」&lt;/b&gt; 嗎？&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4482"/>
        <source>Do not show this anymore.</source>
        <comment>Change video mode warning dialog</comment>
        <translation>不再顯示此提示。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4493"/>
        <source>Shotcut must restarto change external monitoring.
Do you want to restart now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4623"/>
        <source>Do you want to automatically check for updates in the future?</source>
        <translation>要在往後自動檢查更新嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4630"/>
        <source>Do not show this anymore.</source>
        <comment>Automatic upgrade check dialog</comment>
        <translation>不再顯示此提示。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4648"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4702"/>
        <source>You must restart Shotcut to change the display method.
Do you want to restart now?</source>
        <translation>必須重新啟動 Shotcut 才能變更顯示方式。
要立刻重新啟動嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4732"/>
        <source>Application Log</source>
        <translation>應用程式記錄檔</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4735"/>
        <source>Previous</source>
        <translation>上一個</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4797"/>
        <source>Shotcut version %1 is available! Click here to get it.</source>
        <translation>新的 Shotcut 版本 %1 已經可以下載了！按一下這裡取得新版本。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <source>You are running the latest version of Shotcut.</source>
        <translation>正在執行最新版本的 Shotcut。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4817"/>
        <source>Failed to read version.json when checking. Click here to go to the Web site.</source>
        <translation>檢查更新時無法讀取 version.json。按一下這裡以移至官方網站。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="935"/>
        <location filename="../src/mainwindow.ui" line="938"/>
        <location filename="../src/mainwindow.cpp" line="4837"/>
        <source>Export EDL</source>
        <translation>匯出 EDL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4841"/>
        <source>EDL (*.edl);;All Files (*)</source>
        <translation>EDL (*.edl);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4888"/>
        <location filename="../src/mainwindow.cpp" line="5917"/>
        <source>A JavaScript error occurred during export.</source>
        <translation>匯出時發生了 JavaScript 錯誤。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4891"/>
        <source>Failed to open export-edl.js</source>
        <translation>無法開啟 export-edl.js</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4922"/>
        <source>Export frame from proxy?</source>
        <translation>從代理素材匯出影格？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4923"/>
        <source>This frame may be from a lower resolution proxy instead of the original source.

Do you still want to continue?</source>
        <translation>此影格並非來自原始來源，而是解析度可能較低的代理素材。

確定要繼續嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="946"/>
        <location filename="../src/mainwindow.ui" line="949"/>
        <location filename="../src/mainwindow.cpp" line="4935"/>
        <source>Export Frame</source>
        <translation>匯出影格</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4941"/>
        <source>Unable to export frame.</source>
        <translation>無法匯出影格。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4949"/>
        <source>You must restart Shotcut to change the data directory.
Do you want to continue?</source>
        <translation>必須重新啟動 Shotcut 才能變更資料目錄。
要立刻重新啟動嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4960"/>
        <source>Data Directory</source>
        <translation>資料目錄</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5170"/>
        <source>Add Custom Layout</source>
        <translation>新增自訂版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5171"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5210"/>
        <source>Remove Video Mode</source>
        <translation>移除視訊模式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5227"/>
        <source>Remove Layout</source>
        <translation>移除版面配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5381"/>
        <source>GPU effects are EXPERIMENTAL, UNSTABLE and UNSUPPORTED! Unsupported means do not report bugs about it.

Do you want to disable GPU effects and restart Shotcut?</source>
        <translation>GPU 效果為「實驗性」、「不穩定」且「不提供支援」的功能！不提供支援的意思是不要回報與此功能相關的問題。

要停用 GPU 效果並重新啟動程式嗎？</translation>
    </message>
</context>
<context>
    <name>MarkersDock</name>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="129"/>
        <source>Markers</source>
        <translation>標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="200"/>
        <source>Add a marker at the current time</source>
        <translation>於目前時間處新增標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="209"/>
        <source>Remove the selected marker</source>
        <translation>移除選取的標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="218"/>
        <source>Deselect the marker</source>
        <translation>取消選取標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="191"/>
        <source>Markers Menu</source>
        <translation>「標記點」功能表</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="165"/>
        <source>Remove All Markers</source>
        <translation>移除所有標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="167"/>
        <source>Columns</source>
        <translation>欄位</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="168"/>
        <source>Color</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="171"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="174"/>
        <source>Start</source>
        <translation>開始</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="177"/>
        <source>End</source>
        <translation>結束</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="180"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="186"/>
        <source>Markers Controls</source>
        <translation>「標記點」控制項</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="228"/>
        <source>search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="236"/>
        <source>Clear search</source>
        <translation>清除搜尋</translation>
    </message>
</context>
<context>
    <name>MarkersModel</name>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="788"/>
        <source>Color</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="790"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="792"/>
        <source>Start</source>
        <translation>開始</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="794"/>
        <source>End</source>
        <translation>結束</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="796"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
</context>
<context>
    <name>MeltJob</name>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="47"/>
        <source>View XML</source>
        <translation>檢視 XML</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="48"/>
        <source>View the MLT XML for this job</source>
        <translation>檢視此工作的 MLT XML</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="57"/>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="59"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>在 Shotcut 播放器開啟輸出檔案</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="63"/>
        <location filename="../src/jobs/meltjob.cpp" line="68"/>
        <location filename="../src/jobs/meltjob.cpp" line="69"/>
        <source>Show In Folder</source>
        <translation>在資料夾中顯示</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="64"/>
        <source>Show In Files</source>
        <translation>在「檔案」中顯示</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="192"/>
        <source>MLT XML</source>
        <translation>MLT XML</translation>
    </message>
</context>
<context>
    <name>Mlt::VideoWidget</name>
    <message>
        <location filename="../src/videowidget.cpp" line="196"/>
        <source>You cannot drag from Project.</source>
        <translation>無法從「專案」向外拖曳。</translation>
    </message>
    <message>
        <location filename="../src/videowidget.cpp" line="199"/>
        <source>You cannot drag a non-seekable source</source>
        <translation>無法拖曳不可搜尋的來源</translation>
    </message>
</context>
<context>
    <name>MltClipProducerWidget</name>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="47"/>
        <source>Resolution</source>
        <translation>解析度</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="53"/>
        <source>Aspect ratio</source>
        <translation>外觀比例</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="59"/>
        <source>Frame rate</source>
        <translation>影格播放速率</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="65"/>
        <source>Scan mode</source>
        <translation>掃描模式</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="71"/>
        <source>Colorspace</source>
        <translation>色彩空間</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="77"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="150"/>
        <source>%L1 fps</source>
        <translation>%L1 fps</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="153"/>
        <source>Progressive</source>
        <translation>漸進式</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="155"/>
        <source>Interlaced</source>
        <translation>交錯式</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="202"/>
        <source>Subclip profile does not match project profile.
This may provide unexpected results</source>
        <translation>子短片設定與專案設定不符。
可能會產生預料之外的結果。</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="207"/>
        <source>Subclip profile matches project profile.</source>
        <translation>子短片設定與專案設定相符。</translation>
    </message>
</context>
<context>
    <name>MotionTrackerDialog</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="39"/>
        <source>Load Keyframes from Motion Tracker</source>
        <translation>由動態追蹤器載入關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="55"/>
        <source>Motion tracker</source>
        <translation>動態追蹤器</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="75"/>
        <source>Adjust</source>
        <translation>調整</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="92"/>
        <source>Relative Position</source>
        <translation>相對位置</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="96"/>
        <source>Offset Position</source>
        <translation>位移位置</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="100"/>
        <source>Absolute Position</source>
        <translation>絕對位置</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="104"/>
        <source>Size And Position</source>
        <translation>位置與尺寸</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="123"/>
        <source>From start</source>
        <translation>從開始處</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="128"/>
        <source>Current position</source>
        <translation>目前位置</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="142"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="154"/>
        <source>Reset</source>
        <translation>重設</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="165"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>MotionTrackerModel</name>
    <message>
        <location filename="../src/models/motiontrackermodel.cpp" line="180"/>
        <source>Tracker %1</source>
        <translation>追蹤器 %1</translation>
    </message>
</context>
<context>
    <name>MultiFileExportDialog</name>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="63"/>
        <source>Directory</source>
        <translation>目錄</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="76"/>
        <source>Prefix</source>
        <translation>前置詞</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="77"/>
        <source>export</source>
        <translation>匯出</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="82"/>
        <source>Field 1</source>
        <translation>欄位 1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="92"/>
        <source>Field 2</source>
        <translation>欄位 2</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="102"/>
        <source>Field 3</source>
        <translation>欄位 3</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="113"/>
        <source>Extension</source>
        <translation>副檔名</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="207"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="208"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="209"/>
        <source>Index</source>
        <translation>索引</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="210"/>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="211"/>
        <source>Hash</source>
        <translation>雜湊碼</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="234"/>
        <source>Empty File Name</source>
        <translation>檔案名稱為空白</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="236"/>
        <source>Directory does not exist: %1</source>
        <translation>目錄不存在：%1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="243"/>
        <source>File Exists: %1</source>
        <translation>檔案已存在：%1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="248"/>
        <source>Duplicate File Name: %1</source>
        <translation>檔案名稱重複：%1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="274"/>
        <source>Fix file name errors before export.</source>
        <translation>請在匯出前修正檔名錯誤。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="281"/>
        <source>Export Directory</source>
        <translation>匯出目錄</translation>
    </message>
</context>
<context>
    <name>MultitrackModel</name>
    <message>
        <location filename="../src/models/multitrackmodel.cpp" line="115"/>
        <source>(PROXY)</source>
        <translation>（代理）</translation>
    </message>
    <message>
        <location filename="../src/models/multitrackmodel.cpp" line="2653"/>
        <source>Error: Shotcut could not find the %1 plugin on your system.

Please install the %2 plugins.</source>
        <translation>錯誤：Shotcut 在系統上找不到 %1 外掛程式。

請安裝 %2 外掛程式。</translation>
    </message>
</context>
<context>
    <name>NetworkProducerWidget</name>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="26"/>
        <source>Network Stream</source>
        <translation>網路串流</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="41"/>
        <source>&amp;URL</source>
        <translation>&amp;URL</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="57"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
</context>
<context>
    <name>NewProjectFolder</name>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="20"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="61"/>
        <source>Projects</source>
        <translation>專案</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="188"/>
        <location filename="../src/widgets/newprojectfolder.ui" line="205"/>
        <source>PushButton</source>
        <translation>按鈕</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="231"/>
        <source>Start</source>
        <translation>開始</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="372"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="218"/>
        <source>A folder with this name will be created containing
a project file with the same name.</source>
        <translation>將會建立此名稱的資料夾
並包含同樣名稱的專案檔。</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="159"/>
        <source>Projects folder</source>
        <translation>專案資料夾</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="263"/>
        <source>Project name</source>
        <translation>專案名稱</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="253"/>
        <source>Video mode</source>
        <translation>視訊模式</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="201"/>
        <source>This is the folder to contain Shotcut project folders.
A folder will be created in this folder for each project.</source>
        <translation>這是包含 Shotcut 專案資料夾的資料夾。
將會在這個資料夾為每個專案建立一個資料夾。</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="315"/>
        <source>Automatic means the resolution and frame rate are based on the &lt;b&gt;first&lt;/b&gt; file you &lt;b&gt;add&lt;/b&gt; to your project. If the first file is not a video clip (for example, image or audio), then it will be 1920x1080p 25 fps.</source>
        <translation>「自動」意指解析度及影格播放速率皆以&lt;b&gt;新增至專案&lt;/b&gt;的&lt;b&gt;第一個&lt;/b&gt;檔案為準。如果新增的第一個檔案不是視訊短片（例如影像或音訊），則為 1920×1080p 25fps。</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="143"/>
        <source>New Project</source>
        <translation>新專案</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="357"/>
        <source>Automatic</source>
        <translation>自動</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="362"/>
        <source>Add...</source>
        <translation>新增…</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="367"/>
        <source>Remove...</source>
        <translation>移除…</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="130"/>
        <source>Projects Folder</source>
        <translation>專案資料夾</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="167"/>
        <source>Custom</source>
        <translation>自訂</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="184"/>
        <source>Remove Video Mode</source>
        <translation>移除視訊模式</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="213"/>
        <source>The project name cannot include a slash.</source>
        <translation>專案名稱不能包含斜線。</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="229"/>
        <source>There is already a project with that name.
Try again with a different name.</source>
        <translation>已經有同名專案。
請嘗試其他名稱。</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="238"/>
        <source>Unable to create folder %1
Perhaps you do not have permission.
Try again with a different folder.</source>
        <translation>無法寫入檔案 %1
可能沒有所需的權限。
請選擇其他資料夾再試。</translation>
    </message>
</context>
<context>
    <name>NoiseWidget</name>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="26"/>
        <source>Noise</source>
        <translation>雜訊</translation>
    </message>
</context>
<context>
    <name>NotesDock</name>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="79"/>
        <source>Notes</source>
        <translation>筆記</translation>
    </message>
</context>
<context>
    <name>OpenOtherDialog</name>
    <message>
        <location filename="../src/openotherdialog.ui" line="17"/>
        <source>Open Other</source>
        <translation>開啟其他</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.ui" line="55"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="32"/>
        <source>Add To Timeline</source>
        <translation>新增至時間軸</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="38"/>
        <location filename="../src/openotherdialog.cpp" line="143"/>
        <source>Network</source>
        <translation>網路</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="43"/>
        <source>Device</source>
        <translation>裝置</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="45"/>
        <location filename="../src/openotherdialog.cpp" line="145"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="49"/>
        <location filename="../src/openotherdialog.cpp" line="135"/>
        <source>Video4Linux</source>
        <translation>Video4Linux</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="51"/>
        <location filename="../src/openotherdialog.cpp" line="137"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="53"/>
        <location filename="../src/openotherdialog.cpp" line="139"/>
        <source>ALSA Audio</source>
        <translation>ALSA 音訊</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="56"/>
        <location filename="../src/openotherdialog.cpp" line="59"/>
        <location filename="../src/openotherdialog.cpp" line="141"/>
        <source>Audio/Video Device</source>
        <translation>音訊／視訊裝置</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="64"/>
        <source>Generator</source>
        <translation>產生器</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="66"/>
        <location filename="../src/openotherdialog.cpp" line="147"/>
        <source>Color</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="69"/>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="74"/>
        <location filename="../src/openotherdialog.cpp" line="149"/>
        <source>Animation</source>
        <translation>動畫</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="78"/>
        <location filename="../src/openotherdialog.cpp" line="151"/>
        <source>Noise</source>
        <translation>雜訊</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="82"/>
        <location filename="../src/openotherdialog.cpp" line="153"/>
        <source>Ising</source>
        <translation>易辛模型</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="87"/>
        <location filename="../src/openotherdialog.cpp" line="155"/>
        <source>Lissajous</source>
        <translation>利薩如圖形</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="91"/>
        <location filename="../src/openotherdialog.cpp" line="157"/>
        <source>Plasma</source>
        <translation>電漿</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="95"/>
        <location filename="../src/openotherdialog.cpp" line="159"/>
        <source>Color Bars</source>
        <translation>彩條</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="99"/>
        <location filename="../src/openotherdialog.cpp" line="161"/>
        <source>Audio Tone</source>
        <translation>音訊音調</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="103"/>
        <location filename="../src/openotherdialog.cpp" line="163"/>
        <source>Count</source>
        <translation>計數</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="107"/>
        <location filename="../src/openotherdialog.cpp" line="165"/>
        <source>Blip Flash</source>
        <translation>光點閃爍</translation>
    </message>
</context>
<context>
    <name>ParameterHead</name>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="151"/>
        <source>Seek to previous keyframe</source>
        <translation>移至前一個關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="151"/>
        <source>Seek backwards</source>
        <translation>往回搜尋</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="171"/>
        <source>Add a keyframe at play head</source>
        <translation>在播放點新增關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="199"/>
        <source>Delete the selected keyframe</source>
        <translation>刪除選取的關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="228"/>
        <source>Seek to next keyframe</source>
        <translation>移至後一個關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="228"/>
        <source>Seek forwards</source>
        <translation>向前搜尋</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="245"/>
        <source>Unlock track</source>
        <translation>解除鎖定軌道</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="245"/>
        <source>Lock track</source>
        <translation>鎖定軌道</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="256"/>
        <source>Zoom keyframe values</source>
        <translation>縮放關鍵影格值</translation>
    </message>
</context>
<context>
    <name>PlasmaWidget</name>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="26"/>
        <source>Plasma</source>
        <translation>電漿</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="41"/>
        <source>Speed 1</source>
        <translation>速度 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="112"/>
        <source>Speed 2</source>
        <translation>速度 2</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="180"/>
        <source>Speed 3</source>
        <translation>速度 3</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="252"/>
        <source>Speed 4</source>
        <translation>速度 4</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="323"/>
        <source>Move 1</source>
        <translation>動作 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="391"/>
        <source>Move 2</source>
        <translation>動作 2</translation>
    </message>
</context>
<context>
    <name>Player</name>
    <message>
        <location filename="../src/player.cpp" line="91"/>
        <source>Source</source>
        <translation>來源</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="92"/>
        <source>Project</source>
        <translation>專案</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="155"/>
        <source>Adjust the audio volume</source>
        <translation>調整音量</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="177"/>
        <source>Silence the audio</source>
        <translation>將音訊靜音</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="196"/>
        <source>Current position</source>
        <translation>目前位置</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="202"/>
        <source>Total Duration</source>
        <translation>總長度</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="380"/>
        <source>In Point</source>
        <translation>起點</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="388"/>
        <source>Selected Duration</source>
        <translation>選取長度</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="242"/>
        <source>Zoom Fit</source>
        <translation>最適大小</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="191"/>
        <source>Current/Total Times</source>
        <translation>目前／總時間</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="210"/>
        <source>Player Controls</source>
        <translation>「播放器」控制項</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="221"/>
        <location filename="../src/player.cpp" line="375"/>
        <source>Player Options</source>
        <translation>播放器選項</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="248"/>
        <source>Zoom 10%</source>
        <translation>縮放 10%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="254"/>
        <source>Zoom 25%</source>
        <translation>縮放 25%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="260"/>
        <source>Zoom 50%</source>
        <translation>縮放 50%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="267"/>
        <source>Zoom 100%</source>
        <translation>縮放 100%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="273"/>
        <source>Zoom 200%</source>
        <translation>縮放 200%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="311"/>
        <source>Toggle zoom</source>
        <translation>切換縮放</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="318"/>
        <source>2x2 Grid</source>
        <translation>2×2 格線</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="323"/>
        <source>3x3 Grid</source>
        <translation>3×3 格線</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="327"/>
        <source>4x4 Grid</source>
        <translation>4×4 格線</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="331"/>
        <source>16x16 Grid</source>
        <translation>16×16 格線</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="339"/>
        <source>10 Pixel Grid</source>
        <translation>10 像素格線</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="462"/>
        <source>Play/Pause</source>
        <translation>播放／暫停</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="466"/>
        <source>Toggle play or pause</source>
        <translation>切換播放或暫停</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="477"/>
        <source>Loop</source>
        <translation>重複</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="483"/>
        <source>Toggle player looping</source>
        <translation>切換重複播放</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="487"/>
        <source>Loop All</source>
        <translation>重複全部</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="488"/>
        <source>Loop back to the beginning when the end is reached</source>
        <translation>於播放完畢後回到開頭重複播放</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="495"/>
        <source>Loop Marker</source>
        <translation>重複標記點</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="496"/>
        <source>Loop around the marker under the cursor in the timeline</source>
        <translation>重複播放時間軸上位於游標位置的標記點前後的範圍</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="507"/>
        <source>Loop Selection</source>
        <translation>重複選取範圍</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="508"/>
        <source>Loop around the selected clips</source>
        <translation>重複播放選取的短片</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="516"/>
        <source>Nothing selected</source>
        <translation>未選取任何項目</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="521"/>
        <source>Loop Around Cursor</source>
        <translation>重複游標範圍</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="522"/>
        <source>Loop around the current cursor position</source>
        <translation>重複播放游標目前位置前後的範圍</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="551"/>
        <source>Skip to the next point</source>
        <translation>跳到後一個位置</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="574"/>
        <source>Skip to the previous point</source>
        <translation>跳到前一個位置</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="599"/>
        <source>Play quickly backwards</source>
        <translation>向起點快速倒帶</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="609"/>
        <source>Play quickly forwards</source>
        <translation>朝結尾快轉播放</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="613"/>
        <source>Seek Start</source>
        <translation>移至開頭</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="618"/>
        <source>Seek End</source>
        <translation>移至結尾</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="628"/>
        <source>Next Frame</source>
        <translation>後一影格</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="634"/>
        <source>Previous Frame</source>
        <translation>前一影格</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="640"/>
        <source>Forward One Second</source>
        <translation>前進一秒</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="645"/>
        <source>Backward One Second</source>
        <translation>倒退一秒</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="650"/>
        <source>Forward Two Seconds</source>
        <translation>前進兩秒</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="655"/>
        <source>Backward Two Seconds</source>
        <translation>倒退兩秒</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="660"/>
        <source>Forward Five Seconds</source>
        <translation>前進五秒</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="665"/>
        <source>Backward Five Seconds</source>
        <translation>倒退五秒</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="670"/>
        <source>Forward Ten Seconds</source>
        <translation>前進十秒</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="675"/>
        <source>Backward Ten Seconds</source>
        <translation>倒退十秒</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="680"/>
        <source>Forward Jump</source>
        <translation>向前跳躍</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="687"/>
        <source>Backward Jump</source>
        <translation>往回跳躍</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="694"/>
        <source>Set Jump Time</source>
        <translation>設定跳躍時間</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="705"/>
        <source>Trim Clip In</source>
        <translation>修剪短片起點</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="718"/>
        <source>Trim Clip Out</source>
        <translation>修剪短片終點</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="731"/>
        <source>Set Time Position</source>
        <translation>設定播放點位置</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="761"/>
        <source>Pause playback</source>
        <translation>暫停播放</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="763"/>
        <location filename="../src/player.cpp" line="768"/>
        <location filename="../src/player.cpp" line="773"/>
        <source>Player</source>
        <translation>播放器</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="765"/>
        <source>Focus Player</source>
        <translation>移動焦點至播放器</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="770"/>
        <source>Toggle Filter Overlay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="923"/>
        <source>Not Seekable</source>
        <translation>不可搜尋</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="335"/>
        <source>20 Pixel Grid</source>
        <translation>20 像素格線</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="279"/>
        <source>Zoom 300%</source>
        <translation>縮放 300%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="285"/>
        <source>Zoom 400%</source>
        <translation>縮放 400%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="291"/>
        <source>Zoom 500%</source>
        <translation>縮放 500%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="297"/>
        <source>Zoom 750%</source>
        <translation>縮放 750%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="303"/>
        <source>Zoom 1000%</source>
        <translation>縮放 1000%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="343"/>
        <source>80/90% Safe Areas</source>
        <translation>80/90% 安全區域</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="347"/>
        <source>EBU R95 Safe Areas</source>
        <translation>EBU R95 安全區域</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="352"/>
        <source>Snapping</source>
        <translation>貼齊</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="362"/>
        <source>Toggle grid display on the player</source>
        <translation>切換顯示播放器上的格線</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="738"/>
        <source>Switch Source/Project</source>
        <translation>切換「來源」／「專案」</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="758"/>
        <source>Pause</source>
        <translation>暫停</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="545"/>
        <source>Skip Next</source>
        <translation>跳至後一處</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="568"/>
        <source>Skip Previous</source>
        <translation>跳至前一處</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="593"/>
        <source>Rewind</source>
        <translation>倒轉</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="603"/>
        <source>Fast Forward</source>
        <translation>快轉</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="369"/>
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="370"/>
        <source>Show the volume control</source>
        <translation>顯示音量控制</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1278"/>
        <source>Proxy and preview scaling are ON at %1p</source>
        <translation>已啟用代理素材與預覽縮放至 %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1283"/>
        <source>Proxy is ON at %1p</source>
        <translation>已啟用代理素材至 %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1288"/>
        <source>Preview scaling is ON at %1p</source>
        <translation>已啟用預覽縮放至 %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1403"/>
        <source>Unmute</source>
        <translation>解除靜音</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1372"/>
        <location filename="../src/player.cpp" line="1412"/>
        <source>Mute</source>
        <translation>靜音</translation>
    </message>
</context>
<context>
    <name>PlaylistDock</name>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="18"/>
        <location filename="../src/docks/playlistdock.cpp" line="382"/>
        <source>Playlist</source>
        <translation>播放清單</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="59"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; a playlist item to open it in the player.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can freely preview clips without necessarily adding them to the playlist or closing it.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To trim or adjust a playlist item &lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; to open it, make the changes, and click the &lt;span style=&quot; font-weight:600;&quot;&gt;Update&lt;/span&gt; icon.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drag-n-drop&lt;/span&gt; to rearrange the items.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;按兩下&lt;/span&gt;播放清單項目以在播放器中開啟。&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;剪輯不必新增至播放清單或手動關閉便可自由預覽。&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;要修剪或調整播放清單項目，請&lt;span style=&quot; font-weight:600;&quot;&gt;按兩下&lt;/span&gt;開啟，在作成修改後按一下&lt;span style=&quot; font-weight:600;&quot;&gt;「更新」&lt;/span&gt;圖示。&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;拖放&lt;/span&gt;以重新排列項目。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="127"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Double-click a playlist item to open it in the player.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;按兩下播放清單項目以在播放器中開啟。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="601"/>
        <source>Add the Source to the playlist</source>
        <translation>新增「來源」到播放清單</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="612"/>
        <source>Remove cut</source>
        <translation>移除剪輯</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="630"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="642"/>
        <source>View as tiles</source>
        <translation>並排檢視</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="655"/>
        <source>View as icons</source>
        <translation>圖示檢視</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="668"/>
        <source>View as details</source>
        <translation>詳細資料檢視</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="607"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="720"/>
        <source>Set Creation Time...</source>
        <translation>設定建立時間…</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="706"/>
        <location filename="../src/docks/playlistdock.cpp" line="707"/>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="451"/>
        <source>Playlist Menu</source>
        <translation>「播放清單」功能表</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="599"/>
        <source>Append</source>
        <translation>附加</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="681"/>
        <source>Open the clip in the Source player</source>
        <translation>在「來源」播放器開啟短片</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="691"/>
        <source>Go to the start of this clip in the Project player</source>
        <translation>在「專案」播放器前往短片開頭</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="728"/>
        <source>Remove All</source>
        <translation>全部移除</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="729"/>
        <source>Remove all items from the playlist</source>
        <translation>從播放清單移除所有項目</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="805"/>
        <source>Hidden</source>
        <translation>隱藏</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="817"/>
        <source>In and Out - Left/Right</source>
        <translation>起點與終點－左右並排</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="833"/>
        <source>In and Out - Top/Bottom</source>
        <translation>起點與終點－上下並排</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="850"/>
        <source>In Only - Small</source>
        <translation>僅起點－小型</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="866"/>
        <source>In Only - Large</source>
        <translation>僅起點－大型</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="772"/>
        <source>Add Selected to Timeline</source>
        <translation>新增選取項目至時間軸</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="779"/>
        <source>Add Selected to Slideshow</source>
        <translation>新增選取項目至幻燈片秀</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="883"/>
        <source>Play After Open</source>
        <translation>開啟後播放</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="734"/>
        <source>Select All</source>
        <translation>全選</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="740"/>
        <source>Select None</source>
        <translation>取消選取</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="712"/>
        <source>Update Thumbnails</source>
        <translation>更新縮圖</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="786"/>
        <source>Sort By Name</source>
        <translation>依名稱排序</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="794"/>
        <source>Sort By Date</source>
        <translation>依日期排序</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="667"/>
        <source>Details</source>
        <translation>詳細資料</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="412"/>
        <source>Select</source>
        <translation>選取</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="429"/>
        <location filename="../src/docks/playlistdock.cpp" line="1134"/>
        <source>Bins</source>
        <translation>列表</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="436"/>
        <source>Columns</source>
        <translation>欄位</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="446"/>
        <source>Playlist Controls</source>
        <translation>「播放清單」控制項</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="480"/>
        <location filename="../src/docks/playlistdock.cpp" line="484"/>
        <source>Playlist Filters</source>
        <translation>「播放清單」篩選器</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="508"/>
        <source>Only show files whose name, path, or comment contains some text</source>
        <translation>只顯示檔名、路徑、或註解含有特定文字的檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="509"/>
        <source>search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="623"/>
        <source>Add files to playlist</source>
        <translation>新增檔案至播放清單</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="641"/>
        <source>Tiles</source>
        <translation>並排</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="654"/>
        <source>Icons</source>
        <translation>圖示</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="680"/>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="690"/>
        <source>GoTo</source>
        <translation>前往</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="696"/>
        <source>Copy</source>
        <translation>複製</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="697"/>
        <source>Open a copy of the clip in the Source player</source>
        <translation>在「來源」播放器開啟短片複本</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="748"/>
        <source>Move Up</source>
        <translation>上移</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="760"/>
        <source>Move Down</source>
        <translation>下移</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="891"/>
        <source>Open Previous</source>
        <translation>開啟前一項</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="904"/>
        <source>Open Next</source>
        <translation>開啟後一項</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="917"/>
        <source>Select Clip 1</source>
        <translation>選取短片 1</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="929"/>
        <source>Select Clip 2</source>
        <translation>選取短片 2</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="941"/>
        <source>Select Clip 3</source>
        <translation>選取短片 3</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="953"/>
        <source>Select Clip 4</source>
        <translation>選取短片 4</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="965"/>
        <source>Select Clip 5</source>
        <translation>選取短片 5</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="977"/>
        <source>Select Clip 6</source>
        <translation>選取短片 6</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="989"/>
        <source>Select Clip 7</source>
        <translation>選取短片 7</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1001"/>
        <source>Select Clip 8</source>
        <translation>選取短片 8</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1013"/>
        <source>Select Clip 9</source>
        <translation>選取短片 9</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1025"/>
        <source>Thumbnails</source>
        <translation>縮圖</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1034"/>
        <source>Clip</source>
        <translation>短片</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1043"/>
        <source>In</source>
        <translation>起點</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1052"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1061"/>
        <source>Start</source>
        <translation>開始</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1070"/>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1079"/>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1088"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1089"/>
        <source>Show or hide video files</source>
        <translation>顯示或隱藏視訊檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1094"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1095"/>
        <source>Show or hide audio files</source>
        <translation>顯示或隱藏音訊檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1100"/>
        <source>Image</source>
        <translation>影像</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1101"/>
        <source>Show or hide image files</source>
        <translation>顯示或隱藏影像檔</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1106"/>
        <source>Other</source>
        <translation>其他</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1107"/>
        <source>Show or hide other kinds of files</source>
        <translation>顯示或隱藏其他檔案格式</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1112"/>
        <location filename="../src/docks/playlistdock.cpp" line="1113"/>
        <source>New Bin</source>
        <translation>新增列表</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1124"/>
        <location filename="../src/docks/playlistdock.cpp" line="1164"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1135"/>
        <source>Show or hide the list of bins</source>
        <translation>顯示或隱藏列表清單</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1144"/>
        <location filename="../src/docks/playlistdock.cpp" line="1145"/>
        <source>Remove Bin</source>
        <translation>移除列表</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1156"/>
        <location filename="../src/docks/playlistdock.cpp" line="1157"/>
        <source>Rename Bin</source>
        <translation>重新命名列表</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1178"/>
        <source>Search</source>
        <translation>搜尋</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="1213"/>
        <source>Replace %n playlist items</source>
        <translation>
            <numerusform>取代 %n 個播放清單項目</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="2138"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n 個項目</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="433"/>
        <source>Sort</source>
        <translation>排序</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1536"/>
        <location filename="../src/docks/playlistdock.cpp" line="1768"/>
        <source>You cannot insert a playlist into a playlist!</source>
        <translation>無法將播放清單插入播放清單中！</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="1553"/>
        <source>Remove %n playlist items</source>
        <translation>
            <numerusform>移除 %n 個播放清單項目</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="622"/>
        <location filename="../src/docks/playlistdock.cpp" line="1312"/>
        <source>Add Files</source>
        <translation>新增檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1266"/>
        <source>Appending</source>
        <translation>正在附加</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1322"/>
        <location filename="../src/docks/playlistdock.cpp" line="1331"/>
        <source>Failed to open </source>
        <translation>無法開啟</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1395"/>
        <source>Dropped Files</source>
        <translation>置放的檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1857"/>
        <source>Generating</source>
        <translation>正在產生</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="2076"/>
        <source>Open File</source>
        <translation>開啟檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="2078"/>
        <source>All Files (*);;MLT XML (*.mlt)</source>
        <translation>所有檔案 (*);;MLT XML (*.mlt)</translation>
    </message>
</context>
<context>
    <name>PlaylistIconView</name>
    <message>
        <location filename="../src/widgets/playlisticonview.cpp" line="175"/>
        <source>P</source>
        <comment>The first letter or symbol of &quot;proxy&quot;</comment>
        <translation>代</translation>
    </message>
</context>
<context>
    <name>PlaylistModel</name>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="269"/>
        <source>(PROXY)</source>
        <translation>（代理）</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="409"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="411"/>
        <source>Image</source>
        <translation>影像</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="413"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="415"/>
        <source>Other</source>
        <translation>其他</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="494"/>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="496"/>
        <source>Thumbnails</source>
        <translation>縮圖</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="498"/>
        <source>Clip</source>
        <translation>短片</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="500"/>
        <source>In</source>
        <translation>起點</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="502"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="504"/>
        <source>Start</source>
        <translation>開始時間</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="506"/>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="508"/>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="510"/>
        <source>Comment</source>
        <translation>註解</translation>
    </message>
</context>
<context>
    <name>PlaylistProxyModel</name>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Duplicates</source>
        <translation>重複的項目</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Not In Timeline</source>
        <translation>不在時間軸內</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Not In a Bin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preset</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="43"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="73"/>
        <source>Save</source>
        <translation>儲存</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="87"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="111"/>
        <source>Save Preset</source>
        <translation>儲存預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="121"/>
        <source>Name:</source>
        <translation>名稱：</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="147"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="185"/>
        <source>OK</source>
        <translation>確定</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="152"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="197"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="165"/>
        <source>Delete Preset</source>
        <translation>刪除預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="175"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>確定要刪除 %1？</translation>
    </message>
</context>
<context>
    <name>ProducerPreviewWidget</name>
    <message>
        <location filename="../src/widgets/producerpreviewwidget.cpp" line="168"/>
        <source>Play</source>
        <translation>播放</translation>
    </message>
</context>
<context>
    <name>PulseAudioWidget</name>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="26"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
</context>
<context>
    <name>QImageJob</name>
    <message>
        <location filename="../src/jobs/qimagejob.cpp" line="34"/>
        <source>Make proxy for %1</source>
        <translation>為 %1 製作代理素材</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="38"/>
        <source>Append playlist item %1</source>
        <translation>附加播放清單項目 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="65"/>
        <source>Insert playist item %1</source>
        <translation>插入播放清單項目 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="92"/>
        <source>Update playlist item %1</source>
        <translation>更新播放清單項目 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="135"/>
        <source>Remove playlist item %1</source>
        <translation>移除播放清單項目 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="158"/>
        <source>Clear playlist</source>
        <translation>清除播放清單</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="203"/>
        <source>Move item from %1 to %2</source>
        <translation>將項目從 %1 移動到 %2</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="226"/>
        <source>Sort playlist by %1</source>
        <translation>以 %1 排序播放清單</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="273"/>
        <source>Trim playlist item %1 in</source>
        <translation>修剪播放清單項目 %1 起點</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="311"/>
        <source>Trim playlist item %1 out</source>
        <translation>修剪播放清單項目 %1 終點</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="350"/>
        <source>Replace playlist item %1</source>
        <translation>取代播放清單項目 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="381"/>
        <source>Add new bin: %1</source>
        <translation>新增列表 %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/playlistcommands.cpp" line="427"/>
        <source>Move %n item(s) to bin: %1</source>
        <translation>
            <numerusform>移動 %n 個項目至列表 %1</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="462"/>
        <source>Remove bin: %1</source>
        <translation>移除列表 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="464"/>
        <source>Rename bin: %1</source>
        <translation>重新命名列表 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="97"/>
        <source>Append to track</source>
        <translation>附加至軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="103"/>
        <source>Append to Timeline</source>
        <translation>附加至時間軸</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="105"/>
        <source>Preparing</source>
        <translation>正在準備</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="120"/>
        <source>Appending</source>
        <translation>正在附加</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="136"/>
        <source>Finishing</source>
        <translation>正在完成</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="166"/>
        <source>Insert into track</source>
        <translation>插入到軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="185"/>
        <location filename="../src/commands/timelinecommands.cpp" line="251"/>
        <source>Add Files</source>
        <translation>新增檔案</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="238"/>
        <source>Overwrite onto track</source>
        <translation>覆寫至軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="287"/>
        <source>Lift from track</source>
        <translation>從軌道提除</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="321"/>
        <source>Remove from track</source>
        <translation>從軌道移除</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="402"/>
        <source>Group %n clips</source>
        <translation>
            <numerusform>群組 %n 部短片</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="455"/>
        <source>Ungroup %n clips</source>
        <translation>
            <numerusform>取消群組 %n 部短片</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="496"/>
        <source>Change track name</source>
        <translation>變更軌道名稱</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="521"/>
        <source>Merge adjacent clips</source>
        <translation>合併相鄰短片</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="544"/>
        <source>Toggle track mute</source>
        <translation>切換軌道靜音</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="565"/>
        <source>Toggle track hidden</source>
        <translation>切換軌道隱藏</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="590"/>
        <source>Change track compositing</source>
        <translation>變更軌道結合模式</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="615"/>
        <source>Lock track</source>
        <translation>鎖定軌道</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="676"/>
        <source>Move %n timeline clips</source>
        <translation>
            <numerusform>移動 %n 部時間軸短片</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="678"/>
        <source>Move timeline clip</source>
        <translation>移動時間軸短片</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="903"/>
        <source>Trim clip in point</source>
        <translation>修剪短片起點</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1013"/>
        <source>Trim clip out point</source>
        <translation>修剪短片終點</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1118"/>
        <source>Split clip</source>
        <translation>分割短片</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1120"/>
        <source>Split clips</source>
        <translation>分割短片</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1157"/>
        <source>Adjust fade in</source>
        <translation>調整淡入</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1192"/>
        <source>Adjust fade out</source>
        <translation>調整淡出</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1238"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1429"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1620"/>
        <source>Add transition</source>
        <translation>新增轉場效果</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1321"/>
        <source>Trim transition in point</source>
        <translation>修剪轉場效果起點</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1373"/>
        <source>Trim transition out point</source>
        <translation>修剪轉場效果終點</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1485"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1552"/>
        <source>Remove transition</source>
        <translation>移除轉場效果</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1664"/>
        <source>Add video track</source>
        <translation>新增視訊軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1666"/>
        <source>Add audio track</source>
        <translation>新增音訊軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1710"/>
        <source>Insert audio track</source>
        <translation>插入音訊軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1712"/>
        <source>Insert video track</source>
        <translation>插入視訊軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1749"/>
        <source>Remove audio track</source>
        <translation>移除音訊軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1751"/>
        <source>Remove video track</source>
        <translation>移除視訊軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1821"/>
        <source>Move track down</source>
        <translation>向下移動軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1823"/>
        <source>Move track up</source>
        <translation>向上移動軌道</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1847"/>
        <source>Change track blend mode</source>
        <translation>變更軌道混合模式</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1889"/>
        <source>Change clip properties</source>
        <translation>變更短片屬性</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1958"/>
        <source>Detach Audio</source>
        <translation>分離音訊</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2109"/>
        <source>Replace timeline clip</source>
        <translation>取代時間軸短片</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2138"/>
        <source>Align clips to reference track</source>
        <translation>向參考軌道對齊短片</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2219"/>
        <source>Apply copied filters</source>
        <translation>套用複製的濾鏡</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4084"/>
        <source>You cannot add a project to itself!</source>
        <translation>不能把專案加進其本身！</translation>
    </message>
    <message>
        <location filename="../src/mltxmlchecker.cpp" line="118"/>
        <source>The file is not a MLT XML file.</source>
        <translation>檔案不是一個 MLT XML 檔案。</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="95"/>
        <location filename="../src/util.cpp" line="142"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1050"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1140"/>
        <source>Unable to write file %1
Perhaps you do not have permission.
Try again with a different folder.</source>
        <translation>無法寫入檔案 %1
可能沒有所需的權限。
請選擇其他資料夾再試。</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="159"/>
        <source>Transition</source>
        <translation>轉場效果</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="161"/>
        <source>Track: %1</source>
        <translation>軌道：%1</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="163"/>
        <source>Output</source>
        <translation>輸出</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="326"/>
        <source>The value you entered is very similar to the common,
more standard %1 = %2/1001.

Do you want to use %1 = %2/1001 instead?</source>
        <translation>所輸入的值與更常用、更普遍的 %1 = %2/1001 非常接近。

要改用 %1 = %2/1001 嗎？</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="717"/>
        <source>The drive you chose only has %1 MiB of free space.
Do you still want to continue?</source>
        <translation>選擇的磁碟機只有 %1 MiB 的可用空間。
確定要繼續嗎？</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="725"/>
        <source>Do not show this anymore.</source>
        <comment>Export free disk space warning dialog</comment>
        <translation>不再顯示此提示。</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="761"/>
        <source>unknown (%1)</source>
        <translation>未知（%1）</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="764"/>
        <source>NA</source>
        <translation>不適用</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="815"/>
        <source>This file uses color transfer characteristics %1, which may result in incorrect colors or brightness in Shotcut.</source>
        <translation>此檔案使用了 %1 色彩轉換特性，在 Shotcut 中可能會產生不正確的色彩或亮度。</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="820"/>
        <source>This file is variable frame rate, which is not reliable for editing.</source>
        <translation>此檔案以變動影格播放速率編碼，無法用以穩定剪輯。</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="824"/>
        <source>This file does not support seeking and cannot be used for editing.</source>
        <translation>此檔案不支援搜尋，無法用於剪輯。</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="827"/>
        <source>This file format (HDV) is not reliable for editing.</source>
        <translation>此檔案格式（HDV）無法用以穩定剪輯。</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="843"/>
        <source> Do you want to convert it to an edit-friendly format?

If yes, choose a format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, it automatically replaces clips, or you can double-click the job to open it.
</source>
        <translation>要轉換成易於剪輯的格式嗎？

如果是，請在下方選擇一種格式，然後按下「確定」來選擇檔案名稱；在選擇檔案名稱後，會建立相對應的工作。當工作完成時，它會自動取代短片；你也可以按兩下工作來打開它。
</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="30"/>
        <location filename="../src/widgets/textproducerwidget.cpp" line="29"/>
        <source>transparent</source>
        <comment>Open Other &gt; Color</comment>
        <translation>透明</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3114"/>
        <source>Drop Files</source>
        <translation>置放檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3121"/>
        <source>Failed to open </source>
        <translation>無法開啟</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3137"/>
        <source>Not adding non-seekable file: </source>
        <translation>未新增不可搜尋的檔案：</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1250"/>
        <source>Generating Playlist for Bin</source>
        <translation>正在為列表產生播放清單</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1855"/>
        <source>Generate Slideshow</source>
        <translation>產生幻燈片秀</translation>
    </message>
    <message>
        <location filename="../src/proxymanager.cpp" line="366"/>
        <source>Make proxy for %1</source>
        <translation>為 %1 製作代理素材</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="67"/>
        <source>Converting Thumbnails</source>
        <translation>正在轉換縮圖</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="86"/>
        <source>Please wait for this one-time update to the thumbnail cache...</source>
        <translation>縮圖快取正在進行一次性的更新，請稍候…</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="30"/>
        <source>Delete marker: %1</source>
        <translation>刪除標記點 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="49"/>
        <source>Add marker: %1</source>
        <translation>新增標記點 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="73"/>
        <source>Move marker: %1</source>
        <translation>移動標記點 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="75"/>
        <source>Edit marker: %1</source>
        <translation>編輯標記點 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="115"/>
        <source>Clear markers</source>
        <translation>清除標記點</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="43"/>
        <source>transparent</source>
        <comment>Open Other &gt; Animation</comment>
        <translation>透明</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="637"/>
        <source>Edit With Glaxnimate</source>
        <translation>使用 Glaxnimate 編輯</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="43"/>
        <source>Playlist Clip: %1</source>
        <translation>播放清單短片：%1</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="46"/>
        <source>Track: %1, Clip: %2 (transition)</source>
        <translation>軌道：%1，短片：%2（轉場效果）</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="50"/>
        <source>Track: %1, Clip: %2</source>
        <translation>軌道：%1，短片：%2</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="289"/>
        <source>%1x%2</source>
        <translation>%1×%2</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="107"/>
        <source>Add %1 filter</source>
        <translation>新增「%1」濾鏡</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="109"/>
        <source>Add %1 filter set</source>
        <translation>新增「%1」濾鏡集</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="173"/>
        <source>Remove %1 filter</source>
        <translation>移除「%1」濾鏡</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="207"/>
        <source>Move %1 filter</source>
        <translation>移動「%1」濾鏡</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="247"/>
        <source>Disable %1 filter</source>
        <translation>停用「%1」濾鏡</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="249"/>
        <source>Enable %1 filter</source>
        <translation>啟用「%1」濾鏡</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="305"/>
        <source>Paste filters</source>
        <translation>貼上濾鏡</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="359"/>
        <source>Change %1 filter</source>
        <translation>變更「%1」濾鏡</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="361"/>
        <source>Change %1 filter: %2</source>
        <translation>變更「%1」濾鏡：%2</translation>
    </message>
    <message>
        <location filename="../src/models/audiolevelstask.cpp" line="183"/>
        <source>generating audio waveforms for</source>
        <translation>產生音訊波形予</translation>
    </message>
    <message>
        <location filename="../src/models/audiolevelstask.cpp" line="266"/>
        <source>Done</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="188"/>
        <source>add keyframe</source>
        <translation>新增關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="203"/>
        <source>remove keyframe</source>
        <translation>移除關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="220"/>
        <source>modify keyframe</source>
        <translation>修改關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="35"/>
        <source>Add subtitle track: %1</source>
        <translation>新增字幕軌道 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="55"/>
        <source>Remove subtitle track: %1</source>
        <translation>移除字幕軌道 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="83"/>
        <source>Edit subtitle track: %1</source>
        <translation>編輯字幕軌道 %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="106"/>
        <source>Add subtitle</source>
        <translation>新增字幕</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="108"/>
        <source>Add %n subtitles</source>
        <translation>
            <numerusform>新增 %n 字幕</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="162"/>
        <source>Remove %n subtitles</source>
        <translation>
            <numerusform>移除 %n 字幕</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="301"/>
        <source>Move %n subtitles</source>
        <translation>
            <numerusform>移動 %n 字幕</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="160"/>
        <source>Remove subtitle</source>
        <translation>移除字幕</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="190"/>
        <source>Edit subtitle text</source>
        <translation>編輯字幕文字</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="225"/>
        <source>Change subtitle start</source>
        <translation>變更字幕起點</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="259"/>
        <source>Change subtitle end</source>
        <translation>變更字幕終點</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="299"/>
        <source>Move subtitle</source>
        <translation>移動字幕</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/subtitlesdock.cpp" line="504"/>
        <source>Imported %1 subtitle item(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="606"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="621"/>
        <source>Importing subtitles...</source>
        <translation>正在匯入字幕…</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/subtitlesdock.cpp" line="642"/>
        <source>Imported %n subtitle item(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="494"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="637"/>
        <source>No subtitles found to import</source>
        <translation>找不到任何可匯入的字幕</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="311"/>
        <location filename="../src/models/subtitlesmodel.cpp" line="326"/>
        <source>Import %1 subtitle items</source>
        <translation>匯入 %1 字幕項目</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="366"/>
        <source>Append subtitle</source>
        <translation>附加字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1335"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1059"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1149"/>
        <source>A job already exists for %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QmlApplication</name>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="133"/>
        <source>Select a filter to copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="212"/>
        <source>&lt;p&gt;Do you really want to add filters to &lt;b&gt;Output&lt;/b&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timeline &gt; Output&lt;/b&gt; is currently selected. Adding filters to &lt;b&gt;Output&lt;/b&gt; affects ALL clips in the timeline including new ones that will be added.&lt;/p&gt;</source>
        <translation>&lt;p&gt;確定要對&lt;b&gt;「輸出」&lt;/b&gt;添加濾鏡嗎？&lt;/p&gt;&lt;p&gt;目前選取的項目是&lt;b&gt;「時間軸」→「輸出」&lt;/b&gt;。將濾鏡套用到&lt;b&gt;「輸出」&lt;/b&gt;，會影響時間軸上目前、以及之後新增的「所有」短片。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="222"/>
        <source>Do not show this anymore.</source>
        <comment>confirm output filters dialog</comment>
        <translation>不再顯示此提示。</translation>
    </message>
</context>
<context>
    <name>QmlEditMenu</name>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="32"/>
        <source>Undo</source>
        <translation>復原</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="38"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="47"/>
        <source>Cut</source>
        <translation>剪裁</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="53"/>
        <source>Copy</source>
        <translation>複製</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="58"/>
        <source>Paste</source>
        <translation>貼上</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="64"/>
        <source>Paste Text Only</source>
        <translation>僅貼上文字</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="70"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="76"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="84"/>
        <source>Select All</source>
        <translation>全選</translation>
    </message>
</context>
<context>
    <name>QmlFilter</name>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="394"/>
        <source>(defaults)</source>
        <translation>（預設）</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="518"/>
        <source>Analyze %1</source>
        <translation>分析 %1</translation>
    </message>
</context>
<context>
    <name>QmlMarkerMenu</name>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="62"/>
        <source>Edit...</source>
        <translation>編輯…</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="67"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="72"/>
        <source>Choose Color...</source>
        <translation>選擇色彩…</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="86"/>
        <source>Choose Recent Color</source>
        <translation>選擇最近使用的色彩</translation>
    </message>
</context>
<context>
    <name>QmlRichText</name>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="141"/>
        <source>Cannot save: </source>
        <translation>無法儲存：</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="172"/>
        <source>Row</source>
        <translation>列</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="174"/>
        <source>Column</source>
        <translation>欄</translation>
    </message>
</context>
<context>
    <name>QmlRichTextMenu</name>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="30"/>
        <source>File</source>
        <translation>檔案</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="32"/>
        <source>Open...</source>
        <translation>開啟…</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="36"/>
        <source>Save As...</source>
        <translation>另存為…</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="40"/>
        <source>Edit</source>
        <translation>編輯</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="42"/>
        <source>Undo</source>
        <translation>復原</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="47"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="54"/>
        <source>Cut</source>
        <translation>剪裁</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="59"/>
        <source>Copy</source>
        <translation>複製</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="64"/>
        <source>Paste</source>
        <translation>貼上</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="69"/>
        <source>Paste Text Only</source>
        <translation>僅貼上文字</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="74"/>
        <source>Select All</source>
        <translation>全選</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="79"/>
        <source>Insert Table</source>
        <translation>插入表格</translation>
    </message>
</context>
<context>
    <name>RecentDock</name>
    <message>
        <location filename="../src/docks/recentdock.ui" line="24"/>
        <source>Recent</source>
        <translation>最近使用</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="46"/>
        <source>Show only files with name matching text</source>
        <translation>只顯示名稱匹配文字的檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="49"/>
        <source>search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="76"/>
        <location filename="../src/docks/recentdock.ui" line="79"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
</context>
<context>
    <name>ResourceDialog</name>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="35"/>
        <source>Resources</source>
        <translation>資源</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="47"/>
        <source>Convert Selected</source>
        <translation>轉換選取的資源</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="98"/>
        <source>No resources to convert</source>
        <translation>無資源可轉換</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="103"/>
        <source>Choose an edit-friendly format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, double-click the job to open it.
</source>
        <translation>請在下方選擇一種易於剪輯的格式，然後按下「確定」以選擇檔案名稱，並建立相對應的工作。當工作完成時，按兩下以打開轉換後的檔案。
</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="108"/>
        <source>Convert...</source>
        <translation>轉換…</translation>
    </message>
</context>
<context>
    <name>ResourceModel</name>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="266"/>
        <source>%1MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="281"/>
        <source>%1 %2x%3 %4fps</source>
        <translation>%1 %2×%3 %4fps</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="392"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="394"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="396"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="398"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
</context>
<context>
    <name>SaveDefaultButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SaveDefaultButton.qml" line="27"/>
        <source>Set as default</source>
        <translation>設為預設值</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../src/dialogs/saveimagedialog.cpp" line="47"/>
        <source>PNG (*.png);;BMP (*.bmp);;JPEG (*.jpg *.jpeg);;PPM (*.ppm);;TIFF (*.tif *.tiff);;WebP (*.webp);;All Files (*)</source>
        <translation>PNG (*.png);;BMP (*.bmp);;JPEG (*.jpg *.jpeg);;PPM (*.ppm);;TIFF (*.tif *.tiff);;WebP (*.webp);;所有檔案 (*)</translation>
    </message>
</context>
<context>
    <name>ScopeController</name>
    <message>
        <location filename="../src/controllers/scopecontroller.cpp" line="41"/>
        <source>Scopes</source>
        <translation>示波器</translation>
    </message>
</context>
<context>
    <name>ServicePresetWidget</name>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="25"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="45"/>
        <source>Save</source>
        <translation>儲存</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="52"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="80"/>
        <source>(defaults)</source>
        <translation>（預設）</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="87"/>
        <source>Save Preset</source>
        <translation>儲存預設設定</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="88"/>
        <source>Name:</source>
        <translation>名稱：</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="173"/>
        <source>Delete Preset</source>
        <translation>刪除預設設定</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="174"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>確定要刪除 %1？</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="58"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="59"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="66"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="67"/>
        <source>Set to default</source>
        <translation>設為預設值</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="76"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="77"/>
        <source>Clear shortcut</source>
        <translation>清除快速鍵</translation>
    </message>
</context>
<context>
    <name>ShotcutActions</name>
    <message>
        <location filename="../src/actions.cpp" line="52"/>
        <source>Other</source>
        <translation>其他</translation>
    </message>
</context>
<context>
    <name>ShotcutSettings</name>
    <message>
        <location filename="../src/settings.cpp" line="104"/>
        <source>Old (before v23) Layout</source>
        <translation>舊（23 版以前的）版面配置</translation>
    </message>
</context>
<context>
    <name>SimplePropertyUI</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SimplePropertyUI.qml" line="15"/>
        <source>Custom Properties</source>
        <translation>自訂屬性</translation>
    </message>
</context>
<context>
    <name>SizePositionUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="338"/>
        <source>Bottom Left</source>
        <translation>左下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="342"/>
        <source>Bottom Right</source>
        <translation>右下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="346"/>
        <source>Top Left</source>
        <translation>左上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="350"/>
        <source>Top Right</source>
        <translation>右上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="356"/>
        <source>Slide In From Left</source>
        <translation>從左滑入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="358"/>
        <source>Slide In From Right</source>
        <translation>從右滑入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="360"/>
        <source>Slide In From Top</source>
        <translation>從上滑入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="362"/>
        <source>Slide In From Bottom</source>
        <translation>從下滑入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="366"/>
        <source>Slide Out Left</source>
        <translation>向左滑出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="368"/>
        <source>Slide Out Right</source>
        <translation>向右滑出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="370"/>
        <source>Slide Out Top</source>
        <translation>向上滑出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="372"/>
        <source>Slide Out Bottom</source>
        <translation>向下滑出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="377"/>
        <source>Slow Zoom In</source>
        <translation>緩慢放大</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="379"/>
        <source>Slow Zoom Out</source>
        <translation>緩慢縮小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="381"/>
        <source>Slow Pan Left</source>
        <translation>緩慢向左平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="382"/>
        <source>Slow Move Left</source>
        <translation>緩慢左移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="384"/>
        <source>Slow Pan Right</source>
        <translation>緩慢向右平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="385"/>
        <source>Slow Move Right</source>
        <translation>緩慢右移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="387"/>
        <source>Slow Pan Up</source>
        <translation>緩慢向上平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="388"/>
        <source>Slow Move Up</source>
        <translation>緩慢上移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="390"/>
        <source>Slow Pan Down</source>
        <translation>緩慢向下平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="391"/>
        <source>Slow Move Down</source>
        <translation>緩慢下移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="393"/>
        <source>Slow Zoom In, Pan Up Left</source>
        <translation>緩慢放大，向左上平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="394"/>
        <source>Slow Zoom In, Move Up Left</source>
        <translation>緩慢放大，往左上移動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="396"/>
        <source>Slow Zoom In, Pan Down Right</source>
        <translation>緩慢放大，向右下平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="397"/>
        <source>Slow Zoom In, Move Down Right</source>
        <translation>緩慢放大，往右下移動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="399"/>
        <source>Slow Zoom Out, Pan Up Right</source>
        <translation>緩慢縮小，向右上平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="400"/>
        <source>Slow Zoom Out, Move Up Right</source>
        <translation>緩慢縮小，往右上移動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="402"/>
        <source>Slow Zoom Out, Pan Down Left</source>
        <translation>緩慢縮小，向左下平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="403"/>
        <source>Slow Zoom Out, Move Down Left</source>
        <translation>緩慢縮小，往左下移動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="405"/>
        <source>Slow Zoom In, Hold Bottom</source>
        <translation>緩慢放大，底部固定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="407"/>
        <source>Slow Zoom In, Hold Top</source>
        <translation>緩慢放大，頂部固定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="409"/>
        <source>Slow Zoom In, Hold Left</source>
        <translation>緩慢放大，左側固定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="411"/>
        <source>Slow Zoom In, Hold Right</source>
        <translation>緩慢放大，右側固定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="413"/>
        <source>Slow Zoom Out, Hold Bottom</source>
        <translation>緩慢縮小，底部固定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="415"/>
        <source>Slow Zoom Out, Hold Top</source>
        <translation>緩慢縮小，頂部固定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="417"/>
        <source>Slow Zoom Out, Hold Left</source>
        <translation>緩慢縮小，左側固定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="419"/>
        <source>Slow Zoom Out, Hold Right</source>
        <translation>緩慢縮小，右側固定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="487"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="522"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="632"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="707"/>
        <source>Zoom</source>
        <translation>縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="755"/>
        <source>Size mode</source>
        <translation>縮放模式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="762"/>
        <source>Fit</source>
        <translation>適合</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="776"/>
        <source>Fill</source>
        <translation>填滿</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="796"/>
        <source>Distort</source>
        <translation>變形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="824"/>
        <source>Horizontal fit</source>
        <translation>水平位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="831"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="843"/>
        <source>Center</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="855"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="879"/>
        <source>Vertical fit</source>
        <translation>垂直位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="886"/>
        <source>Top</source>
        <translation>上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="898"/>
        <source>Middle</source>
        <comment>Size and Position video filter</comment>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="910"/>
        <source>Bottom</source>
        <translation>下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="934"/>
        <source>Rotation</source>
        <translation>旋轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="947"/>
        <source> °</source>
        <comment>degrees</comment>
        <translation> °</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="974"/>
        <source>Background color</source>
        <translation>背景色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="425"/>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="430"/>
        <source>Shake 1 Second - Scaled</source>
        <translation>搖動 1 秒－放大</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="427"/>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="432"/>
        <source>Shake 1 Second - Unscaled</source>
        <translation>搖動 1 秒－不放大</translation>
    </message>
</context>
<context>
    <name>SizePositionVUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionVUI.qml" line="156"/>
        <source>Click in rectangle + hold Shift to drag, Wheel to zoom, or %1+Wheel to rotate</source>
        <translation>按住矩形後長壓 Shift 即可拖曳，滾動滾輪縮放，或者是按 %1 後滾動滾輪來旋轉。</translation>
    </message>
</context>
<context>
    <name>SlideshowGeneratorDialog</name>
    <message numerus="yes">
        <location filename="../src/dialogs/slideshowgeneratordialog.cpp" line="33"/>
        <source>Slideshow Generator - %n Clips</source>
        <translation>
            <numerusform>幻燈片秀產生器：%n 部短片</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>SlideshowGeneratorWidget</name>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="58"/>
        <source>Clip duration</source>
        <translation>短片長度</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="60"/>
        <source>Set the duration of each clip in the slideshow.</source>
        <translation>設定幻燈片秀中每個短片的長度。</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="69"/>
        <source>Aspect ratio conversion</source>
        <translation>外觀比例轉換</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="71"/>
        <source>Pad Black</source>
        <translation>以黑色填補</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="72"/>
        <source>Crop Center</source>
        <translation>裁剪置中</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="73"/>
        <source>Crop and Pan</source>
        <translation>裁剪並平移</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="77"/>
        <source>Pad Blur</source>
        <translation>以模糊填補</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="80"/>
        <source>Choose an aspect ratio conversion method.</source>
        <translation>選擇外觀比例轉換的方式。</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="89"/>
        <source>Zoom effect</source>
        <translation>縮放效果</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="92"/>
        <source>Set the percentage of the zoom-in effect.
0% will result in no zoom effect.</source>
        <translation>設定放大效果的百分比。
0% 將不會產生縮放效果。</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="100"/>
        <source>Transition duration</source>
        <translation>轉場效果長度</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="103"/>
        <source>Set the duration of the transition.
May not be longer than half the duration of the clip.
If the duration is 0, no transition will be created.</source>
        <translation>設定轉場效果長度。
不可長於短片長度的一半。
若長度為 0，則不會建立任何轉場效果。</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="116"/>
        <source>Transition type</source>
        <translation>轉場效果類型</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="119"/>
        <source>Random</source>
        <translation>隨機</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="120"/>
        <source>Cut</source>
        <translation>剪裁</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="121"/>
        <source>Dissolve</source>
        <translation>溶解</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="122"/>
        <source>Bar Horizontal</source>
        <translation>水平抹除</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="123"/>
        <source>Bar Vertical</source>
        <translation>垂直抹除</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="124"/>
        <source>Barn Door Horizontal</source>
        <translation>水平對開</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="125"/>
        <source>Barn Door Vertical</source>
        <translation>垂直對開</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="126"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>斜角對開－左下至右上</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="127"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>斜角對開－左上至右下</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="128"/>
        <source>Diagonal Top Left</source>
        <translation>對角線，左上</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="129"/>
        <source>Diagonal Top Right</source>
        <translation>對角線，右上</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="130"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>水平矩陣</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="131"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>垂直矩陣</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="132"/>
        <source>Matrix Snake Horizontal</source>
        <translation>水平矩陣－蛇形</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="133"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>水平矩陣－蛇形對消</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="134"/>
        <source>Matrix Snake Vertical</source>
        <translation>垂直矩陣－蛇形</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="135"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>垂直矩陣－蛇形對消</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="136"/>
        <source>Barn V Up</source>
        <translation>V 字對開</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="137"/>
        <source>Iris Circle</source>
        <translation>虹膜</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="138"/>
        <source>Double Iris</source>
        <translation>雙瞳</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="139"/>
        <source>Iris Box</source>
        <translation>矩形</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="140"/>
        <source>Box Bottom Right</source>
        <translation>消去－右下</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="141"/>
        <source>Box Bottom Left</source>
        <translation>消去－左下</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="142"/>
        <source>Box Right Center</source>
        <translation>消去－右中</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="143"/>
        <source>Clock Top</source>
        <translation>順時針</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="147"/>
        <source>Choose a transition effect.</source>
        <translation>選擇轉場效果。</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="155"/>
        <source>Transition softness</source>
        <translation>轉場效果柔邊</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="157"/>
        <source>Change the softness of the edge of the wipe.</source>
        <translation>調整擦除畫面時的柔邊程度。</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="499"/>
        <source>Preview is not available with GPU Effects</source>
        <translation>無法於 GPU 效果下提供預覽</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="500"/>
        <source>Generating Preview...</source>
        <translation>正在產生預覽…</translation>
    </message>
</context>
<context>
    <name>SpeedUI</name>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="96"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>按住 %1 以限制在垂直方向拖曳關鍵影格，或 %2 以限制在水平方向</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="108"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="130"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="134"/>
        <source>Map the specified speed to the current time. Use keyframes to vary the speed mappings over time.</source>
        <translation>將指定的速度對應至目前時間。以關鍵影格調整速度隨時間的映射方式。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="158"/>
        <source>Image mode</source>
        <translation>影像模式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="162"/>
        <source>Use the specified image selection mode. Nearest will output the image that is nearest to the mapped time. Blend will blend all images that occur during the mapped time.</source>
        <translation>使用指定的影像選擇模式。「最接近」會輸出最接近對應時間的影像；「混合」會混合所有在對應時間內產生的影像。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="181"/>
        <source>Nearest</source>
        <translation>最接近</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="186"/>
        <source>Blend</source>
        <translation>混合</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="201"/>
        <source>Enable pitch compensation</source>
        <translation>啟用音高補償</translation>
    </message>
</context>
<context>
    <name>SubtitleBar</name>
    <message>
        <location filename="../src/qml/views/timeline/SubtitleBar.qml" line="73"/>
        <source>Unable to move. Subtitles already exist at this time.</source>
        <translation>無法移動。此時間點已有字幕存在。</translation>
    </message>
</context>
<context>
    <name>SubtitleTrackDialog</name>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="54"/>
        <source>New Subtitle Track</source>
        <translation>新增字幕軌道</translation>
    </message>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="58"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="63"/>
        <source>Language</source>
        <translation>語言</translation>
    </message>
</context>
<context>
    <name>SubtitlesDock</name>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="131"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="177"/>
        <source>Subtitles</source>
        <translation>字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="147"/>
        <source>Add clips to the Timeline to begin editing subtitles.</source>
        <translation>新增短片至「時間軸」以開始編輯字幕。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="178"/>
        <source>Tracks</source>
        <translation>軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="198"/>
        <source>Columns</source>
        <translation>欄位</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="199"/>
        <source>Start</source>
        <translation>開始</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="202"/>
        <source>End</source>
        <translation>結束</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="205"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="211"/>
        <source>Subtitle Controls</source>
        <translation>「字幕」控制項</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="217"/>
        <source>Subtitles Menu</source>
        <translation>「字幕」功能表</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="268"/>
        <source>Previous</source>
        <translation>前一項</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="270"/>
        <source>Current</source>
        <translation>目前</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="272"/>
        <source>Next</source>
        <translation>後一項</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="304"/>
        <source>Add Subtitle Track</source>
        <translation>新增字幕軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="307"/>
        <source>Add a subtitle track</source>
        <translation>新增字幕軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="315"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="545"/>
        <source>Remove Subtitle Track</source>
        <translation>移除字幕軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="318"/>
        <source>Remove this subtitle track</source>
        <translation>移除此字幕軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="326"/>
        <source>Edit Subtitle Track</source>
        <translation>編輯字幕軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="329"/>
        <source>Edit this subtitle track</source>
        <translation>編輯此字幕軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="337"/>
        <source>Import Subtitles From File</source>
        <translation>從檔案匯入字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="340"/>
        <source>Import subtitles from an srt file at the current position</source>
        <translation>由 SRT 檔案匯入字幕至目前位置</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="348"/>
        <source>Export Subtitles To File</source>
        <translation>匯出字幕至檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="351"/>
        <source>Export the current subtitle track to an SRT file</source>
        <translation>將目前的字幕軌道匯出成 SRT 檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="359"/>
        <source>Create/Edit Subtitle</source>
        <translation>建立／編輯字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="363"/>
        <source>Create or Edit a subtitle at the cursor position.</source>
        <translation>於游標位置建立或編輯字幕。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="367"/>
        <source>Add Subtitle Item</source>
        <translation>新增字幕項目</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="371"/>
        <source>Add a subtitle at the cursor position</source>
        <translation>於游標位置新增字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="375"/>
        <source>Remove Subtitle Item</source>
        <translation>移除字幕項目</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="379"/>
        <source>Remove the selected subtitle item</source>
        <translation>移除選取的字幕項目</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="383"/>
        <source>Set Subtitle Start</source>
        <translation>設定字幕起點</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="388"/>
        <source>Set the selected subtitle to start at the cursor position</source>
        <translation>將所選字幕的起點設於游標位置</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="392"/>
        <source>Set Subtitle End</source>
        <translation>設定字幕終點</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="397"/>
        <source>Set the selected subtitle to end at the cursor position</source>
        <translation>將所選字幕的終點設於游標位置</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="401"/>
        <source>Move Subtitles</source>
        <translation>移動字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="405"/>
        <source>Move the selected subtitles to the cursor position</source>
        <translation>將所選字幕移動至游標位置</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="409"/>
        <source>Burn In Subtitles on Output</source>
        <translation>輸出時壓製字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="410"/>
        <source>Create or edit a Burn In Subtitles filter on the timeline output.</source>
        <translation>於時間軸輸出上建立或編輯「字幕壓製」濾鏡。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="415"/>
        <source>Generate Text on Timeline</source>
        <translation>於時間軸上產生文字</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="417"/>
        <source>Create a new video track on the timeline with text showing these subtitles.</source>
        <translation>在時間軸上建立新視訊軌道以呈現字幕文字。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="421"/>
        <source>Speech to Text...</source>
        <translation>語音轉換文字…</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="422"/>
        <source>Detect speech and transcribe to a new subtitle track.</source>
        <translation>偵測語音並將其轉錄至新的字幕軌道。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="428"/>
        <source>Track Timeline Cursor</source>
        <translation>追蹤時間軸游標</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="429"/>
        <source>Track the timeline cursor</source>
        <translation>追蹤時間軸的游標</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="437"/>
        <source>Show Previous/Next</source>
        <translation>顯示前後項目</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="438"/>
        <source>Show the previous and next subtitles</source>
        <translation>顯示前一項與後一項字幕</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="511"/>
        <source>Add a clip to the timeline to create subtitles.</source>
        <translation>新增短片至時間軸以建立字幕。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1067"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1069"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1089"/>
        <source>Subtitle Track %1</source>
        <translation>字幕軌道 %1</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1131"/>
        <source>Generate subtitle text on timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1132"/>
        <source>Text style preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1134"/>
        <source>Default subtitle style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1277"/>
        <source>Extracting Audio</source>
        <translation>正在擷取音訊</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1295"/>
        <source>Speech to Text</source>
        <translation>語音轉換文字</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="522"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="575"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1226"/>
        <source>Subtitle track already exists: %1</source>
        <translation>字幕軌道已存在：%1</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="546"/>
        <source>This track is in use by a subtitle filter.
Remove the subtitle filter before removing this track.</source>
        <translation>仍有字幕濾鏡在使用此軌道。
在移除此軌道前，請先移除字幕濾鏡。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="592"/>
        <source>Import Subtitle File</source>
        <translation>匯入字幕檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="594"/>
        <source>Subtitle Files (*.srt *.SRT *.vtt *.VTT *.ass *.ASS *.ssa *.SSA)</source>
        <translation>字幕檔案 (*.srt *.SRT *.vtt *.VTT *.ass *.ASS *.ssa *.SSA)</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="602"/>
        <source>Unable to find subtitle file.</source>
        <translation>找不到字幕檔案。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="650"/>
        <source>Export SRT File</source>
        <translation>匯出 SRT 檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="652"/>
        <source>SRT Files (*.srt *.SRT)</source>
        <translation>SRT 檔案 (*.srt *.SRT)</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="717"/>
        <source>A subtitle already exists at this time.</source>
        <translation>此時間點已有字幕存在。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="727"/>
        <source>Not enough space to add subtitle.</source>
        <translation>空間不足以新增字幕。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="764"/>
        <source>Start time can not be after end time.</source>
        <translation>開始時間不能晚於結束時間。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="770"/>
        <source>Start time can not be before previous subtitle.</source>
        <translation>開始時間不能早於前一項字幕。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="788"/>
        <source>End time can not be before start time.</source>
        <translation>結束時間不能早於開始時間。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="795"/>
        <source>End time can not be after next subtitle.</source>
        <translation>結束時間不能晚於後一項字幕。</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="817"/>
        <source>Unable to move. Subtitles already exist at this time.</source>
        <translation>無法移動。此時間點已有字幕存在。</translation>
    </message>
</context>
<context>
    <name>SubtitlesModel</name>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="818"/>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="820"/>
        <source>Start</source>
        <translation>開始</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="822"/>
        <source>End</source>
        <translation>結束</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="824"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
</context>
<context>
    <name>SystemSyncDialog</name>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="14"/>
        <source>Player Synchronization</source>
        <translation>播放器同步</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="20"/>
        <source>Adjust your playback audio/video synchronization</source>
        <translation>調整音訊／視訊播放同步速率</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="48"/>
        <source>Reset to default value 0</source>
        <translation>重設至預設值 0</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="65"/>
        <source>Video offset</source>
        <translation>視訊時差</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="75"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="82"/>
        <source> ms</source>
        <translation> 毫秒</translation>
    </message>
</context>
<context>
    <name>TextEditor</name>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="41"/>
        <source>Decrease Text Size</source>
        <translation>減少文字大小</translation>
    </message>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="44"/>
        <location filename="../src/docks/notesdock.cpp" line="49"/>
        <source>Notes</source>
        <translation>筆記</translation>
    </message>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="46"/>
        <source>Increase Text Size</source>
        <translation>增加文字大小</translation>
    </message>
</context>
<context>
    <name>TextFilterUi</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="78"/>
        <source>Bold</source>
        <translation>粗體</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="80"/>
        <source>Italic</source>
        <translation>斜體</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="208"/>
        <source>Font</source>
        <translation>字型</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="267"/>
        <source>Use font size</source>
        <translation>使用字型大小</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="282"/>
        <source>Outline</source>
        <translation>外框</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="303"/>
        <source>Thickness</source>
        <translation>粗細</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="318"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="339"/>
        <source>Padding</source>
        <translation>間距</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="354"/>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="384"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="461"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="520"/>
        <source>Horizontal fit</source>
        <translation>水平位置</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="527"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="535"/>
        <source>Center</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="543"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="560"/>
        <source>Vertical fit</source>
        <translation>垂直位置</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="567"/>
        <source>Top</source>
        <translation>上</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="575"/>
        <source>Middle</source>
        <comment>Text video filter</comment>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="583"/>
        <source>Bottom</source>
        <translation>下</translation>
    </message>
</context>
<context>
    <name>TextFilterVui</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterVui.qml" line="85"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>按住矩形後長壓 Shift 即可拖曳</translation>
    </message>
</context>
<context>
    <name>TextProducerWidget</name>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="26"/>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="39"/>
        <source>Type or paste the text here</source>
        <translation>在這裡輸入或貼上文字</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="48"/>
        <source>Background color...</source>
        <translation>背景色彩…</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="61"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="88"/>
        <source>Simple</source>
        <translation>簡易</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="98"/>
        <source>Rich</source>
        <translation>帶格式</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="120"/>
        <source>Text attributes are available in the &lt;b&gt;Filters&lt;/b&gt; panel after clicking &lt;b&gt;OK&lt;/b&gt;.</source>
        <translation>按下&lt;b&gt;「確定」&lt;/b&gt;後，可在&lt;b&gt;「濾鏡」&lt;/b&gt;面板修改文字屬性。</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="59"/>
        <source>black</source>
        <translation>黑色</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="61"/>
        <source>transparent</source>
        <translation>透明</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="179"/>
        <location filename="../src/widgets/textproducerwidget.cpp" line="212"/>
        <source>Edit your text using the Filters panel.</source>
        <translation>在「濾鏡」面板編輯文字。</translation>
    </message>
</context>
<context>
    <name>TextViewerDialog</name>
    <message>
        <location filename="../src/dialogs/textviewerdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>對話方塊</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="35"/>
        <source>Copy</source>
        <translation>複製</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="64"/>
        <source>Save Text</source>
        <translation>儲存文字</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="65"/>
        <source>Text Documents (*.txt);;All Files (*)</source>
        <translation>文字文件 (*.txt);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="67"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;所有檔案 (*)</translation>
    </message>
</context>
<context>
    <name>TiledItemDelegate</name>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="123"/>
        <source>Duration: %1</source>
        <translation>長度：%1</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="128"/>
        <source>Date: %1</source>
        <translation>日期：%1</translation>
    </message>
</context>
<context>
    <name>TimeSpinner</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="70"/>
        <source>Decrement</source>
        <translation>減少</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="99"/>
        <source>Increment</source>
        <translation>增加</translation>
    </message>
</context>
<context>
    <name>TimelineDock</name>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="83"/>
        <location filename="../src/docks/timelinedock.cpp" line="94"/>
        <source>Timeline</source>
        <translation>時間軸</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1704"/>
        <source>This track is locked</source>
        <translation>此軌道已鎖定</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1709"/>
        <source>You cannot add a non-seekable source.</source>
        <translation>無法新增不可搜尋的來源。</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2107"/>
        <location filename="../src/docks/timelinedock.cpp" line="2141"/>
        <source>Track %1 was not moved</source>
        <translation>軌道 %1 沒有被移動</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2112"/>
        <source>Can not move audio track above video track</source>
        <translation>無法將音訊軌道移到視訊軌道的上方</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2128"/>
        <source>Can not move video track below audio track</source>
        <translation>無法將視訊軌道移到音訊軌道的下方</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1434"/>
        <location filename="../src/docks/timelinedock.cpp" line="2269"/>
        <source>Align To Reference Track</source>
        <translation>與參考軌道對齊</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="95"/>
        <source>Track Operations</source>
        <translation>軌道作業</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="107"/>
        <source>Track Height</source>
        <translation>軌道高度</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="112"/>
        <source>Selection</source>
        <translation>選取</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="125"/>
        <source>Edit</source>
        <translation>編輯</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="142"/>
        <source>View</source>
        <translation>檢視</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="148"/>
        <source>Marker</source>
        <translation>標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="158"/>
        <source>Timeline Clip</source>
        <translation>時間軸短片</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="182"/>
        <source>Timeline Controls</source>
        <translation>「時間軸」控制項</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="186"/>
        <source>Timeline Menu</source>
        <translation>「時間軸」功能表</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="377"/>
        <source>Add Audio Track</source>
        <translation>新增音訊軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="386"/>
        <source>Add Video Track</source>
        <translation>新增視訊軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="395"/>
        <source>Insert Track</source>
        <translation>插入軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="404"/>
        <source>Remove Track</source>
        <translation>移除軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="415"/>
        <source>Move Track Up</source>
        <translation>向上移動軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="426"/>
        <source>Move Track Down</source>
        <translation>向下移動軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="437"/>
        <source>Show/Hide Selected Track</source>
        <translation>顯示／隱藏所選軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="453"/>
        <source>Lock/Unlock Selected Track</source>
        <translation>鎖定／解除鎖定所選軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="472"/>
        <source>Mute/Unmute Selected Track</source>
        <translation>靜音／解除靜音所選軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="488"/>
        <source>Blend/Unblend Selected Track</source>
        <translation>混合／取消混合所選軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="506"/>
        <source>Make Tracks Shorter</source>
        <translation>縮矮軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="515"/>
        <source>Make Tracks Taller</source>
        <translation>增高軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="524"/>
        <source>Reset Track Height</source>
        <translation>重設軌道高度</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="533"/>
        <source>Select All</source>
        <translation>全選</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="544"/>
        <source>Select All On Current Track</source>
        <translation>於目前軌道上全選</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="555"/>
        <source>Select None</source>
        <translation>取消選取</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="567"/>
        <source>Select Next Clip</source>
        <translation>選取後一部短片</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="582"/>
        <source>Select Previous Clip</source>
        <translation>選取前一部短片</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="597"/>
        <source>Select Clip Above</source>
        <translation>選取上方短片</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="618"/>
        <source>Select Clip Below</source>
        <translation>選取下方短片</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="639"/>
        <source>Set Current Track Above</source>
        <translation>將上方軌道設為目前軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="648"/>
        <source>Set Current Track Below</source>
        <translation>將下方軌道設為目前軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="657"/>
        <source>Select Clip Under Playhead</source>
        <translation>選取播放點上的短片</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="672"/>
        <source>Cu&amp;t</source>
        <translation>剪下(&amp;T)</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="693"/>
        <source>&amp;Copy</source>
        <translation>複製(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="722"/>
        <source>&amp;Paste</source>
        <translation>貼上(&amp;P)</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="736"/>
        <source>Nudge Forward</source>
        <translation>向前微調</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="751"/>
        <source>Nudge Forward is not available</source>
        <translation>無法使用「向前微調」</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="773"/>
        <source>Nudge Backward</source>
        <translation>往回微調</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="783"/>
        <source>Nudge Backward is not available</source>
        <translation>無法使用「往回微調」</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="805"/>
        <source>Append</source>
        <translation>附加</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="816"/>
        <source>Ripple Delete</source>
        <translation>連動刪除</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="833"/>
        <source>Lift</source>
        <translation>提除</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="851"/>
        <source>Overwrite</source>
        <translation>覆寫</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="864"/>
        <source>Split At Playhead</source>
        <translation>於播放點分割</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="921"/>
        <source>Split All Tracks At Playhead</source>
        <translation>於播放點分割所有軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="952"/>
        <source>Replace</source>
        <translation>取代</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="971"/>
        <source>Create/Edit Marker</source>
        <translation>建立／編輯標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="984"/>
        <source>Previous Marker</source>
        <translation>前一個標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="998"/>
        <source>Next Marker</source>
        <translation>後一個標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1012"/>
        <source>Delete Marker</source>
        <translation>刪除標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1023"/>
        <source>Cycle Marker Color</source>
        <translation>輪替標記點色彩</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1039"/>
        <source>Create Marker Around Selected Clip</source>
        <translation>於所選短片兩端建立標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1050"/>
        <source>Rectangle Selection</source>
        <translation>矩形選取</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1061"/>
        <source>Automatically Add Tracks</source>
        <translation>自動新增軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1072"/>
        <source>Snap</source>
        <translation>貼齊</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1086"/>
        <source>Scrub While Dragging</source>
        <translation>拖曳時刮盤播放</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1099"/>
        <source>Ripple</source>
        <translation>連動</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1113"/>
        <source>Ripple All Tracks</source>
        <translation>連動所有軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1127"/>
        <source>Ripple Markers</source>
        <translation>連動標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1142"/>
        <source>Toggle Ripple And All Tracks</source>
        <translation>切換連動與連動所有軌道</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1150"/>
        <source>Toggle Ripple, All Tracks, And Markers</source>
        <translation>切換連動、連動所有軌道與標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1159"/>
        <source>Show Audio Waveforms</source>
        <translation>顯示音訊波形</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1173"/>
        <source>Use Higher Performance Waveforms</source>
        <translation>使用效能較佳的波形</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1189"/>
        <source>Show Video Thumbnails</source>
        <translation>顯示視訊縮圖</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1200"/>
        <source>No</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1213"/>
        <source>Page</source>
        <translation>頁面</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1226"/>
        <source>Smooth</source>
        <translation>平滑</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1239"/>
        <source>Center the Playhead</source>
        <translation>播放點置中</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1253"/>
        <source>Scroll to Playhead on Zoom</source>
        <translation>縮放時捲至播放點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1265"/>
        <source>Zoom Timeline Out</source>
        <translation>拉遠時間軸</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1276"/>
        <source>Zoom Timeline In</source>
        <translation>拉近時間軸</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1287"/>
        <source>Zoom Timeline To Fit</source>
        <translation>縮放時間軸至適當比例</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1299"/>
        <source>New Generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1307"/>
        <source>Color</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1309"/>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1313"/>
        <source>Animation</source>
        <translation>動畫</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1317"/>
        <source>Noise</source>
        <translation>雜訊</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1320"/>
        <source>Color Bars</source>
        <translation>彩條</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1324"/>
        <source>Audio Tone</source>
        <translation>音訊音調</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1327"/>
        <source>Count</source>
        <translation>計數</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1330"/>
        <source>Blip Flash</source>
        <translation>光點閃爍</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1353"/>
        <source>Properties</source>
        <translation>屬性</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1360"/>
        <source>Rejoin With Next Clip</source>
        <translation>與後一部短片重新聯結</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1376"/>
        <source>Detach Audio</source>
        <translation>分離音訊</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1404"/>
        <source>Freeze Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1454"/>
        <source>Apply Copied Filters</source>
        <translation>套用複製的濾鏡</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1478"/>
        <source>Update Thumbnails</source>
        <translation>更新縮圖</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1502"/>
        <source>Rebuild Audio Waveform</source>
        <translation>重建音訊波形</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1526"/>
        <source>Ripple Trim Clip In</source>
        <translation>連動修剪短片起點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1533"/>
        <source>Ripple Trim Clip Out</source>
        <translation>連動修剪短片終點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1540"/>
        <source>Group/Ungroup</source>
        <translation>群組／取消群組</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2367"/>
        <source>Append multiple to timeline</source>
        <translation>附加多個項目至時間軸</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2427"/>
        <source>Ripple delete transition</source>
        <translation>連動移除轉場效果</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2476"/>
        <source>Lift transition</source>
        <translation>提除轉場效果</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2551"/>
        <source>Cut %1 from timeline</source>
        <translation>從時間軸剪下 %1</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2553"/>
        <source>Remove %1 from timeline</source>
        <translation>從時間軸移除 %1</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2576"/>
        <source>Lift %1 from timeline</source>
        <translation>從時間軸提除 %1</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2927"/>
        <source>There is nothing in the Source player.</source>
        <translation>「來源」播放器裡沒有短片。</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2942"/>
        <source>You cannot replace a transition.</source>
        <translation>無法取代轉場效果。</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2972"/>
        <source>Select a clip in the timeline to create a marker around it</source>
        <translation>於時間軸上選取短片以在其兩端建立標記點</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2993"/>
        <source>Added marker: &quot;%1&quot;.</source>
        <translation>已新增標記點「%1」。</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3013"/>
        <source>Added marker: &quot;%1&quot;. Hold %2 and drag to create a range</source>
        <translation>已新增標記點「%1」。按住 %2 並拖曳以建立範圍。</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3129"/>
        <source>Failed to open </source>
        <translation>無法開啟</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3162"/>
        <source>Dropped Files</source>
        <translation>置放的檔案</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3207"/>
        <source>You cannot freeze a frame of a transition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3226"/>
        <source>Freeze Frame is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3260"/>
        <source>Insert Freeze Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3264"/>
        <source>The play head is not over the selected clip.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3616"/>
        <source>Insert multiple into timeline</source>
        <translation>插入多個項目至時間軸</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3755"/>
        <source>Overwrite multiple onto timeline</source>
        <translation>覆寫多個項目至時間軸</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="904"/>
        <location filename="../src/docks/timelinedock.cpp" line="936"/>
        <source>You cannot split a transition.</source>
        <translation>無法分割轉場效果。</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/timelinedock.cpp" line="4171"/>
        <source>Replace %n timeline clips</source>
        <translation>
            <numerusform>取代 %n 個時間軸短片</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4224"/>
        <source>voiceover</source>
        <translation>旁白</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4225"/>
        <source>Opus (*.opus);;All Files (*)</source>
        <translation>Opus (*.opus);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1336"/>
        <location filename="../src/docks/timelinedock.cpp" line="4227"/>
        <location filename="../src/docks/timelinedock.cpp" line="4343"/>
        <source>Record Audio</source>
        <translation>錄音</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4241"/>
        <source>Record Audio: %1</source>
        <translation>錄製音訊：%1</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4308"/>
        <source>Audio Recording In Progress</source>
        <translation>正在錄音</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4318"/>
        <source>Record Audio error: check PulseAudio settings</source>
        <translation>錄製音訊錯誤：請檢查 PulseAudio 設定</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4322"/>
        <source>Record Audio error: choose File &gt; Open Other &gt; Audio/Video Device</source>
        <translation>錄製音訊錯誤：選擇「檔案」→「開啟其他…」→「音訊／視訊裝置」</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4349"/>
        <source>Saving audio recording...</source>
        <translation>正在儲存錄音…</translation>
    </message>
</context>
<context>
    <name>TimelinePropertiesWidget</name>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="26"/>
        <source>Timeline</source>
        <translation>時間軸</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="104"/>
        <source>Frame rate</source>
        <translation>影格播放速率</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="246"/>
        <source>Edit...</source>
        <translation>編輯…</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="73"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="114"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="179"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="186"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="237"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="39"/>
        <source>Resolution</source>
        <translation>解析度</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="227"/>
        <source>Scan mode</source>
        <translation>掃描模式</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="169"/>
        <source>Aspect ratio</source>
        <translation>外觀比例</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="193"/>
        <source>Colorspace</source>
        <translation>色彩空間</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="39"/>
        <source>%L1 fps</source>
        <translation>%L1 fps</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="41"/>
        <source>Progressive</source>
        <translation>漸進式</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="43"/>
        <source>Interlaced</source>
        <translation>交錯式</translation>
    </message>
</context>
<context>
    <name>ToneProducerWidget</name>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="26"/>
        <source>Audio Tone</source>
        <translation>音訊音調</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>頻率</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="51"/>
        <source> Hz</source>
        <translation> Hz</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="80"/>
        <source>Level</source>
        <translation>位準</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="90"/>
        <source> dB</source>
        <translation> dB</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.cpp" line="98"/>
        <source>Tone: %1Hz %2dB</source>
        <translation>音調：%Hz %dB</translation>
    </message>
</context>
<context>
    <name>TrackHead</name>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="219"/>
        <source>Unmute</source>
        <translation>解除靜音</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="219"/>
        <source>Mute</source>
        <translation>靜音</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="236"/>
        <source>Show</source>
        <translation>顯示</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="236"/>
        <source>Hide</source>
        <translation>隱藏</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="183"/>
        <source>Unlock track</source>
        <translation>解除鎖定軌道</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="183"/>
        <source>Lock track</source>
        <translation>鎖定軌道</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="255"/>
        <source>Filters</source>
        <translation>濾鏡</translation>
    </message>
</context>
<context>
    <name>TrackPropertiesWidget</name>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="38"/>
        <source>Blend mode</source>
        <translation>混合模式</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="38"/>
        <source>Track: %1</source>
        <translation>軌道：%1</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="45"/>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="77"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="46"/>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="78"/>
        <source>Over</source>
        <translation>正常</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="47"/>
        <source>Add</source>
        <translation>新增…</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="48"/>
        <source>Saturate</source>
        <translation>飽和</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="49"/>
        <source>Multiply</source>
        <translation>色彩增值</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="50"/>
        <source>Screen</source>
        <translation>濾色</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="51"/>
        <source>Overlay</source>
        <translation>覆蓋</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="52"/>
        <source>Darken</source>
        <translation>變暗</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="53"/>
        <source>Dodge</source>
        <translation>加亮顏色</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="54"/>
        <source>Burn</source>
        <translation>加深顏色</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="55"/>
        <source>Hard Light</source>
        <translation>實光</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="56"/>
        <source>Soft Light</source>
        <translation>柔光</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="57"/>
        <source>Difference</source>
        <translation>差異化</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="58"/>
        <source>Exclusion</source>
        <translation>排除</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="59"/>
        <source>HSL Hue</source>
        <translation>HSL 色調</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="60"/>
        <source>HSL Saturation</source>
        <translation>HSL 飽和度</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="61"/>
        <source>HSL Color</source>
        <translation>HSL 色彩</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="62"/>
        <source>HSL Luminosity</source>
        <translation>HSL 明度</translation>
    </message>
</context>
<context>
    <name>TranscodeDialog</name>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="38"/>
        <source>good</source>
        <translation>良好</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="48"/>
        <source>better</source>
        <translation>較佳</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="58"/>
        <source>best</source>
        <translation>最佳</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="94"/>
        <source>medium</source>
        <translation>一般</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="136"/>
        <source>Do not show this anymore.</source>
        <comment>Convert to edit-friendly format dialog</comment>
        <translation>不再顯示此提示。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="206"/>
        <source>Change the frame rate from its source.</source>
        <translation>設定不同於來源的影格速率。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="262"/>
        <location filename="../src/dialogs/transcodedialog.ui" line="266"/>
        <source>Same as original</source>
        <translation>與原始來源相同</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="271"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="276"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="155"/>
        <source>This is useful when the source video is HDR (High Dynamic Range), which requires tone-mapping to the old, standard range.</source>
        <translation>當來源視訊是 HDR（高動態範圍）而需要對應至舊的標準範圍色調時十分實用。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="249"/>
        <source>Frame rate conversion</source>
        <translation>影格播放速率轉換</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="165"/>
        <source>This option converts only the trimmed portion of the source
clip plus a little instead of the entire clip. When this option is
used not all of the matching source clips are replaced, instead
only the currently selected one.</source>
        <translation>此選項僅轉換來源短片已修剪的部分再多一點點，而非整段短片。
當使用此選項時，只有目前選取的短片會被取代，而非對應的所有
來源短片。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="104"/>
        <source>BIG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="114"/>
        <source>&lt;span style=&quot; font-weight:700; color:#ff0000;&quot;&gt;HUGE&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="171"/>
        <source>Use sub-clip</source>
        <translation>使用子短片</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="219"/>
        <source>Sample rate</source>
        <translation>採樣速率</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="239"/>
        <source>If the source is interlaced, each interlaced field will be converted to a progressive frame resulting in double frame rate.</source>
        <translation>若來源為交錯式編碼，因每幅交錯式圖場都將轉換為漸進式影格，影格播放速率將變成兩倍。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="242"/>
        <source>Deinterlace</source>
        <translation>反交錯處理</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="178"/>
        <source>Enable this to keep the Advanced section open for the next time this dialog appears.</source>
        <translation>啟用此選項以保持「進階」區段在下次對話方塊出現時仍然開啟。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="181"/>
        <source>Keep Advanced open</source>
        <translation>保持「進階」開啟</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="148"/>
        <source>Override the frame rate to a specific value.</source>
        <translation>覆寫影格播放速率為指定的值。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="188"/>
        <source>Frame rate conversion method

Duplicate: Duplicate frames.
Blend: Blend frames.
Motion Compensation: Interpolate new frames using motion compensation. This method is very slow and may result in artifacts.</source>
        <translation>影格播放速率轉換方法

複製：複製影格。
混合：混合影格。
動態補償：以動態補償插入新的影格。此方法速度非常慢，並有可能產生偽影。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="209"/>
        <source>Override frame rate</source>
        <translation>覆寫影格播放速率</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="229"/>
        <source>Frames/sec</source>
        <translation>影格／秒</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="158"/>
        <source>Convert to BT.709 colorspace</source>
        <translation>轉換至 BT.709 色彩空間</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="34"/>
        <source>Convert to Edit-friendly...</source>
        <translation>轉換為編輯友善格式…</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="51"/>
        <source>Duplicate (fast)</source>
        <translation>複製（快）</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="52"/>
        <source>Blend</source>
        <translation>混合</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="53"/>
        <source>Motion Compensation (slow)</source>
        <translation>動態補償（慢）</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="56"/>
        <source>Advanced</source>
        <translation>進階</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="146"/>
        <source>Lossy: I-frame–only %1</source>
        <translation>失真：僅有 I 影格的 %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="150"/>
        <source>Intermediate: %1</source>
        <translation>適中：%1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="153"/>
        <source>Lossless: %1</source>
        <translation>不失真：%1</translation>
    </message>
</context>
<context>
    <name>Transcoder</name>
    <message>
        <location filename="../src/transcoder.cpp" line="58"/>
        <source>Sub-clip</source>
        <translation>子短片</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="58"/>
        <source>Converted</source>
        <translation>已轉換</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="66"/>
        <source>MP4 (*.mp4);;All Files (*)</source>
        <translation>MP4 (*.mp4);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="70"/>
        <source>MOV (*.mov);;All Files (*)</source>
        <translation>MOV (*.mov);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="74"/>
        <source>MKV (*.mkv);;All Files (*)</source>
        <translation>MKV (*.mkv);;所有檔案 (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="102"/>
        <location filename="../src/transcoder.cpp" line="138"/>
        <source>A job already exists for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="109"/>
        <location filename="../src/transcoder.cpp" line="120"/>
        <location filename="../src/transcoder.cpp" line="127"/>
        <source>Convert canceled</source>
        <translation>轉換已取消</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="349"/>
        <source>Convert %1</source>
        <translation>轉換 %1</translation>
    </message>
</context>
<context>
    <name>TranscribeAudioDialog</name>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="73"/>
        <source>Speech to Text</source>
        <translation>語音轉換文字</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="85"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="90"/>
        <source>Language</source>
        <translation>語言</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="116"/>
        <source>Translate to English</source>
        <translation>翻譯為英文</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="118"/>
        <source>Maximum line length</source>
        <translation>每行最大長度</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="128"/>
        <source>Include non-spoken sounds</source>
        <translation>包含非口語聲音</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="130"/>
        <source>Tracks with speech</source>
        <translation>語音來源軌道</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="131"/>
        <source>Select tracks that contain speech to be transcribed.</source>
        <translation>選取包含欲轉錄語音的軌道。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="180"/>
        <source>Whisper.cpp executable</source>
        <translation>Whisper.cpp 可執行檔</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="190"/>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="213"/>
        <source>Find Whisper.cpp</source>
        <translation>尋找 Whisper.cpp</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="203"/>
        <source>GGML Model</source>
        <translation>GGML 模型</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="232"/>
        <source>Configuration</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="326"/>
        <source>Path to Whisper.cpp executable</source>
        <translation>Whisper.cpp 可執行檔路徑</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="331"/>
        <source>Whisper.cpp executable not found</source>
        <translation>找不到 Whisper.cpp 可執行檔</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="337"/>
        <source>Path to GGML model</source>
        <translation>GGML 模型路徑</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="342"/>
        <source>GGML model not found</source>
        <translation>找不到 GGML 模型</translation>
    </message>
</context>
<context>
    <name>UndoButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/UndoButton.qml" line="28"/>
        <source>Reset to default</source>
        <translation>重設至預設值</translation>
    </message>
</context>
<context>
    <name>UnlinkedFilesDialog</name>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="14"/>
        <source>Missing Files</source>
        <translation>遺失檔案</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="26"/>
        <source>There are missing files in your project. Double-click each row to locate a file.</source>
        <translation>專案裡有遺失的檔案。在每一列上按兩下以尋找檔案。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="78"/>
        <source>This looks at every file in a folder to see if it matches any of the missing files.</source>
        <translation>這會掃描每個資料夾中檔案，以找出缺少的檔案。</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="81"/>
        <source>Search in Folder...</source>
        <translation>在資料夾中搜尋…</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="43"/>
        <source>Missing</source>
        <translation>遺失</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="44"/>
        <source>Replacement</source>
        <translation>取代為</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="58"/>
        <source>Open File</source>
        <translation>開啟檔案</translation>
    </message>
</context>
<context>
    <name>Video4LinuxWidget</name>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="14"/>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="36"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="43"/>
        <source>Set the path to the video device file</source>
        <translation>設定視訊裝置檔的路徑</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="46"/>
        <source>/dev/video0</source>
        <translation>/dev/video0</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="72"/>
        <source>Video4Linux</source>
        <translation>Video4Linux</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="82"/>
        <source>fps</source>
        <translation>fps</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="102"/>
        <source>Height</source>
        <translation>高</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="115"/>
        <source>Frame rate</source>
        <translation>影格播放速率</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="125"/>
        <source>Resolution</source>
        <translation>解析度</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="135"/>
        <source>Device</source>
        <translation>裝置</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="145"/>
        <source>TV Tuner</source>
        <translation>TV 調諧器</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="157"/>
        <source>Standard</source>
        <translation>標準</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="167"/>
        <source>Set the television standard</source>
        <translation>設定電視標準</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="171"/>
        <source>Automatic</source>
        <translation>自動</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="176"/>
        <source>NTSC</source>
        <translation>NTSC</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="181"/>
        <source>PAL</source>
        <translation>PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="186"/>
        <source>SECAM</source>
        <translation>SECAM</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="194"/>
        <source>Channel</source>
        <translation>頻道</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="213"/>
        <source>Audio Input</source>
        <translation>音訊輸入</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="223"/>
        <source>Width</source>
        <translation>寬</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="236"/>
        <source>pixels</source>
        <translation>像素</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="249"/>
        <source>X</source>
        <translation>×</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="257"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="262"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="267"/>
        <source>ALSA</source>
        <translation>ALSA</translation>
    </message>
</context>
<context>
    <name>VideoHistogramScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="103"/>
        <source>Luma</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="108"/>
        <source>Red</source>
        <translation>紅色</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="113"/>
        <source>Green</source>
        <translation>綠</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="118"/>
        <source>Blue</source>
        <translation>藍</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="205"/>
        <source>Value: %1
IRE: %2</source>
        <translation>數值：%1
IRE：%2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="207"/>
        <source>Value: %1</source>
        <translation>數值：%1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="215"/>
        <source>Video Histogram</source>
        <translation>視訊色階分佈圖</translation>
    </message>
</context>
<context>
    <name>VideoQualityJob</name>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="39"/>
        <source>Open</source>
        <translation>開啟</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="41"/>
        <source>Open original and encoded side-by-side in the Shotcut player</source>
        <translation>在 Shotcut 播放器並排開啟原檔與編碼後的檔案</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="45"/>
        <source>View Report</source>
        <translation>檢視報表</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="49"/>
        <source>Show In Files</source>
        <translation>在「檔案」中顯示</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="53"/>
        <source>Show In Folder</source>
        <translation>在資料夾中顯示</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="57"/>
        <source>Measure %1</source>
        <translation>測量 %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="96"/>
        <source>Video Quality Measurement</source>
        <translation>測量視訊品質</translation>
    </message>
</context>
<context>
    <name>VideoRgbParadeScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="132"/>
        <source>255</source>
        <translation>255</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="136"/>
        <source>191</source>
        <translation>191</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="140"/>
        <source>127</source>
        <translation>127</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="144"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="148"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="158"/>
        <source>Red</source>
        <translation>紅色</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="160"/>
        <source>Green</source>
        <translation>綠</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="162"/>
        <source>Blue</source>
        <translation>藍</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="173"/>
        <source>Channel: %1
Pixel: %2
Value: %3</source>
        <translation>頻道：%1
像素：%2
數值：%3</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="175"/>
        <source>Channel: %1
Value: %2</source>
        <translation>頻道：%1
像素：%2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="182"/>
        <source>Video RGB Parade</source>
        <translation>視訊 RGB 隊列</translation>
    </message>
</context>
<context>
    <name>VideoRgbWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="128"/>
        <source>255</source>
        <translation>255</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="132"/>
        <source>191</source>
        <translation>191</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="136"/>
        <source>127</source>
        <translation>127</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="140"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="144"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="159"/>
        <source>Pixel: %1
Value: %2</source>
        <translation>像素：%1
數值：%2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="161"/>
        <source>Value: %1</source>
        <translation>數值：%1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="168"/>
        <source>Video RGB Waveform</source>
        <translation>視訊 RGB 波形</translation>
    </message>
</context>
<context>
    <name>VideoVectorScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videovectorscopewidget.cpp" line="53"/>
        <source>Video Vector</source>
        <translation>視訊向量</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videovectorscopewidget.cpp" line="243"/>
        <source>U: %1
V: %2</source>
        <translation>U: %1
V: %2</translation>
    </message>
</context>
<context>
    <name>VideoWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="120"/>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="124"/>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="125"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="144"/>
        <source>Pixel: %1
IRE: %2</source>
        <translation>像素：%1
IRE：%2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="146"/>
        <source>IRE: %1</source>
        <translation>IRE：%1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="153"/>
        <source>Video Waveform</source>
        <translation>視訊波形</translation>
    </message>
</context>
<context>
    <name>VideoZoomScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="123"/>
        <source>x</source>
        <translation>×</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="125"/>
        <source>y</source>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="128"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="130"/>
        <source>G</source>
        <translation>G</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="132"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="135"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="137"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="139"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="157"/>
        <source>Pick a pixel from the source player</source>
        <translation>自來源播放器選取像素</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="164"/>
        <source>Lock/Unlock the selected pixel</source>
        <translation>鎖定／解除鎖定所選像素</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="273"/>
        <source>%1x</source>
        <translation>%1x</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="321"/>
        <source>Video Zoom</source>
        <translation>視訊縮放</translation>
    </message>
</context>
<context>
    <name>WhisperJob</name>
    <message>
        <location filename="../src/jobs/whisperjob.cpp" line="94"/>
        <source>SRT</source>
        <translation>SRT</translation>
    </message>
</context>
<context>
    <name>audioloudnessscope</name>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="186"/>
        <source>Momentary Loudness.</source>
        <translation>瞬時響度 (Momentary loudness)</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="229"/>
        <source>Short-term Loudness.</source>
        <translation>短期響度</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="272"/>
        <source>Integrated Loudness.</source>
        <translation>整體響度 (Integrated loudness)</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="315"/>
        <source>Loudness Range.</source>
        <translation>響度範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="358"/>
        <source>Peak.</source>
        <translation>峰值 (Peak)</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="401"/>
        <source>True Peak.</source>
        <translation>真實峰值 (True Peak)</translation>
    </message>
</context>
<context>
    <name>filterview</name>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="173"/>
        <source>Select a clip</source>
        <translation>選取短片</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="193"/>
        <source>Add a filter</source>
        <translation>新增濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="210"/>
        <source>Remove selected filter</source>
        <translation>移除選取的濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="232"/>
        <source>Copy filters</source>
        <translation>複製濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="247"/>
        <source>Paste filters</source>
        <translation>貼上濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="262"/>
        <source>Save a filter set</source>
        <translation>儲存濾鏡集</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="284"/>
        <source>Move filter up</source>
        <translation>向上移動濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="299"/>
        <source>Move filter down</source>
        <translation>向下移動濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="326"/>
        <source>Deselect the filter</source>
        <translation>取消選取濾鏡</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Fill the screen with the Shotcut window.</source>
        <translation>將 Shotcut 視窗填滿螢幕。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="158"/>
        <source>Hide upgrade prompt and menu item.</source>
        <translation>隱藏升級提示與功能表項目。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="162"/>
        <source>Run Glaxnimate instead of Shotcut.</source>
        <translation>執行 Glaxnimate 而非 Shotcut。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <source>Use GPU processing.</source>
        <translation>使用 GPU 處理。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="169"/>
        <source>Clear Recent on Exit</source>
        <translation>結束時清除最近開啟的項目</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="174"/>
        <source>The directory for app configuration and data.</source>
        <translation>應用程式存放組態與資料的目錄。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="175"/>
        <source>directory</source>
        <translation>目錄</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="179"/>
        <source>The scale factor for a high-DPI screen</source>
        <translation>用於高 DPI 螢幕的縮放比例</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="181"/>
        <source>number</source>
        <translation>數字</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="185"/>
        <source>A semicolon-separated list of scale factors for each screen</source>
        <translation>每台螢幕的縮放比例，以分號分隔</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="188"/>
        <source>list</source>
        <translation>列表</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="192"/>
        <source>How to handle a fractional display scale: %1</source>
        <translation>處理小數倍顯示縮放比例的方式：%1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="194"/>
        <location filename="../src/main.cpp" line="202"/>
        <location filename="../src/main.cpp" line="210"/>
        <source>string</source>
        <translation>字串</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="200"/>
        <location filename="../src/main.cpp" line="208"/>
        <source>Which operating system audio API to use: %1</source>
        <translation>要使用的作業系統音訊 API 為何：%1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="216"/>
        <source>Zero or more files or folders to open</source>
        <translation>開啟零或多個檔案或資料夾</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="460"/>
        <source>Loading plugins...</source>
        <translation>正在載入外掛程式…</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="437"/>
        <source>Expiring cache...</source>
        <translation>正在處理逾期快取…</translation>
    </message>
</context>
<context>
    <name>meta</name>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="22"/>
        <source>Alpha Channel: Adjust</source>
        <translation>Alpha 頻道：調整</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="23"/>
        <source>transparency shave shrink grow soft feather</source>
        <comment>search keywords for the Alpha Channel: Adjust video filter</comment>
        <translation>透明度 削切 縮小 放大 柔邊 羽化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="22"/>
        <source>Alpha Channel: View</source>
        <translation>Alpha 頻道：檢視</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="23"/>
        <source>transparency</source>
        <comment>search keywords for the Alpha Channel: View video filter</comment>
        <translation>透明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="7"/>
        <source>Balance</source>
        <translation>平衡</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="8"/>
        <source>pan channel mixer</source>
        <comment>search keywords for the Balance audio filter</comment>
        <translation>平移 聲道 混音器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="19"/>
        <location filename="../src/qml/filters/reframe/meta.qml" line="22"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="7"/>
        <source>Band Pass</source>
        <translation>帶通濾波</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the Band Pass audio filter</comment>
        <translation>頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="18"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="18"/>
        <source>Center Frequency</source>
        <translation>中心頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="26"/>
        <source>Bandwidth</source>
        <translation>頻寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/meta.qml" line="8"/>
        <source>Bass &amp; Treble</source>
        <translation>低音與高音</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="7"/>
        <source>Copy Channel</source>
        <translation>複製頻道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="8"/>
        <source>duplicate</source>
        <comment>search keywords for the Copy Channel audio filter</comment>
        <translation>重複</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="7"/>
        <source>Compressor</source>
        <translation>壓縮器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="8"/>
        <source>loudness dynamics range</source>
        <comment>search keywords for the Compressor audio filter</comment>
        <translation>響度 動態 範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="7"/>
        <source>Delay</source>
        <translation>延遲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="8"/>
        <source>time echo</source>
        <comment>search keywords for the Delay audio filter</comment>
        <translation>時間 回聲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="7"/>
        <source>Expander</source>
        <translation>擴展器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="8"/>
        <source>dynamics range</source>
        <comment>search keywords for the Expander audio filter</comment>
        <translation>動態 範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="8"/>
        <source>Fade In Audio</source>
        <translation>淡入音訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Fade In audio filter</comment>
        <translation>響度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="8"/>
        <source>Fade Out Audio</source>
        <translation>淡出音訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Fade Out audio filter</comment>
        <translation>響度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="7"/>
        <source>Gain / Volume</source>
        <translation>增益／音量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Gain/Volume audio filter</comment>
        <translation>響度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="20"/>
        <location filename="../src/qml/filters/brightness/meta.qml" line="20"/>
        <location filename="../src/qml/filters/contrast/meta.qml" line="21"/>
        <location filename="../src/qml/filters/dither/meta.qml" line="19"/>
        <location filename="../src/qml/filters/opacity/meta.qml" line="20"/>
        <location filename="../src/qml/filters/threshold/meta.qml" line="18"/>
        <source>Level</source>
        <translation>位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="7"/>
        <source>High Pass</source>
        <translation>高通濾波</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the High Pass audio filter</comment>
        <translation>頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="18"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="18"/>
        <source>Cutoff</source>
        <translation>截止</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="34"/>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="34"/>
        <source>Rolloff rate</source>
        <translation>滾落速率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="41"/>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="33"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="33"/>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="25"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="41"/>
        <source>Wetness</source>
        <translation>濕度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="7"/>
        <source>Limiter</source>
        <translation>限制器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="8"/>
        <source>dynamics range loudness</source>
        <comment>search keywords for the Limiter audio filter</comment>
        <translation>動態 範圍 響度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="7"/>
        <source>Low Pass</source>
        <translation>低通濾波</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the Low Pass audio filter</comment>
        <translation>頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="7"/>
        <source>Downmix</source>
        <translation>降混</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="8"/>
        <source>stereo mixdown channel</source>
        <comment>search keywords for the Downmix audio filter</comment>
        <translation>立體聲 混音 頻道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="8"/>
        <source>Mute</source>
        <translation>靜音</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="9"/>
        <source>silent silence volume</source>
        <comment>search keywords for the Mute audio filter</comment>
        <translation>安靜 靜音 音量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="7"/>
        <source>Normalize: One Pass</source>
        <translation>正規化：一階段</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="8"/>
        <source>volume loudness gain dynamics</source>
        <comment>search keywords for the Normalize: One Pass audio filter</comment>
        <translation>音量 響度 增益 動態</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="7"/>
        <source>Normalize: Two Pass</source>
        <translation>正規化：兩階段</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="9"/>
        <source>volume loudness gain dynamics</source>
        <comment>search keywords for the Normalize: Two Pass audio filter</comment>
        <translation>音量 響度 增益 動態</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="7"/>
        <source>Notch</source>
        <translation>陷波濾波</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="8"/>
        <source>frequency pass</source>
        <comment>search keywords for the Notch audio filter</comment>
        <translation>頻率濾波</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="7"/>
        <source>Pan</source>
        <translation>平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="8"/>
        <source>stereo balance channel mixer</source>
        <comment>search keywords for the Pan audio filter</comment>
        <translation>立體聲 平衡 頻道 混音器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="7"/>
        <source>Reverb</source>
        <translation>殘響</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="9"/>
        <source>delay time echo</source>
        <comment>search keywords for the Reverb audio filter</comment>
        <translation>延遲 時間 回聲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="18"/>
        <source>Room size</source>
        <translation>房間大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="26"/>
        <source>Reverb time</source>
        <translation>殘響時間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="34"/>
        <source>Damping</source>
        <translation>阻尼</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="42"/>
        <source>Input bandwidth</source>
        <translation>輸入頻寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="50"/>
        <source>Dry signal level</source>
        <translation>乾訊號位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="58"/>
        <source>Early reflection level</source>
        <translation>早反射位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="66"/>
        <source>Tail level</source>
        <translation>尾聲位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="7"/>
        <source>Swap Channels</source>
        <translation>交換頻道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="9"/>
        <source>switch stereo</source>
        <comment>search keywords for the Swap Channels audio filter</comment>
        <translation>切換 立體聲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="23"/>
        <source>Chroma Key: Simple</source>
        <translation>色鍵：簡易</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="24"/>
        <source>green blue screen</source>
        <comment>search keywords for the Chroma Key: Simple video filter</comment>
        <translation>綠幕 藍幕 螢幕</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="6"/>
        <source>Brightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="8"/>
        <source>lightness value exposure</source>
        <comment>search keywords for the Brightness video filter</comment>
        <translation>明度 數值 曝光</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="6"/>
        <source>Color Grading</source>
        <translation>色階</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="7"/>
        <source>correct shadows lift midtones gamma highlights gain hue lightness brightness value</source>
        <comment>search keywords for the Color Grading video filter</comment>
        <translation>校正 陰影 提升 中間調 色差補正 gamma 亮部 增益 色調 亮度 明度 數值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="17"/>
        <source>Shadows (Lift)</source>
        <translation>陰影（提升）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="22"/>
        <source>Midtones (Gamma)</source>
        <translation>中間調（色差補正）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="27"/>
        <source>Highlights (Gain)</source>
        <translation>亮部（增益）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="6"/>
        <source>Contrast</source>
        <translation>對比</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="7"/>
        <source>variation value</source>
        <comment>search keywords for the Contrast video filter</comment>
        <translation>變異 數值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="6"/>
        <source>Old Film: Dust</source>
        <translation>老電影：灰塵</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="7"/>
        <source>noise dirt hair fiber</source>
        <comment>search keywords for the Old Film: Dust video filter</comment>
        <translation>雜訊 塵土 毛髮 纖維</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="7"/>
        <source>Text: Simple</source>
        <translation>文字：簡易</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="8"/>
        <source>type font timecode timestamp date filename</source>
        <comment>search keywords for the Text: Simple video filter</comment>
        <translation>字體 字型 時間碼 時間戳記 日期 檔名</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="25"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="40"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="26"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="25"/>
        <source>Font color</source>
        <translation>字型色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="31"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="46"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="32"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="31"/>
        <source>Outline</source>
        <translation>外框</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="37"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="52"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="38"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="37"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="20"/>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="20"/>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="36"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="35"/>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="20"/>
        <location filename="../src/qml/filters/richtext/meta.qml" line="21"/>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="20"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="21"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="20"/>
        <source>Position / Size</source>
        <translation>位置／尺寸</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="7"/>
        <source>Fade In Video</source>
        <translation>淡入視訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="8"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="8"/>
        <source>brightness lightness opacity alpha</source>
        <comment>search keywords for the Fade In video filter</comment>
        <translation>亮度 明度 不透明度 Alpha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="7"/>
        <source>Fade Out Video</source>
        <translation>淡出視訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="8"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="8"/>
        <source>brightness lightness opacity alpha</source>
        <comment>search keywords for the Fade Out video filter</comment>
        <translation>亮度 明度 不透明度 Alpha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="6"/>
        <source>Old Film: Grain</source>
        <translation>老電影：雜點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="7"/>
        <source>dots particles noise dirt</source>
        <comment>search keywords for the Old Film: Grain video filter</comment>
        <translation>點 粒子 雜訊 塵土</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="22"/>
        <source>Hue/Lightness/Saturation</source>
        <translation>色調／明度／飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="23"/>
        <source>color value desaturate grayscale</source>
        <comment>search keywords for the Hue/Lightness/Saturation video filter</comment>
        <translation>色彩 數值 去飽和 灰階</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="34"/>
        <source>Hue</source>
        <translation>色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="41"/>
        <source>Lightness</source>
        <translation>明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="48"/>
        <source>Saturation</source>
        <translation>飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="6"/>
        <source>Invert Colors</source>
        <translation>反轉色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="7"/>
        <source>reverse opposite negative</source>
        <comment>search keywords for the Invert Colors video filter</comment>
        <translation>反轉 相反 負片</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="22"/>
        <source>Key Spill: Advanced</source>
        <translation>溢色：進階</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="23"/>
        <source>chroma alpha clean suppress</source>
        <comment>search keywords for the Key Spill: Advanced video filter</comment>
        <translation>彩度 alpha 清理 抑制</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="22"/>
        <source>Lens Correction</source>
        <translation>鏡頭校正</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="23"/>
        <source>deform lens distort wide angle panoramic hemispherical fisheye</source>
        <comment>search keywords for the Lens Correction video filter</comment>
        <translation>變形 鏡頭 扭曲 廣 角度 全景 半球 魚眼</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="34"/>
        <source>X Center</source>
        <translation>X 中心</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="41"/>
        <source>Y Center</source>
        <translation>Y 中心</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="48"/>
        <source>Correction at Center</source>
        <translation>中心修正</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="55"/>
        <source>Correction at Edges</source>
        <translation>邊緣修正</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="6"/>
        <source>Old Film: Scratches</source>
        <translation>老電影：擦痕</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="7"/>
        <source>noise projector lines defect</source>
        <comment>search keywords for the Old Film: Scratches video filter</comment>
        <translation>雜訊 投影機 線條 缺陷</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/meta.qml" line="22"/>
        <source>LUT (3D)</source>
        <translation>LUT (3D)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/meta.qml" line="23"/>
        <source>lookup table color</source>
        <comment>search keywords for the LUT (3D) video filter</comment>
        <translation>查詢 表格 色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/meta.qml" line="6"/>
        <source>Mask</source>
        <translation>遮罩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="7"/>
        <source>360: Rectilinear to Equirectangular</source>
        <translation>360：直線至等距長方投影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="8"/>
        <source>spherical projection</source>
        <comment>search keywords for the 360: Rectilinear to Equirectangular video filter</comment>
        <translation>球面 投影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="20"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="17"/>
        <location filename="../src/qml/filters/nosync/meta.qml" line="26"/>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="41"/>
        <source>Horizontal</source>
        <translation>水平</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="27"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="24"/>
        <location filename="../src/qml/filters/nosync/meta.qml" line="19"/>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="34"/>
        <source>Vertical</source>
        <translation>垂直</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="7"/>
        <source>Mid-Side Matrix</source>
        <translation>中側矩陣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="8"/>
        <source>middle stereo microphone</source>
        <comment>search keywords for the Mid-Side Matrix audio filter</comment>
        <translation>中間 立體聲 麥克風</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="18"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="31"/>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="34"/>
        <source>Width</source>
        <translation>寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/meta.qml" line="38"/>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="41"/>
        <source>Height</source>
        <translation>高</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="6"/>
        <source>Mirror</source>
        <translation>鏡像</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="7"/>
        <source>horizontal flip transpose flop</source>
        <comment>search keywords for the Mirror video filter</comment>
        <translation>水平 翻轉 轉置 正反</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="22"/>
        <source>Mosaic</source>
        <translation>馬賽克</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="23"/>
        <source>pixelize pixelate</source>
        <comment>search keywords for the Mosaic video filter</comment>
        <translation>像素化 點陣化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="6"/>
        <source>Diffusion</source>
        <translation>擴散</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="7"/>
        <source>blur smooth clean beauty</source>
        <comment>search keywords for the Diffusion video filter</comment>
        <translation>模糊 平滑 乾淨 美化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="6"/>
        <source>Old Film: Projector</source>
        <translation>老電影：放映機</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="7"/>
        <source>glitch flashing brightness vertical slip</source>
        <comment>search keywords for the Old Film: Projector video filter</comment>
        <translation>脈衝干擾 閃爍 亮度 垂直 滑動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="43"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="58"/>
        <location filename="../src/qml/filters/opacity/meta.qml" line="7"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="44"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="43"/>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta.qml" line="8"/>
        <source>alpha transparent translucent</source>
        <comment>search keywords for the Opacity video filter</comment>
        <translation>alpha 透明 半透明</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="7"/>
        <source>Rotate and Scale</source>
        <translation>旋轉與縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="7"/>
        <source>matte stencil alpha rectangle ellipse circle triangle diamond</source>
        <comment>search keywords for the Mask: Simple Shape video filter</comment>
        <translation>遮片 模板 alpha 矩形 橢圓 圓形 三角形 菱形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="20"/>
        <source>Size &amp; Position</source>
        <translation>位置與尺寸</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="26"/>
        <location filename="../src/qml/filters/rotate/meta.qml" line="18"/>
        <source>Rotation</source>
        <translation>旋轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="25"/>
        <source>Scale</source>
        <translation>縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="33"/>
        <source>X offset</source>
        <translation>X 位移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="37"/>
        <source>Y offset</source>
        <translation>Y 位移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="22"/>
        <source>Chroma Key: Advanced</source>
        <translation>色鍵：進階</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="23"/>
        <source>green blue screen</source>
        <comment>search keywords for the Chroma Key: Advanced video filter</comment>
        <translation>綠幕 藍幕 螢幕</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="6"/>
        <source>Sepia Tone</source>
        <translation>棕褐色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="7"/>
        <source>color old photograph print</source>
        <comment>search keywords for the Sepia Tone video filter</comment>
        <translation>色彩 老舊 照片 印刷</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/meta.qml" line="6"/>
        <source>Sketch</source>
        <translation>素描</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/meta.qml" line="7"/>
        <source>drawing painting cartoon</source>
        <comment>search keywords for the Sketch video filter</comment>
        <translation>畫畫 繪圖 卡通</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="23"/>
        <source>Key Spill: Simple</source>
        <translation>溢色：簡易</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="24"/>
        <source>chroma alpha clean suppress</source>
        <comment>search keywords for the Key Spill: Simple video filter</comment>
        <translation>彩度 alpha 清理 抑制</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="6"/>
        <source>Stabilize</source>
        <translation>穩定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="7"/>
        <source>smooth deshake</source>
        <comment>search keywords for the Stabilize video filter</comment>
        <translation>平滑 防震</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="6"/>
        <source>Old Film: %1</source>
        <translation>老電影：%1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="7"/>
        <source>projector movie</source>
        <comment>search keywords for the Old Film: Technocolor video filter</comment>
        <translation>投影機 電影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/unpremultiply/meta.qml" line="22"/>
        <source>Unpremultiply Alpha</source>
        <translation>反預乘 Alpha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/unpremultiply/meta.qml" line="23"/>
        <source>disassociate associated straight</source>
        <comment>search keywords for the Unpremultiply Alpha video filter</comment>
        <translation>解除關聯 關聯 直接</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="6"/>
        <source>Wave</source>
        <translation>Wave</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="7"/>
        <source>distort deform frequency water warp bend</source>
        <comment>search keywords for the Wave video filter</comment>
        <translation>扭曲 變形 頻率 水波 翹曲 彎曲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="7"/>
        <source>Crop: Circle</source>
        <translation>裁剪：圓形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="8"/>
        <source>trim remove oval ellipse</source>
        <comment>search keywords for the Crop: Circle video filter</comment>
        <translation>修剪 移除 卵形 橢圓</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="26"/>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="18"/>
        <source>Color</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="6"/>
        <source>Halftone</source>
        <translation>網點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="7"/>
        <source>360: Hemispherical to Equirectangular</source>
        <translation>360：半球至等距長方投影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="9"/>
        <source>spherical projection dual fisheye</source>
        <comment>search keywords for the 360: Hemispherical to Equirectangular video filter</comment>
        <translation>球面 投影 雙重 魚眼</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="48"/>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="19"/>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="24"/>
        <location filename="../src/qml/filters/halftone/meta.qml" line="19"/>
        <source>Radius</source>
        <translation>半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="55"/>
        <source>Front X</source>
        <translation>前 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="62"/>
        <source>Front Y</source>
        <translation>前 Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="69"/>
        <source>Front Up</source>
        <translation>前 Up</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="76"/>
        <source>Back X</source>
        <translation>後 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="83"/>
        <source>Back Y</source>
        <translation>後 Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="90"/>
        <source>Back Up</source>
        <translation>後 Up</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="97"/>
        <source>Nadir Radius</source>
        <translation>天底半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="104"/>
        <source>Nadir Start</source>
        <translation>天底起點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="7"/>
        <source>noise dots newsprint</source>
        <comment>search keywords for the Halftone video filter</comment>
        <translation>雜訊 點 新聞紙</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="26"/>
        <source>Cyan</source>
        <translation>青色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="33"/>
        <source>Magenta</source>
        <translation>洋紅色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="40"/>
        <source>Yellow</source>
        <translation>黃</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="7"/>
        <source>Spot Remover</source>
        <translation>污點移除工具</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="8"/>
        <source>delogo dirt clean watermark</source>
        <comment>search keywords for the Spot Remover video filter</comment>
        <translation>去除標誌 塵土 清理 浮水印</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/meta.qml" line="7"/>
        <source>Timer</source>
        <translation>計時器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/meta.qml" line="8"/>
        <source>text seconds timestamp</source>
        <comment>search keywords for the Timer video filter</comment>
        <translation>文字 秒數 時間戳記</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="6"/>
        <source>Levels</source>
        <comment>Levels video filter</comment>
        <translation>等級</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="7"/>
        <source>gamma value black white color</source>
        <comment>search keywords for the Levels video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="18"/>
        <source>Input Black</source>
        <translation>輸入黑色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="25"/>
        <source>Input White</source>
        <translation>輸入白色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="32"/>
        <source>Gamma</source>
        <translation>色差補正</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="6"/>
        <source>Mask: Simple Shape</source>
        <translation>遮罩：簡易形狀</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_apply/meta.qml" line="6"/>
        <source>Mask: Apply</source>
        <translation>遮罩：套用</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_apply/meta.qml" line="7"/>
        <source>matte stencil alpha confine composite bounce</source>
        <comment>search keywords for the Mask: Apply video filter</comment>
        <translation>遮片 模板 alpha 約束 合成 移位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="6"/>
        <source>Mask: From File</source>
        <translation>遮罩：來自檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="7"/>
        <source>matte stencil alpha luma wipe custom</source>
        <comment>search keywords for the Mask: From File video filter</comment>
        <translation>遮片 模板 alpha 亮度 擦除 自訂</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="7"/>
        <source>Noise Gate</source>
        <translation>雜音閘</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="8"/>
        <source>hum hiss distortion clean</source>
        <comment>search keywords for the Noise Gate audio filter</comment>
        <translation>哼聲 嘶聲 失真 清理</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="18"/>
        <source>Key Filter: Low Frequency</source>
        <translation>濾波器：低頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="25"/>
        <source>Key Filter: High Frequency</source>
        <translation>濾波器：高頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="32"/>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="20"/>
        <location filename="../src/qml/filters/threshold/meta.qml" line="6"/>
        <source>Threshold</source>
        <translation>閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="39"/>
        <source>Attack</source>
        <translation>啟奏</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="46"/>
        <source>Hold</source>
        <translation>延持值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="53"/>
        <source>Decay</source>
        <translation>衰減</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="60"/>
        <source>Range</source>
        <translation>範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/meta.qml" line="7"/>
        <source>Audio Waveform Visualization</source>
        <translation>視覺化音訊波形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/meta.qml" line="8"/>
        <source>music visualizer reactive</source>
        <comment>search keywords for the Audio Waveform Visualization video filter</comment>
        <translation>音樂 視覺效果 反應</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="22"/>
        <source>Chroma Hold</source>
        <translation>固定飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="23"/>
        <source>color hue select choose pick</source>
        <comment>search keywords for the Chroma Hold video filter</comment>
        <translation>色彩 色調 選取 選擇 挑選</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="34"/>
        <source>Distance</source>
        <translation>距離</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="6"/>
        <source>Grid</source>
        <translation>方格</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="7"/>
        <source>repeat</source>
        <comment>search keywords for the Grid video filter</comment>
        <translation>重複</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="18"/>
        <source>Rows</source>
        <translation>列</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="25"/>
        <source>Columns</source>
        <translation>欄</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="22"/>
        <source>Distort</source>
        <translation>扭曲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="23"/>
        <source>deform wiggle wave</source>
        <comment>search keywords for the Distort video filter</comment>
        <translation>變形 搖擺 波動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="34"/>
        <source>Amplitude</source>
        <translation>振幅</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="41"/>
        <location filename="../src/qml/filters/glitch/meta.qml" line="34"/>
        <source>Frequency</source>
        <translation>頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="48"/>
        <source>Velocity</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="22"/>
        <source>Glitch</source>
        <translation>脈衝干擾</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="23"/>
        <source>defect broken distort</source>
        <comment>search keywords for the Glitch video filter</comment>
        <translation>缺陷 損壞 扭曲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="41"/>
        <source>Block height</source>
        <translation>區塊高度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="48"/>
        <source>Shift intensity</source>
        <translation>移位強度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="55"/>
        <source>Color intensity</source>
        <translation>色彩濃度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="22"/>
        <source>RGB Shift</source>
        <translation>RGB 移位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="23"/>
        <source>glitch chroma analog split</source>
        <comment>search keywords for the RGB Shift video filter</comment>
        <translation>脈衝干擾 彩度 類比 分割</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="22"/>
        <source>Blur: Exponential</source>
        <translation>模糊：指數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Exponential video filter</comment>
        <translation>柔化 隱蔽 隱藏</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="7"/>
        <source>360: Equirectangular to Stereographic</source>
        <translation>360：等距長方至球極平面投影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="8"/>
        <source>spherical projection tiny small planet</source>
        <comment>search keywords for the 360: Equirectangular to Stereographic video filter</comment>
        <translation>球面 投影 微小 小型 星球</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="49"/>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="35"/>
        <location filename="../src/qml/filters/blur_gaussian/meta.qml" line="34"/>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="35"/>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="35"/>
        <source>Amount</source>
        <translation>總量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta.qml" line="22"/>
        <source>Blur: Gaussian</source>
        <translation>模糊：高斯</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="22"/>
        <source>Blur: Low Pass</source>
        <translation>模糊：低通</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Low Pass video filter</comment>
        <translation>柔化 隱蔽 隱藏</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="6"/>
        <source>Crop: Source</source>
        <translation>裁剪：來源</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="7"/>
        <source>trim remove edges</source>
        <comment>search keywords for the Crop: Source video filter</comment>
        <translation>修剪 移除 邊緣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta.qml" line="6"/>
        <source>Flip</source>
        <translation>翻轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta.qml" line="7"/>
        <source>vertical flop transpose rotate</source>
        <comment>search keywords for the Flip video filter</comment>
        <translation>垂直 正反 轉置 旋轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="22"/>
        <source>Reduce Noise: HQDN3D</source>
        <translation>減少雜訊：HQDN3D</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="23"/>
        <source>denoise artifact dirt smooth</source>
        <comment>search keywords for the Reduce Noise: HQDN3D video filter</comment>
        <translation>去除雜訊 偽影 塵土 平滑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="34"/>
        <source>Spatial</source>
        <translation>空間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="41"/>
        <source>Temporal</source>
        <translation>時域</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_fast/meta.qml" line="22"/>
        <source>Noise: Fast</source>
        <translation>雜訊：快速</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_fast/meta.qml" line="23"/>
        <source>dirt grunge</source>
        <comment>search keywords for the Noise: Fast video filter</comment>
        <translation>塵土 髒污</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="22"/>
        <source>Noise: Keyframes</source>
        <translation>雜訊：關鍵影格</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="23"/>
        <source>dirt grunge</source>
        <comment>search keywords for the Noise: Keyframes video filter</comment>
        <translation>塵土 髒污</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="22"/>
        <source>Reduce Noise: Smart Blur</source>
        <translation>減少雜訊：智慧型模糊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="23"/>
        <source>denoise artifact clean</source>
        <comment>search keywords for the Reduce Noise: Smart Blur video filter</comment>
        <translation>去除雜訊 偽影 清理</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="7"/>
        <source>Crop: Rectangle</source>
        <translation>裁剪：矩形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="8"/>
        <source>trim remove square</source>
        <comment>search keywords for the Crop: Rectangle video filter</comment>
        <translation>修剪 移除 方形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="25"/>
        <source>Corner radius</source>
        <translation>圓角半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="32"/>
        <source>Padding color</source>
        <translation>間距色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/meta.qml" line="6"/>
        <source>Blend Mode</source>
        <translation>混合模式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/meta.qml" line="7"/>
        <source>blending composite porter duff</source>
        <comment>search keywords for the Blend Mode video filter</comment>
        <translation>混合模式 合成 porter duff</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/meta.qml" line="6"/>
        <source>Dither</source>
        <translation>遞色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/meta.qml" line="7"/>
        <source>noise dots</source>
        <comment>search keywords for the Dither video filter</comment>
        <translation>雜訊 點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="22"/>
        <source>Elastic Scale</source>
        <translation>彈性延展</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="23"/>
        <source>stretch nonlinear</source>
        <comment>search keywords for the Elastic Scale video filter</comment>
        <translation>延展 非線性</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="35"/>
        <source>Center</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="42"/>
        <source>Linear width</source>
        <translation>線性寬度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="49"/>
        <source>Linear scale factor</source>
        <translation>線性縮放倍數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="56"/>
        <source>Non-Linear scale factor</source>
        <translation>非線性縮放倍數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="6"/>
        <source>Posterize</source>
        <translation>色調分離</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="7"/>
        <source>reduce colors banding cartoon</source>
        <comment>search keywords for the Posterize video filter</comment>
        <translation>減少 色彩 頻段 卡通</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="19"/>
        <source>Levels</source>
        <comment>Posterize filter</comment>
        <translation>等級</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nervous/meta.qml" line="6"/>
        <source>Nervous</source>
        <translation>緊張</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nervous/meta.qml" line="7"/>
        <source>random shake twitch glitch</source>
        <comment>search keywords for the Nervous video filter</comment>
        <translation>隨機 搖動 抖動 脈衝干擾</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nosync/meta.qml" line="6"/>
        <source>No Sync</source>
        <translation>不同步</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nosync/meta.qml" line="7"/>
        <source>horizontal vertical synchronization slip analog</source>
        <comment>search keywords for the No Sync video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/trails/meta.qml" line="6"/>
        <source>Trails</source>
        <translation>軌跡</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/trails/meta.qml" line="7"/>
        <source>temporal mix psychedelic motion blur</source>
        <comment>search keywords for the Trails video filter</comment>
        <translation>時域 混合 迷幻 動態 模糊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="22"/>
        <source>Vertigo</source>
        <translation>眩暈</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="23"/>
        <source>temporal mix dizzy psychedelic</source>
        <comment>search keywords for the Vertigo video filter</comment>
        <translation>時域 混合 暈眩 迷幻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="35"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="41"/>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="42"/>
        <source>Zoom</source>
        <translation>縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="6"/>
        <source>Choppy</source>
        <translation>斷續</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="7"/>
        <source>fps framerate</source>
        <comment>search keywords for the Choppy video filter</comment>
        <translation>fps 影格播放速率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="19"/>
        <source>Repeat</source>
        <translation>重複</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/meta.qml" line="7"/>
        <source>Gradient</source>
        <translation>漸層</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/meta.qml" line="8"/>
        <source>graduated color spectrum</source>
        <comment>search keywords for the Gradient video filter</comment>
        <translation>梯度 色彩 頻譜</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/scanlines/meta.qml" line="6"/>
        <source>Scan Lines</source>
        <translation>掃描線</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/scanlines/meta.qml" line="7"/>
        <source>analog horizontal television</source>
        <comment>search keywords for the Scan Lines video filter</comment>
        <translation>類比 水平 電視</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="7"/>
        <source>360: Equirectangular Mask</source>
        <translation>360：等距長方投影遮罩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="9"/>
        <source>spherical matte stencil</source>
        <comment>search keywords for the 360: Equirectangular Mask video filter</comment>
        <translation>球面 遮片 模板</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="20"/>
        <source>Horizontal Start</source>
        <translation>水平起點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="27"/>
        <source>Horizontal End</source>
        <translation>水平終點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="34"/>
        <source>Vertical Start</source>
        <translation>垂直起點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="41"/>
        <source>Vertical End</source>
        <translation>垂直終點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="7"/>
        <source>360: Equirectangular to Rectilinear</source>
        <translation>360：等距長方至直線投影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="9"/>
        <source>spherical projection</source>
        <comment>search keywords for the 360: Equirectangular to Rectilinear video filter</comment>
        <translation>球面 投影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="7"/>
        <source>Ambisonic Decoder</source>
        <translation>Ambisonic 解碼器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="9"/>
        <source>spatial surround binaural</source>
        <comment>search keywords for the Ambisonic Decoder audio filter</comment>
        <translation>空間 立體環繞 雙耳立體聲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="20"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="21"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="21"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="20"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="21"/>
        <source>Yaw</source>
        <translation>偏航</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="27"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="28"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="28"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="27"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="28"/>
        <source>Pitch</source>
        <comment>rotation around the side-to-side axis (roll, pitch, yaw)</comment>
        <translation>俯仰</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="34"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="35"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="35"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="34"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="35"/>
        <source>Roll</source>
        <translation>滾轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="42"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="42"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="41"/>
        <source>FOV</source>
        <comment>field of view</comment>
        <translation>視野</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="49"/>
        <location filename="../src/qml/filters/fisheye/meta.qml" line="22"/>
        <source>Fisheye</source>
        <translation>魚眼效果</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="22"/>
        <source>Corner Pin</source>
        <translation>端點圖釘</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="23"/>
        <source>stretch distort pinch twist deform</source>
        <comment>search keywords for the Corner Pin video filter</comment>
        <translation>延展 扭曲 捏縮 扭轉 變形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="35"/>
        <source>Corners</source>
        <translation>端點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="40"/>
        <source>Stretch X</source>
        <translation>延伸 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="47"/>
        <source>Stretch Y</source>
        <translation>延伸 Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="54"/>
        <source>Feathering</source>
        <translation>羽化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/meta.qml" line="7"/>
        <source>360: Stabilize</source>
        <translation>360：穩定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/meta.qml" line="8"/>
        <source>spherical smooth deshake</source>
        <comment>search keywords for the 360: Stabilize video filter</comment>
        <translation>球面 平滑 防震</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="7"/>
        <source>360: Transform</source>
        <translation>360：變形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="9"/>
        <source>spherical yaw pitch roll</source>
        <comment>search keywords for the 360: Transform video filter</comment>
        <translation>球面 偏航 俯仰 滾轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/meta.qml" line="23"/>
        <source>Reduce Noise: Wavelet</source>
        <translation>減少雜訊：子波</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/meta.qml" line="24"/>
        <source>vague denoise artifact dirt</source>
        <comment>search keywords for the Reduce Noise: Wavelet video filter</comment>
        <translation>模糊 去除雜訊 偽影 塵土</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="7"/>
        <source>Text: Rich</source>
        <translation>文字：帶格式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="8"/>
        <source>type font format overlay</source>
        <comment>search keywords for the Text: Rich video filter</comment>
        <translation>打字 字型 格式 覆疊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="26"/>
        <source>Background color</source>
        <translation>背景色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="7"/>
        <source>Blur: Pad</source>
        <translation>模糊：填補</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="8"/>
        <source>pillar echo fill</source>
        <comment>search keywords for the Blur: Pad video filter</comment>
        <translation>柱狀 迴邊 填滿</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_invert/meta.qml" line="7"/>
        <source>Invert</source>
        <translation>反轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_invert/meta.qml" line="8"/>
        <source>phase</source>
        <comment>search keywords for the Invert audio filter</comment>
        <translation>相位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/meta.qml" line="22"/>
        <source>Reduce Noise: Quantization</source>
        <translation>減少雜訊：量化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/meta.qml" line="23"/>
        <source>denoise artifact postprocess compress</source>
        <comment>search keywords for the Reduce Noise: Quantization video filter</comment>
        <translation>去除雜訊 偽影 後處理 壓縮</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="7"/>
        <source>Time Remap</source>
        <translation>時間重新對應</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="8"/>
        <source>temporal speed ramp reverse fast slow motion</source>
        <comment>search keywords for the Time: Remap filter</comment>
        <translation>時域 速度 斜坡 反轉 快 慢 動態</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="21"/>
        <source>Time</source>
        <translation>時間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/meta.qml" line="23"/>
        <source>Deband</source>
        <translation>去除頻帶</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/meta.qml" line="24"/>
        <source>mean average median contour</source>
        <comment>search keywords for the Deband video filter</comment>
        <translation>均值 平均 中位數 輪廓</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="22"/>
        <source>GPS Text</source>
        <translation>GPS 文字</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="23"/>
        <source>gpx</source>
        <comment>search keywords for the GPS Text video filter</comment>
        <translation>gpx</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reflect/meta.qml" line="6"/>
        <source>Reflect</source>
        <translation>鏡像</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reflect/meta.qml" line="7"/>
        <source>mirror repeat</source>
        <comment>search keywords for the Reflect video filter</comment>
        <translation>鏡像 重複</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_chromakey/meta.qml" line="22"/>
        <source>Mask: Chroma Key</source>
        <translation>遮罩：色鍵</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_chromakey/meta.qml" line="23"/>
        <source>matte stencil alpha color</source>
        <comment>search keywords for the Mask: Chroma Key video filter</comment>
        <translation>遮片 模板 alpha 色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="7"/>
        <source>Equalizer: 15-Band</source>
        <translation>等化器：15 頻段</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: 15-Band audio filter</comment>
        <translation>音調 頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="19"/>
        <source>Equalizer</source>
        <translation>等化器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="7"/>
        <source>Equalizer: Parametric</source>
        <translation>等化器：參數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: Parametric audio filter</comment>
        <translation>音調 頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/meta.qml" line="7"/>
        <source>Audio Level Visualization</source>
        <translation>音訊位準視覺效果</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/meta.qml" line="8"/>
        <source>music visualizer reactive</source>
        <comment>search keywords for the Audio Level Visualization video filter</comment>
        <translation>音樂 視覺效果 反應</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="7"/>
        <source>Equalizer: 3-Band (Bass &amp; Treble)</source>
        <translation>等化器：3 頻段（低音與高音）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: 3-Band audio filter</comment>
        <translation>音調 頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="7"/>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="19"/>
        <source>Pitch</source>
        <comment>audio pitch or tone</comment>
        <translation>音高</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="9"/>
        <source>frequency tone</source>
        <comment>search keywords for the Pitch audio filter</comment>
        <translation>頻率 音調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/meta.qml" line="7"/>
        <source>Stereo Enhancer</source>
        <translation>立體聲強化器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/meta.qml" line="9"/>
        <source>channel spatial delay</source>
        <comment>search keywords for the Stereo Enhancer audio filter</comment>
        <translation>頻道 空間 延遲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/meta.qml" line="6"/>
        <source>Mask: Draw</source>
        <translation>遮罩：描繪</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/meta.qml" line="7"/>
        <source>rotoscope matte stencil alpha</source>
        <comment>search keywords for the Mask: Draw video filter</comment>
        <translation>投影描圖 遮片 模板 alpha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/meta.qml" line="23"/>
        <source>deform lens distort wide angle panoramic hemispherical</source>
        <comment>search keywords for the Fisheye video filter</comment>
        <translation>變形 鏡頭 扭曲 廣 角度 全景 半球</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="22"/>
        <source>GPS Graphic</source>
        <translation>GPS 圖形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="23"/>
        <source>gpx sticker decal gauge map graph speedometer</source>
        <comment>search keywords for the GPS Graphic video filter</comment>
        <translation>gpx 貼紙 印花 儀錶 地圖 圖表 速率計</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/threshold/meta.qml" line="7"/>
        <source>black white luma</source>
        <comment>search keywords for the Threshold video filter</comment>
        <translation>黑點 白點 亮度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/meta.qml" line="6"/>
        <source>Motion Tracker</source>
        <translation>動態追蹤</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/meta.qml" line="8"/>
        <source>tracking</source>
        <comment>search keywords for the Motion Tracker video filter</comment>
        <translation>追踪</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/meta.qml" line="7"/>
        <source>Track Auto Fade Audio</source>
        <translation>軌道自動淡化音訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/meta.qml" line="8"/>
        <source>click splice fade</source>
        <comment>search keywords for the Auto Fade audio filter</comment>
        <translation>按一下 剪接 淡出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/meta.qml" line="7"/>
        <source>Track Seam</source>
        <translation>軌道斷縫</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/meta.qml" line="8"/>
        <source>click splice seam</source>
        <comment>search keywords for the Seam audio filter</comment>
        <translation>按一下 剪接 縫隙</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/meta.qml" line="6"/>
        <source>Declick Audio</source>
        <translation>去除喀擦聲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/meta.qml" line="8"/>
        <source>declick crackle pop</source>
        <comment>search keywords for the Declick audio filter</comment>
        <translation>去除喀擦聲 劈啪聲 爆音</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/meta.qml" line="7"/>
        <source>Track Auto Fade Video</source>
        <translation>軌道自動淡化視訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/meta.qml" line="8"/>
        <source>splice fade dip</source>
        <comment>search keywords for the Track Auto Fade Video filter</comment>
        <translation>剪接 淡出 下沈</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="7"/>
        <source>Ambisonic Encoder</source>
        <translation>Ambisonic 編碼器</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="9"/>
        <source>spatial surround panner</source>
        <comment>search keywords for the Ambisonic Encoder audio filter</comment>
        <translation>空間 立體環繞 平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="20"/>
        <source>Azimuth</source>
        <translation>方位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="27"/>
        <source>Elevation</source>
        <translation>仰角</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="6"/>
        <source>Drop Shadow</source>
        <translation>陰影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="7"/>
        <source></source>
        <comment>search keywords for the Drop Shadow video filter</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="31"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="38"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="22"/>
        <source>Vibrance</source>
        <translation>鮮豔度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="23"/>
        <source>color intensity saturation vibe</source>
        <comment>search keywords for the Vibrance video filter</comment>
        <translation>色彩 濃度 飽和度 氛圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="34"/>
        <source>Intensity</source>
        <translation>濃度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="41"/>
        <source>Red</source>
        <translation>紅色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="48"/>
        <source>Green</source>
        <translation>綠</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="55"/>
        <source>Blue</source>
        <translation>藍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="7"/>
        <source>Subtitle Burn In</source>
        <translation>字幕壓製</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="8"/>
        <source>subtitle overlay burn</source>
        <comment>search keywords for the Subtitle Burn In video filter</comment>
        <translation>字幕 覆疊 壓製</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/meta.qml" line="7"/>
        <source>Reframe</source>
        <translation>重新編碼影格</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/meta.qml" line="8"/>
        <source>crop trim remove square vertical portrait</source>
        <comment>search keywords for the Reframe video filter</comment>
        <translation>裁剪 修剪 移除 方形 垂直 縱向</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/meta.qml" line="7"/>
        <source>Gradient Map</source>
        <translation>漸層</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/meta.qml" line="8"/>
        <source>color mapping intensity</source>
        <comment>search keywords for the Gradient Map video filter</comment>
        <translation>色彩 映射 濃度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="6"/>
        <source>HSL Primaries</source>
        <translation>HSL 原色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="8"/>
        <source>hue saturation lightness color</source>
        <comment>search keywords for the HSL Primaries video filter</comment>
        <translation>色調 飽和度 明度 色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="18"/>
        <source>Overlap</source>
        <translation>重疊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="25"/>
        <source>Red Hue</source>
        <translation>紅色色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="32"/>
        <source>Red Saturation</source>
        <translation>紅色飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="39"/>
        <source>Red Lightness</source>
        <translation>紅色明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="46"/>
        <source>Yellow Hue</source>
        <translation>黃色色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="53"/>
        <source>Yellow Saturation</source>
        <translation>黃色飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="60"/>
        <source>Yellow Lightness</source>
        <translation>黃色明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="67"/>
        <source>Green Hue</source>
        <translation>綠色色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="74"/>
        <source>Green Saturation</source>
        <translation>綠色飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="81"/>
        <source>Green Lightness</source>
        <translation>綠色明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="88"/>
        <source>Cyan Hue</source>
        <translation>青色色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="95"/>
        <source>Cyan Saturation</source>
        <translation>青色飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="102"/>
        <source>Cyan Lightness</source>
        <translation>青色明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="109"/>
        <source>Blue Hue</source>
        <translation>藍色色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="116"/>
        <source>Blue Saturation</source>
        <translation>藍色飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="123"/>
        <source>Blue Lightness</source>
        <translation>藍色明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="130"/>
        <source>Magenta Hue</source>
        <translation>洋紅色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="137"/>
        <source>Magenta Saturation</source>
        <translation>洋紅飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="144"/>
        <source>Magenta Lightness</source>
        <translation>洋紅明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="6"/>
        <source>HSL Range</source>
        <translation>HSL 範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="8"/>
        <source>hue saturation lightness color primaries</source>
        <comment>search keywords for the HSL Range video filter</comment>
        <translation>色調 飽和度 明度 色彩 原色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="18"/>
        <source>Blend</source>
        <translation>混合</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="25"/>
        <source>Hue Shift</source>
        <translation>色調偏移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="32"/>
        <source>Saturation Scale</source>
        <translation>調整飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="39"/>
        <source>Lightness Scale</source>
        <translation>調整明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="46"/>
        <source>Hue Center</source>
        <translation>色調中心</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="53"/>
        <source>Hue Range</source>
        <translation>色調範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="7"/>
        <source>360: Cap Top &amp; Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="9"/>
        <source>spherical fill blur zenith nadir</source>
        <comment>search keywords for the 360: Cap Top &amp; Bottom video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="38"/>
        <source>topStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="45"/>
        <source>topEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="52"/>
        <source>topBlendIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="59"/>
        <source>topBlendOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="66"/>
        <source>topFadeIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="73"/>
        <source>topBlurWidthStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="80"/>
        <source>topBlurWidthEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="87"/>
        <source>topBlurHeightStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="94"/>
        <source>topBlurHeightEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="102"/>
        <source>bottomStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="109"/>
        <source>bottomEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="116"/>
        <source>bottomBlendIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="123"/>
        <source>bottomBlendOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="130"/>
        <source>bottomFadeIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="137"/>
        <source>bottomBlurWidthStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="144"/>
        <source>bottomBlurWidthEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="151"/>
        <source>bottomBlurHeightStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="158"/>
        <source>bottomBlurHeightEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="7"/>
        <source>360: Equirectangular Wrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="9"/>
        <source>spherical stretch</source>
        <comment>search keywords for the 360: Equirectangular Wrap video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="18"/>
        <source>hfov0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="25"/>
        <source>hfov1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="32"/>
        <source>vfov0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="39"/>
        <source>vfov1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="46"/>
        <source>blurStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="53"/>
        <source>blurEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/meta.qml" line="7"/>
        <source>360: Zenith Correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/meta.qml" line="8"/>
        <source>spherical level</source>
        <comment>search keywords for the 360: Zenith correction filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/meta.qml" line="6"/>
        <source>Clarity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/meta.qml" line="7"/>
        <source>histogram equalization constrast detail color distribution</source>
        <comment>search keywords for the Clarity video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="6"/>
        <source>Alpha Strobe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="7"/>
        <source>strobe alpha</source>
        <comment>search keywords for the Strobe video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="17"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_affine</name>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="7"/>
        <source>Size, Position &amp; Rotate</source>
        <translation>位置、尺寸與旋轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="8"/>
        <source>transform zoom rotation distort fill move</source>
        <comment>search keywords for the Size, Position &amp; Rotate video filter</comment>
        <translation>變形 縮放 旋轉 扭曲 填滿 移動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="21"/>
        <source>Size &amp; Position</source>
        <translation>位置與尺寸</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="26"/>
        <source>Rotation</source>
        <translation>旋轉</translation>
    </message>
</context>
<context>
    <name>meta_av</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="22"/>
        <source>Blur: Gaussian</source>
        <translation>模糊：高斯</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Box video filter</comment>
        <translation>柔化 隱蔽 隱藏</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="35"/>
        <source>Amount</source>
        <translation>總量</translation>
    </message>
</context>
<context>
    <name>meta_box_blur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="6"/>
        <source>Blur: Box</source>
        <translation>模糊：盒狀</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="7"/>
        <source>soften obscure hide directional</source>
        <comment>search keywords for the Blur: Box video filter</comment>
        <translation>柔化 隱蔽 隱藏 方向性</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="18"/>
        <source>Width</source>
        <translation>寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="25"/>
        <source>Height</source>
        <translation>高</translation>
    </message>
</context>
<context>
    <name>meta_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="6"/>
        <source>Blur: Box</source>
        <translation>模糊：盒狀</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="17"/>
        <source>Width</source>
        <translation>寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="24"/>
        <source>Height</source>
        <translation>高</translation>
    </message>
</context>
<context>
    <name>meta_dance</name>
    <message>
        <location filename="../src/qml/filters/dance/meta_dance.qml" line="7"/>
        <source>Audio Dance Visualization</source>
        <translation>音訊律動視覺效果</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/meta_dance.qml" line="8"/>
        <source>music visualizer reactive transform move size position rotate rotation</source>
        <comment>search keywords for the Audio Dance Visualization video filter</comment>
        <translation>音樂 視覺效果 反應 變形 移動 大小 尺寸 位置 旋轉</translation>
    </message>
</context>
<context>
    <name>meta_forward</name>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="8"/>
        <source>Speed: Forward Only</source>
        <translation>速度：僅前進</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="9"/>
        <source>temporal speed ramp fast slow motion</source>
        <comment>search keywords for the Speed filter</comment>
        <translation>時域 速度 斜坡 快 慢 動態</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="23"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
</context>
<context>
    <name>meta_forward_reverse</name>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="8"/>
        <source>Speed: Forward &amp; Reverse</source>
        <translation>速度：前進與反轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="9"/>
        <source>temporal speed ramp fast slow motion reverse</source>
        <comment>search keywords for the Speed filter</comment>
        <translation>時域 速度 斜坡 快 慢 動態 反轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="24"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
</context>
<context>
    <name>meta_frei0r</name>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="6"/>
        <source>Glow</source>
        <translation>發光</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="7"/>
        <source>shine blur</source>
        <comment>search keywords for the Glow video filter</comment>
        <translation>閃耀 模糊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="19"/>
        <source>Blur</source>
        <translation>模糊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="6"/>
        <source>Saturation</source>
        <translation>飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="7"/>
        <source>color desaturate grayscale chroma</source>
        <comment>search keywords for the Saturation video filter</comment>
        <translation>色彩 去飽和 灰階 彩度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="19"/>
        <source>Level</source>
        <translation>位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="6"/>
        <source>Sharpen</source>
        <translation>銳化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="7"/>
        <source>sharpness focus clear crisp</source>
        <comment>search keywords for the Sharpen video filter</comment>
        <translation>清晰度 焦點 清楚 銳利</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="19"/>
        <source>Amount</source>
        <translation>總量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="26"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="6"/>
        <source>White Balance</source>
        <translation>白平衡</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="7"/>
        <source>color correct light temperature neutral</source>
        <comment>search keywords for the White Balance video filter</comment>
        <translation>色彩 校正 光線 色溫 中性</translation>
    </message>
</context>
<context>
    <name>meta_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/meta_frei0r_coloradj.qml" line="7"/>
        <source>Color Grading</source>
        <translation>色階</translation>
    </message>
</context>
<context>
    <name>meta_lightshow</name>
    <message>
        <location filename="../src/qml/filters/lightshow/meta_lightshow.qml" line="7"/>
        <source>Audio Light Visualization</source>
        <translation>音訊燈光視覺效果</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/meta_lightshow.qml" line="8"/>
        <source>music visualizer reactive color</source>
        <comment>search keywords for the Audio Light Visualization video filter</comment>
        <translation>音樂 視覺效果 反應 色彩</translation>
    </message>
</context>
<context>
    <name>meta_movit</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="6"/>
        <source>Blur</source>
        <translation>模糊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="7"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur video filter</comment>
        <translation>柔化 隱蔽 隱藏</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="19"/>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="19"/>
        <source>Radius</source>
        <translation>半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="6"/>
        <source>Brightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="7"/>
        <source>lightness value</source>
        <comment>search keywords for the Brightness video filter</comment>
        <translation>明度數值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="21"/>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="21"/>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="20"/>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="19"/>
        <source>Level</source>
        <translation>位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="6"/>
        <source>Color Grading</source>
        <translation>色階</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="7"/>
        <source>correct shadows lift midtones gamma highlights gain hue lightness brightness value</source>
        <comment>search keywords for the Color Grading video filter</comment>
        <translation>校正 陰影 提升 中間調 色差補正 gamma 亮部 增益 色調 亮度 明度 數值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="17"/>
        <source>Shadows (Lift)</source>
        <translation>陰影（提升）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="22"/>
        <source>Midtones (Gamma)</source>
        <translation>中間調（色差補正）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="27"/>
        <source>Highlights (Gain)</source>
        <translation>亮部（增益）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="6"/>
        <source>Contrast</source>
        <translation>對比</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="7"/>
        <source>variation value</source>
        <comment>search keywords for the Contrast video filter</comment>
        <translation>變異 數值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="6"/>
        <source>Glow</source>
        <translation>發光</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="7"/>
        <source>shine blur</source>
        <comment>search keywords for the Glow video filter</comment>
        <translation>閃耀 模糊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="26"/>
        <source>Highlight blurriness</source>
        <translation>亮部模糊度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="33"/>
        <source>Highlight cutoff</source>
        <translation>亮部截止</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="6"/>
        <source>Mirror</source>
        <translation>鏡像</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="7"/>
        <source>horizontal flip transpose flop</source>
        <comment>search keywords for the Mirror video filter</comment>
        <translation>水平 翻轉 轉置 正反</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="7"/>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="8"/>
        <source>alpha transparent translucent</source>
        <comment>search keywords for the Opacity video filter</comment>
        <translation>alpha 透明 半透明</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="6"/>
        <source>Saturation</source>
        <translation>飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="7"/>
        <source>color desaturate grayscale chroma</source>
        <comment>search keywords for the Saturation video filter</comment>
        <translation>色彩 去飽和 灰階 彩度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="6"/>
        <source>Sharpen</source>
        <translation>銳化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="7"/>
        <source>sharpness focus clear crisp</source>
        <comment>search keywords for the Sharpen video filter</comment>
        <translation>清晰度 焦點 清楚 銳利</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="19"/>
        <source>Circle radius</source>
        <translation>圓弧半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="26"/>
        <source>Gaussian radius</source>
        <translation>高斯半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="33"/>
        <source>Correlation</source>
        <translation>係數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="40"/>
        <source>Noise</source>
        <translation>雜訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="6"/>
        <source>Vignette</source>
        <translation>暈影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="7"/>
        <source>dark edges fade</source>
        <comment>search keywords for the Vignette video filter</comment>
        <translation>深色 邊緣 淡出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="19"/>
        <source>Outer radius</source>
        <translation>外半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="26"/>
        <source>Inner radius</source>
        <translation>內半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="6"/>
        <source>White Balance</source>
        <translation>白平衡</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="7"/>
        <source>color correct light temperature neutral</source>
        <comment>search keywords for the White Balance video filter</comment>
        <translation>色彩 校正 光線 色溫 中性</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta_movit.qml" line="6"/>
        <source>Flip</source>
        <translation>翻轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta_movit.qml" line="7"/>
        <source>vertical flop transpose rotate</source>
        <comment>search keywords for the Flip video filter</comment>
        <translation>垂直 正反 轉置 旋轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="6"/>
        <source>Crop: Source</source>
        <translation>裁剪：來源</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="7"/>
        <source>trim remove edges</source>
        <comment>search keywords for the Crop: Source video filter</comment>
        <translation>修剪 移除 邊緣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="7"/>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="24"/>
        <source>Size &amp; Position</source>
        <translation>位置與尺寸</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="8"/>
        <source>transform zoom distort fill move</source>
        <comment>search keywords for the Size and Position filter</comment>
        <translation>變形 縮放 扭曲 填滿 移動</translation>
    </message>
</context>
<context>
    <name>meta_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="6"/>
        <source>Vignette</source>
        <translation>暈影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="7"/>
        <source>dark edges fade</source>
        <comment>search keywords for the Vignette video filter</comment>
        <translation>深色 邊緣 淡出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="18"/>
        <source>Radius</source>
        <translation>半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="25"/>
        <source>Feathering</source>
        <translation>羽化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="32"/>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
</context>
<context>
    <name>meta_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/meta_spectrum.qml" line="7"/>
        <source>Audio Spectrum Visualization</source>
        <translation>音訊頻譜視覺效果</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/meta_spectrum.qml" line="8"/>
        <source>music visualizer reactive frequency</source>
        <comment>search keywords for the Audio Spectrum Visualization video filter</comment>
        <translation>音樂 視覺效果 反應 頻率</translation>
    </message>
</context>
<context>
    <name>timeline</name>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="178"/>
        <source>Output</source>
        <translation>輸出</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="208"/>
        <source>Filters</source>
        <translation>濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="313"/>
        <source>Move %1</source>
        <translation>移動 %1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="355"/>
        <source>Can not move audio track above video track</source>
        <translation>無法將音訊軌道移至視訊軌道上方</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="357"/>
        <source>Can not move video track below audio track</source>
        <translation>無法將視訊軌道移至音訊軌道下方</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="359"/>
        <source>Track %1 was not moved</source>
        <translation>未移動軌道 %1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="706"/>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="706"/>
        <source>Overwrite</source>
        <translation>覆寫</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1028"/>
        <source>Do you want to insert an audio or video track?</source>
        <translation>要插入視訊軌道或音訊軌道？</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1038"/>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1046"/>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
</context>
<context>
    <name>ui</name>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="58"/>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="296"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="353"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="46"/>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="82"/>
        <source>No Change</source>
        <translation>不變</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="87"/>
        <source>Shave</source>
        <translation>刮除</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="92"/>
        <source>Shrink Hard</source>
        <translation>實邊縮減</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="97"/>
        <source>Shrink Soft</source>
        <translation>柔邊縮減</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="102"/>
        <source>Grow Hard</source>
        <translation>實邊擴張</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="107"/>
        <source>Grow Soft</source>
        <translation>柔邊擴張</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="112"/>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="98"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="150"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="138"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="189"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="570"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="118"/>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="158"/>
        <source>Threshold</source>
        <translation>閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="117"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="653"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="916"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="129"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="287"/>
        <source>Blur</source>
        <translation>模糊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="136"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="547"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="543"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="618"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="693"/>
        <location filename="../src/qml/filters/blur_exponential/ui.qml" line="84"/>
        <location filename="../src/qml/filters/blur_lowpass/ui.qml" line="84"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="79"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="82"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="55"/>
        <location filename="../src/qml/filters/noise_fast/ui.qml" line="60"/>
        <location filename="../src/qml/filters/noise_keyframes/ui.qml" line="84"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="63"/>
        <source>Amount</source>
        <translation>總量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="164"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="171"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="445"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="405"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="124"/>
        <source>Invert</source>
        <translation>反轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="50"/>
        <source>Display</source>
        <translation>顯示</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="66"/>
        <source>Gray Alpha</source>
        <translation>灰 Alpha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="71"/>
        <source>Red &amp; Gray Alpha</source>
        <translation>紅與灰 Alpha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="76"/>
        <source>Checkered Background</source>
        <translation>棋盤格背景</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="81"/>
        <source>Black Background</source>
        <translation>黑色背景</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="86"/>
        <source>Gray Background</source>
        <translation>灰色背景</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="91"/>
        <source>White Background</source>
        <translation>白色背景</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="122"/>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="134"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="139"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="61"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="200"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="68"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="132"/>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="134"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="148"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="61"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="220"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="63"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="254"/>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="152"/>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="54"/>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="80"/>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="99"/>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="79"/>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="174"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="68"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="49"/>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="109"/>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="111"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="109"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="56"/>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="142"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="74"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="74"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="68"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="87"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="78"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="138"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="137"/>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="75"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="72"/>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="92"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="451"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="232"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="294"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="295"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="314"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="692"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="150"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="308"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="211"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="125"/>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="50"/>
        <location filename="../src/qml/filters/blur_exponential/ui.qml" line="65"/>
        <location filename="../src/qml/filters/blur_lowpass/ui.qml" line="65"/>
        <location filename="../src/qml/filters/brightness/ui.qml" line="138"/>
        <location filename="../src/qml/filters/choppy/ui.qml" line="62"/>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="69"/>
        <location filename="../src/qml/filters/color/ui.qml" line="177"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="144"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="304"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="99"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="185"/>
        <location filename="../src/qml/filters/deband/ui.qml" line="197"/>
        <location filename="../src/qml/filters/distort/ui.qml" line="77"/>
        <location filename="../src/qml/filters/dither/ui.qml" line="67"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="81"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="47"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="157"/>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="83"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="432"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="720"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="900"/>
        <location filename="../src/qml/filters/fspp/ui.qml" line="52"/>
        <location filename="../src/qml/filters/glitch/ui.qml" line="82"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="482"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="679"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="196"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="246"/>
        <location filename="../src/qml/filters/grain/ui.qml" line="48"/>
        <location filename="../src/qml/filters/grid/ui.qml" line="137"/>
        <location filename="../src/qml/filters/halftone/ui.qml" line="82"/>
        <location filename="../src/qml/filters/histeq/ui.qml" line="50"/>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="70"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="140"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="109"/>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="75"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="96"/>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="82"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="154"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="51"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="153"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="326"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="52"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="204"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="71"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="42"/>
        <location filename="../src/qml/filters/noise_fast/ui.qml" line="47"/>
        <location filename="../src/qml/filters/noise_keyframes/ui.qml" line="65"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="71"/>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="59"/>
        <location filename="../src/qml/filters/opacity/ui.qml" line="106"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="129"/>
        <location filename="../src/qml/filters/posterize/ui.qml" line="65"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="192"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="70"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="271"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="136"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="105"/>
        <location filename="../src/qml/filters/sepia/ui.qml" line="37"/>
        <location filename="../src/qml/filters/sketch/ui.qml" line="52"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="55"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="161"/>
        <location filename="../src/qml/filters/strobe/ui.qml" line="97"/>
        <location filename="../src/qml/filters/subtitle/ui.qml" line="83"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="47"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="70"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="290"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="117"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="109"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="50"/>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="108"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="70"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="81"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="85"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="42"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="79"/>
        <location filename="../src/qml/filters/white/ui.qml" line="64"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="72"/>
        <source>The size of the window, in milliseconds, which will be processed at once.</source>
        <translation>批次處理的視域大小，單位為毫秒。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="101"/>
        <source>The strength of impulsive noise which is going to be removed. The lower value, the more samples will be detected as impulsive noise.</source>
        <translation>要移除的脈衝雜訊強度。數值越低，偵測為脈衝雜訊的取樣數越多。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="126"/>
        <source>Burst Fusion</source>
        <translation>叢發融合</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="129"/>
        <source>Treat small bursts that are close together as one large burst. Units are percent of the window size. A higher percent will combine bursts that are farther apart.</source>
        <translation>將相鄰的小型叢發視為單個大型叢發。單位為所佔視域大小的百分比。佔比越高，整合的叢發範圍越廣。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="32"/>
        <source>Fast Fade</source>
        <translation>快速淡出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="93"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="98"/>
        <source>Fade duration</source>
        <translation>淡化長度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="97"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="102"/>
        <source>The duration of fade to apply at the begining and end of each clip</source>
        <translation>套用至每部短片開頭與結尾的淡出及淡入長度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="133"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="168"/>
        <source>Fade in</source>
        <translation>淡入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="137"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="172"/>
        <source>Status indicator showing when a fade in has occured.</source>
        <translation>淡入發生時的狀態指示器。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="163"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="198"/>
        <source>Fade out</source>
        <translation>淡出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="167"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="202"/>
        <source>Status indicator showing when a fade out has occured.</source>
        <translation>淡出發生時的狀態指示器。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="98"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="97"/>
        <source>Center frequency</source>
        <translation>中心頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="125"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="124"/>
        <source>Bandwidth</source>
        <translation>頻寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="152"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="151"/>
        <source>Rolloff rate</source>
        <translation>滾落速率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="178"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="110"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="146"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="146"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="114"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="177"/>
        <source>Dry</source>
        <translation>乾</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="188"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="156"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="156"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="124"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="187"/>
        <source>Wet</source>
        <translation>濕</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="215"/>
        <source>Bass</source>
        <translation>低音</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="245"/>
        <source>Middle</source>
        <comment>Bass &amp; Treble audio filter</comment>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="275"/>
        <source>Treble</source>
        <translation>高音</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Front left</source>
        <translation>左前</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Front right</source>
        <translation>右前</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="117"/>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="102"/>
        <source>Center</source>
        <translation>中心</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Low frequency</source>
        <translation>低頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Left surround</source>
        <translation>左環場</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Right surround</source>
        <translation>右環場</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="54"/>
        <source>Copy from</source>
        <translation>複製來源</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="65"/>
        <source>to</source>
        <translation>到</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="81"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="69"/>
        <source>RMS</source>
        <translation>方均根</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="85"/>
        <source>The balance between the RMS and peak envelope followers. RMS is generally better for subtle, musical compression and peak is better for heavier, fast compression and percussion.</source>
        <translation>方均根與峰值輪廓間的平衡。方均根通常適合輕微、音樂性的壓縮，峰值則較適合重度、快速的壓縮及打擊樂。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="95"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="83"/>
        <source>Peak</source>
        <translation>峰值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="96"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="218"/>
        <source>Attack</source>
        <translation>啟奏</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="129"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="117"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="125"/>
        <source>Release</source>
        <translation>釋放值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="154"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="142"/>
        <source>The point at which the compressor will start to kick in.</source>
        <translation>壓縮器會開始作用的時機點。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="176"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="164"/>
        <source>Ratio</source>
        <translation>比率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="180"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="168"/>
        <source>The gain reduction ratio used when the signal level exceeds the threshold.</source>
        <translation>當訊號位準超過閾值時的增益減抑幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="201"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="189"/>
        <source>Knee radius</source>
        <translation>拐點半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="205"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="193"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="315"/>
        <source>The distance from the threshold where the knee curve starts.</source>
        <translation>曲線拐點與閾值間的距離。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="227"/>
        <source>Makeup gain</source>
        <translation>增益補償</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="231"/>
        <source>The gain of the makeup input signal.</source>
        <translation>補償輸入訊號的增益幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="270"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="166"/>
        <source>Gain Reduction</source>
        <translation>增益減抑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="274"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="170"/>
        <source>Status indicator showing the gain reduction applied by the compressor.</source>
        <translation>顯示壓縮器所套用的增益減抑幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="294"/>
        <source>About dynamic range compression</source>
        <translation>關於動態範圍壓縮</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="62"/>
        <source>Delay</source>
        <translation>延遲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="66"/>
        <source>The neutral delay time is 2 seconds.
Times above 2 seconds will have reduced quality.
Times below will have increased CPU usage.</source>
        <translation>中性延遲時間是 2 秒。
超過 2 秒會減損音質，
低於 2 秒則會增加 CPU 使用量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="88"/>
        <source>Feedback</source>
        <translation>回授</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="73"/>
        <source>The balance between the RMS and peak envelope followers.
RMS is generally better for subtle, musical compression.
Peak is better for heavier, fast compression and percussion.</source>
        <translation>方均根與峰值輪廓間的平衡。
方均根通常適合細微、音樂劇的壓縮，
峰值則較適合重度、快速的壓縮及打擊樂。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="215"/>
        <source>Attenuation</source>
        <translation>衰減</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="219"/>
        <source>The gain of the output signal.
Used to correct for excessive amplitude caused by the extra dynamic range.</source>
        <translation>輸出訊號的增益幅度。
用以修正額外動態範圍造成的過度振幅。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="67"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="72"/>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="62"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="67"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="271"/>
        <source>Duration</source>
        <translation>長度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="166"/>
        <location filename="../src/qml/filters/brightness/ui.qml" line="162"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="167"/>
        <location filename="../src/qml/filters/opacity/ui.qml" line="131"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="89"/>
        <source>Level</source>
        <translation>位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="93"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="93"/>
        <source>Cutoff frequency</source>
        <translation>截止頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="73"/>
        <source>Input gain</source>
        <translation>輸入增益</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="77"/>
        <source>Gain that is applied to the input stage. Can be used to trim gain to bring it roughly under the limit or to push the signal against the limit.</source>
        <translation>輸入階段套用的增益幅度。可被用於修剪增益幅度、使其約略低於限制值，或使訊號趨近限制值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="99"/>
        <source>Limit</source>
        <translation>限制值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="103"/>
        <source>The maximum output amplitude. Peaks over this level will be attenuated as smoothly as possible to bring them as close as possible to this level.</source>
        <translation>最大輸出振幅。超過此位準的峰值將盡可能平滑的衰減至接近此數值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="129"/>
        <source>The time taken for the limiter&apos;s attenuation to return to 0 dB&apos;s.</source>
        <translation>限制器衰減至 0 dB 所用的時間。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="100"/>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="67"/>
        <source>Target Loudness</source>
        <translation>目標響度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="104"/>
        <source>The target loudness of the output in LUFS.</source>
        <translation>輸出的目標響度，以 LUFS 為單位。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="125"/>
        <source>Analysis Window</source>
        <translation>分析視域</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="129"/>
        <source>The amount of history to use to calculate the input loudness.</source>
        <translation>計算輸入響度時使用的歷程紀錄總量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="150"/>
        <source>Maximum Gain</source>
        <translation>增益上限</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="154"/>
        <source>The maximum that the gain can be increased.</source>
        <translation>增益增加的最大程度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="175"/>
        <source>Minimum Gain</source>
        <translation>增益下限</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="179"/>
        <source>The maximum that the gain can be decreased.</source>
        <translation>增益減少的最大程度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="200"/>
        <source>Maximum Rate</source>
        <translation>比率上限</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="204"/>
        <source>The maximum rate that the gain can be changed.</source>
        <translation>增益改變的最大比率。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="230"/>
        <source>Reset on discontinuity</source>
        <translation>不連續時重設</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="234"/>
        <source>Reset the measurement if a discontinuity is detected - such as seeking or clip change.</source>
        <translation>當偵測到諸如搜尋或變更短片等不連續狀態時，重設測量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="260"/>
        <source>Input Loudness</source>
        <translation>輸入響度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="264"/>
        <source>Status indicator showing the loudness measured on the input.</source>
        <translation>顯示測量到的輸入響度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="283"/>
        <source>Output Gain</source>
        <translation>輸出增益</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="287"/>
        <source>Status indicator showing the gain being applied.</source>
        <translation>顯示套用的增益幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="122"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="304"/>
        <source>Reset</source>
        <translation>重設</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="308"/>
        <source>Status indicator showing when the loudness measurement is reset.</source>
        <translation>當響度測量重設時，顯示狀態。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="26"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="35"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="30"/>
        <source>Analyzing...</source>
        <translation>正在分析…</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="30"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="38"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="32"/>
        <source>Analysis complete.</source>
        <translation>分析完成。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="33"/>
        <source>%1 LUFS</source>
        <translation>%1 LUFS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="36"/>
        <source>%1 dB</source>
        <translation>%1 dB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="38"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="34"/>
        <source>Click &quot;Analyze&quot; to use this filter.</source>
        <translation>按一下「分析」以使用此濾鏡。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="97"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="360"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="165"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="376"/>
        <source>Analyze</source>
        <translation>分析</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="128"/>
        <source>Detected Loudness:</source>
        <translation>偵測到的響度：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="132"/>
        <source>The loudness calculated by the analysis.</source>
        <translation>經分析所計算出的響度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="143"/>
        <source>Normalization Gain:</source>
        <translation>正規化增益：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="147"/>
        <source>The gain applied to normalize to the Target Loudness.</source>
        <translation>正規化至目標響度所需套用的增益幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="126"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="175"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="491"/>
        <source>Channel</source>
        <translation>聲道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="83"/>
        <source>Quick fix</source>
        <translation>快速修正</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="91"/>
        <source>Small hall</source>
        <translation>小型穿堂</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="99"/>
        <source>Large hall</source>
        <translation>大廳</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="107"/>
        <source>Sewer</source>
        <translation>下水道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="115"/>
        <source>Church</source>
        <translation>教堂</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="156"/>
        <source>Room size</source>
        <translation>房間大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="160"/>
        <source>The size of the room, in meters. Excessively large, and excessively small values will make it sound a bit unrealistic. Values of around 30 sound good.</source>
        <translation>房間的大小，以公尺為單位。極大或極小的數值聽起來會有些失真，30 上下是個不錯的數值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="187"/>
        <source>Reverb time</source>
        <translation>殘響時間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="215"/>
        <source>Damping</source>
        <translation>阻尼</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="219"/>
        <source>This controls the high frequency damping (a lowpass filter), values near 1 will make it sound very bright, values near 0 will make it sound very dark.</source>
        <translation>控制高頻阻尼（一種低通濾波器）：數值接近 1 聽起來會非常清亮，接近 0 則會顯得暗沈。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="247"/>
        <source>Input bandwidth</source>
        <translation>輸入頻寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="251"/>
        <source>This is like a damping control for the input, it has a similar effect to the damping control, but is subtly different.</source>
        <translation>類似於輸入的阻尼控制器。具有與阻尼相似的效果，但有微妙的差異。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="279"/>
        <source>Dry signal level</source>
        <translation>乾訊號位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="283"/>
        <source>The amount of dry signal to be mixed with the reverberated signal.</source>
        <translation>乾訊號與殘響訊號混合的總量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="311"/>
        <source>Early reflection level</source>
        <translation>早反射位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="342"/>
        <source>Tail level</source>
        <translation>尾聲位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="346"/>
        <source>The quantity of early reflections (scatter reflections directly from the source).</source>
        <translation>早反射（自聲源散射的反射音）的量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="375"/>
        <source>About reverb</source>
        <translation>關於殘響</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="55"/>
        <source>Swap</source>
        <translation>交換</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="66"/>
        <source>with</source>
        <translation>與</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="66"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="109"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="68"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="118"/>
        <source>Key color</source>
        <translation>色鍵</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="86"/>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="110"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="88"/>
        <source>Distance</source>
        <translation>距離</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="203"/>
        <source>Shadows (Lift)</source>
        <translation>陰影（提升）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="241"/>
        <source>Midtones (Gamma)</source>
        <translation>中間調（色差補正）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="279"/>
        <source>Highlights (Gain)</source>
        <translation>亮部（增益）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/ui.qml" line="140"/>
        <source>Center bias</source>
        <translation>中心偏差</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="503"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="160"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="78"/>
        <source>Top</source>
        <translation>頂部</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="566"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="829"/>
        <source>Fade</source>
        <translation>淡化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="601"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="864"/>
        <source>In</source>
        <translation>起點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="627"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="890"/>
        <source>Out</source>
        <translation>終點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="662"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="925"/>
        <source>Width at start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="688"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="951"/>
        <source>Height at start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="714"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="977"/>
        <source>Width at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="740"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="1003"/>
        <source>Height at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="766"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="180"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="73"/>
        <source>Bottom</source>
        <translation>底部</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="239"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="291"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="60"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1584"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="370"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="471"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="231"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="301"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="265"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="204"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="187"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="61"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="87"/>
        <source>Bottom Left</source>
        <translation>左下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="65"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="91"/>
        <source>Bottom Right</source>
        <translation>右下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="69"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>Top Left</source>
        <translation>左上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="73"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>Top Right</source>
        <translation>右上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="77"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="206"/>
        <source>Lower Third</source>
        <translation>底部字幕</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="81"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="222"/>
        <source>Slide In From Left</source>
        <translation>從左滑入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="83"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="224"/>
        <source>Slide In From Right</source>
        <translation>從右滑入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="85"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="226"/>
        <source>Slide In From Top</source>
        <translation>從上滑入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="87"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="228"/>
        <source>Slide In From Bottom</source>
        <translation>從下滑入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="91"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="232"/>
        <source>Slide Out Left</source>
        <translation>向左滑出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="93"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="234"/>
        <source>Slide Out Right</source>
        <translation>向右滑出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="95"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="236"/>
        <source>Slide Out Top</source>
        <translation>向上滑出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="97"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="238"/>
        <source>Slide Out Bottom</source>
        <translation>向下滑出</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="101"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="242"/>
        <source>Slow Zoom In</source>
        <translation>緩慢放大</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="103"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="244"/>
        <source>Slow Zoom Out</source>
        <translation>緩慢縮小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="105"/>
        <source>Slow Pan Left</source>
        <translation>緩慢向左平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="106"/>
        <source>Slow Move Left</source>
        <translation>緩慢左移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="108"/>
        <source>Slow Pan Right</source>
        <translation>緩慢向右平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="109"/>
        <source>Slow Move Right</source>
        <translation>緩慢右移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="111"/>
        <source>Slow Pan Up</source>
        <translation>緩慢向上平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="112"/>
        <source>Slow Move Up</source>
        <translation>緩慢上移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="114"/>
        <source>Slow Pan Down</source>
        <translation>緩慢向下平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="115"/>
        <source>Slow Move Down</source>
        <translation>緩慢下移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="117"/>
        <source>Slow Zoom In, Pan Up Left</source>
        <translation>緩慢放大，向左上平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="118"/>
        <source>Slow Zoom In, Move Up Left</source>
        <translation>緩慢放大，往左上移動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="120"/>
        <source>Slow Zoom In, Pan Down Right</source>
        <translation>緩慢放大，向右下平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="121"/>
        <source>Slow Zoom In, Move Down Right</source>
        <translation>緩慢放大，往右下移動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="123"/>
        <source>Slow Zoom Out, Pan Up Right</source>
        <translation>緩慢縮小，向右上平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="124"/>
        <source>Slow Zoom Out, Move Up Right</source>
        <translation>緩慢縮小，向右上平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="126"/>
        <source>Slow Zoom Out, Pan Down Left</source>
        <translation>緩慢縮小，向左下平移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="127"/>
        <source>Slow Zoom Out, Move Down Left</source>
        <translation>緩慢縮小，往左下移動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="187"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="709"/>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="277"/>
        <source>Insert field</source>
        <translation>插入欄位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="299"/>
        <source># (Hash sign)</source>
        <translation>#（井字號）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="304"/>
        <source>Timecode (drop frame)</source>
        <translation>時間碼（漏格）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="309"/>
        <source>Timecode (non-drop frame)</source>
        <translation>時間碼（非漏格）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="339"/>
        <source>File base name</source>
        <translation>檔案基礎檔名</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="314"/>
        <source>Frame #</source>
        <comment>Frame number</comment>
        <translation>影格 #</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="319"/>
        <source>File date</source>
        <translation>檔案日期</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="324"/>
        <source>Creation date</source>
        <translation>建立日期</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="329"/>
        <source>File name and path</source>
        <translation>檔案名稱與路徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="334"/>
        <source>File name</source>
        <translation>檔案名稱</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="130"/>
        <source>Bar</source>
        <translation>直條</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="130"/>
        <source>Segment</source>
        <translation>區段</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="138"/>
        <source>Graph Colors</source>
        <translation>圖表色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="168"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1447"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="126"/>
        <source>Thickness</source>
        <translation>粗細</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="192"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="216"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1529"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="313"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="367"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="390"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="156"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="222"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="310"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="188"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="144"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="146"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="293"/>
        <source>Mirror the levels.</source>
        <translation>鏡像位準。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="305"/>
        <source>Reverse the levels.</source>
        <translation>反轉位準。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="314"/>
        <source>Channels</source>
        <translation>聲道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="337"/>
        <source>Segments</source>
        <translation>區段</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="360"/>
        <source>Segment Gap</source>
        <translation>區段間距</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="98"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="92"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="98"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="95"/>
        <source>Adjust opacity instead of fade with black</source>
        <translation>調整不透明度而非淡出至黑色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="61"/>
        <source>Noise</source>
        <translation>雜訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="80"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="503"/>
        <source>Brightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="92"/>
        <source>Hue</source>
        <translation>色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1428"/>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="101"/>
        <source> °</source>
        <comment>degrees</comment>
        <translation> °</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="119"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="118"/>
        <source>Lightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="146"/>
        <source>Saturation</source>
        <translation>飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="135"/>
        <source>Target color</source>
        <translation>目標色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="162"/>
        <source>Mask type</source>
        <translation>遮罩類型</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Color Distance</source>
        <translation>色彩距離</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Transparency</source>
        <translation>透明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Edge Inwards</source>
        <translation>邊緣向內</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Edge Outwards</source>
        <translation>邊緣向外</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="182"/>
        <source>Tolerance</source>
        <translation>誤差值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="128"/>
        <source>&lt;b&gt;Low Shelf&lt;/b&gt;</source>
        <translation>&lt;b&gt;Low Shelf&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="204"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="281"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="359"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="437"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="515"/>
        <source>Gain</source>
        <translation>增益</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="228"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="539"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="202"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="315"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="329"/>
        <source>Slope</source>
        <translation>梯度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="251"/>
        <source>&lt;b&gt;Band 1&lt;/b&gt;</source>
        <translation>&lt;b&gt;頻段 1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="305"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="383"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="461"/>
        <source>Bandwidth</source>
        <comment>Parametric equalizer bandwidth</comment>
        <translation>頻寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="316"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="394"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="472"/>
        <source> octaves</source>
        <translation> 八度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="329"/>
        <source>&lt;b&gt;Band 2&lt;/b&gt;</source>
        <translation>&lt;b&gt;頻段 2&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="407"/>
        <source>&lt;b&gt;Band 3&lt;/b&gt;</source>
        <translation>&lt;b&gt;頻段 3&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="485"/>
        <source>&lt;b&gt;High Shelf&lt;/b&gt;</source>
        <translation>&lt;b&gt;High Shelf&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="222"/>
        <source>Hue gate</source>
        <translation>色調閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="242"/>
        <source>Saturation threshold</source>
        <translation>飽和度閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="262"/>
        <source>Operation 1</source>
        <translation>運算 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="50"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="427"/>
        <source>Blend mode</source>
        <translation>混合模式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="65"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="442"/>
        <source>Over</source>
        <translation>正常</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="70"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="447"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="80"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="457"/>
        <source>Saturate</source>
        <translation>飽和</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="85"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="462"/>
        <source>Multiply</source>
        <translation>色彩增值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="90"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="467"/>
        <source>Screen</source>
        <translation>螢幕</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="95"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="472"/>
        <source>Overlay</source>
        <translation>覆蓋</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="100"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="477"/>
        <source>Darken</source>
        <translation>變暗</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="105"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="482"/>
        <source>Dodge</source>
        <translation>加亮顏色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="110"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="487"/>
        <source>Burn</source>
        <translation>加深顏色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="115"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="492"/>
        <source>Hard Light</source>
        <translation>實光</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="120"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="497"/>
        <source>Soft Light</source>
        <translation>柔光</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="125"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="502"/>
        <source>Difference</source>
        <translation>差異化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="130"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="507"/>
        <source>Exclusion</source>
        <translation>排除</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="135"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="512"/>
        <source>HSL Hue</source>
        <translation>HSL 色調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="140"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="517"/>
        <source>HSL Saturation</source>
        <translation>HSL 飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="145"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="522"/>
        <source>HSL Color</source>
        <translation>HSL 色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="150"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="527"/>
        <source>HSL Luminosity</source>
        <translation>HSL 明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>De-Key</source>
        <translation>消除色鍵</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>Desaturate</source>
        <translation>去飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>Adjust Luma</source>
        <translation>調整亮度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="282"/>
        <source>Amount 1</source>
        <translation>總量 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="302"/>
        <source>Operation 2</source>
        <translation>運算 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="322"/>
        <source>Amount 2</source>
        <translation>總量 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="346"/>
        <source>Show mask</source>
        <translation>顯示遮罩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="359"/>
        <source>Send mask to alpha channel</source>
        <translation>將遮罩套用至 Alpha 頻道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="101"/>
        <source>X Center</source>
        <translation>X 中心</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="130"/>
        <source>Y Center</source>
        <translation>Y 中心</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="159"/>
        <source>Correction at Center</source>
        <translation>中心修正</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="188"/>
        <source>Correction at Edges</source>
        <translation>邊緣修正</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="87"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="64"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="265"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="90"/>
        <source>Width</source>
        <translation>寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/ui.qml" line="100"/>
        <source>Darkness</source>
        <translation>暗度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="43"/>
        <source>No File Loaded</source>
        <translation>沒有載入檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="45"/>
        <source>No 3D LUT file loaded.
Click &quot;Open&quot; to load a file.</source>
        <translation>沒有載入 3D LUT 檔案。
按一下「開啟」以載入檔案。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="81"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="121"/>
        <source>Open...</source>
        <translation>開啟…</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="84"/>
        <source>Open 3D LUT File</source>
        <translation>開啟 3D LUT 檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="488"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="343"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="344"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="791"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="181"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="418"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="248"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="189"/>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="101"/>
        <source>Interpolation</source>
        <translation>內插補點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="305"/>
        <source>Stereo</source>
        <translation>立體聲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="314"/>
        <source>Binaural</source>
        <translation>雙耳立體聲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="323"/>
        <source>Quad</source>
        <translation>四聲道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="354"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="366"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="368"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="820"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="537"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="271"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="204"/>
        <source>Yaw</source>
        <translation>偏航</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="400"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="410"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="412"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="864"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="612"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="315"/>
        <source>Pitch</source>
        <comment>rotation around the side-to-side axis (roll, pitch, yaw)</comment>
        <translation>俯仰</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="446"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="454"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="456"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="909"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="687"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="359"/>
        <source>Roll</source>
        <translation>滾轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="541"/>
        <source>Paste Parameters</source>
        <translation>貼上參數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="498"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="500"/>
        <source>FOV</source>
        <comment>field of view</comment>
        <translation>視野</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="501"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="503"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="985"/>
        <source>Field of view</source>
        <translation>視野</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="590"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="592"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="414"/>
        <source>Copy Parameters</source>
        <translation>複製參數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="982"/>
        <source>FOV</source>
        <translation>視野</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="545"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="450"/>
        <source>Fisheye</source>
        <translation>魚眼效果</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="403"/>
        <source>Nearest</source>
        <translation>最接近</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <source>Trilinear</source>
        <translation>三線性</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <source>Tetrahedral</source>
        <translation>四面體</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="173"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="348"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="202"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="349"/>
        <source>Operation</source>
        <translation>運算</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="336"/>
        <source>Corner 1 X</source>
        <translation>端點 1 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="431"/>
        <source>Corner 2 X</source>
        <translation>端點 2 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="483"/>
        <source>Corner 3 X</source>
        <translation>端點 3 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="535"/>
        <source>Corner 4 X</source>
        <translation>端點 4 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="587"/>
        <source>Stretch X</source>
        <translation>延伸 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="645"/>
        <source>Interpolator</source>
        <translation>內插運算</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Nearest Neighbor</source>
        <translation>最接近像素</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="557"/>
        <source>Bilinear</source>
        <translation>雙線性</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Bicubic Smooth</source>
        <translation>平滑雙立方</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Bicubic Sharp</source>
        <translation>銳利雙立方</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="572"/>
        <source>Spline 4x4</source>
        <translation>樣條 4×4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="577"/>
        <source>Spline 6x6</source>
        <translation>樣條 6×6</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="667"/>
        <source>Alpha Operation</source>
        <translation>Alpha 運算</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="226"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="533"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="369"/>
        <source>Maximum</source>
        <translation>最大值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="231"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="538"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="374"/>
        <source>Minimum</source>
        <translation>最小值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <source>Opaque</source>
        <translation>不透明</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="221"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="528"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="364"/>
        <source>Overwrite</source>
        <translation>覆寫</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="694"/>
        <source>Feathering</source>
        <translation>羽化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="75"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="480"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="452"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="236"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="543"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="379"/>
        <source>Add</source>
        <translation>增加</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="241"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="548"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="384"/>
        <source>Subtract</source>
        <translation>減去</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="194"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="369"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="241"/>
        <source>Shape</source>
        <translation>形狀</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Ellipse</source>
        <translation>橢圓</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Triangle</source>
        <translation>三角形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="266"/>
        <source>Diamond</source>
        <translation>菱形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="273"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="362"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="204"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="164"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="215"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="120"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="116"/>
        <source>Horizontal</source>
        <translation>水平</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="514"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="777"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="279"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="373"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="446"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1395"/>
        <source>Start</source>
        <translation>開始</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="540"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="803"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="323"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="417"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="404"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="483"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="557"/>
        <source>End</source>
        <translation>結束</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="105"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="109"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="222"/>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="230"/>
        <source>Linear</source>
        <translation>線性</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="241"/>
        <source>Radial</source>
        <translation>放射狀</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="277"/>
        <source>Colors</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="441"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="248"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="240"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="91"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="87"/>
        <source>Vertical</source>
        <translation>垂直</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="290"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="119"/>
        <source>Height</source>
        <translation>高</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1413"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="315"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="530"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="158"/>
        <source>Rotation</source>
        <translation>旋轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="336"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="566"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="596"/>
        <source>Softness</source>
        <translation>柔邊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="814"/>
        <source>Alignment</source>
        <translation>對齊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="953"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="597"/>
        <source>Lens</source>
        <translation>鏡頭</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="959"/>
        <source>Projection</source>
        <translation>投影</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1029"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1352"/>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="63"/>
        <location filename="../src/qml/filters/halftone/ui.qml" line="104"/>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="33"/>
        <source>Radius</source>
        <translation>半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1072"/>
        <source>Front</source>
        <translation>前</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1078"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1215"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="157"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1121"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1258"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="405"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="457"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="509"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="561"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="616"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="185"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="768"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1209"/>
        <source>Back</source>
        <translation>後</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1346"/>
        <source>Nadir</source>
        <translation>天底</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="133"/>
        <source>Cyan</source>
        <translation>青色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="162"/>
        <source>Magenta</source>
        <translation>洋紅色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="54"/>
        <source>Blurriness</source>
        <translation>模糊度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="72"/>
        <source>Vertical amount</source>
        <translation>垂直總量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="90"/>
        <source>Vertical frequency</source>
        <translation>垂直頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="109"/>
        <source>Brightness up</source>
        <translation>亮度提升</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="127"/>
        <source>Brightness down</source>
        <translation>亮度調降</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="145"/>
        <source>Brightness frequency</source>
        <translation>亮度頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="164"/>
        <source>Uneven develop up</source>
        <translation>不均顯影向上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="182"/>
        <source>Uneven develop down</source>
        <translation>不均顯影向下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="200"/>
        <source>Uneven develop duration</source>
        <translation>不均顯影長度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="326"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="549"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="169"/>
        <source> deg</source>
        <comment>degrees</comment>
        <translation>度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="454"/>
        <source>Add or remove fisheye effect</source>
        <translation>新增或移除魚眼效果</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="466"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="501"/>
        <source>Focal ratio</source>
        <translation>焦比</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="506"/>
        <source>The amount of lens distortion</source>
        <translation>鏡頭失真的幅度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="531"/>
        <source>Quality</source>
        <translation>品質</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="535"/>
        <source>Resample quality</source>
        <translation>重新採樣品質</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="552"/>
        <source>Nearest neighbor</source>
        <translation>最接近像素</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="562"/>
        <source>Bicubic smooth</source>
        <translation>平滑雙立方</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="567"/>
        <source>Bicubic sharp</source>
        <translation>清晰雙立方</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="582"/>
        <source>Lanczos 16x16</source>
        <translation>Lanczos 16×16</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="601"/>
        <source>Select a lens distortion pattern that best matches your camera</source>
        <translation>選取最符合相機的鏡頭失真模式。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="619"/>
        <source>Equidistant</source>
        <translation>等距</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="624"/>
        <source>Orthographic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="629"/>
        <source>Equiarea</source>
        <translation>等積</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="634"/>
        <source>Stereographic</source>
        <translation>球極平面</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="643"/>
        <source>Non-Linear scale</source>
        <translation>非線性縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="657"/>
        <source>The image will be stretched/squished to fix camera scaling between 4:3 and 16:9
Like used in GoPro&apos;s superview</source>
        <translation>將壓縮或延展影像，以在 4:3 與 16:9 比例間修正相機縮放
類似 GoPro SuperView 的呈現方式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="673"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="707"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1723"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="187"/>
        <source>Scale</source>
        <translation>縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="677"/>
        <source>Use negative values for up-scaled videos
Use positive values for down-scaled videos</source>
        <translation>輸入負值以放大視訊
輸入正值以縮小視訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="724"/>
        <source>Preset scale methods
Lock pixels at specific locations</source>
        <translation>預設設定的縮放模式
將像素固定於特定位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="744"/>
        <source>Scale to Fill</source>
        <translation>縮放以填滿</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="749"/>
        <source>Keep Center Scale</source>
        <translation>保持中心縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="754"/>
        <source>Scale to Fit</source>
        <translation>縮放到適當大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="759"/>
        <source>Manual Scale</source>
        <translation>手動縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="782"/>
        <source>Scale Y separately
This changes video aspect ratio</source>
        <translation>分開縮放 Y 軸
將改變視訊外觀比例</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="789"/>
        <source>Crop</source>
        <translation>裁剪</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="801"/>
        <source>Remove distorted edges</source>
        <translation>移除失真邊緣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="820"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="962"/>
        <source>Manual</source>
        <translation>手動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="825"/>
        <source>User set zoom/scale
Sides of image are not fixed</source>
        <translation>使用者設定的縮放比例
不會修正影像邊緣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="852"/>
        <source>Y ratio</source>
        <translation>Y 比率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="857"/>
        <source>Separate Y scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="887"/>
        <source>Aspect</source>
        <translation>像素外觀比例</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="904"/>
        <source>Preset pixel aspect ratio</source>
        <translation>預設設定 像素 外觀比例</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="944"/>
        <source>Manual Aspect</source>
        <translation>手動外觀比例</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="967"/>
        <source>User set pixel aspect ratios
Change top/side distortion bias</source>
        <translation>使用者設定的像素外觀比例
影響頂部與側邊的偏移失真</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="998"/>
        <source>Cameras</source>
        <translation>相機</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1012"/>
        <source>Camera</source>
        <translation>相機</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1032"/>
        <source>Record mode</source>
        <translation>錄影模式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1053"/>
        <source>Result</source>
        <translation>結果</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1073"/>
        <source>Apply</source>
        <translation>套用</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="234"/>
        <source>X offset</source>
        <translation>X 位移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="272"/>
        <source>Y offset</source>
        <translation>Y 位移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="208"/>
        <source>Full Screen</source>
        <translation>全螢幕</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="212"/>
        <source>Scroll Down</source>
        <translation>向下捲動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="214"/>
        <source>Scroll Up</source>
        <translation>向上捲動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="216"/>
        <source>Scroll Right</source>
        <translation>向右捲動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="218"/>
        <source>Scroll Left</source>
        <translation>向左捲動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="305"/>
        <source>Click in the rectangle atop the video to edit the text.</source>
        <translation>按一下視訊上的矩形以編輯文字。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="396"/>
        <source>Background size</source>
        <translation>背景尺寸</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="459"/>
        <source>Text size</source>
        <translation>文字大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="524"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="310"/>
        <source>Background color</source>
        <translation>背景色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="556"/>
        <source>Overflow</source>
        <translation>溢位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="570"/>
        <source>Automatic</source>
        <translation>自動</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="583"/>
        <source>Visible</source>
        <translation>可見</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="595"/>
        <source>Hidden</source>
        <translation>隱藏</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="144"/>
        <source>Color space</source>
        <translation>色彩空間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="156"/>
        <source>Red-Green-Blue</source>
        <translation>紅-綠-藍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="167"/>
        <source>Hue-Chroma-Intensity</source>
        <translation>色調–彩度–濃度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="181"/>
        <source>Red delta</source>
        <translation>紅色差量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="181"/>
        <source>Hue delta</source>
        <translation>色調差量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Green delta</source>
        <translation>綠色差量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Chroma delta</source>
        <translation>彩度差量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="221"/>
        <source>Blue delta</source>
        <translation>藍色差量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="221"/>
        <source>Intensity delta</source>
        <translation>濃度差量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="256"/>
        <source>Box</source>
        <translation>方形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="261"/>
        <source>Ellipsoid</source>
        <translation>橢圓</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="280"/>
        <source>Edge</source>
        <translation>邊緣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="295"/>
        <source>Hard</source>
        <comment>Chroma Key Advanced filter</comment>
        <translation>實邊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="300"/>
        <source>Fat</source>
        <translation>厚</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="305"/>
        <source>Normal</source>
        <translation>標準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="310"/>
        <source>Thin</source>
        <translation>薄</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="53"/>
        <source>Yellow-Blue</source>
        <translation>黃-藍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="71"/>
        <source>Cyan-Red</source>
        <translation>青-紅</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="65"/>
        <source>Line Width</source>
        <translation>線條寬度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="85"/>
        <source>Line Height</source>
        <translation>線條高度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="105"/>
        <source>Contrast</source>
        <translation>對比</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="86"/>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="91"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="98"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1302"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1366"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="383"/>
        <location filename="../src/qml/filters/sketch/ui.qml" line="126"/>
        <source>Color</source>
        <translation>色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="68"/>
        <source>Blur Radius</source>
        <translation>模糊半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="72"/>
        <source>The radius of the gaussian blur.</source>
        <translation>高斯模糊的半徑。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="93"/>
        <source>Blur Strength</source>
        <translation>模糊強度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="97"/>
        <source>The strength of the gaussian blur.</source>
        <translation>高斯模糊的強度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="122"/>
        <source>If the difference between the original pixel and the blurred pixel is less than threshold, the pixel will be replaced with the blurred pixel.</source>
        <translation>若原像素與模糊後的像素差值小於閾值，該像素便會被模糊後的像素取代。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="50"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="60"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="152"/>
        <source>Green</source>
        <translation>綠</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="58"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="89"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="179"/>
        <source>Blue</source>
        <translation>藍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="125"/>
        <source>Red</source>
        <translation>紅色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <source>Value</source>
        <translation>數值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="198"/>
        <source>Histogram</source>
        <translation>長條圖</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="227"/>
        <source>Input Black</source>
        <translation>輸入黑色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="251"/>
        <source>Input White</source>
        <translation>輸入白色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="275"/>
        <source>Gamma</source>
        <translation>色差補正</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="299"/>
        <source>Output Black</source>
        <translation>輸出黑色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="320"/>
        <source>Output White</source>
        <translation>輸出白色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="27"/>
        <source>Click Analyze to use this filter.</source>
        <translation>按一下「分析」以使用此濾鏡。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="90"/>
        <source>Select a file to store analysis results.</source>
        <translation>選取要儲存分析結果的檔案。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="116"/>
        <source>&lt;b&gt;Analyze Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;分析選項&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="121"/>
        <source>Shakiness</source>
        <translation>抖動程度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="142"/>
        <source>Accuracy</source>
        <translation>準確性</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="184"/>
        <source>&lt;b&gt;Filter Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;濾鏡選項&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="492"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="189"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="118"/>
        <source>Zoom</source>
        <translation>縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="248"/>
        <source>Stabilization file:</source>
        <translation>穩定紀錄檔：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="252"/>
        <source>The stabilization file generated by the analysis.</source>
        <translation>經分析所產生的穩定紀錄檔。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="189"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="291"/>
        <source>File for motion analysis</source>
        <translation>用於動態分析的檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="390"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="168"/>
        <source>Browse...</source>
        <translation>瀏覽…</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="395"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="172"/>
        <source>Start Offset</source>
        <translation>起始位移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="407"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="181"/>
        <source>seconds</source>
        <translation>秒</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="438"/>
        <source>Analysis</source>
        <translation>分析</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="448"/>
        <source>Apply transform</source>
        <translation>套用變形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="454"/>
        <source>Sample Radius</source>
        <translation>採樣半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="477"/>
        <source>Search Radius</source>
        <translation>搜尋半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="523"/>
        <source>Track Points</source>
        <translation>追蹤點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="530"/>
        <source>Use backwards-facing track points</source>
        <translation>使用反向追蹤點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="566"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="641"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="716"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="215"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="212"/>
        <source>Smoothing</source>
        <translation>平滑處理</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="589"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="664"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="739"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="233"/>
        <source>Time Bias</source>
        <translation>時間偏差</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="70"/>
        <source> Red</source>
        <translation>紅</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="191"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="79"/>
        <source>Yellow</source>
        <translation>黃</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/ui.qml" line="96"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="60"/>
        <source>Amplitude</source>
        <translation>振幅</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="180"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="257"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="335"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="413"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="491"/>
        <location filename="../src/qml/filters/distort/ui.qml" line="125"/>
        <location filename="../src/qml/filters/glitch/ui.qml" line="101"/>
        <source>Frequency</source>
        <translation>頻率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/ui.qml" line="154"/>
        <source>Velocity</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="68"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>按住 %1 以限制在垂直方向拖曳關鍵影格，或 %2 以限制在水平方向</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="50"/>
        <source>Forward</source>
        <translation>快轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="52"/>
        <source>Freeze</source>
        <translation>凍結</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="53"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="54"/>
        <source>%L1s</source>
        <translation>%L1s</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="205"/>
        <source>Set Speed After</source>
        <translation>設定向後速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="205"/>
        <source>Set Speed Before</source>
        <translation>設定向前速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="242"/>
        <source>Modify current mapping</source>
        <translation>改變目前映射</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="247"/>
        <source>Lock current mapping</source>
        <translation>鎖定目前映射</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="257"/>
        <source>&quot;Modify current mapping&quot; will modify the input time at the current position.
&quot;Lock current mapping&quot; will lock the input time at the current position and modify the value of an adjacent keyframe</source>
        <translation>「改變目前映射」將改變目前位置的輸入時間。
「鎖定目前映射」將鎖定目前位置的輸入時間並調整相鄰關鍵影格的值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="265"/>
        <source>OK</source>
        <translation>確定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="273"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="309"/>
        <source>Time</source>
        <translation>時間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="313"/>
        <source>Map the specified input time to the current time. Use keyframes to vary the time mappings over time.</source>
        <translation>將指定的輸入時間對應至目前時間。以關鍵影格調整時間的映射方式。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="345"/>
        <source>Set the input time to achieve a desired speed before the current frame.</source>
        <translation>設定輸入時間，以在目前影格之前達到指定的速度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="361"/>
        <source>Set the input time to achieve a desired speed after the current frame.</source>
        <translation>設定輸入時間，以在目前影格之後達到指定的速度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="379"/>
        <source>Image mode</source>
        <translation>影像模式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="383"/>
        <source>Use the specified image selection mode. Nearest will output the image that is nearest to the mapped time. Blend will blend all images that occur during the mapped time.</source>
        <translation>使用指定的影像選擇模式。「最接近」會輸出最接近對應時間的影像；「混合」會混合所有在對應時間內產生的影像。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="128"/>
        <source>Hue Center</source>
        <translation>色調中心</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="131"/>
        <source>The center of the color range to be changed.</source>
        <translation>要改變的色彩範圍的中心點。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="157"/>
        <source>Hue Range</source>
        <translation>色調範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="160"/>
        <source>The width of the color range to be changed.</source>
        <translation>要改變的色彩範圍的寬度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="260"/>
        <source>Pick the center hue from a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation>從螢幕上的色彩選取中心色調。按住並拖曳滑鼠以選取一小塊螢幕區域，並取其平均色彩。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="592"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="855"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="265"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="408"/>
        <source>Blend</source>
        <translation>混色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="268"/>
        <source>The amount of blending to apply to the edges of the color range.</source>
        <translation>套用至色彩範圍邊界的混色幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="297"/>
        <source>The amount to shift the Hue of the color range.</source>
        <translation>偏移色彩範圍色調的幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="326"/>
        <source>The amount to scale the saturation of the color range.</source>
        <translation>調整色彩範圍飽和度的幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="355"/>
        <source>The amount to scale the lightness of the color range.</source>
        <translation>調整色彩範圍明度的幅度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="424"/>
        <source>Enable pitch compensation</source>
        <translation>啟用音高補償</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="452"/>
        <source>Speed:</source>
        <translation>速度：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="482"/>
        <source>Input Time:</source>
        <translation>輸入時間：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="497"/>
        <source>Output Time:</source>
        <translation>輸出時間：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="338"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="89"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="78"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="456"/>
        <source>The instantaneous speed of the last frame that was processed.</source>
        <translation>最後一個已處理影格的瞬時速度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="467"/>
        <source>Direction:</source>
        <translation>方向：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="471"/>
        <source>The instantaneous direction of the last frame that was processed.</source>
        <translation>最後一個已處理影格的瞬時方向。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="486"/>
        <source>The original clip time of the frame.</source>
        <translation>影格原先在短片中的時間。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="501"/>
        <source>The mapped output time for the input frame.</source>
        <translation>輸入影格對應的輸出時間。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="102"/>
        <source>Deform horizontally?</source>
        <translation>水平變形？</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="119"/>
        <source>Deform vertically?</source>
        <translation>垂直變形？</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="81"/>
        <source>Neutral color</source>
        <translation>中性色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="111"/>
        <source>Color temperature</source>
        <translation>色溫</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="183"/>
        <source>degrees</source>
        <translation>度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="147"/>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="161"/>
        <source>HH:MM:SS</source>
        <translation>HH:MM:SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="166"/>
        <source>HH:MM:SS.S</source>
        <translation>HH:MM:SS.S</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="171"/>
        <source>MM:SS</source>
        <translation>MM:SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="176"/>
        <source>MM:SS.SS</source>
        <translation>MM:SS.SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="181"/>
        <source>MM:SS.SSS</source>
        <translation>MM:SS.SSS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="186"/>
        <source>SS</source>
        <translation>SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="191"/>
        <source>SS.S</source>
        <translation>SS.S</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="196"/>
        <source>SS.SS</source>
        <translation>SS.SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="201"/>
        <source>SS.SSS</source>
        <translation>SS.SSS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="290"/>
        <source>A value of 0 will run the timer to the end of the filter</source>
        <translation>若設為 0，計時器將會執行至濾鏡結束為止</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="332"/>
        <source>When the direction is Down, the timer will count down to Offset.
When the direction is Up, the timer will count up starting from Offset.</source>
        <translation>當方向為「向下」，計時器將會往下倒數到「位移」。
當方向為「向上」，計時器將會由「位移」開始往上數。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="359"/>
        <source>Timer seconds per playback second. Scales Duration but does not affect Start Delay or Offset.</source>
        <translation>每播放一秒，計時器所顯示經過的秒數。「長度」依此比例縮放，但「啟動延遲」與「時差」不受影響。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="122"/>
        <source>Minimal strength</source>
        <translation>最低強度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="133"/>
        <source>Average strength</source>
        <translation>平均強度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="144"/>
        <source>Blue sky</source>
        <translation>藍色天空</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="155"/>
        <source>Red sky</source>
        <translation>紅色天空</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="166"/>
        <source>Full range to limited range</source>
        <translation>轉換全範圍色彩至有限範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="210"/>
        <source>Contrast threshold</source>
        <translation>對比閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="214"/>
        <source>Banding similarity within first component
Y (luma) in YCbCr mode
Red in RGB mode</source>
        <translation>第一項色彩分量中的頻帶相似度
於 YCbCr 模式下為 Y（亮度）
於 RGB 模式下為紅色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="233"/>
        <source>Blue threshold</source>
        <translation>藍色閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="237"/>
        <source>Banding similarity within second component
Cb (blue) in YCbCr mode
Green in RGB mode</source>
        <translation>第二項色彩分量中的頻帶相似度
於 YCbCr 模式下為 Cb（藍色）
於 RGB 模式下為綠色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="256"/>
        <source>Red threshold</source>
        <translation>紅色閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="260"/>
        <source>Banding similarity within third component
Cr (red) in YCbCr mode
Blue in RGB mode</source>
        <translation>第三項色彩分量中的頻帶相似度
於 YCbCr 模式下為 Cr（紅色）
於 RGB 模式下為藍色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="279"/>
        <source>Alpha threshold</source>
        <translation>Alpha 閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="283"/>
        <source>Banding similarity within fourth component</source>
        <translation>第四項色彩分量中的頻帶相似度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="308"/>
        <source>Link thresholds</source>
        <translation>連動閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="317"/>
        <source>Pixel range</source>
        <translation>像素範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="321"/>
        <source>The size of bands being targeted</source>
        <translation>目標頻帶的大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="348"/>
        <source>Randomize pixel range between zero and value</source>
        <translation>在 0 到此值之間隨機分布像素範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="357"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="208"/>
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="361"/>
        <source>Up = 270°
Down = 90°
Left = 180°
Right = 0° or 360°
All = 360° + Randomize</source>
        <translation>上：270°
下：90°
左：180°
右：0° 或 360°
全部：360° + 隨機</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="388"/>
        <source>Randomize direction between zero degrees and value</source>
        <translation>在 0 度到此數值間隨機選擇方向</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="403"/>
        <source>Measure similarity using average of neighbors</source>
        <translation>以鄰近像素的平均值測量相似度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="407"/>
        <source>Compare to thresholds using average versus exact neighbor values</source>
        <translation>使用相鄰像素確切的數值或平均值來比較閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="425"/>
        <source>All components required to trigger deband</source>
        <translation>所有分量皆需達到觸發標準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="429"/>
        <source>Deband only if all pixel components (including alpha) are within thresholds</source>
        <translation>只有當所有色彩分量（包含不透明度）皆在閾值內，才會對像素去除頻帶</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1164"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1301"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="222"/>
        <source>Up</source>
        <translation>向上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="227"/>
        <source>Down</source>
        <translation>向下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="234"/>
        <source>Start Delay</source>
        <translation>啟動延遲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="253"/>
        <source>The timer will be frozen from the beginning of the filter until the Start Delay time has elapsed.</source>
        <translation>從濾鏡開始後到經過「啟動延遲」的這段時間，計時器都將凍結。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="265"/>
        <source>Set start to begin at the current position</source>
        <translation>將起始點設為目前位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="290"/>
        <source>The timer will be frozen after the Duration has elapsed.</source>
        <translation>計時器在經過指定的時間「長度」後將會凍結。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="307"/>
        <source>Set duration to end at the current position</source>
        <translation>將長度設為在目前位置結束</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="500"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="258"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="313"/>
        <source>Offset</source>
        <translation>時差</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="149"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="223"/>
        <source>File</source>
        <translation>檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="285"/>
        <source>Custom...</source>
        <translation>自訂…</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="280"/>
        <source>Bar Horizontal</source>
        <translation>水平抹除</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="290"/>
        <source>Bar Vertical</source>
        <translation>垂直抹除</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="295"/>
        <source>Barn Door Horizontal</source>
        <translation>水平對開</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="300"/>
        <source>Barn Door Vertical</source>
        <translation>垂直對開</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="305"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>斜角對開－左下至右上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="310"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>斜角對開－左上至右下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="315"/>
        <source>Diagonal Top Left</source>
        <translation>對角左上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="320"/>
        <source>Diagonal Top Right</source>
        <translation>對角右上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="325"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>水平矩陣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="330"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>垂直矩陣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="335"/>
        <source>Matrix Snake Horizontal</source>
        <translation>水平矩陣－蛇形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="340"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>水平矩陣－蛇形對消</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="345"/>
        <source>Matrix Snake Vertical</source>
        <translation>垂直矩陣－蛇形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="350"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>垂直矩陣－蛇形對消</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="355"/>
        <source>Barn V Up</source>
        <translation>V 字對開</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="360"/>
        <source>Iris Circle</source>
        <translation>虹膜</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="365"/>
        <source>Double Iris</source>
        <translation>雙瞳</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="370"/>
        <source>Iris Box</source>
        <translation>矩形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="375"/>
        <source>Box Bottom Right</source>
        <translation>消去－右下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="380"/>
        <source>Box Bottom Left</source>
        <translation>消去－左下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="385"/>
        <source>Box Right Center</source>
        <translation>消去－右中</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="390"/>
        <source>Clock Top</source>
        <translation>順時針</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="262"/>
        <source>Set a mask from another file&apos;s brightness or alpha.</source>
        <translation>以其他檔案的亮度或 Alpha 頻道作為遮罩。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="238"/>
        <source>Open Mask File</source>
        <translation>開啟遮罩檔</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="189"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="464"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="48"/>
        <source>Reverse</source>
        <translation>反轉</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="511"/>
        <source>Alpha</source>
        <translation>Alpha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="96"/>
        <source>Waveform Color</source>
        <translation>波形色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="154"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="112"/>
        <source>Background Color</source>
        <translation>背景色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="235"/>
        <source>Fill the area under the waveform.</source>
        <translation>填滿波形背後的區域。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="247"/>
        <source>Combine all channels into one waveform.</source>
        <translation>將多個頻道結合成一個波形。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="69"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="252"/>
        <source>Window</source>
        <translation>視域</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/ui.qml" line="166"/>
        <source>Rows</source>
        <translation>列</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/ui.qml" line="206"/>
        <source>Columns</source>
        <translation>欄</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="130"/>
        <source>Block height</source>
        <translation>區塊高度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="159"/>
        <source>Shift intensity</source>
        <translation>移位強度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="188"/>
        <source>Color intensity</source>
        <translation>色彩濃度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="89"/>
        <source>Spatial</source>
        <translation>空間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="118"/>
        <source>Temporal</source>
        <translation>時域</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="353"/>
        <source>Apply to Source</source>
        <translation>套用至來源</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="379"/>
        <source>Corner radius</source>
        <translation>圓角半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="407"/>
        <source>Padding color</source>
        <translation>間距色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="86"/>
        <source>Levels</source>
        <comment>Dither video filter</comment>
        <translation>等級</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="115"/>
        <source>Matrix</source>
        <translation>矩陣</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>2x2 Magic Square</source>
        <translation>2×2 魔方</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Magic Square</source>
        <translation>4×4 魔方</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Ordered</source>
        <translation>4×4 有序</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Lines</source>
        <translation>4×4 線條</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>6x6 90 Degree Halftone</source>
        <translation>6×6 90 度網點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>6x6 Ordered</source>
        <translation>6×6 有序</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>8x8 Ordered</source>
        <translation>8×8 有序</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-3 Clustered</source>
        <translation>Order-3 叢集</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-4 Ordered</source>
        <translation>Order-4 有序</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-8 Ordered</source>
        <translation>Order-8 有序</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="106"/>
        <source>Horizontal center position of the linear area.</source>
        <translation>線性區域的水平中心位置。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="135"/>
        <source>Linear width</source>
        <translation>線性寬度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="139"/>
        <source>Width of the linear area.</source>
        <translation>線性區域寬度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="168"/>
        <source>Linear scale factor</source>
        <translation>線性縮放因數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="172"/>
        <source>Amount the linear area is scaled.</source>
        <translation>線性區域縮放量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="201"/>
        <source>Non-Linear scale factor</source>
        <translation>非線性縮放倍數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="205"/>
        <source>Amount the outer left and outer right areas are scaled non linearly.</source>
        <translation>左右外側區域非線性延展的程度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/threshold/ui.qml" line="141"/>
        <source>Compare with alpha channel</source>
        <translation>與 Alpha 頻道比較</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/ui.qml" line="91"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="65"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="73"/>
        <source> frames</source>
        <translation> 影格</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/ui.qml" line="81"/>
        <source>Repeat</source>
        <translation>重複</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="121"/>
        <source>Key Filter: Low Frequency</source>
        <translation>濾波器：低頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="150"/>
        <source>Key Filter: High Frequency</source>
        <translation>濾波器：高頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="184"/>
        <source>Output key only</source>
        <translation>僅輸出濾波</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="246"/>
        <source>Hold</source>
        <translation>延持</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="274"/>
        <source>Decay</source>
        <translation>衰減</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="302"/>
        <source>Range</source>
        <translation>範圍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="161"/>
        <source>Octave Shift</source>
        <translation>八度音位移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="165"/>
        <source>Specify the pitch shift in octaves.
-1 shifts down an octave.
+1 shifts up an octave.
0 is unchanged.</source>
        <translation>指定音高位移幾個八度。
-1 向下位移一個八度。
+1 向上位移一個八度。
0 不作改變。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="205"/>
        <source>Specify the speed change that should be compensated for.
2x will halve the pitch to compensate for the speed being doubled.</source>
        <translation>指定要被補償的速度變化。
2x 會將音高折半以補償加倍的速度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="201"/>
        <source>Speed Compensation</source>
        <translation>速度補償</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="69"/>
        <source>Light</source>
        <translation>輕微</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="75"/>
        <source>Medium</source>
        <translation>中等</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="81"/>
        <source>Heavy</source>
        <translation>強烈</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="121"/>
        <source>Method</source>
        <translation>方式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Soft</source>
        <translation>柔邊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Garrote</source>
        <translation>Garrote</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Hard</source>
        <comment>Remove Noise Wavelet filter</comment>
        <translation>實邊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="141"/>
        <source>Decompose</source>
        <translation>分解</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="175"/>
        <source>Percent</source>
        <translation>比率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="193"/>
        <source>Max decompositions for the current video mode</source>
        <translation>目前視訊模式的最大分解度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="199"/>
        <source>More information</source>
        <translation>更多資訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/ui.qml" line="84"/>
        <source>Levels</source>
        <comment>Posterize filter</comment>
        <translation>等級</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="113"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="430"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="143"/>
        <source>Transparent</source>
        <translation>透明</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="408"/>
        <source>Show grid</source>
        <translation>顯示格線</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/ui.qml" line="65"/>
        <source>Quantization</source>
        <translation>量化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/ui.qml" line="83"/>
        <location filename="../src/qml/filters/histeq/ui.qml" line="63"/>
        <source>Strength</source>
        <translation>強度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="105"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="40"/>
        <source>No File Loaded.</source>
        <translation>未載入檔案。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="107"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="42"/>
        <source>No GPS file loaded.
Click &quot;Open&quot; to load a file.</source>
        <translation>未載入 GPS 檔案。
按一下「開啟」以載入檔案。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="401"/>
        <source>Select GPS File</source>
        <translation>選取 GPS 檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="443"/>
        <source>Select Background Image</source>
        <translation>選取背景影像</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="463"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="218"/>
        <source>Open file</source>
        <translation>開啟檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="221"/>
        <source>Open GPS File</source>
        <translation>開啟 GPS 檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="503"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="238"/>
        <source>&lt;b&gt;GPS options&lt;/b&gt;</source>
        <translation>&lt;b&gt;GPS 選項&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="510"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="245"/>
        <source>GPS offset</source>
        <translation>GPS 時差</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="514"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="249"/>
        <source>This is added to video time to sync with gps time.</source>
        <translation>視訊時間將加上此值，以與 GPS 時間同步。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="533"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="266"/>
        <source>+ : Adds time to video (use if GPS is ahead).
 - : Subtracts time from video (use if video is ahead).</source>
        <translation>+：向視訊增加時間（當 GPS 較早開始時使用）。
−：由視訊扣除時間（當視訊較早開始時使用）。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="574"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="307"/>
        <source>Number of days to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>為了同步而需添加或扣除的視訊天數。
提示：可以用滑鼠滾輪調整數值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="613"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="346"/>
        <source>Number of hours to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>為了同步而需添加或扣除的視訊小時數。
提示：可以用滑鼠滾輪調整數值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="652"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="385"/>
        <source>Number of minutes to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>為了同步而需添加或扣除的視訊分鐘數。
提示：可以用滑鼠滾輪調整數值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="691"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="424"/>
        <source>Number of seconds to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>為了同步而需添加或扣除的視訊秒數。
提示：可以用滑鼠滾輪調整數值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="710"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="443"/>
        <source>Sync start of GPS to start of video file.
Tip: use this if you started GPS and video recording at the same time.</source>
        <translation>將 GPS 起始點與視訊檔案開頭同步。
提示：若錄影與 GPS 紀錄同時開始，請啟用此選項。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="749"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="482"/>
        <source>Sync start of GPS to current video time.
Tip: use this if you recorded the moment of the first GPS fix.</source>
        <translation>將 GPS 起始點與目前視訊時間同步。
提示：若有記錄首次 GPS 定位的時間，請啟用此選項。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="759"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="492"/>
        <source>GPS smoothing</source>
        <translation>GPS 平滑處理</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="763"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="496"/>
        <source>Average nearby GPS points to smooth out errors.</source>
        <translation>將相鄰的 GPS 座標取平均值，以平滑處理誤差。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="889"/>
        <source>&lt;b&gt;Graph data&lt;/b&gt;</source>
        <translation>&lt;b&gt;圖表資料&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="894"/>
        <source>Data source</source>
        <translation>資料來源</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="898"/>
        <source>Choose which data type is used for graph drawing.</source>
        <translation>選擇用以描繪圖表的資料類型。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Location (2D map)</source>
        <translation>地點（2D 地圖）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Altitude</source>
        <translation>高度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Heart rate</source>
        <translation>心率</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="919"/>
        <source>Graph type</source>
        <translation>圖表類型</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="923"/>
        <source>Graph types can add advanced interactions.</source>
        <translation>圖表類型可進一步增添互動。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Standard</source>
        <translation>標準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Follow dot (cropped)</source>
        <translation>跟隨點（裁剪）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Speedometer</source>
        <translation>速率計</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="941"/>
        <source>Standard = just a static map.
Follow dot = centers on the current location.
Speedometer = draws a simple speedometer.</source>
        <translation>標準：僅靜態地圖。
跟隨點：以目前位置為中心。
速率計：描繪簡易的速率計。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="947"/>
        <source>Trim time</source>
        <translation>修剪時間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="951"/>
        <source>Hides part of the graph at beginning or end.
This does not recompute min/max for any field.</source>
        <translation>隱藏圖表的部分開頭或結尾。
不會重新計算任何欄位的最大／最小值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="978"/>
        <source>Hides part of the beginning of the graph.</source>
        <translation>隱藏圖表的部分開頭。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1022"/>
        <source>Hides part of the end of the graph.</source>
        <translation>隱藏圖表的部分結尾。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1039"/>
        <source>Crop horizontal</source>
        <translation>水平裁剪</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1043"/>
        <source>Zooms in on the graph on the horizontal axis (longitude if map, time if simple graph).
The number is either a percentage or a numeric value interpreted as the legend type.
This field is not applicable for Speedometer type.</source>
        <translation>於橫軸（地圖為經度，簡易圖表為時間）上放大圖表。
可以數字或百分比的方式指定值；數字會解譯成圖例單位。
「速率計」圖表類型不適用此欄位。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1065"/>
        <source>Crops the graph from the left side.</source>
        <translation>從左側裁剪圖表。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1108"/>
        <source>Crops the graph from the right side. This value is ignored if mode is Follow dot.</source>
        <translation>從右側裁剪圖表。「跟隨點」模式將忽略此值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1116"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1225"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1116"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1225"/>
        <source>value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1126"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1235"/>
        <source>The crop values are interpreted as a percentage of total or as an absolute value (in legend unit).</source>
        <translation>裁剪數值可以是相對於整體的百分比，或是絕對的圖例單位數值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1130"/>
        <source>Input for horizontal crops can be a percentage or an absolute value.</source>
        <translation>水平裁剪可輸入百分比或絕對值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1147"/>
        <source>Crop vertical</source>
        <translation>垂直裁剪</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1151"/>
        <source>Zooms in on the graph on the vertical axis (latitude if map, value if simple graph).
The number is either a percentage or a numeric value interpreted as the legend type.
This field affects min/max values on the Speedometer type.</source>
        <translation>於縱軸（地圖為緯度，簡易圖表為數值）上放大圖表。
可以數字或百分比的方式指定值；數字會解譯成圖例單位。
此欄位影響「速率計」圖表類型中呈現的最大與最小值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1174"/>
        <source>Crops the graph from the bottom side.</source>
        <translation>從底部裁剪圖表。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1217"/>
        <source>Crops the graph from the top side. This value is ignored if mode is Follow dot.</source>
        <translation>從頂部裁剪圖表。「跟隨點」模式將忽略此值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1239"/>
        <source>Input for vertical crops can be a percentage or an absolute value.</source>
        <translation>垂直裁剪可輸入百分比或絕對值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1257"/>
        <source>&lt;b&gt;Graph design&lt;/b&gt;</source>
        <translation>&lt;b&gt;圖表設計&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1262"/>
        <source>Color style</source>
        <translation>色彩樣式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1266"/>
        <source>Choose how you want to color the graph line.</source>
        <translation>選擇為圖表線條上色的方式。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>One color</source>
        <translation>單色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Two colors</source>
        <translation>雙色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Solid past, thin future</source>
        <translation>過去實線、未來細線</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Solid future, thin past</source>
        <translation>未來實線、過去細線</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Vertical gradient</source>
        <translation>垂直漸層</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Horizontal gradient</source>
        <translation>水平漸層</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by duration</source>
        <translation>依長度上色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by altitude</source>
        <translation>依高度上色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by heart rate</source>
        <translation>依心率上色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by speed</source>
        <translation>依速度上色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by speed (max 100km/h)</source>
        <translation>依速度上色（最高 100km/h）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by grade (max 90°)</source>
        <translation>依坡度上色（最大 90°）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by grade (max 20°)</source>
        <translation>依坡度上色（最大 20°）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1306"/>
        <source>Color by Altitude/HR only work if there are recorded values in the gps file.
For speedometer type, only first 2 colors are used.</source>
        <translation>「依高度」、「依心率上色」僅於 GPS 檔案中有對應紀錄值時發揮作用。
「速率計」圖表類型僅使用前 2 種顏色。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1348"/>
        <source>Now dot</source>
        <translation>現在地點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1352"/>
        <source>Draw a dot showing current position on the graph.
For speedometer type, this is the needle.</source>
        <translation>於圖表上描繪代表目前位置的點。
「速率計」圖表類型中為指針。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1370"/>
        <source>Set the color of the inside of the now dot (or needle).</source>
        <translation>設定現在地點（或指針）內部填充的色彩。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1394"/>
        <source>Now text</source>
        <translation>現在地文字</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1399"/>
        <source>Draw a large white text showing the current value.
The legend unit (if present) will be appended at the end.</source>
        <translation>描繪大型白色文字以顯示目前數值。
若有圖例單位，則將附加於文字結尾。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1417"/>
        <source>Rotate the entire graph. Speedometer also rotates internal text.</source>
        <translation>旋轉整幅圖表。「速率計」圖表類型中亦將旋轉內部文字。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1451"/>
        <source>Set the thickness of the graph line. Does not affect speedometer.</source>
        <translation>設定圖表線條粗細。「速率計」圖表類型不受影響。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1481"/>
        <source>Draw legend</source>
        <translation>描繪圖例</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1485"/>
        <source>Draw 5 horizontal white lines with individual values for graph readability. 2D map also draws vertical (longitude) lines.
For speedometer this draws text for divisions.</source>
        <translation>描繪各有標示數值的 5 條水平白線以增加圖表易讀性。
在 2D 地圖中，會一併描繪垂直（經度）線。
速率計則會為刻度描繪文字。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1498"/>
        <source>Unit</source>
        <translation>單位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1502"/>
        <source>This will be used in legend text if active and in absolute value math.</source>
        <translation>用於圖例文字與絕對值運算。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1514"/>
        <source>Defaults are km/h (speed) and meters (altitude).
 Available options: km/h, mi/h, nm/h (kn), m/s, ft/s.</source>
        <translation>預設值為 km/h（速度）及 m（高度）。
可用選項：km/h、mi/h、nm/h (kn)、m/s、ft/s。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1648"/>
        <source>Sets the height to the correct map aspect ratio or 1:1.</source>
        <translation>將高度設定為正確的地圖外觀比例或 1:1。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1655"/>
        <source>&lt;b&gt;Background options&lt;/b&gt;</source>
        <translation>&lt;b&gt;背景選項&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1660"/>
        <source>Image path</source>
        <translation>影像路徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1664"/>
        <source>Choose an image to overlay behind the graph. Tip: you can use an actual map image to make the GPS track more interesting.</source>
        <translation>選擇欲覆疊於圖表後方的影像。提示：使用實際地圖影像能讓 GPS 軌跡更有吸引力。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1696"/>
        <source>GPS file center is: </source>
        <translation>GPS 檔案中心為：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1699"/>
        <source>Get the center coordinate of GPS map. This does not change with trim or crop.
TIP:OpenStreetMap website can save the current standard map centered on searched location (but only at screen resolution).
Google Earth for desktop can center on a coordinate and save a 4K image of it. Disable the Terrain layer for best results.</source>
        <translation>取得 GPS 地圖的中心座標，不依修剪或裁剪而變動。
提示：OpenStreetMap 網站能儲存以目前搜尋地點為中心點的標準地圖（但受限於螢幕解析度）。
桌面版 Google Earth 能以特定座標為中心儲存 4K 影像。停用「地形」圖層以取得最佳結果。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1710"/>
        <source>Browse for an image file to be assigned as graph background.</source>
        <translation>瀏覽欲指定為圖表背景的影像檔案。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1727"/>
        <source>Increase or decrease the size of the background image.
Values smaller than 1 will zoom into image.</source>
        <translation>放大或縮小背景影像的尺寸。
小於 1 的數值將會放大影像。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="584"/>
        <source>Processing start</source>
        <translation>起計點</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="589"/>
        <source>Distances are calculated since the start of the gps file, use this field to reset them (GPS time).</source>
        <translation>預設為從 GPS 檔案開頭開始計算距離，使用此欄位以重設起計點（GPS 時間）。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="606"/>
        <source>Insert date and time formatted exactly as: YYYY-MM-DD HH:MM:SS (GPS time).</source>
        <translation>輸入完全符合「YYYY-MM-DD HH:MM:SS」（GPS 時間）格式的日期與時間。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="621"/>
        <source>Set start of GPS processing to current video time.</source>
        <translation>將 GPS 資料處理起計點設為目前視訊時間。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="674"/>
        <source>&lt;b&gt;Text options&lt;/b&gt;</source>
        <translation>&lt;b&gt;文字選項&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="792"/>
        <source>Insert GPS field</source>
        <translation>插入 GPS 欄位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="881"/>
        <source>Extra arguments can be added inside keywords:
Distance units: m [km|ft|mi].
Speed units: km/h [mi/h|m/s|ft/s].
Time default: %Y-%m-%d %H:%M:%S, extra offset can be added as +/-seconds (+3600).
Extra keyword: RAW (prints only values from file).</source>
        <translation>可於關鍵字內額外添加格式引數：
距離單位：m［km、ft、mi］。
速度單位：km/h［mi/h、m/s、ft/s］。
時間預設：%Y-%m-%d %H:%M:%S，可以 +/- 秒數添加額外的時差（+3600）。
額外關鍵字：RAW（只顯示檔案數值）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS latitude</source>
        <translation>GPS 緯度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS longitude</source>
        <translation>GPS 經度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation (m)</source>
        <translation>海拔（公尺）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Speed (km/h)</source>
        <translation>速度（km/h）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance (m)</source>
        <translation>距離（公尺）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS date-time</source>
        <translation>GPS 日期與時間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Video file date-time</source>
        <translation>視訊檔案日期與時間</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Heart-rate (bpm)</source>
        <translation>心率（bpm）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Bearing (degrees)</source>
        <translation>方位（度）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Bearing (compass)</source>
        <translation>方位（羅盤）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation gain (m)</source>
        <translation>海拔增益（公尺）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation loss (m)</source>
        <translation>海拔損失（公尺）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance uphill (m)</source>
        <translation>上坡距離（公尺）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance downhill (m)</source>
        <translation>下坡距離（公尺）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance flat (m)</source>
        <translation>平地距離（公尺）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Cadence</source>
        <translation>步調</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Temperature (C)</source>
        <translation>氣溫（攝氏）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Grade (%)</source>
        <translation>坡度（%）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Grade (degrees)</source>
        <translation>坡度（度）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Vertical speed (m/s)</source>
        <translation>垂直速度（m/s）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>3D Speed (km/h)</source>
        <translation>3D 速度（km/h）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="803"/>
        <source>Power (W)</source>
        <translation>功率（瓦）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="895"/>
        <source>&lt;b&gt;Advanced options&lt;/b&gt;</source>
        <translation>&lt;b&gt;進階選項&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="848"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="634"/>
        <source>Video speed</source>
        <translation>視訊速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="852"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="639"/>
        <source>If the current video is sped up (timelapse) or slowed down use this field to set the speed.</source>
        <translation>若視訊經過加速（縮時）或減速，請以此欄位設定正確速度。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="875"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="660"/>
        <source>Fractional times are also allowed (0.25 = 4x slow motion, 5 = 5x timelapse).</source>
        <translation>亦可輸入分數倍率（0.25：4× 慢動作，5：5× 縮時）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="900"/>
        <source>Update speed</source>
        <translation>更新速度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="905"/>
        <source>Set how many text updates to show per second.
Set to 0 to only print real points (no interpolation).</source>
        <translation>設定文字每秒顯示的更新次數。
若只要顯示實際資料點（不進行內插補點），請設為 0。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="923"/>
        <source>Fractional times are also allowed (0.25 = update every 4 seconds, 5 = 5 updates per second).</source>
        <translation>亦可輸入分數倍率（0.25：每 4 秒更新一次，5：每秒更新 5 次）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="933"/>
        <source> per second</source>
        <translation> 次／秒</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1770"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="960"/>
        <source>Video start time:</source>
        <translation>視訊開始時間：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1775"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="965"/>
        <source>Detected date-time for the video file.</source>
        <translation>偵測到視訊檔案的日期與時間。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1793"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="983"/>
        <source>GPS start time:</source>
        <translation>GPS 開始時間：</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1798"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="988"/>
        <source>Detected date-time for the GPS file.</source>
        <translation>偵測到 GPS 檔案的日期與時間。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1809"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="999"/>
        <source>This time will be used for synchronization.</source>
        <translation>此時間將用於同步。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="599"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="111"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="259"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="622"/>
        <source>Tip: Mask other video filters by adding filters after this one followed by &lt;b&gt;Mask: Apply&lt;/b&gt;</source>
        <translation>提示：將其他視訊濾鏡置於&lt;b&gt;「遮罩：套用」&lt;/b&gt;後方以對其套用遮罩。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="128"/>
        <source>50 Hz</source>
        <translation>50 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="198"/>
        <source>100 Hz</source>
        <translation>100 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="222"/>
        <source>156 Hz</source>
        <translation>156 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="246"/>
        <source>220 Hz</source>
        <translation>220 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="270"/>
        <source>311 Hz</source>
        <translation>311 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="294"/>
        <source>440 Hz</source>
        <translation>440 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="318"/>
        <source>622 Hz</source>
        <translation>622 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="342"/>
        <source>880 Hz</source>
        <translation>880 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="366"/>
        <source>1250 Hz</source>
        <translation>1250 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="390"/>
        <source>1750 Hz</source>
        <translation>1750 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="414"/>
        <source>2500 Hz</source>
        <translation>2500 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="438"/>
        <source>3500 Hz</source>
        <translation>3500 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="462"/>
        <source>5000 Hz</source>
        <translation>5000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="486"/>
        <source>10000 Hz</source>
        <translation>10000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="510"/>
        <source>20000 Hz</source>
        <translation>20000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="130"/>
        <source>Low</source>
        <translation>低</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="188"/>
        <source>Mid</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="212"/>
        <source>High</source>
        <translation>高</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="87"/>
        <source>Source</source>
        <translation>來源</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <source>Middle (L+R)</source>
        <translation>中央（左+右）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <source>Side (L-R)</source>
        <translation>側邊（左−右）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="117"/>
        <source>Left delay</source>
        <translation>左方延遲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="143"/>
        <source>Left delay gain</source>
        <translation>左方延遲增益</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="169"/>
        <source>Right delay</source>
        <translation>右方延遲</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="195"/>
        <source>Right delay gain</source>
        <translation>右方延遲增益</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="221"/>
        <source>Output gain</source>
        <translation>輸出增益</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="103"/>
        <source>New...</source>
        <translation>新增…</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="114"/>
        <source>New Animation File</source>
        <translation>新增動畫檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="124"/>
        <source>Open Animation File</source>
        <translation>開啟動畫檔案</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="134"/>
        <source>Click &lt;b&gt;New...&lt;/b&gt; or &lt;b&gt;Open...&lt;/b&gt; to use this filter</source>
        <translation>按一下&lt;b&gt;「新增…」&lt;/b&gt;或&lt;b&gt;「開啟…」&lt;/b&gt;以使用此濾鏡</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="149"/>
        <source>Edit...</source>
        <translation>編輯…</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="154"/>
        <source>Reload</source>
        <translation>重新載入</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="124"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="139"/>
        <source>Region To Track</source>
        <translation>追蹤區域</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="148"/>
        <source>Set the region of interest to track.</source>
        <translation>設定追蹤的目標區域。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="267"/>
        <source>Algorithm</source>
        <translation>演算法</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="270"/>
        <source>Chooses the way (rules) the tracking is calculated.</source>
        <translation>選取追蹤計算的方式（規則）。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="348"/>
        <source>Show preview</source>
        <translation>顯示預覽</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="88"/>
        <source>Discontinuity threshold</source>
        <translation>不連續閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="92"/>
        <source>The threshold to apply a seam to splices</source>
        <translation>套用斷縫至剪輯片段的閾值。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="128"/>
        <source>Seam applied</source>
        <translation>套用斷縫</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="132"/>
        <source>Status indicator showing when a splice has been seamed.</source>
        <translation>剪輯片段斷縫時的狀態指示器。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="36"/>
        <source>Fade to White</source>
        <translation>淡出至白色</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="123"/>
        <source>Fade color</source>
        <translation>淡化色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="181"/>
        <source>Azimuth</source>
        <translation>方位</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="225"/>
        <source>Elevation</source>
        <translation>仰角</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/ui.qml" line="82"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="98"/>
        <source>Intensity</source>
        <translation>濃度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/ui.qml" line="113"/>
        <source>Subtitle Track</source>
        <translation>字幕軌道</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="153"/>
        <source>Horizontal 4:3</source>
        <translation>水平 4:3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="158"/>
        <source>Horizontal 16:9</source>
        <translation>水平 16:9</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="163"/>
        <source>Square</source>
        <translation>正方形</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="170"/>
        <source>Vertical 9:16</source>
        <translation>垂直 9:16</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="140"/>
        <source>Sepia</source>
        <translation>棕褐</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="146"/>
        <source>Thermal</source>
        <translation>熱力</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="205"/>
        <source>Color #%1</source>
        <translation>色彩 #%1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="211"/>
        <source>Color: %1
Click to select, drag to change position</source>
        <translation>色彩：%1
按一下以選取，拖曳以變更位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="344"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="159"/>
        <source>Overlap</source>
        <translation>重疊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="186"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="294"/>
        <source>Hue Shift</source>
        <translation>色調偏移</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="192"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="355"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="518"/>
        <source>Reds</source>
        <translation>紅</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="218"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="381"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="544"/>
        <source>Yellows</source>
        <translation>黃</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="244"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="407"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="570"/>
        <source>Greens</source>
        <translation>綠</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="270"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="433"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="596"/>
        <source>Cyans</source>
        <translation>青</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="296"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="459"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="622"/>
        <source>Blues</source>
        <translation>藍</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="322"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="485"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="648"/>
        <source>Magentas</source>
        <translation>洋紅</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="349"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="323"/>
        <source>Saturation Scale</source>
        <translation>調整飽和度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="512"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="352"/>
        <source>Lightness Scale</source>
        <translation>調整明度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="520"/>
        <source>Blur Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="111"/>
        <source>File for zenith correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="209"/>
        <source>Smooth yaw instead of locking it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/ui.qml" line="116"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ui_av</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="70"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="89"/>
        <source>Amount</source>
        <translation>總量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="126"/>
        <source>Blur alpha</source>
        <translation>模糊 Alpha</translation>
    </message>
</context>
<context>
    <name>ui_box_blur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="70"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="90"/>
        <source>Width</source>
        <translation>寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="119"/>
        <source>Height</source>
        <translation>高</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="152"/>
        <source>Blur alpha</source>
        <translation>模糊 Alpha</translation>
    </message>
</context>
<context>
    <name>ui_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="138"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="169"/>
        <source>Width</source>
        <translation>寬</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="208"/>
        <source>Height</source>
        <translation>高</translation>
    </message>
</context>
<context>
    <name>ui_dance</name>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="71"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="84"/>
        <source>Initial Zoom</source>
        <translation>初始縮放量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="88"/>
        <source>The amount to zoom the image before any motion occurs.</source>
        <translation>在所有動作開始之前，影像要縮放的量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="108"/>
        <source>Oscillation</source>
        <translation>振盪</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="112"/>
        <source>Oscillation can be useful to make the image move back and forth during long periods of sound.</source>
        <translation>振盪能在諸如聲音長時間持續的情況下派上用場，使影像來回移動。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="132"/>
        <source>Zoom</source>
        <translation>縮放</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="136"/>
        <source>The amount that the audio affects the zoom of the image.</source>
        <translation>音訊影響影像的縮放量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="156"/>
        <source>Up</source>
        <translation>向上</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="160"/>
        <source>The amount that the audio affects the upward offset of the image.</source>
        <translation>音訊影響影像往上的位移量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="180"/>
        <source>Down</source>
        <translation>向下</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="184"/>
        <source>The amount that the audio affects the downward offset of the image.</source>
        <translation>音訊影響影像往下的位移量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="204"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="208"/>
        <source>The amount that the audio affects the left offset of the image.</source>
        <translation>音訊影響影像往左的位移量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="228"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="232"/>
        <source>The amount that the audio affects the right offset of the image.</source>
        <translation>音訊影響影像往右的位移量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="252"/>
        <source>Clockwise</source>
        <translation>順時針</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="256"/>
        <source>The amount that the audio affects the clockwise rotation of the image.</source>
        <translation>音訊影響影像順時針的轉動量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="267"/>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="291"/>
        <source> deg</source>
        <translation>度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="276"/>
        <source>Counterclockwise</source>
        <translation>逆時針</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="280"/>
        <source>The amount that the audio affects the counterclockwise rotation of the image.</source>
        <translation>音訊影響影像逆時針的轉動量。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="300"/>
        <source>Low Frequency</source>
        <translation>低頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="304"/>
        <source>The low end of the frequency range to be used to influence the image motion.</source>
        <translation>用以影響影像動態的頻段低端。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="328"/>
        <source>High Frequency</source>
        <translation>高頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="332"/>
        <source>The high end of the frequency range to be used to influence the image motion.</source>
        <translation>用以影響影像動態的頻段高端。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="356"/>
        <source>Threshold</source>
        <translation>閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="360"/>
        <source>The minimum amplitude of sound that must occur within the frequency range to cause the image to move.</source>
        <translation>頻段內能使影像移動的最小聲音振幅。</translation>
    </message>
</context>
<context>
    <name>ui_frei0r</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_frei0r.qml" line="65"/>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="97"/>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="100"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="130"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="116"/>
        <source>Blur</source>
        <translation>模糊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="81"/>
        <source>Grayscale</source>
        <translation>灰階</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="123"/>
        <source>Level</source>
        <translation>位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_frei0r.qml" line="84"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="148"/>
        <source>Amount</source>
        <translation>總量</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="173"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
</context>
<context>
    <name>ui_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="56"/>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Shadows (Lift)</source>
        <translation>陰影（提升）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Midtones (Gamma)</source>
        <translation>中間調（色差補正）</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Highlights (Gain)</source>
        <translation>亮部（增益）</translation>
    </message>
</context>
<context>
    <name>ui_lightshow</name>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="79"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="96"/>
        <source>Waveform Color</source>
        <translation>波形色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="112"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="153"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="194"/>
        <source>Oscillation</source>
        <translation>振盪</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="198"/>
        <source>Oscillation can be useful to make the light blink during long periods of sound.</source>
        <translation>振盪能在諸如聲音長時間持續的情況下派上用場，使光線閃爍。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="218"/>
        <source>Low Frequency</source>
        <translation>低頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="222"/>
        <source>The low end of the frequency range to be used to influence the light.</source>
        <translation>用以影響光線的頻段低端。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="246"/>
        <source>High Frequency</source>
        <translation>高頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="250"/>
        <source>The high end of the frequency range to be used to influence the light.</source>
        <translation>用以影響光線的頻段高端。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="274"/>
        <source>Threshold</source>
        <translation>閾值</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="278"/>
        <source>The minimum amplitude of sound that must occur within the frequency range to cause the light to change.</source>
        <translation>頻段內能使光線變化的最小聲音振幅。</translation>
    </message>
</context>
<context>
    <name>ui_movit</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="118"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="149"/>
        <source>Radius</source>
        <translation>半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="163"/>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="121"/>
        <source>Level</source>
        <translation>位準</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="95"/>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="139"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="129"/>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="98"/>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="136"/>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="127"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="175"/>
        <source>Highlight blurriness</source>
        <translation>亮部模糊度</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="201"/>
        <source>Highlight cutoff</source>
        <translation>亮部截止</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="79"/>
        <source>Grayscale</source>
        <translation>灰階</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="155"/>
        <source>Circle radius</source>
        <translation>圓弧半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="181"/>
        <source>Gaussian radius</source>
        <translation>高斯半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="207"/>
        <source>Correlation</source>
        <translation>係數</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="232"/>
        <source>Noise</source>
        <translation>雜訊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="147"/>
        <source>Outer radius</source>
        <translation>外半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="171"/>
        <source>Inner radius</source>
        <translation>內半徑</translation>
    </message>
</context>
<context>
    <name>ui_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="137"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="158"/>
        <source>Radius</source>
        <translation>半徑</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="182"/>
        <source>Feathering</source>
        <translation>羽化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="212"/>
        <source>Non-linear feathering</source>
        <translation>非線性羽化</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="222"/>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
</context>
<context>
    <name>ui_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="103"/>
        <source>Preset</source>
        <translation>預設設定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="120"/>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Line</source>
        <translation>線條</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Bar</source>
        <translation>直條</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Segment</source>
        <translation>區段</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="149"/>
        <source>Spectrum Color</source>
        <translation>頻譜色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="165"/>
        <source>Background Color</source>
        <translation>背景色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="179"/>
        <source>Thickness</source>
        <translation>粗細</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="199"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="246"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="300"/>
        <source>Fill the area under the spectrum.</source>
        <translation>填滿頻譜背後的區域。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="312"/>
        <source>Mirror the spectrum.</source>
        <translation>鏡像頻譜。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="324"/>
        <source>Reverse the spectrum.</source>
        <translation>反轉頻譜。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="329"/>
        <source>Tension</source>
        <translation>張力</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="348"/>
        <source>Segments</source>
        <translation>區段</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="371"/>
        <source>Segment Gap</source>
        <translation>區段間距</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="394"/>
        <source>Bands</source>
        <translation>頻段</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="413"/>
        <source>Low Frequency</source>
        <translation>低頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="417"/>
        <source>The low end of the frequency range of the spectrum.</source>
        <translation>頻譜的頻段低端。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="441"/>
        <source>High Frequency</source>
        <translation>高頻</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="445"/>
        <source>The high end of the frequency range of the spectrum.</source>
        <translation>頻譜的頻段高端。</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="469"/>
        <source>Threshold</source>
        <translation>閾值</translation>
    </message>
</context>
<context>
    <name>vui</name>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="213"/>
        <source>Hold Shift while dragging any corner to drag all corners</source>
        <translation>在拖曳任一角時按住 Shift 鍵，以同時拖曳所有角落</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="276"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="318"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="360"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="402"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="366"/>
        <source>Text size</source>
        <translation>文字大小</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="385"/>
        <source>Text color</source>
        <translation>文字色彩</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="487"/>
        <source>Collapse Toolbar</source>
        <translation>摺疊工具列</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="487"/>
        <source>Expand Toolbar</source>
        <translation>展開工具列</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="270"/>
        <source>Menu</source>
        <translation>功能表</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="596"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="607"/>
        <source>Center</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="618"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="629"/>
        <source>Justify</source>
        <translation>對齊</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="640"/>
        <source>Bold</source>
        <translation>粗體</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="651"/>
        <source>Italic</source>
        <translation>斜體</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="662"/>
        <source>Underline</source>
        <translation>底線</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="812"/>
        <source>OK</source>
        <translation>確定</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="820"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="331"/>
        <location filename="../src/qml/filters/richtext/vui.qml" line="673"/>
        <source>Font</source>
        <translation>字型</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="746"/>
        <source>Insert Table</source>
        <translation>插入表格</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="686"/>
        <source>Decrease Indent</source>
        <translation>減少縮排</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="695"/>
        <source>Insert Indent</source>
        <translation>插入縮排</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="758"/>
        <source>Rows</source>
        <translation>列</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="775"/>
        <source>Columns</source>
        <translation>欄</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="791"/>
        <source>Border</source>
        <translation>框線</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/vui.qml" line="26"/>
        <location filename="../src/qml/filters/gpsgraphic/vui.qml" line="26"/>
        <location filename="../src/qml/filters/gradient/vui.qml" line="109"/>
        <location filename="../src/qml/filters/lightshow/vui.qml" line="26"/>
        <location filename="../src/qml/filters/mask_alphaspot/vui.qml" line="108"/>
        <location filename="../src/qml/filters/pillar_echo/vui.qml" line="82"/>
        <location filename="../src/qml/filters/reframe/vui.qml" line="86"/>
        <location filename="../src/qml/filters/spot_remover/vui.qml" line="82"/>
        <location filename="../src/qml/filters/tracker/vui.qml" line="48"/>
        <location filename="../src/qml/filters/waveform/vui.qml" line="26"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>在矩形內按一下並按住 Shift 鍵以拖曳</translation>
    </message>
</context>
<context>
    <name>vui_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/vui_spectrum.qml" line="26"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>按住矩形後長壓 Shift 即可拖曳</translation>
    </message>
</context>
</TS>
