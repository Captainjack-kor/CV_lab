<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs_CZ">
<context>
    <name>AbstractJob</name>
    <message>
        <location filename="../src/jobs/abstractjob.cpp" line="53"/>
        <source>Pause This Job</source>
        <translation>Pozastavit tuto úlohu</translation>
    </message>
    <message>
        <location filename="../src/jobs/abstractjob.cpp" line="56"/>
        <source>Resume This Job</source>
        <translation>Pokračovat v této úloze</translation>
    </message>
</context>
<context>
    <name>ActionsDialog</name>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="238"/>
        <source>Actions and Shortcuts</source>
        <translation>Činnosti a klávesové zkratky</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="246"/>
        <source>search</source>
        <translation>Hledání</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="260"/>
        <source>Clear search</source>
        <translation>Vyprázdnit hledání</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="295"/>
        <source>Click on the selected shortcut to show the editor</source>
        <translation>Klepněte na vybranou klávesovou zkratku pro zobrazení editoru.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="301"/>
        <source>Reserved shortcuts can not be edited</source>
        <translation>Vyhrazené klávesové zkratky nelze upravovat</translation>
    </message>
</context>
<context>
    <name>ActionsModel</name>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="188"/>
        <source>Shortcut %1 is used by %2</source>
        <translation>Klávesovou zkratku %1 používá %2</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="198"/>
        <source>Shortcut %1 is reserved for use by %2</source>
        <translation>Klávesová zkratka %1 je vyhrazena pro používání %2</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="233"/>
        <source>Action</source>
        <translation>Činnost</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="235"/>
        <source>Shortcut 1</source>
        <translation>Klávesová zkratka 1</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="237"/>
        <source>Shortcut 2</source>
        <translation>Klávesová zkratka 2</translation>
    </message>
</context>
<context>
    <name>AddEncodePresetDialog</name>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="25"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="52"/>
        <source>File name extension</source>
        <translation>Souborová přípona</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="59"/>
        <source>for example, mp4</source>
        <translation>například mp4</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="84"/>
        <source>Make final changes to the preset including removing items you do not want to include, or copy/paste the clipboard.</source>
        <translation>Udělejte konečné změny přednastavení včetně odstranění položek, jež nechcete zahrnout, nebo kopírovat/vložit do schránky.</translation>
    </message>
</context>
<context>
    <name>AlignAudioDialog</name>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="234"/>
        <source>Reference audio track</source>
        <translation>Vzorová zvuková stopa</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="251"/>
        <source>Speed adjustment range</source>
        <translation>Rozsah nastavení rychlosti</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="254"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="255"/>
        <source>Narrow</source>
        <translation>Úzký</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="257"/>
        <source>Normal</source>
        <translation>Normální</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="259"/>
        <source>Wide</source>
        <translation>Široký</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="260"/>
        <source>Very wide</source>
        <translation>Velmi široký</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="303"/>
        <source>Process</source>
        <translation>Zpracovat</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="306"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="309"/>
        <source>Process + Apply</source>
        <translation>Zpracovat a použít</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="347"/>
        <source>This clip will be skipped because it is on the reference track.</source>
        <translation>Tento záběr bude přeskočen, protože se nachází na vzorové stopě.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="353"/>
        <source>This item can not be aligned.</source>
        <translation>Tuto položku nelze zarovnat.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="365"/>
        <source>Align Audio</source>
        <translation>Zarovnat zvuk</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="482"/>
        <source>Analyze Reference Track</source>
        <translation>Rozebrat vzorovou stopu</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="490"/>
        <source>Analyze Clips</source>
        <translation>Rozebrat záběry</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="500"/>
        <source>Alignment not found.</source>
        <translation>Zarovnání nebylo nalezeno.</translation>
    </message>
</context>
<context>
    <name>AlignClipsModel</name>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="202"/>
        <source>Clip</source>
        <translation>Záběr</translation>
    </message>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="204"/>
        <source>Offset</source>
        <translation>Posun</translation>
    </message>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="206"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
</context>
<context>
    <name>AlsaWidget</name>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="26"/>
        <source>ALSA Audio</source>
        <translation>Zvuk ALSA</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="54"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="61"/>
        <source>PCM Device</source>
        <translation>Zařízení PCM</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="71"/>
        <source>default</source>
        <translation>Výchozí</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="78"/>
        <source>Channels</source>
        <translation>Kanály</translation>
    </message>
</context>
<context>
    <name>AttachedFiltersModel</name>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="236"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="238"/>
        <source>Time</source>
        <translation>Čas</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="240"/>
        <source>GPU</source>
        <translation>Grafický procesor</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="242"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="491"/>
        <source>This file has B-frames, which is not supported by %1.</source>
        <translation>Tento soubor má B-snímky, které %1 nepodporuje.</translation>
    </message>
</context>
<context>
    <name>AudioLoudnessScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="85"/>
        <source>Momentary Loudness</source>
        <translation>Chvilková hlasitost</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="88"/>
        <source>Short Term Loudness</source>
        <translation>Krátkodobá hlasitost</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="91"/>
        <source>Integrated Loudness</source>
        <translation>Jednotná hlasitost</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="94"/>
        <source>Loudness Range</source>
        <translation>Rozsah hlasitosti</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="97"/>
        <source>Peak</source>
        <translation>Vrchol</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="100"/>
        <source>True Peak</source>
        <translation>Skutečný vrchol</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="106"/>
        <source>Configure Graphs</source>
        <translation>Nastavit grafy</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="114"/>
        <source>Reset</source>
        <translation>Obnovit výchozí</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="115"/>
        <source>Reset the measurement.</source>
        <translation>Nastavit měření znovu na výchozí hodnotu.</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="122"/>
        <source>Time Since Reset</source>
        <translation>Čas od obnovení výchozího nastavení</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="178"/>
        <source>Audio Loudness</source>
        <translation>Hlasitost zvuku</translation>
    </message>
</context>
<context>
    <name>AudioPeakMeterScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="90"/>
        <source>Audio Peak Meter</source>
        <translation>Měřič hladin zvuku</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="107"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="107"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>R</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>C</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>LF</source>
        <translation>LP</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>Ls</source>
        <translation>Ls</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>Rs</source>
        <translation>Ps</translation>
    </message>
</context>
<context>
    <name>AudioSpectrumScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiospectrumscopewidget.cpp" line="217"/>
        <source>Audio Spectrum</source>
        <translation>Zvukové spektrum</translation>
    </message>
</context>
<context>
    <name>AudioSurroundScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="70"/>
        <source>Audio Surround</source>
        <translation>Prostorový zvuk</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="252"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="265"/>
        <source>C</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="279"/>
        <source>R</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="293"/>
        <source>LS</source>
        <translation>LS</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="306"/>
        <source>RS</source>
        <translation>RS</translation>
    </message>
</context>
<context>
    <name>AudioVectorScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="90"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="91"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="99"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="100"/>
        <source>C</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="93"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="95"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="94"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="96"/>
        <source>R</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="103"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="105"/>
        <source>Ls</source>
        <translation>Ls</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="104"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="106"/>
        <source>Rs</source>
        <translation>Ps</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="110"/>
        <source>LFE</source>
        <translation>LFE</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="215"/>
        <source>Audio Vector</source>
        <translation>Zvukový vektor</translation>
    </message>
</context>
<context>
    <name>AudioWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="181"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="182"/>
        <source>-inf</source>
        <translation>-inf</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="265"/>
        <source>Sample: %1
</source>
        <translation>Vzorek: %1
</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="273"/>
        <source>Ch: %1: %2 (%3 dBFS)</source>
        <translation>Kan: %1: %2 (%3 dBFS)</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="298"/>
        <source>Audio Waveform</source>
        <translation>Zvuková vlna</translation>
    </message>
</context>
<context>
    <name>AvformatProducerWidget</name>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="60"/>
        <source>Comments:</source>
        <translation>Poznámky:</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="174"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="120"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="289"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="569"/>
        <source>Broadcast Limited (MPEG)</source>
        <translation>Vysílání omezeno (MPEG)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="574"/>
        <source>Full (JPEG)</source>
        <translation>Plný (JPEG)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="472"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="697"/>
        <source>Track</source>
        <translation>Stopa</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="460"/>
        <source>Aspect ratio</source>
        <translation>Poměr stran</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="525"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="295"/>
        <source>Scan mode</source>
        <translation>Režim snímání</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="600"/>
        <source>Interlaced</source>
        <translation>Prokládaný</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="605"/>
        <source>Progressive</source>
        <translation>Progresivní</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="374"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="414"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="783"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="813"/>
        <source>Codec</source>
        <translation>Kodek</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="184"/>
        <source>Timeline</source>
        <translation>Časová osa</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="199"/>
        <source>Speed Presets</source>
        <translation>Přednastavení rychlosti</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="251"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="258"/>
        <source>Apply pitch compensation when the speed is changed.</source>
        <translation>Použít vyrovnání výšky tónu, když je změněna rychlost.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="261"/>
        <source>Pitch Compensation</source>
        <translation>Vyrovnání výšky tónu</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="315"/>
        <source>Rotation</source>
        <translation>Otočení</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="379"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="419"/>
        <source>Resolution</source>
        <translation>Rozlišení</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="384"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="424"/>
        <source>Frame rate</source>
        <translation>Snímková rychlost</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="389"/>
        <source>Pixel format</source>
        <translation>Formát pixelu</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="394"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="434"/>
        <source>Color space</source>
        <translation>Barevný prostor</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="399"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="439"/>
        <source>Color transfer</source>
        <translation>Přenos barev</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="404"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="803"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="943"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="409"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="808"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="948"/>
        <source>Value</source>
        <translation>Hodnota</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="429"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="798"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="828"/>
        <source>Format</source>
        <translation>Formát</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="614"/>
        <source>Bottom Field First</source>
        <translation>Nejprve dolní pole</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="619"/>
        <source>Top Field First</source>
        <translation>Nejprve horní pole</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="645"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="650"/>
        <source>90</source>
        <translation>90</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="655"/>
        <source>180</source>
        <translation>180</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="660"/>
        <source>270</source>
        <translation>270</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="668"/>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="691"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="788"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="818"/>
        <source>Channels</source>
        <translation>Kanály</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="793"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="823"/>
        <source>Sample rate</source>
        <translation>Vzorkování</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="836"/>
        <source>Adjust the audio/video synchronization. The center position is equivalent to no alteration.</source>
        <translation>Upravit sladění zvuku/obrazu. Poloha středu se rovná žádná změna.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="855"/>
        <source>Sync</source>
        <translation>Seřízení</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="880"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="909"/>
        <source>Metadata</source>
        <translation>Popis</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="979"/>
        <source>Properties Menu</source>
        <translation>Nabídka pro vlastnosti</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1032"/>
        <source>Show In Folder</source>
        <translation>Ukázat ve složce</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1062"/>
        <source>Extract Subtitles...</source>
        <translation>Vytáhnout titulky...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1095"/>
        <source>Reset</source>
        <translation>Obnovit výchozí</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1100"/>
        <source>Set Equirectangular...</source>
        <translation>Nastavit rovnostranné...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1105"/>
        <source>Measure Video Quality...</source>
        <translation>Měřit jakost obrazu...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1113"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1116"/>
        <source>Export GPX</source>
        <translation>Vyvést GPX</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1121"/>
        <source>View Bitrate...</source>
        <translation>Zobrazit datový tok...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1124"/>
        <source>View Bitrate</source>
        <translation>Zobrazit datový tok</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1129"/>
        <source>Show In Files</source>
        <translation>Ukázat v souborech</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1000"/>
        <source>Convert to Edit-friendly</source>
        <translation>Převést na upravit-přátelsky</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="305"/>
        <source>Color range</source>
        <translation>Barevný rozsah</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1003"/>
        <source>Convert...</source>
        <translation>Převést</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1037"/>
        <source>Copy Full File Path</source>
        <translation>Kopírovat celou souborovou cestu</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1042"/>
        <source>More Information...</source>
        <translation>Více informací...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1047"/>
        <source>Start Integrity Check Job</source>
        <translation>Spustit úlohu ověřování celistvosti</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1052"/>
        <source>Convert to Edit-friendly...</source>
        <translation>Převést na přátelský pro úpravy...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1067"/>
        <source>Set Creation Time...</source>
        <translation>Nastavit čas vytvoření...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1075"/>
        <source>Disable Proxy</source>
        <translation>Zakázat proxy</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1080"/>
        <source>Make Proxy</source>
        <translation>Udělat proxy</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1085"/>
        <source>Delete Proxy</source>
        <translation>Smazat proxy</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1090"/>
        <source>Copy Hash Code</source>
        <translation>Kopírovat kód hash</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="993"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="861"/>
        <source>Reverse...</source>
        <translation>Obrátit...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1057"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1127"/>
        <source>Extract Sub-clip...</source>
        <translation>Vytáhnout podzáběr...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="347"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="418"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="376"/>
        <source>unknown (%1)</source>
        <translation>Neznámý (%1)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="452"/>
        <source>All</source>
        <translation>Vše</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="498"/>
        <source>(PROXY)</source>
        <translation>(PROXY)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="541"/>
        <source>(variable)</source>
        <translation>(proměnná)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1010"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="134"/>
        <source> Do you want to convert it to an edit-friendly format?

If yes, choose a format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, it automatically replaces clips, or you can double-click the job to open it.
</source>
        <translation>Chcete jej převést na formát přátelský pro úpravy?

Pokud ano, vyberte formát níže, a potom klepněte na OK pro výběr názvu souboru. Po zvolení názvu souboru je vytvořena úloha. Když je hotova, záběry jsou automaticky nahrazeny, nebo klepněte dvakrát na úlohu pro její otevření.
</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="781"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="856"/>
        <source>Choose an edit-friendly format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, double-click the job to open it.
</source>
        <translation>Vyberte formát přátelský pro úpravy, a potom klepněte na OK pro výběr názvu souboru. Po zvolení názvu souboru je vytvořena úloha. Když je hotova, dvakrát klepněte na úlohu pro její otevření.
</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="970"/>
        <source>MP4 (*.mp4);;All Files (*)</source>
        <translation>MP4 (*.mp4);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1015"/>
        <source>MOV (*.mov);;All Files (*)</source>
        <translation>MOV (*.mov);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1032"/>
        <source>MKV (*.mkv);;All Files (*)</source>
        <translation>MKV (*.mkv);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1085"/>
        <source>Convert %1</source>
        <translation>Převést %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1036"/>
        <source>Reversed</source>
        <translation>Obráceno</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1066"/>
        <source>Reverse canceled</source>
        <translation>Zpět zrušeno</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1095"/>
        <source>Reverse %1</source>
        <translation>Obrátit %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1464"/>
        <source>Choose the Other Video</source>
        <translation>Vybrat jiný obraz</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1517"/>
        <source>Measure %1</source>
        <translation>Měřit %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1126"/>
        <source>Sub-clip</source>
        <translation>Podzáběr</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1128"/>
        <source>%1 (*.%2);;All Files (*)</source>
        <translation>%1 (*.%2);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1200"/>
        <source>Extract sub-clip %1</source>
        <translation>Vytáhnout podzáběr %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1219"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1269"/>
        <source>Track %1</source>
        <translation>Stopa %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1221"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1271"/>
        <source>Track %1 (%2)</source>
        <translation>Stopa %1 (%2)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1225"/>
        <source>Export Subtitles...</source>
        <translation>Vyvést titulky...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1227"/>
        <source>No subtitles found</source>
        <translation>Nenalezeny žádné titulky</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1286"/>
        <source>Extract subtitles %1</source>
        <translation>Vytáhnout titulky %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1399"/>
        <source>The hash code below is already copied to your clipboard:

</source>
        <translation>Níže uvedený hashovací kód je již zkopírován do vaší schránky:

</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1443"/>
        <source>Set Equirectangular Projection</source>
        <translation>Nastavit rovnostranné promítání</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1455"/>
        <source>Successfully wrote %1</source>
        <translation>Úspěšně zapsal %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1457"/>
        <source>An error occurred saving the projection.</source>
        <translation>Během ukládání promítání došlo k chybě.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1577"/>
        <source>Bitrate %1</source>
        <translation>Datový tok %1</translation>
    </message>
</context>
<context>
    <name>AvfoundationProducerWidget</name>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="26"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="107"/>
        <source>Audio/Video Device</source>
        <translation>Zařízení pro zvuk/obraz</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="39"/>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="58"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="83"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="84"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="90"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="99"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="47"/>
        <source>Video Input</source>
        <translation>Obrazový vstup</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="66"/>
        <source>Audio Input</source>
        <translation>Zvukový vstup</translation>
    </message>
</context>
<context>
    <name>BitrateDialog</name>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="48"/>
        <source>Bitrate Viewer</source>
        <translation>Prohlížeč datového toku</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="66"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="74"/>
        <source>Average</source>
        <translation>Průměrný</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="135"/>
        <source>Bitrates for %1 ~~ Avg. %2 Min. %3 Max. %4 Kb/s</source>
        <translation>Datové toky pro %1 ~~ Prům. %2 Min. %3 Max. %4 Kb/s</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="179"/>
        <source>Save Bitrate Graph</source>
        <translation>Uložit graf datového toku</translation>
    </message>
</context>
<context>
    <name>BitrateViewerJob</name>
    <message>
        <location filename="../src/jobs/bitrateviewerjob.cpp" line="34"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
</context>
<context>
    <name>BlipProducerWidget</name>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="26"/>
        <source>Blip Flash</source>
        <translation>Záblesk</translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>Kmitočet</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/widgets/blipproducerwidget.cpp" line="67"/>
        <source> second(s)</source>
        <translation>
            <numerusform>sekunda</numerusform>
            <numerusform>sekundy</numerusform>
            <numerusform>sekund</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.cpp" line="89"/>
        <source>Period: %1s</source>
        <translation>Perioda: %1s</translation>
    </message>
</context>
<context>
    <name>ClockSpinner</name>
    <message>
        <location filename="../src/qml/filters/timer/ClockSpinner.qml" line="121"/>
        <source>Decrement</source>
        <translation>Snížení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ClockSpinner.qml" line="150"/>
        <source>Increment</source>
        <translation>Zvýšení</translation>
    </message>
</context>
<context>
    <name>ColorBarsWidget</name>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="26"/>
        <source>Color Bars</source>
        <translation>Barevné pruhy</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="38"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="55"/>
        <source>100% PAL color bars</source>
        <translation>Barevné pruhy 100% PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="60"/>
        <source>100% PAL color bars with red</source>
        <translation>Barevné pruhy 100% PAL s červenou</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="65"/>
        <source>95% BBC PAL color bars</source>
        <translation>Barevné pruhy 95% BBC</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="70"/>
        <source>75% EBU color bars</source>
        <translation>Barevné pruhy 75% EBU</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="75"/>
        <source>SMPTE color bars</source>
        <translation>Barevné pruhy SMPTE</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="80"/>
        <source>Philips PM5544</source>
        <translation>Philips PM5544</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="85"/>
        <source>FuBK</source>
        <translation>FuBK</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="90"/>
        <source>Simplified FuBK</source>
        <translation>Zjednodušený FuBK</translation>
    </message>
</context>
<context>
    <name>ColorPicker</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="58"/>
        <source>Click to open color dialog</source>
        <translation>Klepněte pro otevření dialogu pro barvy</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="89"/>
        <source>Pick a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation>Vyberte barvu na obrazovce. Stisknutím tlačítka myši a potom pohybem myši můžete vybrat oblast obrazovky, ze které se má získat průměrná barva.</translation>
    </message>
</context>
<context>
    <name>ColorProducerWidget</name>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="20"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="30"/>
        <source>Comments:</source>
        <translation>Poznámky:</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="61"/>
        <source>Color...</source>
        <translation>Barva...</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="74"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="58"/>
        <source>black</source>
        <translation>Černý</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="60"/>
        <source>transparent</source>
        <translation>Průhledný</translation>
    </message>
</context>
<context>
    <name>CopyFiltersDialog</name>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="44"/>
        <source>Copy Filters</source>
        <translation>Kopírovat filtry</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="57"/>
        <source>Enter a name to save a filter set, or
leave blank to use the clipboard:</source>
        <translation>Pro uložení sady filtrů zadejte název nebo
ponechte prázdné, chcete-li použít schránku:</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="64"/>
        <source>optional</source>
        <translation>volitelné</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="84"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="89"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>CountProducerWidget</name>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="26"/>
        <source>Count</source>
        <translation>Počítání</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="41"/>
        <source>Direction</source>
        <translation>Směr</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="74"/>
        <source>Style</source>
        <translation>Styl</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="107"/>
        <source>Sound</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="110"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Silent - No sound&lt;/p&gt;&lt;p&gt;2-Pop - A 1kHz beep exactly two seconds before the out point&lt;/p&gt;&lt;p&gt;Frame 0 - A 1kHz beep at frame 0 of every second&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tichý - žádný zvuk&lt;/p&gt;&lt;p&gt;2-pípnutí - pípnutí 1 kHz po dobu přesně dvou sekund před koncovým bodem&lt;/p&gt;&lt;p&gt;Snímek 0 - pípnutí 1 kHz na snímku 0 každé sekundy&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="143"/>
        <source>Background</source>
        <translation>Pozadí</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="146"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;None - No background&lt;/p&gt;&lt;p&gt;Clock  - Film style clock animation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Žádné - žádné pozadí&lt;/p&gt;&lt;p&gt;Hodiny  - animace hodin po způsobu filmu&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="179"/>
        <source>Drop Frame</source>
        <translation>Zahodit snímek</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="182"/>
        <source>Use SMPTE style drop-frame counting for non-integer frame rates. The clock and timecode will advance two frames every minute if necessary to keep time with wall clock time.</source>
        <translation>Použít počítání zahozených snímků ve stylu SMPTE pro ne-celočíselné snímkové rychlosti. Hodiny a časový kód provedou v případě potřeby přesun na dřívější datum každou minutu, aby šly podle nástěnných hodin.</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="189"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="41"/>
        <source>Down</source>
        <translation>Dolů</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="42"/>
        <source>Up</source>
        <translation>Nahoru</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="45"/>
        <source>Seconds</source>
        <translation>Sekundy</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="46"/>
        <source>Seconds + 1</source>
        <translation>Sekundy + 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="47"/>
        <source>Frames</source>
        <translation>Snímky</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="48"/>
        <source>Timecode</source>
        <translation>Časový kód</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="49"/>
        <location filename="../src/widgets/countproducerwidget.cpp" line="57"/>
        <source>Clock</source>
        <translation>Hodiny</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="52"/>
        <source>2-Pop</source>
        <translation>2-pípnutí</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="53"/>
        <source>Silent</source>
        <translation>Tichý</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="54"/>
        <source>Frame 0</source>
        <translation>Snímek 0</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="58"/>
        <source>None</source>
        <translation>Žádné</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="225"/>
        <source>Count: %1 %2</source>
        <translation>Počítání: %1 %2</translation>
    </message>
</context>
<context>
    <name>CurveComboBox</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="36"/>
        <source>Natural</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="40"/>
        <source>S-Curve</source>
        <translation>Křivka S</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="44"/>
        <source>Fast-Slow</source>
        <translation>Rychle-pomalu</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="48"/>
        <source>Slow-Fast</source>
        <translation>Pomalu-rychle</translation>
    </message>
</context>
<context>
    <name>CustomProfileDialog</name>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="14"/>
        <source>Add Custom Video Mode</source>
        <translation>Přidat vlastní obrazový režim</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="29"/>
        <source>Colorspace</source>
        <translation>Barevný prostor</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="58"/>
        <source>ITU-R BT.2020</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="81"/>
        <source>Resolution</source>
        <translation>Rozlišení</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="112"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="182"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="201"/>
        <source>Interlaced</source>
        <translation>Prokládaný</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="206"/>
        <source>Progressive</source>
        <translation>Progresivní</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="229"/>
        <source>Aspect ratio</source>
        <translation>Poměr stran</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="260"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="348"/>
        <source>Frames/sec</source>
        <translation>Snímků za sekundu</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="449"/>
        <source>Scan mode</source>
        <translation>Režim snímání</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="481"/>
        <source>&lt;small&gt;(Leave Name blank to skip saving a preset and use a temporary or project-specific Video Mode.)&lt;/small&gt;</source>
        <translation>&lt;small&gt;(Ponechte název prázdný pro přeskočení uložení přednastavení a použijte dočasný nebo pro projekt specifický obrazový režim.)&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.cpp" line="134"/>
        <source>Video Mode Frames/sec</source>
        <translation>Snímků za sekundu v obrazovém režimu</translation>
    </message>
</context>
<context>
    <name>DecklinkProducerWidget</name>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="26"/>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="85"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="57"/>
        <source>Device</source>
        <translation>Zařízení</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="67"/>
        <source>Signal mode</source>
        <translation>Režim signálu</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="85"/>
        <source>Please be aware that not every card model supports automatic signal detection, and not all cards support all of the signal modes.</source>
        <translation>Buďte si, prosím, vědomi, že ne každý model karty podporuje automatické zjištění signálu, a že ne všechny karty podporují všechny režimy signálu.</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="31"/>
        <source>Detect Automatically</source>
        <translation>Zjistit automaticky</translation>
    </message>
</context>
<context>
    <name>DirectShowVideoWidget</name>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="26"/>
        <location filename="../src/widgets/directshowvideowidget.cpp" line="166"/>
        <source>Audio/Video Device</source>
        <translation>Zařízení pro zvuk/obraz</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="52"/>
        <location filename="../src/widgets/directshowvideowidget.ui" line="81"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="60"/>
        <source>Video Input</source>
        <translation>Obrazový vstup</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="70"/>
        <source>Audio Input</source>
        <translation>Zvukový vstup</translation>
    </message>
</context>
<context>
    <name>DurationDialog</name>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="17"/>
        <source>Set Duration</source>
        <translation>Nastavit dobu trvání</translation>
    </message>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="25"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
</context>
<context>
    <name>EditMarkerDialog</name>
    <message>
        <location filename="../src/dialogs/editmarkerdialog.cpp" line="31"/>
        <source>Edit Marker</source>
        <translation>Upravit značku</translation>
    </message>
</context>
<context>
    <name>EditMarkerWidget</name>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="46"/>
        <source>Set the name for this marker.</source>
        <translation>Nastavte název pro tuto značku.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="49"/>
        <source>Color...</source>
        <translation>Barva...</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="57"/>
        <source>Start</source>
        <translation>Začátek</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="62"/>
        <source>Set the start time for this marker.</source>
        <translation>Nastavte čas začátku pro tuto značku.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="69"/>
        <source>End</source>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="74"/>
        <source>Set the end time for this marker.</source>
        <translation>Nastavte čas konce pro tuto značku.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="78"/>
        <source>Duration:</source>
        <translation>Doba trvání:</translation>
    </message>
</context>
<context>
    <name>EncodeDock</name>
    <message>
        <location filename="../src/docks/encodedock.ui" line="18"/>
        <source>Export</source>
        <translation>Vyvedení</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="45"/>
        <source>&lt;b&gt;Presets&lt;/b&gt;</source>
        <translation>&lt;b&gt;Přednastavení&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="58"/>
        <source>search</source>
        <translation>Hledání</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="89"/>
        <source>Add current settings as a new custom preset</source>
        <translation>Přidat nynější nastavení jako nové vlastní přednastavení</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="103"/>
        <source>Delete currently selected preset</source>
        <translation>Smazat nyní vybrané přednastavení</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="169"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Export Help&lt;/span&gt;&lt;/p&gt;&lt;p&gt;The defaults create a H.264/AAC MP4 file, which is suitable for most users and purposes. Choose a &lt;span style=&quot; font-weight:600;&quot;&gt;Preset&lt;/span&gt; at the left before deciding to use the &lt;span style=&quot; font-weight:600;&quot;&gt;Advanced&lt;/span&gt; mode. The &lt;span style=&quot; font-weight:600;&quot;&gt;Advanced&lt;/span&gt; mode does not prevent creating an invalid combination of options!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nápověda k vyvedení&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ve výchozím nastavení se vytvoří soubor H.264/AAC MP4, jenž je vhodný pro většinu uživatelů a účelů. Vyberte &lt;span style=&quot; font-weight:600;&quot;&gt;přednastavení&lt;/span&gt; nalevo, před rozhodnutím použít &lt;span style=&quot; font-weight:600;&quot;&gt;Pokročilý&lt;/span&gt; režim. &lt;span style=&quot; font-weight:600;&quot;&gt;Pokročilý&lt;/span&gt; režim nezabrání vytvoření nepatného spojení voleb!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="187"/>
        <source>From</source>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="217"/>
        <source>Format</source>
        <translation>Formát</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="253"/>
        <source>Use hardware encoder</source>
        <translation>Použít hardvarový kodér</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="260"/>
        <source>Configure...</source>
        <translation>Nastavit...</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="294"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="485"/>
        <source>Interpolation</source>
        <translation>Interpolace</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="539"/>
        <source>Field order</source>
        <translation>Pořadí polí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="549"/>
        <source>Aspect ratio</source>
        <translation>Poměr stran</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="723"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="579"/>
        <source>Scan mode</source>
        <translation>Režim snímání</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="664"/>
        <source>Interlaced</source>
        <translation>Prokládaný</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="669"/>
        <source>Progressive</source>
        <translation>Progresivní</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="617"/>
        <source>Resolution</source>
        <translation>Rozlišení</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="569"/>
        <source>Frames/sec</source>
        <translation>Snímků za sekundu</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="916"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="824"/>
        <source>Bottom Field First</source>
        <translation>Nejprve dolní pole</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="829"/>
        <source>Top Field First</source>
        <translation>Nejprve horní pole</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="858"/>
        <source>One Field (fast)</source>
        <translation>Jedno pole (rychlé)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="863"/>
        <source>Linear Blend (fast)</source>
        <translation>Lineární smíchání (nejrychlejší)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="868"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF - pouze dočasné (dobré)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="559"/>
        <source>Deinterlacer</source>
        <translation>Odstranění prokládání</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="501"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>Nejbližší soused (rychlá)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="506"/>
        <source>Bilinear (good)</source>
        <translation>Bilineární (dobrá)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="511"/>
        <source>Bicubic (better)</source>
        <translation>Bikubická (lepší)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="811"/>
        <source>Use preview scaling</source>
        <translation>Použít náhledovou změnu velikosti</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="599"/>
        <source>This enables multiple image processing threads.
Sometimes, this can be a problem, and you can
test if turning this off helps. For example, some
interlaced AVCHD in conjunction with the YADIF
deinterlacer has been reported as problematic
with parallel processing enabled.</source>
        <translation>Toto umožňuje zpracování více vláken.
Někdy to může být problém. Můžete
vyzkoušet, zda vypnutí této funkce pomůže.
Například některá prokládaná AVCHD
ve spojení s rušením prokládání YADIF
byla oznámena jako problematická při
povolení souběžného zpracování.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="330"/>
        <source>Reframe</source>
        <translation>Přesnímkovat</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="589"/>
        <source>Color range</source>
        <translation>Barevný rozsah</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="607"/>
        <source>Parallel processing</source>
        <translation>Paralelní zpracování</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="630"/>
        <source>Broadcast Limited (MPEG)</source>
        <translation>Vysílání omezeno (MPEG)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="635"/>
        <source>Full (JPEG)</source>
        <translation>Plný (JPEG)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="873"/>
        <source>YADIF - temporal + spatial (better)</source>
        <translation>YADIF - časové + prostorové (lepší)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="878"/>
        <source>BWDIF (best)</source>
        <translation>BWDIF (nejlepší)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="955"/>
        <location filename="../src/docks/encodedock.ui" line="964"/>
        <location filename="../src/docks/encodedock.ui" line="1647"/>
        <source>Codec</source>
        <translation>Kodek</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="994"/>
        <source>GOP</source>
        <translation>Skupina obrázků</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1006"/>
        <source>GOP = group of pictures, which is the maximum key frame interval</source>
        <translation>Skupina obrázků (GOP = group of pictures), což je největší interval pro klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1019"/>
        <source>frames</source>
        <translation>snímků</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1039"/>
        <source>A fixed GOP means that keyframes will
not be inserted at detected scene changes.</source>
        <translation>Pevný GOP znamená, že klíčové snímky nebudou
vkládány u zjištěných změn scény.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1043"/>
        <source>Fixed</source>
        <translation>Pevný</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1067"/>
        <location filename="../src/docks/encodedock.ui" line="1689"/>
        <source>The average bit rate</source>
        <translation>Průměrný datový tok</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1220"/>
        <location filename="../src/docks/encodedock.ui" line="1772"/>
        <source>b/s</source>
        <translation>b/s</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1242"/>
        <source>Disable video</source>
        <translation>Zakázat obraz</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1249"/>
        <source>Dual pass</source>
        <translation>Dvojí průchod</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1256"/>
        <source>B frames</source>
        <translation>B snímky</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1268"/>
        <source>B frames are the bidirectional &quot;delta&quot; pictures
in temporal compression</source>
        <translation>B snímky jsou dvojsměrné obrázky &quot;delta&quot;
v dočasném zhuštění</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1307"/>
        <source>Codec threads</source>
        <translation>Vlákna kodeků</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1322"/>
        <source>(0 = auto)</source>
        <translation>(0 = auto)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1344"/>
        <location filename="../src/docks/encodedock.ui" line="1814"/>
        <source>Rate control</source>
        <translation>Ovládání toku</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1357"/>
        <location filename="../src/docks/encodedock.ui" line="1827"/>
        <source>Average Bitrate</source>
        <translation>Průměrný datový tok</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1362"/>
        <location filename="../src/docks/encodedock.ui" line="1832"/>
        <source>Constant Bitrate</source>
        <translation>Stálý datový tok</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1367"/>
        <location filename="../src/docks/encodedock.ui" line="1837"/>
        <source>Quality-based VBR</source>
        <translation>Na jakosti založený SDT</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1372"/>
        <source>Constrained VBR</source>
        <translation>Nucený proměnlivý datový tok (PDT)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1395"/>
        <source>Buffer size</source>
        <translation>Velikost vyrovnávací paměti</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1417"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1439"/>
        <location filename="../src/docks/encodedock.ui" line="1860"/>
        <source>Quality</source>
        <translation>Kvalita</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1451"/>
        <location filename="../src/docks/encodedock.ui" line="1872"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1467"/>
        <location filename="../src/docks/encodedock.ui" line="1888"/>
        <source>TextLabel</source>
        <translation>Textový popisek</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1489"/>
        <location filename="../src/docks/encodedock.ui" line="1677"/>
        <source>Bitrate</source>
        <translation>Datový tok</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1500"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1509"/>
        <source>Channels</source>
        <translation>Kanály</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1521"/>
        <source>The number of audio channels in the output.</source>
        <translation>Počet zvukových kanálů ve výstupu.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1525"/>
        <source>1 (mono)</source>
        <translation>1 (mono)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1530"/>
        <source>2 (stereo)</source>
        <translation>2 (stereo)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1535"/>
        <source>4 (quad/Ambisonics)</source>
        <translation>4 (quad/Ambisonics)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1540"/>
        <source>6 (5.1 surround)</source>
        <translation>6 (5.1 prostorový zvuk)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1615"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1637"/>
        <source>Sample rate</source>
        <translation>Vzorkování</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1794"/>
        <source>Disable audio</source>
        <translation>Zakázat zvuk</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1911"/>
        <source>Other</source>
        <translation>Jiné</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1927"/>
        <source>Disable subtitles</source>
        <translation>Zakázat titulky</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1960"/>
        <location filename="../src/docks/encodedock.cpp" line="1328"/>
        <location filename="../src/docks/encodedock.cpp" line="1839"/>
        <location filename="../src/docks/encodedock.cpp" line="2331"/>
        <source>Export File</source>
        <translation>Vyvést soubor</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1970"/>
        <source>Reset options to defaults</source>
        <translation>Nastavit volby znovu na výchozí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1973"/>
        <source>Reset</source>
        <translation>Obnovit výchozí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1980"/>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1990"/>
        <source>Always start in Advanced mode</source>
        <translation>Vždy začít v Pokročilém režimu</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="2000"/>
        <location filename="../src/docks/encodedock.cpp" line="2035"/>
        <location filename="../src/docks/encodedock.cpp" line="2042"/>
        <location filename="../src/docks/encodedock.cpp" line="2154"/>
        <source>Stream</source>
        <translation>Proud</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="2027"/>
        <location filename="../src/docks/encodedock.cpp" line="1822"/>
        <location filename="../src/docks/encodedock.cpp" line="1923"/>
        <location filename="../src/docks/encodedock.cpp" line="1933"/>
        <source>Stop Capture</source>
        <translation>Zastavit zachytávání</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="135"/>
        <source>Automatic from extension</source>
        <translation>Automaticky podle přípony</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="143"/>
        <location filename="../src/docks/encodedock.cpp" line="153"/>
        <source>Default for format</source>
        <translation>Výchozí pro formát</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="465"/>
        <source>Timeline</source>
        <translation>Časová osa</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="472"/>
        <location filename="../src/docks/encodedock.cpp" line="478"/>
        <source>Source</source>
        <translation>Zdroj</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="483"/>
        <location filename="../src/docks/encodedock.cpp" line="490"/>
        <source>Marker</source>
        <translation>Značka</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="501"/>
        <source>You must enter numeric values using &apos;%1&apos; as the decimal point.</source>
        <translation>Musíte zadat číselné hodnoty za použití &apos;%1&apos; jako desetinné čárky (tečky).</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="510"/>
        <location filename="../src/docks/encodedock.cpp" line="1769"/>
        <location filename="../src/docks/encodedock.cpp" line="1770"/>
        <source>Custom</source>
        <translation>Vlastní</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="546"/>
        <source>Stock</source>
        <translation>Tovární</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="549"/>
        <source>Default</source>
        <translation>Výchozí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1395"/>
        <source>You cannot write to a file that is in your project.
Try again with a different folder or file name.</source>
        <translation>Nemůžete psát do souboru, který je ve vašem projektu.
Zkuste to znovu s jinou složkou nebo názvem souboru.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1493"/>
        <source>Shotcut found filters that require analysis jobs that have not run.
Do you want to run the analysis jobs now?</source>
        <translation>Shotcut našel filtry, které vyžadují rozbory, které nebyly spuštěny.
Chcete úlohy rozborů spustit nyní?</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1839"/>
        <location filename="../src/docks/encodedock.cpp" line="2333"/>
        <source>Capture File</source>
        <translation>Zachytit soubor</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1841"/>
        <source>Export Files</source>
        <translation>Vyvést soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1856"/>
        <source>%1 (*.%2);;All Files (*)</source>
        <translation>%1 (*.%2);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1858"/>
        <source>Determined by Export (*)</source>
        <translation>Určeno vyvedením (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2030"/>
        <location filename="../src/docks/encodedock.cpp" line="2052"/>
        <source>Stop Stream</source>
        <translation>Zastavit proud</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2044"/>
        <source>Enter the network protocol scheme, address, port, and parameters as an URL:</source>
        <translation>Zadejte schéma síťového protokolu, adresu, přípojku a parametry jako adresu (URL):</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2087"/>
        <source>Add Export Preset</source>
        <translation>Přidat přednastavení vyvedení</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2131"/>
        <source>Delete Preset</source>
        <translation>Smazat přednastavení</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2132"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Opravdu chcete smazat %1?</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2260"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2315"/>
        <source>KiB (%1s)</source>
        <translation>KiB (%1s)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2463"/>
        <source>Detect</source>
        <translation>Zjistit</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2520"/>
        <source>(auto)</source>
        <translation>(auto)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2566"/>
        <source>Detecting hardware encoders...</source>
        <translation>Zjišťují se hardvarové kodéry</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2623"/>
        <source>Nothing found</source>
        <translation>Nic nebylo nalezeno</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2625"/>
        <source>Found %1</source>
        <translation>Nalezeno %1</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2848"/>
        <source>Your project is missing some files.

Save your project, close it, and reopen it.
Shotcut will attempt to repair your project.</source>
        <translation>V projektu chybí některé soubory.

Uložte projekt, zavřete jej a znovu otevřete.
Shotcut se pokusí opravit váš projekt.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2897"/>
        <source>Aspect ratio does not match project Video Mode, which causes black bars.</source>
        <translation>Poměr stran neodpovídá režimu videa projektu, což způsobuje černé pruhy.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2935"/>
        <source>Frame rate is higher than project Video Mode, which causes frames to repeat.</source>
        <translation>Snímková frekvence je vyšší než u obrazového režimu projektu, což způsobuje opakování snímků.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2461"/>
        <source>Configure Hardware Encoding</source>
        <translation>Nastavit hardvarové kódování</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="468"/>
        <source>Current Playlist Bin</source>
        <translation>Nynější koš záběrů pro přehrávání</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="469"/>
        <source>Each Playlist Bin Item</source>
        <translation>Každou položku v koši záběrů pro přehrávání</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1842"/>
        <source>Export Each Playlist Bin Item</source>
        <translation>Vyvést každou položku v koši záběrů pro přehrávání</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1887"/>
        <source>Export canceled</source>
        <translation>Vyvedení zrušeno</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2485"/>
        <source>Export Frames/sec</source>
        <translation>Snímků za sekundu při vyvedení</translation>
    </message>
</context>
<context>
    <name>EncodeJob</name>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="46"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="48"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>Otevřít výstupní soubor v přehrávači Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="52"/>
        <location filename="../src/jobs/encodejob.cpp" line="53"/>
        <source>Show In Files</source>
        <translation>Ukázat v souborech</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="57"/>
        <location filename="../src/jobs/encodejob.cpp" line="58"/>
        <source>Show In Folder</source>
        <translation>Ukázat ve složce</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="62"/>
        <source>Measure Video Quality...</source>
        <translation>Měřit jakost obrazu...</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="66"/>
        <source>Set Equirectangular...</source>
        <translation>Nastavit rovnostranné...</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="75"/>
        <source>Video Quality Report</source>
        <translation>Zpráva o jakosti obrazu</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="76"/>
        <source>Text Documents (*.txt);;All Files (*)</source>
        <translation>Textové dokumenty (*.txt);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="138"/>
        <source>Set Equirectangular Projection</source>
        <translation>Nastavit rovnostranné promítání</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="152"/>
        <source>Successfully wrote %1</source>
        <translation>Úspěšně zapsal %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="154"/>
        <source>An error occurred saving the projection.</source>
        <translation>Během ukládání promítání došlo k chybě.</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="182"/>
        <source>Export job failed; trying again without Parallel processing.</source>
        <translation>Úloha vyvedení selhala. Proběhne nový pokus bez souběžného zpracování.</translation>
    </message>
</context>
<context>
    <name>FfmpegJob</name>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="43"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="48"/>
        <source>Check %1</source>
        <translation>Prověřit %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="77"/>
        <source>FFmpeg Log</source>
        <translation>Zápis FFmpeg</translation>
    </message>
</context>
<context>
    <name>FfprobeJob</name>
    <message>
        <location filename="../src/jobs/ffprobejob.cpp" line="52"/>
        <source>More Information</source>
        <translation>Více informací</translation>
    </message>
</context>
<context>
    <name>FileDateDialog</name>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="46"/>
        <source>%1 File Date</source>
        <translation>%1 Datum souboru</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="102"/>
        <source>Current Value</source>
        <translation>Nynější hodnota</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="106"/>
        <source>Now</source>
        <translation>Nyní</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="112"/>
        <source>System - Modified</source>
        <translation>Systém - Změněno</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="113"/>
        <source>System - Created</source>
        <translation>Systém - Vytvořeno</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="123"/>
        <source>Metadata - Creation Time</source>
        <translation>Popisné údaje - Čas vytvoření</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="130"/>
        <source>Metadata - QuickTime date</source>
        <translation>Popisné údaje - Satum QuickTime</translation>
    </message>
</context>
<context>
    <name>FilesDock</name>
    <message>
        <location filename="../src/docks/filesdock.ui" line="18"/>
        <location filename="../src/docks/filesdock.cpp" line="597"/>
        <source>Files</source>
        <translation>Soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="61"/>
        <source>Location</source>
        <translation>Umístění</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="90"/>
        <source>Add the current folder to the saved locations</source>
        <translation>Přidat nynější složku do uložených umístění</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="110"/>
        <source>Remove the selected location</source>
        <translation>Odstranit vybrané umístění</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="502"/>
        <source>Home</source>
        <comment>The user&apos;s home folder in the file system</comment>
        <translation>Domovská složka</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="503"/>
        <source>Current Project</source>
        <translation>Nynější projekt</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="504"/>
        <source>Documents</source>
        <translation>Dokumenty</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="509"/>
        <source>Movies</source>
        <comment>The system-provided videos folder called Movies on macOS</comment>
        <translation>Filmy</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="513"/>
        <source>Music</source>
        <translation>Hudba</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="516"/>
        <source>Pictures</source>
        <comment>The system-provided photos folder</comment>
        <translation>Obrázky</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="520"/>
        <source>Volumes</source>
        <comment>The macOS file system location where external drives and network shares are mounted</comment>
        <translation>Svazky</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="525"/>
        <source>Videos</source>
        <translation>Videa</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="607"/>
        <source>Select</source>
        <translation>Vybrat</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="611"/>
        <source>Files Controls</source>
        <translation>Ovládání souborů</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="616"/>
        <source>Files Menu</source>
        <translation>Nabídka pro soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="642"/>
        <location filename="../src/docks/filesdock.cpp" line="652"/>
        <source>Files Filters</source>
        <translation>Filtry souborů</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="675"/>
        <source>Only show files whose name contains some text</source>
        <translation>Zobrazit pouze soubory, jejichž název obsahuje nějaký text</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="676"/>
        <source>search</source>
        <translation>Hledání</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="785"/>
        <source>Tiles</source>
        <translation>Dlaždice</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="786"/>
        <source>View as tiles</source>
        <translation>Zobrazit jako dlaždice</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="798"/>
        <source>Icons</source>
        <translation>Obrázky</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="799"/>
        <source>View as icons</source>
        <translation>Zobrazit jako obrázky</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="811"/>
        <source>Details</source>
        <translation>Podrobnosti</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="812"/>
        <source>View as details</source>
        <translation>Zobrazit jako podrobnosti</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="824"/>
        <source>Open In Shotcut</source>
        <translation>Otevřít v Shotcutu</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="825"/>
        <source>Open the clip in the Source player</source>
        <translation>Otevřít záběr v přehrávači zdroje</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="833"/>
        <source>System Default</source>
        <translation>Výchozí systému</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="847"/>
        <source>Other...</source>
        <translation>Jiné...</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="855"/>
        <source>Remove...</source>
        <translation>Odstranit...</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="863"/>
        <source>Show In File Manager</source>
        <translation>Zobrazit ve správci souborů</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="873"/>
        <source>Update Thumbnails</source>
        <translation>Obnovit náhledy</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="881"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="892"/>
        <source>Select None</source>
        <translation>Nevybrat nic</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="903"/>
        <source>Open Previous</source>
        <translation>Otevřít předchozí</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="915"/>
        <source>Open Next</source>
        <translation>Otevřít další</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="927"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="928"/>
        <source>Show or hide video files</source>
        <translation>Ukázat nebo skrýt obrazové soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="933"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="934"/>
        <source>Show or hide audio files</source>
        <translation>Ukázat nebo skrýt zvukové soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="939"/>
        <source>Image</source>
        <translation>Obrázek</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="940"/>
        <source>Show or hide image files</source>
        <translation>Ukázat nebo skrýt obrázkové soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="945"/>
        <source>Other</source>
        <translation>Jiné</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="946"/>
        <source>Show or hide other kinds of files</source>
        <translation>Ukázat nebo skrýt ostatní druhy souborů</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="951"/>
        <source>Folders</source>
        <translation>Složky</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="952"/>
        <source>Hide or show the list of folders</source>
        <translation>Skrýt nebo zobrazit seznam složek</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="963"/>
        <source>Go Up</source>
        <translation>Jít nahoru</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="964"/>
        <source>Show the parent folder</source>
        <translation>Zobrazit nadřazenou složku</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="982"/>
        <source>Refresh Folders</source>
        <translation>Obnovit složky</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1003"/>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1027"/>
        <source>Open With</source>
        <translation>Otevřít s</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1279"/>
        <source>Executable Files (*.exe);;All Files (*)</source>
        <translation>Spustitelné soubory (*.exe);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1284"/>
        <source>Choose Executable</source>
        <translation>Vybrat spustitelný soubor</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1308"/>
        <source>Remove From Open With</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/filesdock.cpp" line="1329"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n položka</numerusform>
            <numerusform>%n položky</numerusform>
            <numerusform>%n položek</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1371"/>
        <source>Add Location</source>
        <translation>Přidat umístění</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1372"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1390"/>
        <source>Delete Location</source>
        <translation>Smazat umístění</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1391"/>
        <source>Are you sure you want to remove %1?</source>
        <translation>Opravdu chcete odstranit %1?</translation>
    </message>
</context>
<context>
    <name>FilesModel</name>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="238"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="239"/>
        <source>Image</source>
        <translation>Obrázek</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="240"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="241"/>
        <source>Other</source>
        <translation>Jiné</translation>
    </message>
</context>
<context>
    <name>FilesTileDelegate</name>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="412"/>
        <source>Date: %1</source>
        <translation>Datum: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="421"/>
        <source>Size: %1</source>
        <translation>Velikost: %1</translation>
    </message>
</context>
<context>
    <name>FilterController</name>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="119"/>
        <source>(DEPRECATED)</source>
        <translation>(ODMÍTNUTO)</translation>
    </message>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="342"/>
        <source>Only one %1 filter is allowed.</source>
        <translation>Je povolen pouze jeden filtr %1.</translation>
    </message>
</context>
<context>
    <name>FilterMenu</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="77"/>
        <source>search</source>
        <translation>Hledání</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="121"/>
        <source>Clear search</source>
        <translation>Vyprázdnit hledání</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="177"/>
        <source>Show favorite filters</source>
        <translation>Ukázat oblíbené filtry</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="200"/>
        <source>Show GPU video filters</source>
        <translation>Ukázat obrazové filtry GPU</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="221"/>
        <source>Show video filters</source>
        <translation>Ukázat obrazové filtry</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="242"/>
        <source>Show audio filters</source>
        <translation>Ukázat zvukové filtry</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="253"/>
        <source>Time</source>
        <translation>Čas</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="264"/>
        <source>Show time filters</source>
        <translation>Ukázat časové filtry</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="274"/>
        <source>Sets</source>
        <translation>Sady</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="285"/>
        <source>Show filter sets</source>
        <translation>Zobrazit sady filtrů</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="140"/>
        <source>Close menu</source>
        <translation>Zavřít nabídku</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="371"/>
        <source>Delete a custom filter set by right-clicking it.</source>
        <translation>Vlastní sadu filtrů odstraníte klepnutím pravým tlačítkem myši na ni.</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="165"/>
        <source>Favorite</source>
        <translation>Oblíbené</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="210"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="231"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
</context>
<context>
    <name>FilterMenuDelegate</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="112"/>
        <source>Delete Filter Set</source>
        <translation>Smazat sadu filtrů</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="124"/>
        <source>Are you sure you want to delete this?
%1</source>
        <translation>Opravdu chcete smazat toto?
%1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="139"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="149"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>FiltersDock</name>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="49"/>
        <source>Filters</source>
        <translation>Filtry</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="214"/>
        <source>Add</source>
        <translation>Přidat</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="216"/>
        <source>Choose a filter to add</source>
        <translation>Vyberte filtr, který chcete přidat</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="228"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="230"/>
        <source>Remove selected filter</source>
        <translation>Odstranit vybraný filtr</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="237"/>
        <source>Copy Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="238"/>
        <source>Copy checked filters to the clipboard</source>
        <translation>Kopírovat zaškrtnuté filtry do schránky</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="245"/>
        <source>Copy Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="246"/>
        <source>Copy current filter to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="253"/>
        <source>Copy All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="254"/>
        <source>Copy all filters to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="261"/>
        <source>Paste Filters</source>
        <translation>Vložit filtry</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="262"/>
        <source>Paste the filters from the clipboard</source>
        <translation>Vložit filtry ze schránky</translation>
    </message>
</context>
<context>
    <name>FrameRateWidget</name>
    <message>
        <location filename="../src/widgets/frameratewidget.cpp" line="74"/>
        <source>Convert Frames/sec</source>
        <translation>Snímků za sekundu při převádění</translation>
    </message>
</context>
<context>
    <name>GlaxnimateIpcServer</name>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="642"/>
        <source>Preparing Glaxnimate preview....</source>
        <translation>Připravuje se náhled Glaxnimate...</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="695"/>
        <source>The Glaxnimate program was not found.

Click OK to open a file dialog to choose its location.
Click Cancel if you do not have Glaxnimate.</source>
        <translation>Program Glaxnimate nebyl nalezen.

Klepnutím na tlačítko OK otevřete dialogové okno pro výběr umístění souboru.
Pokud program Glaxnimate nemáte, klepněte na tlačítko Zrušit.</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="705"/>
        <source>Find Glaxnimate</source>
        <translation>Najít Glaxnimate</translation>
    </message>
</context>
<context>
    <name>GlaxnimateProducerWidget</name>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="20"/>
        <source>Animation</source>
        <translation>Animace</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="30"/>
        <source>Comments:</source>
        <translation>Poznámky:</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="61"/>
        <source>Background color...</source>
        <translation>Barva pozadí...</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="76"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="103"/>
        <source>Edit...</source>
        <translation>Upravit...</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="110"/>
        <source>Reload</source>
        <translation>Nahrát znovu</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="132"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="71"/>
        <source>black</source>
        <translation>Černý</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="73"/>
        <source>transparent</source>
        <translation>Průhledný</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="204"/>
        <source>animation</source>
        <translation>Animace</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="205"/>
        <source>Glaxnimate (*.rawr);;All Files (*)</source>
        <translation>Glaxnimate (*.rawr);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="207"/>
        <source>New Animation</source>
        <translation>Nová animace</translation>
    </message>
</context>
<context>
    <name>GoPro2GpxJob</name>
    <message>
        <location filename="../src/jobs/gopro2gpxjob.cpp" line="34"/>
        <source>Export GPX</source>
        <translation>Vyvést GPX</translation>
    </message>
</context>
<context>
    <name>GradientControl</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="122"/>
        <source>Color #%1</source>
        <translation>Barva #%1</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="128"/>
        <source>Color: %1
Click to change</source>
        <translation>Barva: %1
Klepněte pro změnu</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="178"/>
        <source>colors</source>
        <comment>gradient control</comment>
        <translation>Barvy</translation>
    </message>
</context>
<context>
    <name>ImageProducerWidget</name>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="27"/>
        <source>Comments:</source>
        <translation>Poznámky:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="61"/>
        <source>Resolution</source>
        <translation>Rozlišení</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="70"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="82"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="134"/>
        <source>Pixel aspect ratio</source>
        <translation>Poměr stran pixelu</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="165"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="193"/>
        <source>Image sequence</source>
        <translation>Obrázková řada</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="200"/>
        <source>Repeat</source>
        <translation>Opakovat</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="218"/>
        <source> frames</source>
        <translation> snímků</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="234"/>
        <source>per picture</source>
        <translation>na obrázek</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="261"/>
        <source>Properties Menu</source>
        <translation>Nabídka pro vlastnosti</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="303"/>
        <source>Copy Full File Path</source>
        <translation>Kopírovat celou souborovou cestu</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="308"/>
        <source>Show In Folder</source>
        <translation>Ukázat ve složce</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="341"/>
        <source>Show In Files</source>
        <translation>Ukázat v souborech</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="313"/>
        <source>Set Creation Time...</source>
        <translation>Nastavit čas vytvoření...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="321"/>
        <source>Disable Proxy</source>
        <translation>Zakázat proxy</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="326"/>
        <source>Make Proxy</source>
        <translation>Udělat proxy</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="331"/>
        <source>Delete Proxy</source>
        <translation>Smazat proxy</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="336"/>
        <source>Copy Hash Code</source>
        <translation>Kopírovat kód hash</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="122"/>
        <source>Make the current duration value the default value</source>
        <translation>Udělat z nynější doby trvání výchozí hodnotu</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="125"/>
        <source>Set Default</source>
        <translation>Nastavit na výchozí</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="247"/>
        <source>Reset</source>
        <translation>Obnovit výchozí</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="99"/>
        <source>(PROXY)</source>
        <translation>(PROXY)</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="288"/>
        <source>Getting length of image sequence...</source>
        <translation>Získává se délka posloupnosti obrázků...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="311"/>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="333"/>
        <source>Reloading image sequence...</source>
        <translation>Nahrává se znovu posloupnost obrázků...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="466"/>
        <source>The hash code below is already copied to your clipboard:

</source>
        <translation>Níže uvedený hashovací kód je již zkopírován do vaší schránky:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="254"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
</context>
<context>
    <name>IsingWidget</name>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="26"/>
        <source>Ising Model</source>
        <translation>Model Ising</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="41"/>
        <source>Noise Temperature</source>
        <translation>Teplota šumu</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="106"/>
        <source>Border Growth</source>
        <translation>Růst okraje</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="174"/>
        <source>Spontaneous Growth</source>
        <translation>Přirozený růst</translation>
    </message>
</context>
<context>
    <name>JobQueue</name>
    <message>
        <location filename="../src/jobqueue.cpp" line="59"/>
        <source>pending</source>
        <translation>Zbývá</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="63"/>
        <source>Estimated Hours:Minutes:Seconds</source>
        <translation>Odhadované hodiny:minuty:sekundy</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="92"/>
        <source>paused</source>
        <translation>Pozastaveno</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="120"/>
        <source>Elapsed Hours:Minutes:Seconds</source>
        <translation>Uplynulé hodiny:minuty:sekundy</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="123"/>
        <source>stopped</source>
        <translation>Zastaveno</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="126"/>
        <source>failed</source>
        <translation>Nepodařilo se</translation>
    </message>
</context>
<context>
    <name>JobsDock</name>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="18"/>
        <source>Jobs</source>
        <translation>Úlohy</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="115"/>
        <source>Stop automatically processing the next pending job in
the list. This does not stop a currently running job. Right-
-click a job to open a menu to stop a currently running job.</source>
        <translation>Zastavit automatické zpracování dalšího čekajícího úlohy
v seznamu. To nezastaví nyní běžící úkol. Klepnutí pravým
tlačítkem myši na úlohu k otevření nabídky pro zastavení nyní běžícího úkolu.</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="130"/>
        <source>Remove all of the completed and failed jobs from the list</source>
        <translation>Odstranit všechny hotové a selhavší úlohy ze seznamu</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="133"/>
        <source>Clean</source>
        <translation>Uklidit</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="104"/>
        <source>Jobs Menu</source>
        <translation>Nabídka pro úlohy</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="120"/>
        <source>Pause Queue</source>
        <translation>Pozastavit řadu</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="156"/>
        <source>Stop This Job</source>
        <translation>Zastavit tuto úlohu</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="159"/>
        <source>Stop the currently selected job</source>
        <translation>Zastavit nyní vybranou úlohu</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="164"/>
        <source>View Log</source>
        <translation>Zobrazit zápis</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="167"/>
        <source>View the messages of MLT and FFmpeg </source>
        <translation>Zobrazit zprávy MLT a FFmpeg</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="172"/>
        <source>Run</source>
        <translation>Spustit</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="175"/>
        <source>Restart a stopped job</source>
        <translation>Obnovit zastavenou úlohu</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="180"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="185"/>
        <location filename="../src/docks/jobsdock.ui" line="188"/>
        <source>Remove Finished</source>
        <translation>Odstranit dokončené</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.cpp" line="153"/>
        <source>Job Log</source>
        <translation>Zápis o úlohách</translation>
    </message>
</context>
<context>
    <name>KeyframeClip</name>
    <message>
        <location filename="../src/qml/views/keyframes/KeyframeClip.qml" line="245"/>
        <source>Confirm Removing Advanced Keyframes</source>
        <translation>Potvrdit odstranění pokročilých klíčových snímků</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/KeyframeClip.qml" line="246"/>
        <source>This will remove all advanced keyframes to enable simple keyframes.&lt;p&gt;Do you still want to do this?</source>
        <translation>Tím se odstraní všechny pokročilé klíčové snímky, aby se umožnily jednoduché klíčové snímky.&lt;p&gt;Stále to chcete udělat?</translation>
    </message>
</context>
<context>
    <name>KeyframesButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="58"/>
        <source>Use Keyframes for this parameter</source>
        <translation>Použít klíčové snímky pro tento parametr</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="45"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Podržte %1 pro tažení klíčového snímku pouze svisle nebo %2 pro tažení pouze vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="64"/>
        <source>Confirm Removing Keyframes</source>
        <translation>Potvrdit odstranění klíčových snímků</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="65"/>
        <source>This will remove all keyframes for this parameter.&lt;p&gt;Do you still want to do this?</source>
        <translation>Toto odstraní všechny klíčové snímky pro tento parametr.&lt;p&gt;Pořád to chcete udělat??</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="80"/>
        <source>Confirm Removing Simple Keyframes</source>
        <translation>Potvrdit odstranění jednoduchých klíčových snímků</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="81"/>
        <source>This will remove all simple keyframes for all parameters.&lt;p&gt;Simple keyframes will be converted to advanced keyframes.&lt;p&gt;Do you still want to do this?</source>
        <translation>Tím se odstraní všechny jednoduché klíčové snímky pro všechny parametry.&lt;p&gt;Jednoduché klíčové snímky budou převedeny na pokročilé klíčové snímky.&lt;p&gt;Stále to chcete udělat?</translation>
    </message>
</context>
<context>
    <name>KeyframesDock</name>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="48"/>
        <location filename="../src/docks/keyframesdock.cpp" line="62"/>
        <source>Keyframes</source>
        <translation>Klíčové snímky</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="71"/>
        <source>View</source>
        <translation>Pohled</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="78"/>
        <source>Keyframe</source>
        <translation>Klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="79"/>
        <source>From Previous</source>
        <translation>Od předchozího</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="84"/>
        <source>Ease Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="101"/>
        <source>To Next</source>
        <translation>K dalšímu</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="106"/>
        <source>Ease In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="121"/>
        <source>Ease In/Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="141"/>
        <source>Keyframes Clip</source>
        <translation>Záběr klíčového snímku</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="149"/>
        <source>Keyframes Controls</source>
        <translation>Ovládání klíčových snímků</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="153"/>
        <source>Keyframes Menu</source>
        <translation>Nabídka pro klíčové snímky</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="223"/>
        <source>Set Filter Start</source>
        <translation>Nastavit začátek filtru</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="242"/>
        <source>Set Filter End</source>
        <translation>Nastavit konec filtru</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="261"/>
        <source>Set First Simple Keyframe</source>
        <translation>Nastavit první jednoduchý klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="280"/>
        <source>Set Second Simple Keyframe</source>
        <translation>Nastavit druhý jednoduchý klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="299"/>
        <source>Scrub While Dragging</source>
        <translation>Při tažení záběrů do nebo na časové ose přehrávat rychle snímek za snímkem. Časová poloha přehrávače sleduje vodorovnou polohu myši na časové ose</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="312"/>
        <source>Zoom Keyframes Out</source>
        <translation>Oddálit klíčové snímky</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="323"/>
        <source>Zoom Keyframes In</source>
        <translation>Přiblížit klíčové snímky</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="334"/>
        <source>Zoom Keyframes To Fit</source>
        <translation>Přizpůsobit klíčové snímky</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="350"/>
        <location filename="../src/docks/keyframesdock.cpp" line="596"/>
        <source>Hold</source>
        <translation>Držet</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="367"/>
        <location filename="../src/docks/keyframesdock.cpp" line="613"/>
        <source>Linear</source>
        <translation>Lineární</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="384"/>
        <location filename="../src/docks/keyframesdock.cpp" line="630"/>
        <source>Smooth</source>
        <translation>Plynulý</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="406"/>
        <source>Ease Out Sinusoidal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="423"/>
        <source>Ease Out Quadratic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="440"/>
        <source>Ease Out Cubic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="457"/>
        <source>Ease Out Quartic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="474"/>
        <source>Ease Out Quintic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="491"/>
        <source>Ease Out Exponential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="508"/>
        <source>Ease Out Circular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="525"/>
        <source>Ease Out Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="550"/>
        <source>Ease Out Elastic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="575"/>
        <source>Ease Out Bounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="652"/>
        <source>Ease In Sinusoidal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="668"/>
        <source>Ease In Quadratic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="684"/>
        <source>Ease In Cubic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="700"/>
        <source>Ease In Quartic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="716"/>
        <source>Ease In Quintic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="732"/>
        <source>Ease In Exponential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="748"/>
        <source>Ease In Circular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="764"/>
        <source>Ease In Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="788"/>
        <source>Ease In Elastic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="812"/>
        <source>Ease In Bounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="828"/>
        <source>Ease In/Out Sinusoidal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="845"/>
        <source>Ease In/Out Quadratic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="862"/>
        <source>Ease In/Out Cubic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="879"/>
        <source>Ease In/Out Quartic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="896"/>
        <source>Ease In/Out Quintic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="913"/>
        <source>Ease In/Out Exponential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="930"/>
        <source>Ease In/Out Circular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="947"/>
        <source>Ease In/Out Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="972"/>
        <source>Ease In/Out Elastic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="997"/>
        <source>Ease In/Out Bounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1014"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1025"/>
        <source>Rebuild Audio Waveform</source>
        <translation>Obnovit zvukovou vlnu</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1037"/>
        <source>Seek Previous Keyframe</source>
        <translation>Vyhledat předchozí klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1053"/>
        <source>Seek Next Keyframe</source>
        <translation>Vyhledat další klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1069"/>
        <source>Toggle Keyframe At Playhead</source>
        <translation>Přepnout klíčový snímek v poloze přehrávání</translation>
    </message>
</context>
<context>
    <name>KeyframesModel</name>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="74"/>
        <source>Hold</source>
        <translation>Držet</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="71"/>
        <source>Linear</source>
        <translation>Lineární</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="80"/>
        <location filename="../src/models/keyframesmodel.cpp" line="174"/>
        <source>Smooth</source>
        <translation>Plynulý</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="83"/>
        <source>Ease In Sinusoidal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="86"/>
        <source>Ease Out Sinusoidal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="89"/>
        <source>Ease In/Out Sinusoidal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="92"/>
        <source>Ease In Quadratic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="95"/>
        <source>Ease Out Quadratic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="98"/>
        <source>Ease In/Out Quadratic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="101"/>
        <source>Ease In Cubic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="104"/>
        <source>Ease Out Cubic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="107"/>
        <source>Ease In/Out Cubic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="110"/>
        <source>Ease In Quartic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="113"/>
        <source>Ease Out Quartic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="116"/>
        <source>Ease In/Out Quartic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="119"/>
        <source>Ease In Quintic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="122"/>
        <source>Ease Out Quintic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="125"/>
        <source>Ease In/Out Quintic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="128"/>
        <source>Ease In Exponential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="131"/>
        <source>Ease Out Exponential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="134"/>
        <source>Ease In/Out Exponential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="137"/>
        <source>Ease In Circular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="140"/>
        <source>Ease Out Circular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="143"/>
        <source>Ease In/Out Circular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="146"/>
        <source>Ease In Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="149"/>
        <source>Ease Out Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="152"/>
        <source>Ease In/Out Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="155"/>
        <source>Ease In Elastic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="158"/>
        <source>Ease Out Elastic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="161"/>
        <source>Ease In/Out Elastic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="164"/>
        <source>Ease In Bounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="167"/>
        <source>Ease Out Bounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="170"/>
        <source>Ease In/Out Bounce</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LissajousWidget</name>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="26"/>
        <source>Lissajous</source>
        <translation>Lissajous</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="41"/>
        <source>X Ratio</source>
        <translation>Poměr X</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="106"/>
        <source>Y Ratio</source>
        <translation>Poměr Y</translation>
    </message>
</context>
<context>
    <name>ListSelectionDialog</name>
    <message>
        <location filename="../src/dialogs/listselectiondialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
</context>
<context>
    <name>LumaMixTransition</name>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="25"/>
        <source>Transition</source>
        <translation>Přechod</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="351"/>
        <source>Preview</source>
        <translation>Náhled</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="360"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="92"/>
        <source>Dissolve</source>
        <translation>Prolínat se</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="97"/>
        <source>Cut</source>
        <translation>Vyjmout</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="107"/>
        <source>Bar Horizontal</source>
        <translation>Pruh vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="112"/>
        <source>Bar Vertical</source>
        <translation>Pruh svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="117"/>
        <source>Barn Door Horizontal</source>
        <translation>Vrata od stodoly vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="122"/>
        <source>Barn Door Vertical</source>
        <translation>Vrata od stodoly svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="127"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Vrata od stodoly diagonálně SW-NE</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="132"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Vrata od stodoly diagonálně NW-SE</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="137"/>
        <source>Diagonal Top Left</source>
        <translation>Diagonálně nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="142"/>
        <source>Diagonal Top Right</source>
        <translation>Diagonálně nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="147"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Matrix vodopád vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="152"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Matrix vodopád svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="157"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Matrix had vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="162"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Matrix had souběžně vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="167"/>
        <source>Matrix Snake Vertical</source>
        <translation>Matrix had svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="172"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Matrix had souběžně svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="177"/>
        <source>Barn V Up</source>
        <translation>Stodola V nahoru</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="182"/>
        <source>Iris Circle</source>
        <translation>Kruh duhy</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="187"/>
        <source>Double Iris</source>
        <translation>Dvojitá duha</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="192"/>
        <source>Iris Box</source>
        <translation>Obdélník duhy</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="197"/>
        <source>Box Bottom Right</source>
        <translation>Obdélník dole vpravo</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="202"/>
        <source>Box Bottom Left</source>
        <translation>Obdélník dole vlevo</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="207"/>
        <source>Box Right Center</source>
        <translation>Obdélník vpravo střed</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="212"/>
        <source>Clock Top</source>
        <translation>Hodiny nahoře</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="370"/>
        <source>Get custom transitions on our Web site.</source>
        <translation>Získejte vlastní přechody na našich internetových stránkách.</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="102"/>
        <source>Custom...</source>
        <translation>Vlastní...</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="243"/>
        <source>TextLabel</source>
        <translation>Textový popisek</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="341"/>
        <source>Swap the appearance of the A and B clips</source>
        <translation>Vyměnit zobrazení záběrů A a B</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="344"/>
        <source>Invert Wipe</source>
        <translation>Obrátit stírání obrazu</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="39"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="234"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="240"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="261"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="265"/>
        <source>Softness</source>
        <translation>Měkkost</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="52"/>
        <source>Change the softness of the edge of the wipe</source>
        <translation>Změnit jemnost okraje stírání obrazu</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="68"/>
        <location filename="../src/widgets/lumamixtransition.ui" line="311"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="222"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="232"/>
        <source>Save the custom transition as a favorite</source>
        <translation>Uložit vlastní přechod jako oblíbený</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="252"/>
        <source>Automatically fade-out the audio of clip A
and fade-in the audio of clip B over the
duration of the transition.</source>
        <translation>Automaticky zeslabit zvuk záběru A
a zesílit zvuk záběru B po dobu
trvání přechodu.</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="257"/>
        <source>Cross-fade</source>
        <translation>Prolínání</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="271"/>
        <source>Do not alter the audio levels during the
course of the transition. Instead, set a
fixed mixing level, or choose only clip A&apos;s
audio (0%) or clip B&apos;s audio (100%).</source>
        <translation>Neměňte zvukové úrovně během
toku přechodu. Místo toho nastavte
pevnou úroveň míchání, nebo vyberte pouze zvuk
záběru A (0%) nebo zvuk záběru B (100%).</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="277"/>
        <source>Mix:</source>
        <translation>Míchání:</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="287"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="304"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="64"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="237"/>
        <source>Position</source>
        <translation>Poloha</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="106"/>
        <source>Preview Not Available</source>
        <translation>Náhled není dostupný</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="247"/>
        <source>Open File</source>
        <translation>Otevřít soubor</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Shotcut</source>
        <translation>Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>&amp;File</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>&amp;View</source>
        <translation>Pohled</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Layout</source>
        <translation>Rozvržení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>&amp;Edit</source>
        <translation>Úpravy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>&amp;Help</source>
        <translation>Nápo&amp;věda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="145"/>
        <source>Audio Channels</source>
        <translation>Zvukové kanály</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="246"/>
        <source>Deinterlacer</source>
        <translation>Odstranění prokládání</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="256"/>
        <source>Interpolation</source>
        <translation>Interpolace</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="154"/>
        <source>Video Mode</source>
        <translation>Obrazový režim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="265"/>
        <source>External Monitor</source>
        <translation>Vnější monitor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="160"/>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="165"/>
        <source>Theme</source>
        <translation>Vzhled</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="173"/>
        <source>Display Method</source>
        <translation>Způsob zobrazení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="199"/>
        <source>App Data Directory</source>
        <translation>Adresář s daty programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="206"/>
        <source>Preview Scaling</source>
        <translation>Náhled změny velikosti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="224"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Storage</source>
        <translation>Úložiště</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Toolbar</source>
        <translation>Nástrojový pruh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="378"/>
        <source>&amp;Open File...</source>
        <translation>&amp;Otevřít soubor...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>E&amp;xit</source>
        <translation>U&amp;končit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="395"/>
        <source>Quit the application</source>
        <translation>Ukončit program</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <source>&amp;About Shotcut</source>
        <translation>O &amp;programu Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>About Qt</source>
        <translation>O Qt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="419"/>
        <source>Open Other...</source>
        <translation>Otevřít jiné...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="422"/>
        <source>Open a device, stream or generator</source>
        <translation>Otevřít zařízení, soubor nebo generátor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="437"/>
        <source>&amp;Save</source>
        <translation>&amp;Uložit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <source>Save project as a MLT XML file</source>
        <translation>Uložit projekt jako soubor MLT XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>Save &amp;As...</source>
        <translation>Uložit &amp;jako...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="454"/>
        <source>Save project to a different MLT XML file</source>
        <translation>Uložit projekt do jiného souboru MLT XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="51"/>
        <location filename="../src/mainwindow.ui" line="466"/>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Export</source>
        <translation>Vyvedení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Job Priority</source>
        <translation>Přednost úlohy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="478"/>
        <source>&amp;Undo</source>
        <translation>&amp;Zpět</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="487"/>
        <source>&amp;Redo</source>
        <translation>Z&amp;novu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="492"/>
        <source>Forum...</source>
        <translation>Fórum...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="497"/>
        <source>FAQ...</source>
        <translation>Často kladené otázky...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="506"/>
        <location filename="../src/mainwindow.cpp" line="3922"/>
        <source>Enter Full Screen</source>
        <translation>Vstoupit do režimu na celou obrazovku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="518"/>
        <source>Peak Meter</source>
        <translation>Měřič hladin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="530"/>
        <location filename="../src/mainwindow.cpp" line="401"/>
        <location filename="../src/mainwindow.cpp" line="2408"/>
        <source>Properties</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <location filename="../src/mainwindow.cpp" line="2417"/>
        <source>Recent</source>
        <translation>Naposledy otevřené</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <location filename="../src/mainwindow.ui" line="548"/>
        <source>Playlist</source>
        <translation>Seznam záběrů</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <source>History</source>
        <translation>Historie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="568"/>
        <source>Realtime (frame dropping)</source>
        <translation>Ve skutečném čase (zahazování snímků)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="579"/>
        <source>Progressive</source>
        <translation>Progresivní</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="587"/>
        <source>GPU Effects (unstable)</source>
        <translation>Efekty GPU (nestálé)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="590"/>
        <source>Use GPU filters</source>
        <translation>Použít grafické procesorové filtry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="601"/>
        <source>1 (mono)</source>
        <translation>1 (mono)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="609"/>
        <source>2 (stereo)</source>
        <translation>2 (stereo)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="636"/>
        <source>One Field (fast)</source>
        <translation>Jedno pole (rychlé)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="644"/>
        <source>Linear Blend (fast)</source>
        <translation>Lineární smíchání (nejrychlejší)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="652"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF - pouze dočasné (dobré)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>Nejbližší soused (rychlá)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="687"/>
        <source>Bilinear (good)</source>
        <translation>Bilineární (dobrá)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="695"/>
        <source>Bicubic (better)</source>
        <translation>Bikubická (lepší)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="714"/>
        <location filename="../src/mainwindow.ui" line="847"/>
        <location filename="../src/mainwindow.cpp" line="2613"/>
        <source>Automatic</source>
        <translation>Automaticky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="725"/>
        <location filename="../src/mainwindow.ui" line="1191"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="733"/>
        <source>Use JACK Audio</source>
        <translation>Použít JACK Audio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="742"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <source>Filters</source>
        <translation>Filtry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <source>Add...</source>
        <translation>Přidat...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="758"/>
        <source>System</source>
        <translation>Systém</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="761"/>
        <source>Use the user or platform style, colors, and icons.</source>
        <translation>Použít styl, barvy a ikony uživatele nebo systému.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="769"/>
        <source>Fusion Dark</source>
        <translation>Tmavá slitina</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="777"/>
        <source>Fusion Light</source>
        <translation>Světlá slitina</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="782"/>
        <source>Tutorials...</source>
        <translation>Návody...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <location filename="../src/mainwindow.ui" line="791"/>
        <location filename="../src/mainwindow.cpp" line="2427"/>
        <source>Timeline</source>
        <translation>Časová osa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="796"/>
        <location filename="../src/mainwindow.ui" line="799"/>
        <source>Restore Default Layout</source>
        <translation>Obnovit výchozí rozvržení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="807"/>
        <source>Show Title Bars</source>
        <translation>Ukázat titulkové proužky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="815"/>
        <source>Show Toolbar</source>
        <translation>Ukázat nástrojový pruh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="820"/>
        <source>Upgrade...</source>
        <translation>Povýšit...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="825"/>
        <source>Open MLT XML As Clip...</source>
        <translation>Otevřít MLT XML jako záběr...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="828"/>
        <source>Open a MLT XML project file as a virtual clip</source>
        <translation>Otevřít projektový soubor MLT XML jako virtuální záběr</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="836"/>
        <source>Scrub Audio</source>
        <translation>Hrát zvuk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="871"/>
        <source>Software (Mesa)</source>
        <extracomment>Do not translate &quot;Mesa&quot;</extracomment>
        <translation>Software (Mesa)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>Low</source>
        <translation>Nízká</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="887"/>
        <source>Normal</source>
        <translation>Normální</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="897"/>
        <source>Application Log...</source>
        <translation>Zápis programu...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="905"/>
        <location filename="../src/mainwindow.ui" line="996"/>
        <location filename="../src/mainwindow.ui" line="999"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="1329"/>
        <source>Player</source>
        <translation>Přehrávač</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="913"/>
        <source>User Interface</source>
        <translation>Uživatelské rozhraní</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="921"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1144"/>
        <source>Notes</source>
        <translation>Poznámky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1358"/>
        <source>Markers as Chapters...</source>
        <translation>Značky jako kapitoly...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1361"/>
        <location filename="../src/mainwindow.ui" line="1364"/>
        <location filename="../src/mainwindow.cpp" line="5861"/>
        <source>Export Chapters</source>
        <translation>Vyvést kapitoly</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1369"/>
        <source>Audio/Video Device...</source>
        <translation>Zařízení pro zvuk/obraz...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="971"/>
        <location filename="../src/mainwindow.ui" line="1269"/>
        <source>Set...</source>
        <translation>Nastavit...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Other Versions</source>
        <translation>Jiné verze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>&amp;Player</source>
        <translation>&amp;Přehrávač</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="141"/>
        <source>&amp;Settings</source>
        <translation>&amp;Nastavení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Time Format</source>
        <translation>Formát času</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="381"/>
        <source>Open a video, audio, image, or project file</source>
        <translation>Otevřít soubor s obrazem (video), zvukem (audio) nebo projektem</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="521"/>
        <source>Audio Peak Meter</source>
        <translation>Měřič hladin zvuku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="617"/>
        <source>4 (quad/Ambisonics)</source>
        <translation>4 (quad/Ambisonics)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="625"/>
        <source>6 (5.1 surround)</source>
        <translation>6 (5.1 prostorový zvuk)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="660"/>
        <source>YADIF - temporal + spatial (better)</source>
        <translation>YADIF - časové + prostorové (lepší)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="668"/>
        <source>BWDIF (best)</source>
        <translation>BWDIF (nejlepší)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Lanczos (best)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="892"/>
        <source>Resources...</source>
        <translation>Zdroje...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="976"/>
        <location filename="../src/mainwindow.ui" line="1277"/>
        <source>Show...</source>
        <translation>Ukázat...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="979"/>
        <source>Show</source>
        <translation>Ukázat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="988"/>
        <location filename="../src/mainwindow.ui" line="991"/>
        <source>Keyframes</source>
        <translation>Klíčové snímky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>New</source>
        <translation>Nový</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1002"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1018"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1021"/>
        <source>Switch to the audio layout</source>
        <translation>Přepnout do rozvržení pro zvuk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1024"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1032"/>
        <source>Logging</source>
        <translation>Zápis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1035"/>
        <source>Switch to the logging layout</source>
        <translation>Přepnout do rozvržení pro zápis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1038"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1046"/>
        <source>Editing</source>
        <translation>Úpravy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1049"/>
        <source>Switch to the editing layout</source>
        <translation>Přepnout do rozvržení pro úpravy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1052"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1060"/>
        <source>FX</source>
        <translation>Efekty</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <source>Switch to the effects layout</source>
        <translation>Přepnout do rozvržení pro efekty</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1066"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <source>New Generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1135"/>
        <source>Markers</source>
        <translation>Značky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1153"/>
        <source>Subtitles</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1183"/>
        <source>1080p</source>
        <translation type="unfinished">1080p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Timecode (Drop-Frame)</source>
        <translation>Časový kód (zahodit-snímek)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1221"/>
        <source>Frames</source>
        <translation>Snímky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1229"/>
        <source>Clock</source>
        <translation>Hodiny</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1237"/>
        <source>Timecode (Non-Drop Frame)</source>
        <translation>Časový kód (ne-zahodit-snímek)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1242"/>
        <source>Topics</source>
        <translation>Témata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1250"/>
        <source>Synchronization...</source>
        <translation>Synchronizace...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1253"/>
        <source>Synchronization</source>
        <translation>Synchronizace</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Use Proxy</source>
        <translation>Použít proxy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1272"/>
        <source>Set the proxy storage folder</source>
        <translation>Nastavit ukládací složku proxy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1280"/>
        <source>Show the proxy storage folder</source>
        <translation>Ukázat ukládací složku proxy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1291"/>
        <source>Use Project Folder</source>
        <translation>Použít složku projekty</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1294"/>
        <source>Store proxies in the project folder if defined</source>
        <translation>Ukládat proxy ve složce projektu, pokud je stanoveno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1302"/>
        <source>Use Hardware Encoder</source>
        <translation>Použít hardvarový kodér</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1307"/>
        <source>Configure Hardware Encoder...</source>
        <translation>Nastavit hardvarový kodér...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1318"/>
        <source>Switch to the color layout</source>
        <translation>Přepnout do rozvržení pro barvy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1321"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1332"/>
        <source>Switch to the player only layout</source>
        <translation>Přepnout do rozvržení pouze pro přehrávač</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1335"/>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1348"/>
        <source>Playlist Project</source>
        <translation>Projekt se seznamem záběrů</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1353"/>
        <source>Clip-only Project</source>
        <translation>Projekt jen se záběry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1374"/>
        <source>Reset...</source>
        <translation>Obnovit výchozí...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1379"/>
        <location filename="../src/mainwindow.ui" line="1382"/>
        <source>Backup and Save</source>
        <translation>Zálohovat a uložit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1393"/>
        <source>Manually</source>
        <translation>Ručně</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1401"/>
        <source>Hourly</source>
        <translation>Hodinově</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1409"/>
        <source>Daily</source>
        <translation>Denně</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1420"/>
        <source>Weekly</source>
        <translation>Týdně</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1425"/>
        <source>Show Project in Folder</source>
        <translation>Zobrazit projekt ve složce</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1436"/>
        <source>Pause After Seek</source>
        <translation>Pozastavení po vyhledávání</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1445"/>
        <source>Files</source>
        <translation>Soubory</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1076"/>
        <location filename="../src/mainwindow.ui" line="1081"/>
        <source>Remove...</source>
        <translation>Odstranit...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="509"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="932"/>
        <source>EDL...</source>
        <translation>EDL...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="943"/>
        <source>Frame...</source>
        <translation>Snímek...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <source>Video...</source>
        <translation>Obrazový záznam...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="960"/>
        <location filename="../src/mainwindow.ui" line="963"/>
        <source>Export Video</source>
        <translation>Vyvést obrazový záznam</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1007"/>
        <source>Actions and Shortcuts...</source>
        <translation>Činnosti a klávesové zkratky...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <source>Clear Recent on Exit</source>
        <translation>Vyprázdnit nedávné při ukončení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <source>Show Text Under Icons</source>
        <translation>Ukázat text pod obrázky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1117"/>
        <source>Show Small Icons</source>
        <translation>Ukázat malé obrázky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1126"/>
        <source>Jobs</source>
        <translation>Úlohy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1161"/>
        <source>540p</source>
        <translation>540 p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1172"/>
        <source>720p</source>
        <translation>720 p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1202"/>
        <source>360p</source>
        <translation>360 p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <source>Error: This program requires the SDL 2 library.

Please install it using your package manager. It may be named libsdl2-2.0-0, SDL2, or similar.</source>
        <translation>Chyba: Tento program vyžaduje knihovnu SDL 2.

Nainstalujte ji, prosím, pomocí správce balíčků. Může být pojmenována libsdl2-2.0-0, SDL2, nebo tak nějak.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1162"/>
        <source>Screen %1 (%2 x %3 @ %4 Hz)</source>
        <translation>Obrazovka %1 (%2 x %3 @ %4 Hz)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1198"/>
        <source>Off</source>
        <translation>Vypnuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1201"/>
        <source>Internal</source>
        <translation>Vnitřní</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1204"/>
        <source>External</source>
        <translation>Vnější</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1227"/>
        <source>DeckLink Keyer</source>
        <translation>Klíčovač DeckLink</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1315"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1491"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1498"/>
        <source>Animation</source>
        <translation>Animace</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1503"/>
        <source>Noise</source>
        <translation>Šum</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1508"/>
        <source>Color Bars</source>
        <translation>Barevné pruhy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1513"/>
        <source>Audio Tone</source>
        <translation>Zvukový tón</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1518"/>
        <source>Count</source>
        <translation>Počítání</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1523"/>
        <source>Blip Flash</source>
        <translation>Záblesk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1548"/>
        <location filename="../src/mainwindow.cpp" line="1550"/>
        <location filename="../src/mainwindow.cpp" line="1988"/>
        <location filename="../src/mainwindow.cpp" line="1996"/>
        <location filename="../src/mainwindow.cpp" line="2019"/>
        <location filename="../src/mainwindow.cpp" line="2079"/>
        <location filename="../src/mainwindow.cpp" line="4659"/>
        <location filename="../src/mainwindow.cpp" line="4672"/>
        <location filename="../src/mainwindow.cpp" line="5637"/>
        <source>Failed to open </source>
        <translation>Nepodařilo se otevřít</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1583"/>
        <source>The file you opened uses GPU effects, but GPU effects are not enabled.</source>
        <translation>Soubor, který jste otevřeli, používá efekty GPU, ale efekty GPU nejsou povoleny.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1595"/>
        <source>The file you opened uses CPU effects that are incompatible with GPU effects, but GPU effects are enabled.
Do you want to disable GPU effects and restart?</source>
        <translation>Soubor, který jste otevřel, používá efekty procesoru, které se neslučují s efekty grafického procesoru. Tyto však nejsou povoleny.
Chcete zakázat efekty grafického procesoru a program spustit znovu?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1618"/>
        <source>Repaired</source>
        <translation>Opraveno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1619"/>
        <source>Save Repaired XML</source>
        <translation>Uložit opravené XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1656"/>
        <source>Repairing the project failed.</source>
        <translation>Opravení projektu se nezdařilo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1669"/>
        <source>Shotcut noticed some problems in your project.
Do you want Shotcut to try to repair it?

If you choose Yes, Shotcut will create a copy of your project
with &quot;- Repaired&quot; in the file name and open it.</source>
        <translation>Shotcut si povšimnul některých potíží vašeho projektu.
Má se Shotcut pokusit o jejich vyřešení?

Pokud zvolíte Ano, Shotcut vytvoří kopii vašeho projektu
s &quot;- Opraveno&quot; v názvu souboru a otevře ji.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1704"/>
        <source>Auto-saved files exist. Do you want to recover them now?</source>
        <translation>Existují automaticky uložené soubory. Chcete je nyní obnovit?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1776"/>
        <source>You cannot add a project to itself!</source>
        <translation>Nemůžete přidat projekt do něj samotného</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1814"/>
        <source>There was an error saving. Please try again.</source>
        <translation>Při ukládání se vyskytla chyba. Prosím, zkuste to znovu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1899"/>
        <source>This project file requires a newer version!

It was made with version </source>
        <translation>Tento soubor projektu vyžaduje novější verzi!

Byl vyroben s verzí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1930"/>
        <source>You are running low on available memory!

Please close other applications or web browser tabs and retry.
Or save and restart Shotcut.</source>
        <translation>Dochází vám dostupná paměť!

Zavřete, prosím, další aplikace nebo karty internetového prohlížeče a zkuste to znovu.
Nebo uložte a spusťte Shotcut znovu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1982"/>
        <source>Opening %1</source>
        <translation>Otevírá se %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2121"/>
        <location filename="../src/mainwindow.cpp" line="4646"/>
        <source>Open File</source>
        <translation>Otevřít soubor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2123"/>
        <source>All Files (*);;MLT XML (*.mlt)</source>
        <translation>Všechny soubory (*);;MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2391"/>
        <source>Preferences</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2401"/>
        <source>Rename Clip</source>
        <translation>Přejmenovat záběr</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2410"/>
        <source>Find</source>
        <translation>Najít</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2419"/>
        <source>Reload</source>
        <translation>Nahrát znovu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2429"/>
        <source>Rerun Filter Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="2443"/>
        <source>This will start %n analysis job(s). Continue?</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2461"/>
        <source>No filters to analyze.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2602"/>
        <source>Untitled</source>
        <translation>Bez názvu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2607"/>
        <source>%1x%2 %3fps %4ch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2634"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2763"/>
        <source>Non-Broadcast</source>
        <translation>Nestandardní</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2768"/>
        <source>DVD Widescreen NTSC</source>
        <translation>Širokoúhlé DVD NTSC</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2769"/>
        <source>DVD Widescreen PAL</source>
        <translation>Širokoúhlé DVD PAL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2780"/>
        <source>Square 1080p 30 fps</source>
        <translation>Čtverec 1080 p 30 FPS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2781"/>
        <source>Square 1080p 60 fps</source>
        <translation>Čtverec 1080 p 60 FPS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2782"/>
        <source>Vertical HD 30 fps</source>
        <translation>Svislý HD 30 FPS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2783"/>
        <source>Vertical HD 60 fps</source>
        <translation>Svislý HD 60 FPS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2784"/>
        <source>Custom</source>
        <translation>Vlastní</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2815"/>
        <location filename="../src/mainwindow.cpp" line="3110"/>
        <source>Saved %1</source>
        <translation>Uloženo %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3101"/>
        <location filename="../src/mainwindow.cpp" line="3124"/>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <source>Save XML</source>
        <translation>Uložit XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3220"/>
        <source>Timeline is not loaded</source>
        <translation>Časová osa není načtena</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3230"/>
        <source>Range marker not found under the timeline cursor</source>
        <translation>Značka rozsahu nenalezena pod ukazatelem časové osy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3295"/>
        <source>There are incomplete jobs.
Do you still want to exit?</source>
        <translation>Jsou tu nedokončené úlohy.
Pořád ještě chcete skončit?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3307"/>
        <source>An export is in progress.
Do you still want to exit?</source>
        <translation>Probíhá vyvádění do souboru.
Pořád ještě chcete skončit?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4448"/>
        <source>Saved backup %1</source>
        <translation>Uložená záloha %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3186"/>
        <source>Do you also want to change the Video Mode to %1 x %2?</source>
        <translation>Chcete také změnit obrazový režim na %1 x %2?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4101"/>
        <source>Opened Files</source>
        <translation>Otevřené soubory</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4183"/>
        <source>GPU effects are experimental and do not work good on all computers. Plan to do some testing after turning this on.
At this time, a project created with GPU effects cannot be converted to a CPU-only project later.

Do you want to enable GPU effects and restart Shotcut?</source>
        <translation>Efekty GPU jsou pokusné a nepracují dobře na všech počítačích. Plánujte provést nějaké zkoušení po zapnutí této funkce.
V tuto chvíli nelze projekt vytvořený s efekty GPU později převést na projekt pouze pro CPU.

Chcete zapnout efekty GPU a restartovat Shotcut?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5281"/>
        <source>Add To Timeline</source>
        <translation>Přidat do časové osy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5837"/>
        <source>Include ranges (Duration &gt; 1 frame)?</source>
        <translation>Zahrnout rozsahy (Doba trvání &gt; 1 snímek)?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5848"/>
        <source>Choose Markers</source>
        <translation>Vybrat značky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5865"/>
        <source>Text (*.txt);;All Files (*)</source>
        <translation>Text (*.txt);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5920"/>
        <source>Failed to open export-chapters.js</source>
        <translation>Nepodařilo se otevřít export-chapters.js</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5961"/>
        <source>This will reset &lt;b&gt;all&lt;/b&gt; settings, and Shotcut must restart afterwards.
Do you want to reset and restart now?</source>
        <translation>Tím se obnoví &lt;b&gt;všechna&lt;/b&gt; nastavení a aplikace Shotcut se poté musí spustit znovu.
Chcete nyní obnovit výchozí nastavení a restartovat?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1623"/>
        <location filename="../src/mainwindow.cpp" line="3128"/>
        <source>MLT XML (*.mlt)</source>
        <translation>MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <source>View Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3268"/>
        <source>The project has been modified.
Do you want to save your changes?</source>
        <translation>Projekt byl změněn.
Chcete uložit své změny?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3925"/>
        <source>Exit Full Screen</source>
        <translation>Opustit režim na celou obrazovku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <source>Turn Proxy On</source>
        <translation>Zapnout proxy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <source>Turn Proxy Off</source>
        <translation>Vypnout proxy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5601"/>
        <source>Converting</source>
        <translation>Převádí se</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5617"/>
        <source>Do you want to create missing proxies for every file in this project?

You must reopen your project after all proxy jobs are finished.</source>
        <translation>Chcete vytvořit chybějící proxy pro každý soubor v tomto projektu?

Po dokončení všech úloh proxy musíte znovu otevřít svůj projekt.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5655"/>
        <source>Proxy Folder</source>
        <translation>Složka proxy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5673"/>
        <source>Do you want to move all files from the old folder to the new folder?</source>
        <translation>Chcete přesunout všechny soubory ze staré složky do nové složky?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5681"/>
        <source>Moving Files</source>
        <translation>Přesouvání souborů</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3937"/>
        <source>GPU effects are not supported</source>
        <translation>Efekty grafického procesorového filtru nejsou podporovány</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>Set Loop Range</source>
        <translation>Nastavit rozsah smyčky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="474"/>
        <source>Thumbnails</source>
        <translation>Náhledy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <source>Scrolling</source>
        <translation>Posunování</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1043"/>
        <source>Audio API</source>
        <translation>Zvukové API</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1064"/>
        <source>default</source>
        <translation>Výchozí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1071"/>
        <source>You must restart Shotcut to change the audio API.
Do you want to restart now?</source>
        <translation>Musíte Shotcut spustit kvůli změně vukového API znovu.
Chcete jej spustit znovu nyní?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1189"/>
        <source>SDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>HLG HDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>DeckLink Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3957"/>
        <source>Click here to check for a new version of Shotcut.</source>
        <translation>Zde klepněte pro ověření dostupnosti nové verze Shotcutu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4072"/>
        <source>Open Files</source>
        <translation>Otevřít soubory</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4131"/>
        <source>You must restart Shotcut to switch to the new language.
Do you want to restart now?</source>
        <translation>Musíte Shotcut spustit kvůli přepnutí rozhraní na nový jazyk znovu.
Chcete jej spustit znovu nyní?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4174"/>
        <source>Failed to connect to JACK.
Please verify that JACK is installed and running.</source>
        <translation>Nepodařilo se spojit se s JACKem.
Ověřte, prosím, že je JACK nainstalován a běží.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4203"/>
        <source>Shotcut must restart to disable GPU effects.

Disable GPU effects and restart?</source>
        <translation>Shotcut se musí restartovat kvůli zakázání efektů grafického procesoru.

Zakázat efekty grafického procesoru a program spustit znovu?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4425"/>
        <source>You must restart %1 to switch to the new theme.
Do you want to restart now?</source>
        <translation>Musíte %1 spustit kvůli přepnutí do nového vzhledu znovu.
Chcete jej spustit znovu nyní?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4468"/>
        <source>&lt;p&gt;Please review your entire project after making this change.&lt;/p&gt;&lt;p&gt;Shotcut does not automatically adjust things that are sensitive to size and position if you change resolution or aspect ratio.&lt;/p&lt;br&gt;The timing of edits and keyframes may be slightly different if you change frame rate.&lt;/p&gt;&lt;p&gt;It is a good idea to use &lt;b&gt;File &gt; Backup and Save&lt;/b&gt; before or after this operation.&lt;/p&gt;&lt;p&gt;Do you want to change the &lt;b&gt;Video Mode&lt;/b&gt; now?&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4482"/>
        <source>Do not show this anymore.</source>
        <comment>Change video mode warning dialog</comment>
        <translation>Toto už vícekrát neukazovat.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4493"/>
        <source>Shotcut must restarto change external monitoring.
Do you want to restart now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4623"/>
        <source>Do you want to automatically check for updates in the future?</source>
        <translation>Chcete v budoucnosti automaticky kontrolovat aktualizace?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4630"/>
        <source>Do not show this anymore.</source>
        <comment>Automatic upgrade check dialog</comment>
        <translation>Toto už vícekrát neukazovat.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4648"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4702"/>
        <source>You must restart Shotcut to change the display method.
Do you want to restart now?</source>
        <translation>Musíte Shotcut spustit kvůli změně způsobu zobrazení znovu.
Chcete jej spustit znovu nyní?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4732"/>
        <source>Application Log</source>
        <translation>Zápis programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4735"/>
        <source>Previous</source>
        <translation>Předchozí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4797"/>
        <source>Shotcut version %1 is available! Click here to get it.</source>
        <translation>Je dostupná verze %1 Shotcutu. Klepněte zde a dostaňte ji.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <source>You are running the latest version of Shotcut.</source>
        <translation>Provozujete nejnovější verzi Shotcutu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4817"/>
        <source>Failed to read version.json when checking. Click here to go to the Web site.</source>
        <translation>Při ověřování se nepodařilo přečíst version.json. Klepněte sem pro přechod na internetovou stránku.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="935"/>
        <location filename="../src/mainwindow.ui" line="938"/>
        <location filename="../src/mainwindow.cpp" line="4837"/>
        <source>Export EDL</source>
        <translation>Vyvést EDL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4841"/>
        <source>EDL (*.edl);;All Files (*)</source>
        <translation>EDL (*.edl);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4888"/>
        <location filename="../src/mainwindow.cpp" line="5917"/>
        <source>A JavaScript error occurred during export.</source>
        <translation>Během vyvádění došlo k chybě v JavaScriptu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4891"/>
        <source>Failed to open export-edl.js</source>
        <translation>Nepodařilo se otevřít export-edl.js</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4922"/>
        <source>Export frame from proxy?</source>
        <translation>Vyvést snímek z proxy?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4923"/>
        <source>This frame may be from a lower resolution proxy instead of the original source.

Do you still want to continue?</source>
        <translation>Tento snímek může být z proxy s nižším rozlišením namísto původního zdroje.

Stále chcete pokračovat?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="946"/>
        <location filename="../src/mainwindow.ui" line="949"/>
        <location filename="../src/mainwindow.cpp" line="4935"/>
        <source>Export Frame</source>
        <translation>Vyvést snímek</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4941"/>
        <source>Unable to export frame.</source>
        <translation>Nelze vyvést snímek.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4949"/>
        <source>You must restart Shotcut to change the data directory.
Do you want to continue?</source>
        <translation>Musíte Shotcut spustit kvůli změně adresáře s daty znovu.
Chcete pokračovat?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4960"/>
        <source>Data Directory</source>
        <translation>Adresář s daty</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5170"/>
        <source>Add Custom Layout</source>
        <translation>Přidat vlastní rozvržení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5171"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5210"/>
        <source>Remove Video Mode</source>
        <translation> Odstranit obrazový režim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5227"/>
        <source>Remove Layout</source>
        <translation>Odstranit rozvržení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5381"/>
        <source>GPU effects are EXPERIMENTAL, UNSTABLE and UNSUPPORTED! Unsupported means do not report bugs about it.

Do you want to disable GPU effects and restart Shotcut?</source>
        <translation>Efekty GPU jsou EXPERIMENTÁLNÍ, NESTABILNÍ a NEPODPOROVANÉ! Nepodporované znamená že se o nich nehlásí chyby. 

Chcete zakázat efekty GPU a restartovat Shotcut?</translation>
    </message>
</context>
<context>
    <name>MarkersDock</name>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="129"/>
        <source>Markers</source>
        <translation>Značky</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="200"/>
        <source>Add a marker at the current time</source>
        <translation>Přidat značku v nynějším čase</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="209"/>
        <source>Remove the selected marker</source>
        <translation>Odstranit vybranou značku</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="218"/>
        <source>Deselect the marker</source>
        <translation>Zrušit výběr značky</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="191"/>
        <source>Markers Menu</source>
        <translation>Nabídka pro značky</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="165"/>
        <source>Remove All Markers</source>
        <translation>Odstranit všechny značky</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="167"/>
        <source>Columns</source>
        <translation>Sloupce</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="168"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="171"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="174"/>
        <source>Start</source>
        <translation>Začátek</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="177"/>
        <source>End</source>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="180"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="186"/>
        <source>Markers Controls</source>
        <translation>Ovládání značek</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="228"/>
        <source>search</source>
        <translation>Hledání</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="236"/>
        <source>Clear search</source>
        <translation>Vyprázdnit hledání</translation>
    </message>
</context>
<context>
    <name>MarkersModel</name>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="788"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="790"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="792"/>
        <source>Start</source>
        <translation>Začátek</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="794"/>
        <source>End</source>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="796"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
</context>
<context>
    <name>MeltJob</name>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="47"/>
        <source>View XML</source>
        <translation>Zobrazit XML</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="48"/>
        <source>View the MLT XML for this job</source>
        <translation>Zobrazit MLT XML pro tuto úlohu</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="57"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="59"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>Otevřít výstupní soubor v přehrávači Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="63"/>
        <location filename="../src/jobs/meltjob.cpp" line="68"/>
        <location filename="../src/jobs/meltjob.cpp" line="69"/>
        <source>Show In Folder</source>
        <translation>Ukázat ve složce</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="64"/>
        <source>Show In Files</source>
        <translation>Ukázat v souborech</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="192"/>
        <source>MLT XML</source>
        <translation>MLT XML</translation>
    </message>
</context>
<context>
    <name>Mlt::VideoWidget</name>
    <message>
        <location filename="../src/videowidget.cpp" line="196"/>
        <source>You cannot drag from Project.</source>
        <translation>Nemůžete táhnout z projektu.</translation>
    </message>
    <message>
        <location filename="../src/videowidget.cpp" line="199"/>
        <source>You cannot drag a non-seekable source</source>
        <translation>Nemůžete táhnout neprohledávatelný zdroj</translation>
    </message>
</context>
<context>
    <name>MltClipProducerWidget</name>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="47"/>
        <source>Resolution</source>
        <translation>Rozlišení</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="53"/>
        <source>Aspect ratio</source>
        <translation>Poměr stran</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="59"/>
        <source>Frame rate</source>
        <translation>Snímková rychlost</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="65"/>
        <source>Scan mode</source>
        <translation>Režim snímání</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="71"/>
        <source>Colorspace</source>
        <translation>Barevný prostor</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="77"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="150"/>
        <source>%L1 fps</source>
        <translation>%L1 szs</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="153"/>
        <source>Progressive</source>
        <translation>Progresivní</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="155"/>
        <source>Interlaced</source>
        <translation>Prokládaný</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="202"/>
        <source>Subclip profile does not match project profile.
This may provide unexpected results</source>
        <translation>Profil dílčího záběru neodpovídá profilu projektu.
To může vést k neočekávaným výsledkům</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="207"/>
        <source>Subclip profile matches project profile.</source>
        <translation>Profil dílčího záběru odpovídá profilu projektu.</translation>
    </message>
</context>
<context>
    <name>MotionTrackerDialog</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="39"/>
        <source>Load Keyframes from Motion Tracker</source>
        <translation>Nahrát klíčové snímky ze sledování pohybu</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="55"/>
        <source>Motion tracker</source>
        <translation>Sledování pohybu</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="75"/>
        <source>Adjust</source>
        <translation>Upravit</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="92"/>
        <source>Relative Position</source>
        <translation>Relativní poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="96"/>
        <source>Offset Position</source>
        <translation>Posunutá poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="100"/>
        <source>Absolute Position</source>
        <translation>Absolutní poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="104"/>
        <source>Size And Position</source>
        <translation>Velikost a poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="123"/>
        <source>From start</source>
        <translation>Od začátku</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="128"/>
        <source>Current position</source>
        <translation>Nynější poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="142"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="154"/>
        <source>Reset</source>
        <translation>Obnovit výchozí</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="165"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>MotionTrackerModel</name>
    <message>
        <location filename="../src/models/motiontrackermodel.cpp" line="180"/>
        <source>Tracker %1</source>
        <translation>Sledování %1</translation>
    </message>
</context>
<context>
    <name>MultiFileExportDialog</name>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="63"/>
        <source>Directory</source>
        <translation>Adresář</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="76"/>
        <source>Prefix</source>
        <translation>Předpona</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="77"/>
        <source>export</source>
        <translation>Vyvedení</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="82"/>
        <source>Field 1</source>
        <translation>Pole 1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="92"/>
        <source>Field 2</source>
        <translation>Pole 2</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="102"/>
        <source>Field 3</source>
        <translation>Pole 3</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="113"/>
        <source>Extension</source>
        <translation>Rozšíření</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="207"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="208"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="209"/>
        <source>Index</source>
        <translation>Číslo</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="210"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="211"/>
        <source>Hash</source>
        <translation>Suma identifikující data</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="234"/>
        <source>Empty File Name</source>
        <translation>Vyprázdnit název souboru</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="236"/>
        <source>Directory does not exist: %1</source>
        <translation>Adresář neexistuje: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="243"/>
        <source>File Exists: %1</source>
        <translation>Soubor existuje: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="248"/>
        <source>Duplicate File Name: %1</source>
        <translation>Zdvojený název souboru: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="274"/>
        <source>Fix file name errors before export.</source>
        <translation>Opravit chyby v názvech souborů před vyvedením.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="281"/>
        <source>Export Directory</source>
        <translation>Adresář pro vyvedení</translation>
    </message>
</context>
<context>
    <name>MultitrackModel</name>
    <message>
        <location filename="../src/models/multitrackmodel.cpp" line="115"/>
        <source>(PROXY)</source>
        <translation>(PROXY)</translation>
    </message>
    <message>
        <location filename="../src/models/multitrackmodel.cpp" line="2653"/>
        <source>Error: Shotcut could not find the %1 plugin on your system.

Please install the %2 plugins.</source>
        <translation>Chyba: Shotcut nedokázal najít přídavný modul %1 v systému.

Nainstalujte, prosím, přídavné moduly %2.</translation>
    </message>
</context>
<context>
    <name>NetworkProducerWidget</name>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="26"/>
        <source>Network Stream</source>
        <translation>Síťový proud</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="41"/>
        <source>&amp;URL</source>
        <translation>Adresa (&amp;URL)</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="57"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
</context>
<context>
    <name>NewProjectFolder</name>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="20"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="61"/>
        <source>Projects</source>
        <translation>Projekty</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="188"/>
        <location filename="../src/widgets/newprojectfolder.ui" line="205"/>
        <source>PushButton</source>
        <translation>Tlačítko</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="231"/>
        <source>Start</source>
        <translation>Začít</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="372"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="218"/>
        <source>A folder with this name will be created containing
a project file with the same name.</source>
        <translation>Bude vytvořena složka s tímto názvem, která bude
obsahovat soubor s projektem se stejným názvem.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="159"/>
        <source>Projects folder</source>
        <translation>Složka projektu</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="263"/>
        <source>Project name</source>
        <translation>Název projektu</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="253"/>
        <source>Video mode</source>
        <translation>Obrazový režim</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="201"/>
        <source>This is the folder to contain Shotcut project folders.
A folder will be created in this folder for each project.</source>
        <translation>Toto je složka, která obsahuje složky s projekty Shotcutu.
V této složce bude pro každý projekt vytvořena složka.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="315"/>
        <source>Automatic means the resolution and frame rate are based on the &lt;b&gt;first&lt;/b&gt; file you &lt;b&gt;add&lt;/b&gt; to your project. If the first file is not a video clip (for example, image or audio), then it will be 1920x1080p 25 fps.</source>
        <translation>Automaticky znamená, že rozlišení a snímková rychlost jsou založeny na &lt;b&gt;prvním&lt;/b&gt; souboru, jejž &lt;b&gt;přidáte&lt;/b&gt; do svého projektu. Pokud se u prvního souboru nejedná o záběr obrazového záznamu (například obrázek nebo zvuk), potom to bude 1920x1080p 25 fps.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="143"/>
        <source>New Project</source>
        <translation>Nový projekt</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="357"/>
        <source>Automatic</source>
        <translation>Automaticky</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="362"/>
        <source>Add...</source>
        <translation>Přidat...</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="367"/>
        <source>Remove...</source>
        <translation>Odstranit...</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="130"/>
        <source>Projects Folder</source>
        <translation>Složka projektu</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="167"/>
        <source>Custom</source>
        <translation>Vlastní</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="184"/>
        <source>Remove Video Mode</source>
        <translation> Odstranit obrazový režim</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="213"/>
        <source>The project name cannot include a slash.</source>
        <translation>Název projektu nesmí obsahovat lomítko.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="229"/>
        <source>There is already a project with that name.
Try again with a different name.</source>
        <translation>Již je projekt s tímto názvem.
Zkuste to znovu s jiným názvem.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="238"/>
        <source>Unable to create folder %1
Perhaps you do not have permission.
Try again with a different folder.</source>
        <translation>Nelze vytvořit složku %1
Možná nemáte oprávnění.
Zkuste to znovu s jinou složkou.</translation>
    </message>
</context>
<context>
    <name>NoiseWidget</name>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="26"/>
        <source>Noise</source>
        <translation>Šum</translation>
    </message>
</context>
<context>
    <name>NotesDock</name>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="79"/>
        <source>Notes</source>
        <translation>Poznámky</translation>
    </message>
</context>
<context>
    <name>OpenOtherDialog</name>
    <message>
        <location filename="../src/openotherdialog.ui" line="17"/>
        <source>Open Other</source>
        <translation>Otevřít jiné</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.ui" line="55"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="32"/>
        <source>Add To Timeline</source>
        <translation>Přidat do časové osy</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="38"/>
        <location filename="../src/openotherdialog.cpp" line="143"/>
        <source>Network</source>
        <translation>Síť</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="43"/>
        <source>Device</source>
        <translation>Zařízení</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="45"/>
        <location filename="../src/openotherdialog.cpp" line="145"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="49"/>
        <location filename="../src/openotherdialog.cpp" line="135"/>
        <source>Video4Linux</source>
        <translation>Video4Linux</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="51"/>
        <location filename="../src/openotherdialog.cpp" line="137"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="53"/>
        <location filename="../src/openotherdialog.cpp" line="139"/>
        <source>ALSA Audio</source>
        <translation>ALSA Audio</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="56"/>
        <location filename="../src/openotherdialog.cpp" line="59"/>
        <location filename="../src/openotherdialog.cpp" line="141"/>
        <source>Audio/Video Device</source>
        <translation>Zařízení pro zvuk/obraz</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="64"/>
        <source>Generator</source>
        <translation>Generátor</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="66"/>
        <location filename="../src/openotherdialog.cpp" line="147"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="69"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="74"/>
        <location filename="../src/openotherdialog.cpp" line="149"/>
        <source>Animation</source>
        <translation>Animace</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="78"/>
        <location filename="../src/openotherdialog.cpp" line="151"/>
        <source>Noise</source>
        <translation>Šum</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="82"/>
        <location filename="../src/openotherdialog.cpp" line="153"/>
        <source>Ising</source>
        <translation>Ising</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="87"/>
        <location filename="../src/openotherdialog.cpp" line="155"/>
        <source>Lissajous</source>
        <translation>Lissajous</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="91"/>
        <location filename="../src/openotherdialog.cpp" line="157"/>
        <source>Plasma</source>
        <translation>Plasma</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="95"/>
        <location filename="../src/openotherdialog.cpp" line="159"/>
        <source>Color Bars</source>
        <translation>Barevné pruhy</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="99"/>
        <location filename="../src/openotherdialog.cpp" line="161"/>
        <source>Audio Tone</source>
        <translation>Zvukový tón</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="103"/>
        <location filename="../src/openotherdialog.cpp" line="163"/>
        <source>Count</source>
        <translation>Počítání</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="107"/>
        <location filename="../src/openotherdialog.cpp" line="165"/>
        <source>Blip Flash</source>
        <translation>Záblesk</translation>
    </message>
</context>
<context>
    <name>ParameterHead</name>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="151"/>
        <source>Seek to previous keyframe</source>
        <translation>Prohledávat po předchozí klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="151"/>
        <source>Seek backwards</source>
        <translation>Prohledávat dozadu</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="171"/>
        <source>Add a keyframe at play head</source>
        <translation>Přidat klíčový snímek v poloze přehrávání</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="199"/>
        <source>Delete the selected keyframe</source>
        <translation>Smazat vybraný klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="228"/>
        <source>Seek to next keyframe</source>
        <translation>Prohledat po další klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="228"/>
        <source>Seek forwards</source>
        <translation>Prohledávat dopředu</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="245"/>
        <source>Unlock track</source>
        <translation>Odemknout stopu</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="245"/>
        <source>Lock track</source>
        <translation>Zamknout stopu</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="256"/>
        <source>Zoom keyframe values</source>
        <translation>Přiblížit hodnoty klíčových snímků</translation>
    </message>
</context>
<context>
    <name>PlasmaWidget</name>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="26"/>
        <source>Plasma</source>
        <translation>Plasma</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="41"/>
        <source>Speed 1</source>
        <translation>Rychlost 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="112"/>
        <source>Speed 2</source>
        <translation>Rychlost 2</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="180"/>
        <source>Speed 3</source>
        <translation>Rychlost 3</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="252"/>
        <source>Speed 4</source>
        <translation>Rychlost 4</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="323"/>
        <source>Move 1</source>
        <translation>Přesun 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="391"/>
        <source>Move 2</source>
        <translation>Přesun 2</translation>
    </message>
</context>
<context>
    <name>Player</name>
    <message>
        <location filename="../src/player.cpp" line="91"/>
        <source>Source</source>
        <translation>Zdroj</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="92"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="155"/>
        <source>Adjust the audio volume</source>
        <translation>Upravit hlasitost zvuku</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="177"/>
        <source>Silence the audio</source>
        <translation>Umlčet zvuk</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="196"/>
        <source>Current position</source>
        <translation>Nynější poloha</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="202"/>
        <source>Total Duration</source>
        <translation>Celková doba trvání</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="380"/>
        <source>In Point</source>
        <translation>Počáteční bod</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="388"/>
        <source>Selected Duration</source>
        <translation>Vybraná doba trvání</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="242"/>
        <source>Zoom Fit</source>
        <translation>Přizpůsobit velikost</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="191"/>
        <source>Current/Total Times</source>
        <translation>Čas nynější/celkový</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="210"/>
        <source>Player Controls</source>
        <translation>Ovládání přehrávače</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="221"/>
        <location filename="../src/player.cpp" line="375"/>
        <source>Player Options</source>
        <translation>Volby pro přehrávač</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="248"/>
        <source>Zoom 10%</source>
        <translation>Zvětšení 10 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="254"/>
        <source>Zoom 25%</source>
        <translation>Zvětšení 25 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="260"/>
        <source>Zoom 50%</source>
        <translation>Zvětšení 50 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="267"/>
        <source>Zoom 100%</source>
        <translation>Zvětšení 100 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="273"/>
        <source>Zoom 200%</source>
        <translation>Zvětšení 200 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="311"/>
        <source>Toggle zoom</source>
        <translation>Přepnout zvětšení</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="318"/>
        <source>2x2 Grid</source>
        <translation>Mřížka 2 x 2</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="323"/>
        <source>3x3 Grid</source>
        <translation>Mřížka 3 x 3</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="327"/>
        <source>4x4 Grid</source>
        <translation>Mřížka 4 x 4</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="331"/>
        <source>16x16 Grid</source>
        <translation>Mřížka 16 x 16</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="339"/>
        <source>10 Pixel Grid</source>
        <translation>Mřížka 10 obrazových bodů</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="462"/>
        <source>Play/Pause</source>
        <translation>Přehrát/Pozastavit</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="466"/>
        <source>Toggle play or pause</source>
        <translation>Přepnout přehrávání nebo pozastavení</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="477"/>
        <source>Loop</source>
        <translation>Smyčka</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="483"/>
        <source>Toggle player looping</source>
        <translation>Zapnout/Vypnout přehrávání ve smyčce</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="487"/>
        <source>Loop All</source>
        <translation>Přehrávat ve smyčce vše</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="488"/>
        <source>Loop back to the beginning when the end is reached</source>
        <translation>Po dosažení konce zpět na začátek a přehrávat</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="495"/>
        <source>Loop Marker</source>
        <translation>Značka přehrávání ve smyčce</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="496"/>
        <source>Loop around the marker under the cursor in the timeline</source>
        <translation>Přehrávat ve smyčce kolem značky pod ukazatelem na časové ose</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="507"/>
        <source>Loop Selection</source>
        <translation>Přehrávat ve smyčce výběr</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="508"/>
        <source>Loop around the selected clips</source>
        <translation>Přehrávat ve smyčce kolem vybraných záběrů</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="516"/>
        <source>Nothing selected</source>
        <translation>Nic není vybráno</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="521"/>
        <source>Loop Around Cursor</source>
        <translation>Přehrávat ve smyčce kolem ukazatele</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="522"/>
        <source>Loop around the current cursor position</source>
        <translation>Přehrávat ve smyčce kolem nynější polohy ukazatele</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="551"/>
        <source>Skip to the next point</source>
        <translation>Skočit na další bod</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="574"/>
        <source>Skip to the previous point</source>
        <translation>Skočit na předchozí bod</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="599"/>
        <source>Play quickly backwards</source>
        <translation>Přehrávat rychle dozadu</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="609"/>
        <source>Play quickly forwards</source>
        <translation>Přehrávat rychle dopředu</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="613"/>
        <source>Seek Start</source>
        <translation>Prohledat po začátek</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="618"/>
        <source>Seek End</source>
        <translation>Prohledat po konec</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="628"/>
        <source>Next Frame</source>
        <translation>Další snímek</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="634"/>
        <source>Previous Frame</source>
        <translation>Předchozí snímek</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="640"/>
        <source>Forward One Second</source>
        <translation>Dopředu o jednu sekundu</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="645"/>
        <source>Backward One Second</source>
        <translation>Dozadu o jednu sekundu</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="650"/>
        <source>Forward Two Seconds</source>
        <translation>Dopředu o dvě sekundy</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="655"/>
        <source>Backward Two Seconds</source>
        <translation>Dozadu o dvě sekundy</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="660"/>
        <source>Forward Five Seconds</source>
        <translation>Dopředu o pět sekund</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="665"/>
        <source>Backward Five Seconds</source>
        <translation>Dozadu o pět sekund</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="670"/>
        <source>Forward Ten Seconds</source>
        <translation>Dopředu o deset sekund</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="675"/>
        <source>Backward Ten Seconds</source>
        <translation>Dozadu o deset sekund</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="680"/>
        <source>Forward Jump</source>
        <translation>Skok dopředu</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="687"/>
        <source>Backward Jump</source>
        <translation>Skok dozadu</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="694"/>
        <source>Set Jump Time</source>
        <translation>Nastavit čas skoku</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="705"/>
        <source>Trim Clip In</source>
        <translation>Oříznout začátek záběru</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="718"/>
        <source>Trim Clip Out</source>
        <translation>Oříznout konec záběru</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="731"/>
        <source>Set Time Position</source>
        <translation>Nastavit časovou polohu</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="761"/>
        <source>Pause playback</source>
        <translation>Pozastavit přehrávání</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="763"/>
        <location filename="../src/player.cpp" line="768"/>
        <location filename="../src/player.cpp" line="773"/>
        <source>Player</source>
        <translation>Přehrávač</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="765"/>
        <source>Focus Player</source>
        <translation>Zaměřit přehrávač</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="770"/>
        <source>Toggle Filter Overlay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="923"/>
        <source>Not Seekable</source>
        <translation>Neprohledávatelný</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="335"/>
        <source>20 Pixel Grid</source>
        <translation>Mřížka 20 obrazových bodů</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="279"/>
        <source>Zoom 300%</source>
        <translation>Zvětšení 300 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="285"/>
        <source>Zoom 400%</source>
        <translation>Zvětšení 400 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="291"/>
        <source>Zoom 500%</source>
        <translation>Zvětšení 500 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="297"/>
        <source>Zoom 750%</source>
        <translation>Zvětšení 750 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="303"/>
        <source>Zoom 1000%</source>
        <translation>Zvětšení 1000 %</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="343"/>
        <source>80/90% Safe Areas</source>
        <translation>80/90% bezpečné oblasti</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="347"/>
        <source>EBU R95 Safe Areas</source>
        <translation>EBU R95 bezpečné oblasti</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="352"/>
        <source>Snapping</source>
        <translation>Přichytávání</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="362"/>
        <source>Toggle grid display on the player</source>
        <translation>Přepnout zobrazení mřížky na přehrávači</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="738"/>
        <source>Switch Source/Project</source>
        <translation>Přepnout zdroj/projekt</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="758"/>
        <source>Pause</source>
        <translation>Pozastavit</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="545"/>
        <source>Skip Next</source>
        <translation>Skočit na další</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="568"/>
        <source>Skip Previous</source>
        <translation>Skočit na předchozí</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="593"/>
        <source>Rewind</source>
        <translation>Přetočit</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="603"/>
        <source>Fast Forward</source>
        <translation>Rychle vpřed</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="369"/>
        <source>Volume</source>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="370"/>
        <source>Show the volume control</source>
        <translation>Ukázat ovládání hlasitosti</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1278"/>
        <source>Proxy and preview scaling are ON at %1p</source>
        <translation>Proxy a náhled změny velikosti jsou ZAPNUTY v %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1283"/>
        <source>Proxy is ON at %1p</source>
        <translation>Proxy je ZAPNUTA v %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1288"/>
        <source>Preview scaling is ON at %1p</source>
        <translation>Náhled změny velikosti je ZAPNUT v %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1403"/>
        <source>Unmute</source>
        <translation>Zrušit ztlumení</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1372"/>
        <location filename="../src/player.cpp" line="1412"/>
        <source>Mute</source>
        <translation>Ztlumit</translation>
    </message>
</context>
<context>
    <name>PlaylistDock</name>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="18"/>
        <location filename="../src/docks/playlistdock.cpp" line="382"/>
        <source>Playlist</source>
        <translation>Seznam záběrů</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="59"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; a playlist item to open it in the player.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can freely preview clips without necessarily adding them to the playlist or closing it.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To trim or adjust a playlist item &lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; to open it, make the changes, and click the &lt;span style=&quot; font-weight:600;&quot;&gt;Update&lt;/span&gt; icon.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drag-n-drop&lt;/span&gt; to rearrange the items.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Dvakrát klepněte&lt;/span&gt; na položku v seznamu záběrů pro její otevření v přehrávači.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Můžete se volně dívat na záznamy, aniž byste je nutně přidali do seznamu záběrů nebo je zavřeli.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Pro zkrácení nebo upravení položky ze seznamu záběrů na ni pro její otevření &lt;span style=&quot; font-weight:600;&quot;&gt;dvakrát klepněte&lt;/span&gt;, udělejte změny, a pak klepněte na &lt;span style=&quot; font-weight:600;&quot;&gt;Obnovit&lt;/span&gt;.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Táhněte a pusťte&lt;/span&gt; pro přeuspořádání položek.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="127"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Double-click a playlist item to open it in the player.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dvakrát klepněte na položku v seznamu záběrů pro její otevření v přehrávači.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="601"/>
        <source>Add the Source to the playlist</source>
        <translation>Přidat zdroj do seznamu záběrů</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="612"/>
        <source>Remove cut</source>
        <translation>Odstranit střih</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="630"/>
        <source>Update</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="642"/>
        <source>View as tiles</source>
        <translation>Zobrazit jako dlaždice</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="655"/>
        <source>View as icons</source>
        <translation>Zobrazit jako obrázky</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="668"/>
        <source>View as details</source>
        <translation>Zobrazit jako podrobnosti</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="607"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="720"/>
        <source>Set Creation Time...</source>
        <translation>Nastavit čas vytvoření...</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="706"/>
        <location filename="../src/docks/playlistdock.cpp" line="707"/>
        <source>Insert</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="451"/>
        <source>Playlist Menu</source>
        <translation>Nabídka pro seznam záběrů</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="599"/>
        <source>Append</source>
        <translation>Připojit</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="681"/>
        <source>Open the clip in the Source player</source>
        <translation>Otevřít záběr v přehrávači zdroje</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="691"/>
        <source>Go to the start of this clip in the Project player</source>
        <translation>Jít na začátek tohoto záběrů v přehrávači projektu</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="728"/>
        <source>Remove All</source>
        <translation>Odstranit vše</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="729"/>
        <source>Remove all items from the playlist</source>
        <translation>Odstranit všechny položky ze seznamu záběrů</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="805"/>
        <source>Hidden</source>
        <translation>Skryto</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="817"/>
        <source>In and Out - Left/Right</source>
        <translation>Začátek a konec záběru - vlevo/vpravo</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="833"/>
        <source>In and Out - Top/Bottom</source>
        <translation>Začátek a konec záběru - nahoře/dole</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="850"/>
        <source>In Only - Small</source>
        <translation>Pouze začátek záběru - malý</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="866"/>
        <source>In Only - Large</source>
        <translation>Pouze začátek záběru - velký</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="772"/>
        <source>Add Selected to Timeline</source>
        <translation>Přidat vybrané do časové osy</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="779"/>
        <source>Add Selected to Slideshow</source>
        <translation>Přidat vybrané do promítání</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="883"/>
        <source>Play After Open</source>
        <translation>Přehrát po otevření</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="734"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="740"/>
        <source>Select None</source>
        <translation>Nevybrat nic</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="712"/>
        <source>Update Thumbnails</source>
        <translation>Obnovit náhledy</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="786"/>
        <source>Sort By Name</source>
        <translation>Řadit podle názvu</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="794"/>
        <source>Sort By Date</source>
        <translation>Řadit podle data</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="667"/>
        <source>Details</source>
        <translation>Podrobnosti</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="412"/>
        <source>Select</source>
        <translation>Vybrat</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="429"/>
        <location filename="../src/docks/playlistdock.cpp" line="1134"/>
        <source>Bins</source>
        <translation>Koše</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="436"/>
        <source>Columns</source>
        <translation>Sloupce</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="446"/>
        <source>Playlist Controls</source>
        <translation>Ovládání seznamu skladeb</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="480"/>
        <location filename="../src/docks/playlistdock.cpp" line="484"/>
        <source>Playlist Filters</source>
        <translation>Filtry seznamu skladeb</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="508"/>
        <source>Only show files whose name, path, or comment contains some text</source>
        <translation>Zobrazit pouze soubory, jejichž název, cesta nebo poznámka obsahuje nějaký text</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="509"/>
        <source>search</source>
        <translation>Hledání</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="623"/>
        <source>Add files to playlist</source>
        <translation>Přidat soubory do seznamu skladeb</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="641"/>
        <source>Tiles</source>
        <translation>Dlaždice</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="654"/>
        <source>Icons</source>
        <translation>Obrázky</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="680"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="690"/>
        <source>GoTo</source>
        <translation>Jít na</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="696"/>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="697"/>
        <source>Open a copy of the clip in the Source player</source>
        <translation>Otevřít kopii záběru v přehrávači zdroje</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="748"/>
        <source>Move Up</source>
        <translation>Posunout nahoru</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="760"/>
        <source>Move Down</source>
        <translation>Posunout dolů</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="891"/>
        <source>Open Previous</source>
        <translation>Otevřít předchozí</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="904"/>
        <source>Open Next</source>
        <translation>Otevřít další</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="917"/>
        <source>Select Clip 1</source>
        <translation>Vybrat záběr 1</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="929"/>
        <source>Select Clip 2</source>
        <translation>Vybrat záběr 2</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="941"/>
        <source>Select Clip 3</source>
        <translation>Vybrat záběr 3</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="953"/>
        <source>Select Clip 4</source>
        <translation>Vybrat záběr 4</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="965"/>
        <source>Select Clip 5</source>
        <translation>Vybrat záběr 5</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="977"/>
        <source>Select Clip 6</source>
        <translation>Vybrat záběr 6</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="989"/>
        <source>Select Clip 7</source>
        <translation>Vybrat záběr 7</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1001"/>
        <source>Select Clip 8</source>
        <translation>Vybrat záběr 8</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1013"/>
        <source>Select Clip 9</source>
        <translation>Vybrat záběr 9</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1025"/>
        <source>Thumbnails</source>
        <translation>Náhledy</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1034"/>
        <source>Clip</source>
        <translation>Záběr</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1043"/>
        <source>In</source>
        <translation>Začátek záběru</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1052"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1061"/>
        <source>Start</source>
        <translation>Začátek</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1070"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1079"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1088"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1089"/>
        <source>Show or hide video files</source>
        <translation>Ukázat nebo skrýt obrazové soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1094"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1095"/>
        <source>Show or hide audio files</source>
        <translation>Ukázat nebo skrýt zvukové soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1100"/>
        <source>Image</source>
        <translation>Obrázek</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1101"/>
        <source>Show or hide image files</source>
        <translation>Ukázat nebo skrýt obrázkové soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1106"/>
        <source>Other</source>
        <translation>Jiné</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1107"/>
        <source>Show or hide other kinds of files</source>
        <translation>Ukázat nebo skrýt ostatní druhy souborů</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1112"/>
        <location filename="../src/docks/playlistdock.cpp" line="1113"/>
        <source>New Bin</source>
        <translation>Nový koš</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1124"/>
        <location filename="../src/docks/playlistdock.cpp" line="1164"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1135"/>
        <source>Show or hide the list of bins</source>
        <translation>Ukázat nebo skrýt seznam košů</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1144"/>
        <location filename="../src/docks/playlistdock.cpp" line="1145"/>
        <source>Remove Bin</source>
        <translation>Odstranit koš</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1156"/>
        <location filename="../src/docks/playlistdock.cpp" line="1157"/>
        <source>Rename Bin</source>
        <translation>Přejmenovat koš</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1178"/>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="1213"/>
        <source>Replace %n playlist items</source>
        <translation>
            <numerusform>Nahradit %1 položku seznamu záběrů</numerusform>
            <numerusform>Nahradit %1 položky seznamu záběrů</numerusform>
            <numerusform>Nahradit %1 položek seznamu záběrů</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="2138"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n položka</numerusform>
            <numerusform>%n položky</numerusform>
            <numerusform>%n položek</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="433"/>
        <source>Sort</source>
        <translation>Řadit</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1536"/>
        <location filename="../src/docks/playlistdock.cpp" line="1768"/>
        <source>You cannot insert a playlist into a playlist!</source>
        <translation>Nemůžete vložit seznam záběrů do seznamu záběrů!</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="1553"/>
        <source>Remove %n playlist items</source>
        <translation>
            <numerusform>Odstranit %n položku seznamu záběrů</numerusform>
            <numerusform>Odstranit %n položky seznamu záběrů</numerusform>
            <numerusform>Odstranit %n položek seznamu záběrů</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="622"/>
        <location filename="../src/docks/playlistdock.cpp" line="1312"/>
        <source>Add Files</source>
        <translation>Přidat soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1266"/>
        <source>Appending</source>
        <translation>Připojuje se</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1322"/>
        <location filename="../src/docks/playlistdock.cpp" line="1331"/>
        <source>Failed to open </source>
        <translation>Nepodařilo se otevřít</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1395"/>
        <source>Dropped Files</source>
        <translation>Zahozené soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1857"/>
        <source>Generating</source>
        <translation>Vytváří se</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="2076"/>
        <source>Open File</source>
        <translation>Otevřít soubor</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="2078"/>
        <source>All Files (*);;MLT XML (*.mlt)</source>
        <translation>Všechny soubory (*);;MLT XML (*.mlt)</translation>
    </message>
</context>
<context>
    <name>PlaylistIconView</name>
    <message>
        <location filename="../src/widgets/playlisticonview.cpp" line="175"/>
        <source>P</source>
        <comment>The first letter or symbol of &quot;proxy&quot;</comment>
        <translation>P</translation>
    </message>
</context>
<context>
    <name>PlaylistModel</name>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="269"/>
        <source>(PROXY)</source>
        <translation>(PROXY)</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="409"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="411"/>
        <source>Image</source>
        <translation>Obrázek</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="413"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="415"/>
        <source>Other</source>
        <translation>Jiné</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="494"/>
        <source>#</source>
        <translation>Číslo</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="496"/>
        <source>Thumbnails</source>
        <translation>Náhledy</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="498"/>
        <source>Clip</source>
        <translation>Záběr</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="500"/>
        <source>In</source>
        <translation>Začátek záběru</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="502"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="504"/>
        <source>Start</source>
        <translation>Začátek</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="506"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="508"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="510"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlaylistProxyModel</name>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>All</source>
        <translation>Vše</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Duplicates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Not In Timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Not In a Bin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preset</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="43"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="73"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="87"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="111"/>
        <source>Save Preset</source>
        <translation>Uložit přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="121"/>
        <source>Name:</source>
        <translation>Název:</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="147"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="185"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="152"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="197"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="165"/>
        <source>Delete Preset</source>
        <translation>Smazat přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="175"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Opravdu chcete smazat %1?</translation>
    </message>
</context>
<context>
    <name>ProducerPreviewWidget</name>
    <message>
        <location filename="../src/widgets/producerpreviewwidget.cpp" line="168"/>
        <source>Play</source>
        <translation>Přehrát</translation>
    </message>
</context>
<context>
    <name>PulseAudioWidget</name>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="26"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
</context>
<context>
    <name>QImageJob</name>
    <message>
        <location filename="../src/jobs/qimagejob.cpp" line="34"/>
        <source>Make proxy for %1</source>
        <translation>Udělat proxy pro %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="38"/>
        <source>Append playlist item %1</source>
        <translation>Připojit položku seznamu záběrů %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="65"/>
        <source>Insert playist item %1</source>
        <translation>Vložit položku seznamu skladeb %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="92"/>
        <source>Update playlist item %1</source>
        <translation>Obnovit položku seznamu záběrů %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="135"/>
        <source>Remove playlist item %1</source>
        <translation>Odstranit položku seznamu záběrů %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="158"/>
        <source>Clear playlist</source>
        <translation>Vyprázdnit seznam záběrů</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="203"/>
        <source>Move item from %1 to %2</source>
        <translation>Přesunout položku z %1 do %2</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="226"/>
        <source>Sort playlist by %1</source>
        <translation>Řadit seznam záběrů podle %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="273"/>
        <source>Trim playlist item %1 in</source>
        <translation>Zkrátit začátek položky seznamu záběrů %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="311"/>
        <source>Trim playlist item %1 out</source>
        <translation>Zkrátit konec položky seznamu záběrů %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="350"/>
        <source>Replace playlist item %1</source>
        <translation>Nahradit položku seznamu záběrů %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="381"/>
        <source>Add new bin: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/playlistcommands.cpp" line="427"/>
        <source>Move %n item(s) to bin: %1</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="462"/>
        <source>Remove bin: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="464"/>
        <source>Rename bin: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="97"/>
        <source>Append to track</source>
        <translation>Připojit ke stopě</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="103"/>
        <source>Append to Timeline</source>
        <translation>Připojit k časové ose</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="105"/>
        <source>Preparing</source>
        <translation>Připravuje se</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="120"/>
        <source>Appending</source>
        <translation>Připojuje se</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="136"/>
        <source>Finishing</source>
        <translation>Dokončuje se</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="166"/>
        <source>Insert into track</source>
        <translation>Vložit do stopy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="185"/>
        <location filename="../src/commands/timelinecommands.cpp" line="251"/>
        <source>Add Files</source>
        <translation>Přidat soubory</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="238"/>
        <source>Overwrite onto track</source>
        <translation>Přepsat na stopě</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="287"/>
        <source>Lift from track</source>
        <translation>Vyzvednout ze stopy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="321"/>
        <source>Remove from track</source>
        <translation> Odstranit ze stopy</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="402"/>
        <source>Group %n clips</source>
        <translation>
            <numerusform>Seskupit %n záběr</numerusform>
            <numerusform>Seskupit %n záběry</numerusform>
            <numerusform>Seskupit %n záběrů</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="455"/>
        <source>Ungroup %n clips</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="496"/>
        <source>Change track name</source>
        <translation>Změnit název stopy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="521"/>
        <source>Merge adjacent clips</source>
        <translation>Sloučit sousední záběry</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="544"/>
        <source>Toggle track mute</source>
        <translation>Přepnout ztlumení stopy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="565"/>
        <source>Toggle track hidden</source>
        <translation>Přepnout skrytí stopy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="590"/>
        <source>Change track compositing</source>
        <translation>Změnit vrstvení stopy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="615"/>
        <source>Lock track</source>
        <translation>Zamknout stopu</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="676"/>
        <source>Move %n timeline clips</source>
        <translation>
            <numerusform>Přesunout %n záběr časové osy</numerusform>
            <numerusform>Přesunout %n záběry časové osy</numerusform>
            <numerusform>Přesunout %n záběrů časové osy</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="678"/>
        <source>Move timeline clip</source>
        <translation>Přesunout záběr časové osy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="903"/>
        <source>Trim clip in point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1013"/>
        <source>Trim clip out point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1118"/>
        <source>Split clip</source>
        <translation>Rozdělit záběr</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1120"/>
        <source>Split clips</source>
        <translation>Rozdělit záběry</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1157"/>
        <source>Adjust fade in</source>
        <translation>Nastavit postupné zesílení</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1192"/>
        <source>Adjust fade out</source>
        <translation>Nastavit postupné zeslabení</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1238"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1429"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1620"/>
        <source>Add transition</source>
        <translation>Přidat přechod</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1321"/>
        <source>Trim transition in point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1373"/>
        <source>Trim transition out point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1485"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1552"/>
        <source>Remove transition</source>
        <translation>Odstranit přechod</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1664"/>
        <source>Add video track</source>
        <translation>Přidat obrazovou stopu</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1666"/>
        <source>Add audio track</source>
        <translation>Přidat zvukovou stopu</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1710"/>
        <source>Insert audio track</source>
        <translation>Vložit do zvukové stopy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1712"/>
        <source>Insert video track</source>
        <translation>Vložit do obrazové stopy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1749"/>
        <source>Remove audio track</source>
        <translation> Odstranit zvukovou stopu</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1751"/>
        <source>Remove video track</source>
        <translation> Odstranit obrazovou stopu</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1821"/>
        <source>Move track down</source>
        <translation>Posunout stopu dolů</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1823"/>
        <source>Move track up</source>
        <translation>Posunout stopu nahoru</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1847"/>
        <source>Change track blend mode</source>
        <translation>Změnit režim smíchání pro stopu</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1889"/>
        <source>Change clip properties</source>
        <translation>Změnit vlastnosti záběru</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1958"/>
        <source>Detach Audio</source>
        <translation>Odpojit zvuk</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2109"/>
        <source>Replace timeline clip</source>
        <translation>Nahradit záběr časové osy</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2138"/>
        <source>Align clips to reference track</source>
        <translation>Zarovnat záběry se vzorovou stopu</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2219"/>
        <source>Apply copied filters</source>
        <translation>Použít zkopírované filtry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4084"/>
        <source>You cannot add a project to itself!</source>
        <translation>Nemůžete přidat projekt do něj samotného</translation>
    </message>
    <message>
        <location filename="../src/mltxmlchecker.cpp" line="118"/>
        <source>The file is not a MLT XML file.</source>
        <translation>Soubor není souborem MLT XML.</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="95"/>
        <location filename="../src/util.cpp" line="142"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1050"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1140"/>
        <source>Unable to write file %1
Perhaps you do not have permission.
Try again with a different folder.</source>
        <translation>Nelze zapsat soubor %1
Možná nemáte oprávnění.
Zkuste to znovu s jinou složkou.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="159"/>
        <source>Transition</source>
        <translation>Přechod</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="161"/>
        <source>Track: %1</source>
        <translation>Stopa: %1</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="163"/>
        <source>Output</source>
        <translation>Výstup</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="326"/>
        <source>The value you entered is very similar to the common,
more standard %1 = %2/1001.

Do you want to use %1 = %2/1001 instead?</source>
        <translation>Zadaná hodnota je velice podobná běžné,
více standardní %1 = %2/1001.

Chcete namísto ní použít %1 = %2/1001?</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="717"/>
        <source>The drive you chose only has %1 MiB of free space.
Do you still want to continue?</source>
        <translation>Na vámi zvoleném disku je jen %1 MiB volného místa.
Stále ještě chcete pokračovat?</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="725"/>
        <source>Do not show this anymore.</source>
        <comment>Export free disk space warning dialog</comment>
        <translation>Toto už vícekrát neukazovat.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="761"/>
        <source>unknown (%1)</source>
        <translation>Neznámý (%1)</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="764"/>
        <source>NA</source>
        <translation>nedostupný</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="815"/>
        <source>This file uses color transfer characteristics %1, which may result in incorrect colors or brightness in Shotcut.</source>
        <translation>Tento soubor používá vlastnosti přenosu barev %1, což může mít v Shotcutu za následek nesprávné barvy nebo jas.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="820"/>
        <source>This file is variable frame rate, which is not reliable for editing.</source>
        <translation>Tento soubor má proměnlivou snímkovou rychlost, což není pro úpravy spolehlivé.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="824"/>
        <source>This file does not support seeking and cannot be used for editing.</source>
        <translation>Tento soubor nepodporuje prohledávání a nelze jej použít pro úpravy.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="827"/>
        <source>This file format (HDV) is not reliable for editing.</source>
        <translation>Tento souborový formát (HDV) není pro úpravy spolehlivý.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="843"/>
        <source> Do you want to convert it to an edit-friendly format?

If yes, choose a format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, it automatically replaces clips, or you can double-click the job to open it.
</source>
        <translation>Chcete jej převést na formát přátelský pro úpravy?

Pokud ano, vyberte formát níže, a potom klepněte na OK pro výběr názvu souboru. Po zvolení názvu souboru je vytvořena úloha. Když je hotova, záběry jsou automaticky nahrazeny, nebo klepněte dvakrát na úlohu pro její otevření.
</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="30"/>
        <location filename="../src/widgets/textproducerwidget.cpp" line="29"/>
        <source>transparent</source>
        <comment>Open Other &gt; Color</comment>
        <translation>Průhledný</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3114"/>
        <source>Drop Files</source>
        <translation>Zahodit soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3121"/>
        <source>Failed to open </source>
        <translation>Nepodařilo se otevřít</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3137"/>
        <source>Not adding non-seekable file: </source>
        <translation>Nepřidávat soubor, který nelze prohledat:</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1250"/>
        <source>Generating Playlist for Bin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1855"/>
        <source>Generate Slideshow</source>
        <translation>Vytvořit promítání</translation>
    </message>
    <message>
        <location filename="../src/proxymanager.cpp" line="366"/>
        <source>Make proxy for %1</source>
        <translation>Udělat proxy pro %1</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="67"/>
        <source>Converting Thumbnails</source>
        <translation>Převádí se náhledy</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="86"/>
        <source>Please wait for this one-time update to the thumbnail cache...</source>
        <translation>Počkejte, prosím, na tuto jednorázovou aktualizaci vyrovnávací paměti náhledů...</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="30"/>
        <source>Delete marker: %1</source>
        <translation>Smazat značku: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="49"/>
        <source>Add marker: %1</source>
        <translation>Přidat značku: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="73"/>
        <source>Move marker: %1</source>
        <translation>Posunout značku: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="75"/>
        <source>Edit marker: %1</source>
        <translation>Upravit značku: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="115"/>
        <source>Clear markers</source>
        <translation>Vyprázdnit značky</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="43"/>
        <source>transparent</source>
        <comment>Open Other &gt; Animation</comment>
        <translation>Průhledný</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="637"/>
        <source>Edit With Glaxnimate</source>
        <translation>Upravit v Glaxnimate</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="43"/>
        <source>Playlist Clip: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="46"/>
        <source>Track: %1, Clip: %2 (transition)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="50"/>
        <source>Track: %1, Clip: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="289"/>
        <source>%1x%2</source>
        <translation>%1x%2</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="107"/>
        <source>Add %1 filter</source>
        <translation>Přidat filtr %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="109"/>
        <source>Add %1 filter set</source>
        <translation>Přidat sadu filtrů %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="173"/>
        <source>Remove %1 filter</source>
        <translation>Odebrat filtr %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="207"/>
        <source>Move %1 filter</source>
        <translation>Přesunout filtr %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="247"/>
        <source>Disable %1 filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="249"/>
        <source>Enable %1 filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="305"/>
        <source>Paste filters</source>
        <translation>Vložit filtry</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="359"/>
        <source>Change %1 filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="361"/>
        <source>Change %1 filter: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/audiolevelstask.cpp" line="183"/>
        <source>generating audio waveforms for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/audiolevelstask.cpp" line="266"/>
        <source>Done</source>
        <translation>Hotovo</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="188"/>
        <source>add keyframe</source>
        <translation>přidat klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="203"/>
        <source>remove keyframe</source>
        <translation>odebrat klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="220"/>
        <source>modify keyframe</source>
        <translation>změnit klíčový snímek</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="35"/>
        <source>Add subtitle track: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="55"/>
        <source>Remove subtitle track: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="83"/>
        <source>Edit subtitle track: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="106"/>
        <source>Add subtitle</source>
        <translation>Přidat titulek</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="108"/>
        <source>Add %n subtitles</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="162"/>
        <source>Remove %n subtitles</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="301"/>
        <source>Move %n subtitles</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="160"/>
        <source>Remove subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="190"/>
        <source>Edit subtitle text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="225"/>
        <source>Change subtitle start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="259"/>
        <source>Change subtitle end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="299"/>
        <source>Move subtitle</source>
        <translation>Přesunout titulek</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/subtitlesdock.cpp" line="504"/>
        <source>Imported %1 subtitle item(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="606"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="621"/>
        <source>Importing subtitles...</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/subtitlesdock.cpp" line="642"/>
        <source>Imported %n subtitle item(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="494"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="637"/>
        <source>No subtitles found to import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="311"/>
        <location filename="../src/models/subtitlesmodel.cpp" line="326"/>
        <source>Import %1 subtitle items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="366"/>
        <source>Append subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1335"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1059"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1149"/>
        <source>A job already exists for %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QmlApplication</name>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="133"/>
        <source>Select a filter to copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="212"/>
        <source>&lt;p&gt;Do you really want to add filters to &lt;b&gt;Output&lt;/b&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timeline &gt; Output&lt;/b&gt; is currently selected. Adding filters to &lt;b&gt;Output&lt;/b&gt; affects ALL clips in the timeline including new ones that will be added.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Opravdu chcete přidat filtry do &lt;b&gt;Výstup&lt;/b&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Časová osa &gt; Výstup&lt;/b&gt; je nyní vybrán. Přidání filtrů do &lt;b&gt;Výstup&lt;/b&gt; ovlivní VŠECHNY záběry do časové osy včetně nových, které budou přidány.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="222"/>
        <source>Do not show this anymore.</source>
        <comment>confirm output filters dialog</comment>
        <translation>Toto už vícekrát neukazovat.</translation>
    </message>
</context>
<context>
    <name>QmlEditMenu</name>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="32"/>
        <source>Undo</source>
        <translation>Zpět</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="38"/>
        <source>Redo</source>
        <translation>Znovu</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="47"/>
        <source>Cut</source>
        <translation>Vyjmout</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="53"/>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="58"/>
        <source>Paste</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="64"/>
        <source>Paste Text Only</source>
        <translation>Vložit pouze text</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="70"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="76"/>
        <source>Clear</source>
        <translation>Vyprázdnit</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="84"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
</context>
<context>
    <name>QmlFilter</name>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="394"/>
        <source>(defaults)</source>
        <translation>(výchozí)</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="518"/>
        <source>Analyze %1</source>
        <translation>Vyhodnotit %1</translation>
    </message>
</context>
<context>
    <name>QmlMarkerMenu</name>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="62"/>
        <source>Edit...</source>
        <translation>Upravit...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="67"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="72"/>
        <source>Choose Color...</source>
        <translation>Vybrat barvu...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="86"/>
        <source>Choose Recent Color</source>
        <translation>Vybrat nedávnou barvu</translation>
    </message>
</context>
<context>
    <name>QmlRichText</name>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="141"/>
        <source>Cannot save: </source>
        <translation>Nelze uložit:</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="172"/>
        <source>Row</source>
        <translation>Řádek</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="174"/>
        <source>Column</source>
        <translation>Sloupec</translation>
    </message>
</context>
<context>
    <name>QmlRichTextMenu</name>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="30"/>
        <source>File</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="32"/>
        <source>Open...</source>
        <translation>Otevřít...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="36"/>
        <source>Save As...</source>
        <translation>Uložit jako...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="40"/>
        <source>Edit</source>
        <translation>Upravit</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="42"/>
        <source>Undo</source>
        <translation>Zpět</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="47"/>
        <source>Redo</source>
        <translation>Znovu</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="54"/>
        <source>Cut</source>
        <translation>Vyjmout</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="59"/>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="64"/>
        <source>Paste</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="69"/>
        <source>Paste Text Only</source>
        <translation>Vložit pouze text</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="74"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="79"/>
        <source>Insert Table</source>
        <translation>Vložit tabulku</translation>
    </message>
</context>
<context>
    <name>RecentDock</name>
    <message>
        <location filename="../src/docks/recentdock.ui" line="24"/>
        <source>Recent</source>
        <translation>Naposledy otevřené</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="46"/>
        <source>Show only files with name matching text</source>
        <translation>Ukázat jen soubory s názvem odpovídajícím textu</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="49"/>
        <source>search</source>
        <translation>Hledání</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="76"/>
        <location filename="../src/docks/recentdock.ui" line="79"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
</context>
<context>
    <name>ResourceDialog</name>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="35"/>
        <source>Resources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="47"/>
        <source>Convert Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="98"/>
        <source>No resources to convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="103"/>
        <source>Choose an edit-friendly format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, double-click the job to open it.
</source>
        <translation>Vyberte formát přátelský pro úpravy, a potom klepněte na OK pro výběr názvu souboru. Po zvolení názvu souboru je vytvořena úloha. Když je hotova, dvakrát klepněte na úlohu pro její otevření.
</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="108"/>
        <source>Convert...</source>
        <translation>Převést...</translation>
    </message>
</context>
<context>
    <name>ResourceModel</name>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="266"/>
        <source>%1MB</source>
        <translation>%1MB</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="281"/>
        <source>%1 %2x%3 %4fps</source>
        <translation>%1 %2x%3 %4fps</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="392"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="394"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="396"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="398"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
</context>
<context>
    <name>SaveDefaultButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SaveDefaultButton.qml" line="27"/>
        <source>Set as default</source>
        <translation>Nastavit jako výchozí</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../src/dialogs/saveimagedialog.cpp" line="47"/>
        <source>PNG (*.png);;BMP (*.bmp);;JPEG (*.jpg *.jpeg);;PPM (*.ppm);;TIFF (*.tif *.tiff);;WebP (*.webp);;All Files (*)</source>
        <translation>PNG (*.png);;BMP (*.bmp);;JPEG (*.jpg *.jpeg);;PPM (*.ppm);;TIFF (*.tif *.tiff);;WebP (*.webp);;Všechny soubory (*)</translation>
    </message>
</context>
<context>
    <name>ScopeController</name>
    <message>
        <location filename="../src/controllers/scopecontroller.cpp" line="41"/>
        <source>Scopes</source>
        <translation>Pohledy</translation>
    </message>
</context>
<context>
    <name>ServicePresetWidget</name>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="25"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="45"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="52"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="80"/>
        <source>(defaults)</source>
        <translation>(výchozí)</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="87"/>
        <source>Save Preset</source>
        <translation>Uložit přednastavení</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="88"/>
        <source>Name:</source>
        <translation>Název:</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="173"/>
        <source>Delete Preset</source>
        <translation>Smazat přednastavení</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="174"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Opravdu chcete smazat %1?</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="58"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="59"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="66"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="67"/>
        <source>Set to default</source>
        <translation>Nastavit na výchozí</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="76"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="77"/>
        <source>Clear shortcut</source>
        <translation>Smazat klávesovou zkratku</translation>
    </message>
</context>
<context>
    <name>ShotcutActions</name>
    <message>
        <location filename="../src/actions.cpp" line="52"/>
        <source>Other</source>
        <translation>Jiné</translation>
    </message>
</context>
<context>
    <name>ShotcutSettings</name>
    <message>
        <location filename="../src/settings.cpp" line="104"/>
        <source>Old (before v23) Layout</source>
        <translation>Staré rozvržení (před verzí 23)</translation>
    </message>
</context>
<context>
    <name>SimplePropertyUI</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SimplePropertyUI.qml" line="15"/>
        <source>Custom Properties</source>
        <translation>Uživatelské vlastnosti</translation>
    </message>
</context>
<context>
    <name>SizePositionUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="338"/>
        <source>Bottom Left</source>
        <translation>Dole vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="342"/>
        <source>Bottom Right</source>
        <translation>Dole vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="346"/>
        <source>Top Left</source>
        <translation>Nahoře vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="350"/>
        <source>Top Right</source>
        <translation>Nahoře vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="356"/>
        <source>Slide In From Left</source>
        <translation>Skouznout zleva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="358"/>
        <source>Slide In From Right</source>
        <translation>Skouznout zprava</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="360"/>
        <source>Slide In From Top</source>
        <translation>Skouznout shora</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="362"/>
        <source>Slide In From Bottom</source>
        <translation>Skouznout zdola</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="366"/>
        <source>Slide Out Left</source>
        <translation>Vykouznout doleva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="368"/>
        <source>Slide Out Right</source>
        <translation>Vykouznout doprava</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="370"/>
        <source>Slide Out Top</source>
        <translation>Vykouznout nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="372"/>
        <source>Slide Out Bottom</source>
        <translation>Vykouznout dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="377"/>
        <source>Slow Zoom In</source>
        <translation>Pomalu přiblížit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="379"/>
        <source>Slow Zoom Out</source>
        <translation>Pomalu oddálit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="381"/>
        <source>Slow Pan Left</source>
        <translation>Pomalu najíždět vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="382"/>
        <source>Slow Move Left</source>
        <translation>Pomalu posunovat vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="384"/>
        <source>Slow Pan Right</source>
        <translation>Pomalu najíždět vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="385"/>
        <source>Slow Move Right</source>
        <translation>Pomalu posunovat vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="387"/>
        <source>Slow Pan Up</source>
        <translation>Pomalu najíždět nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="388"/>
        <source>Slow Move Up</source>
        <translation>Pomalu posunovat nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="390"/>
        <source>Slow Pan Down</source>
        <translation>Pomalu najíždět dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="391"/>
        <source>Slow Move Down</source>
        <translation>Pomalu posunovat dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="393"/>
        <source>Slow Zoom In, Pan Up Left</source>
        <translation>Pomalu přiblížit, najíždět nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="394"/>
        <source>Slow Zoom In, Move Up Left</source>
        <translation>Pomalu přiblížit, posunovat nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="396"/>
        <source>Slow Zoom In, Pan Down Right</source>
        <translation>Pomalu přiblížit, najíždět nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="397"/>
        <source>Slow Zoom In, Move Down Right</source>
        <translation>Pomalu přiblížit, posunovat dolů vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="399"/>
        <source>Slow Zoom Out, Pan Up Right</source>
        <translation>Pomalu oddálit, najíždět nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="400"/>
        <source>Slow Zoom Out, Move Up Right</source>
        <translation>Pomalu oddálit, posunovat nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="402"/>
        <source>Slow Zoom Out, Pan Down Left</source>
        <translation>Pomalu oddálit, najíždět nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="403"/>
        <source>Slow Zoom Out, Move Down Left</source>
        <translation>Pomalu přiblížit, posunovat dolů vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="405"/>
        <source>Slow Zoom In, Hold Bottom</source>
        <translation>Pomalu přiblížit, podržet dole</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="407"/>
        <source>Slow Zoom In, Hold Top</source>
        <translation>Pomalu přiblížit, podržet nahoře</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="409"/>
        <source>Slow Zoom In, Hold Left</source>
        <translation>Pomalu přiblížit, podržet vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="411"/>
        <source>Slow Zoom In, Hold Right</source>
        <translation>Pomalu přiblížit, podržet vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="413"/>
        <source>Slow Zoom Out, Hold Bottom</source>
        <translation>Pomalu oddálit, podržet dole</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="415"/>
        <source>Slow Zoom Out, Hold Top</source>
        <translation>Pomalu oddálit, podržet nahoře</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="417"/>
        <source>Slow Zoom Out, Hold Left</source>
        <translation>Pomalu oddálit, podržet vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="419"/>
        <source>Slow Zoom Out, Hold Right</source>
        <translation>Pomalu oddálit, podržet vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="487"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="522"/>
        <source>Position</source>
        <translation>Poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="632"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="707"/>
        <source>Zoom</source>
        <translation>Zvětšení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="755"/>
        <source>Size mode</source>
        <translation>Režim velikosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="762"/>
        <source>Fit</source>
        <translation>Umístit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="776"/>
        <source>Fill</source>
        <translation>Vyplnit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="796"/>
        <source>Distort</source>
        <translation>Zkreslit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="824"/>
        <source>Horizontal fit</source>
        <translation>Vodorovné umístění</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="831"/>
        <source>Left</source>
        <translation>Vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="843"/>
        <source>Center</source>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="855"/>
        <source>Right</source>
        <translation>Vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="879"/>
        <source>Vertical fit</source>
        <translation>Svislé umístění</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="886"/>
        <source>Top</source>
        <translation>Nahoře</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="898"/>
        <source>Middle</source>
        <comment>Size and Position video filter</comment>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="910"/>
        <source>Bottom</source>
        <translation>Dole</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="934"/>
        <source>Rotation</source>
        <translation>Otočení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="947"/>
        <source> °</source>
        <comment>degrees</comment>
        <translation> °</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="974"/>
        <source>Background color</source>
        <translation>Barva pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="425"/>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="430"/>
        <source>Shake 1 Second - Scaled</source>
        <translation>Zatřesení 1 sekunda - s měřítkem</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="427"/>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="432"/>
        <source>Shake 1 Second - Unscaled</source>
        <translation>Zatřesení 1 sekunda - bez měřítka</translation>
    </message>
</context>
<context>
    <name>SizePositionVUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionVUI.qml" line="156"/>
        <source>Click in rectangle + hold Shift to drag, Wheel to zoom, or %1+Wheel to rotate</source>
        <translation>Klepněte v obdélníku + držte klávesu Shift pro tažení, otáčejte kolečkem myši pro přibližování a oddalování (zvětšení/zmenšení), nebo %1+kolečko pro otáčení</translation>
    </message>
</context>
<context>
    <name>SlideshowGeneratorDialog</name>
    <message numerus="yes">
        <location filename="../src/dialogs/slideshowgeneratordialog.cpp" line="33"/>
        <source>Slideshow Generator - %n Clips</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
</context>
<context>
    <name>SlideshowGeneratorWidget</name>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="58"/>
        <source>Clip duration</source>
        <translation>Doba trvání záběru</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="60"/>
        <source>Set the duration of each clip in the slideshow.</source>
        <translation>Nastavte dobu trvání každého záběru v promítání.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="69"/>
        <source>Aspect ratio conversion</source>
        <translation>Převod poměru stran</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="71"/>
        <source>Pad Black</source>
        <translation>Černá vsuvka</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="72"/>
        <source>Crop Center</source>
        <translation>Ořezat na střed</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="73"/>
        <source>Crop and Pan</source>
        <translation>Ořezat a najíždět</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="77"/>
        <source>Pad Blur</source>
        <translation>Rozostřená vsuvka</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="80"/>
        <source>Choose an aspect ratio conversion method.</source>
        <translation>Vyberte způsob převedení poměru stran.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="89"/>
        <source>Zoom effect</source>
        <translation>Efekt přiblížení</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="92"/>
        <source>Set the percentage of the zoom-in effect.
0% will result in no zoom effect.</source>
        <translation>Nastavte procento efektu přiblížení.
0 % povede k efektu bez přiblížení.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="100"/>
        <source>Transition duration</source>
        <translation>Doba trvání přechodu</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="103"/>
        <source>Set the duration of the transition.
May not be longer than half the duration of the clip.
If the duration is 0, no transition will be created.</source>
        <translation>Nastavte dobu přechodu.
Nesmí být delší než polovina trvání záběru.
Pokud je trvání 0, nebude vytvořen žádný přechod.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="116"/>
        <source>Transition type</source>
        <translation>Druh přechodu</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="119"/>
        <source>Random</source>
        <translation>Náhodný</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="120"/>
        <source>Cut</source>
        <translation>Vyjmout</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="121"/>
        <source>Dissolve</source>
        <translation>Prolínat se</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="122"/>
        <source>Bar Horizontal</source>
        <translation>Pruh vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="123"/>
        <source>Bar Vertical</source>
        <translation>Pruh svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="124"/>
        <source>Barn Door Horizontal</source>
        <translation>Vrata od stodoly vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="125"/>
        <source>Barn Door Vertical</source>
        <translation>Vrata od stodoly svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="126"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Vrata od stodoly diagonálně JZ-SV</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="127"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Vrata od stodoly diagonálně SZ-JV</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="128"/>
        <source>Diagonal Top Left</source>
        <translation>Diagonálně nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="129"/>
        <source>Diagonal Top Right</source>
        <translation>Diagonálně nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="130"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Vodopád matrice vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="131"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Vodopád matrice svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="132"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Had matrice vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="133"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Had matrice souběžně vodorovně</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="134"/>
        <source>Matrix Snake Vertical</source>
        <translation>Had matrice svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="135"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Had matrice souběžně svisle</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="136"/>
        <source>Barn V Up</source>
        <translation>Vrata od stodoly svisle nahoru</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="137"/>
        <source>Iris Circle</source>
        <translation>Kruh s duhou</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="138"/>
        <source>Double Iris</source>
        <translation>Dvojitá duha</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="139"/>
        <source>Iris Box</source>
        <translation>Rámeček s duhou</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="140"/>
        <source>Box Bottom Right</source>
        <translation>Rámeček dole vpravo</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="141"/>
        <source>Box Bottom Left</source>
        <translation>Rámeček dole vlevo</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="142"/>
        <source>Box Right Center</source>
        <translation>Rámeček vpravo na střed</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="143"/>
        <source>Clock Top</source>
        <translation>Hodiny nahoře</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="147"/>
        <source>Choose a transition effect.</source>
        <translation>Vyberte efekt přechodu.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="155"/>
        <source>Transition softness</source>
        <translation>Měkkost přechodu</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="157"/>
        <source>Change the softness of the edge of the wipe.</source>
        <translation>Změňte měkkost okraje stíračky.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="499"/>
        <source>Preview is not available with GPU Effects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="500"/>
        <source>Generating Preview...</source>
        <translation>Vytváří se náhled...</translation>
    </message>
</context>
<context>
    <name>SpeedUI</name>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="96"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Podržte %1 pro tažení klíčového snímku pouze svisle nebo %2 pro tažení pouze vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="108"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="130"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="134"/>
        <source>Map the specified speed to the current time. Use keyframes to vary the speed mappings over time.</source>
        <translation>Mapuje zadanou rychlost na aktuální čas. Pomocí klíčových snímků můžete mapování rychlosti v čase měnit.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="158"/>
        <source>Image mode</source>
        <translation>Režim obrázků</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="162"/>
        <source>Use the specified image selection mode. Nearest will output the image that is nearest to the mapped time. Blend will blend all images that occur during the mapped time.</source>
        <translation>Použijte zadaný režim výběru obrázku. Nejbližší zobrazí obrázek, který je nejblíže mapovanému času. Smíchání sloučí všechny obrázky, které se vyskytnou během mapovaného času.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="181"/>
        <source>Nearest</source>
        <translation>Nejbližší</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="186"/>
        <source>Blend</source>
        <translation>Smíchat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="201"/>
        <source>Enable pitch compensation</source>
        <translation>Povolit vyrovnání výšky tónu</translation>
    </message>
</context>
<context>
    <name>SubtitleBar</name>
    <message>
        <location filename="../src/qml/views/timeline/SubtitleBar.qml" line="73"/>
        <source>Unable to move. Subtitles already exist at this time.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubtitleTrackDialog</name>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="54"/>
        <source>New Subtitle Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="58"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="63"/>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
</context>
<context>
    <name>SubtitlesDock</name>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="131"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="177"/>
        <source>Subtitles</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="147"/>
        <source>Add clips to the Timeline to begin editing subtitles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="178"/>
        <source>Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="198"/>
        <source>Columns</source>
        <translation>Sloupce</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="199"/>
        <source>Start</source>
        <translation>Začátek</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="202"/>
        <source>End</source>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="205"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="211"/>
        <source>Subtitle Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="217"/>
        <source>Subtitles Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="268"/>
        <source>Previous</source>
        <translation>Předchozí</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="270"/>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="272"/>
        <source>Next</source>
        <translation>Další</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="304"/>
        <source>Add Subtitle Track</source>
        <translation>Přidat stopu titulků</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="307"/>
        <source>Add a subtitle track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="315"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="545"/>
        <source>Remove Subtitle Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="318"/>
        <source>Remove this subtitle track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="326"/>
        <source>Edit Subtitle Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="329"/>
        <source>Edit this subtitle track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="337"/>
        <source>Import Subtitles From File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="340"/>
        <source>Import subtitles from an srt file at the current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="348"/>
        <source>Export Subtitles To File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="351"/>
        <source>Export the current subtitle track to an SRT file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="359"/>
        <source>Create/Edit Subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="363"/>
        <source>Create or Edit a subtitle at the cursor position.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="367"/>
        <source>Add Subtitle Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="371"/>
        <source>Add a subtitle at the cursor position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="375"/>
        <source>Remove Subtitle Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="379"/>
        <source>Remove the selected subtitle item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="383"/>
        <source>Set Subtitle Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="388"/>
        <source>Set the selected subtitle to start at the cursor position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="392"/>
        <source>Set Subtitle End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="397"/>
        <source>Set the selected subtitle to end at the cursor position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="401"/>
        <source>Move Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="405"/>
        <source>Move the selected subtitles to the cursor position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="409"/>
        <source>Burn In Subtitles on Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="410"/>
        <source>Create or edit a Burn In Subtitles filter on the timeline output.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="415"/>
        <source>Generate Text on Timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="417"/>
        <source>Create a new video track on the timeline with text showing these subtitles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="421"/>
        <source>Speech to Text...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="422"/>
        <source>Detect speech and transcribe to a new subtitle track.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="428"/>
        <source>Track Timeline Cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="429"/>
        <source>Track the timeline cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="437"/>
        <source>Show Previous/Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="438"/>
        <source>Show the previous and next subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="511"/>
        <source>Add a clip to the timeline to create subtitles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1067"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1069"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1089"/>
        <source>Subtitle Track %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1131"/>
        <source>Generate subtitle text on timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1132"/>
        <source>Text style preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1134"/>
        <source>Default subtitle style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1277"/>
        <source>Extracting Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1295"/>
        <source>Speech to Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="522"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="575"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1226"/>
        <source>Subtitle track already exists: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="546"/>
        <source>This track is in use by a subtitle filter.
Remove the subtitle filter before removing this track.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="592"/>
        <source>Import Subtitle File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="594"/>
        <source>Subtitle Files (*.srt *.SRT *.vtt *.VTT *.ass *.ASS *.ssa *.SSA)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="602"/>
        <source>Unable to find subtitle file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="650"/>
        <source>Export SRT File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="652"/>
        <source>SRT Files (*.srt *.SRT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="717"/>
        <source>A subtitle already exists at this time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="727"/>
        <source>Not enough space to add subtitle.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="764"/>
        <source>Start time can not be after end time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="770"/>
        <source>Start time can not be before previous subtitle.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="788"/>
        <source>End time can not be before start time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="795"/>
        <source>End time can not be after next subtitle.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="817"/>
        <source>Unable to move. Subtitles already exist at this time.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubtitlesModel</name>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="818"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="820"/>
        <source>Start</source>
        <translation>Začátek</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="822"/>
        <source>End</source>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="824"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
</context>
<context>
    <name>SystemSyncDialog</name>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="14"/>
        <source>Player Synchronization</source>
        <translation>Seřízení přehrávače</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="20"/>
        <source>Adjust your playback audio/video synchronization</source>
        <translation>Upravte synchronizaci zvuku a obrazu při přehrávání</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="48"/>
        <source>Reset to default value 0</source>
        <translation>Nastavit znovu na výchozí hodnotu 0</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="65"/>
        <source>Video offset</source>
        <translation>Posun obrazu</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="75"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="82"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
</context>
<context>
    <name>TextEditor</name>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="41"/>
        <source>Decrease Text Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="44"/>
        <location filename="../src/docks/notesdock.cpp" line="49"/>
        <source>Notes</source>
        <translation>Poznámky</translation>
    </message>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="46"/>
        <source>Increase Text Size</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextFilterUi</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="78"/>
        <source>Bold</source>
        <translation>Tučné</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="80"/>
        <source>Italic</source>
        <translation>Kurzíva</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="208"/>
        <source>Font</source>
        <translation>Písmo</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="267"/>
        <source>Use font size</source>
        <translation>Použít velikost písma</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="282"/>
        <source>Outline</source>
        <translation>Obrys</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="303"/>
        <source>Thickness</source>
        <translation>Tloušťka</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="318"/>
        <source>Background</source>
        <translation>Pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="339"/>
        <source>Padding</source>
        <translation>Prázdné okraje</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="354"/>
        <source>Opacity</source>
        <translation>Neprůhlednost</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="384"/>
        <source>Position</source>
        <translation>Poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="461"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="520"/>
        <source>Horizontal fit</source>
        <translation>Vodorovné umístění</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="527"/>
        <source>Left</source>
        <translation>Vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="535"/>
        <source>Center</source>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="543"/>
        <source>Right</source>
        <translation>Vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="560"/>
        <source>Vertical fit</source>
        <translation>Svislé umístění</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="567"/>
        <source>Top</source>
        <translation>Nahoře</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="575"/>
        <source>Middle</source>
        <comment>Text video filter</comment>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="583"/>
        <source>Bottom</source>
        <translation>Dole</translation>
    </message>
</context>
<context>
    <name>TextFilterVui</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterVui.qml" line="85"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Klepněte v obdélníku + držte klávesu Shift pro tažení</translation>
    </message>
</context>
<context>
    <name>TextProducerWidget</name>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="26"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="39"/>
        <source>Type or paste the text here</source>
        <translation>Zde pište nebo vložte text</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="48"/>
        <source>Background color...</source>
        <translation>Barva pozadí...</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="61"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="88"/>
        <source>Simple</source>
        <translation>Prostý</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="98"/>
        <source>Rich</source>
        <translation>Formátovaný</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="120"/>
        <source>Text attributes are available in the &lt;b&gt;Filters&lt;/b&gt; panel after clicking &lt;b&gt;OK&lt;/b&gt;.</source>
        <translation>Vlastnosti textu jsou dostupné v panelu &lt;b&gt;Filtry&lt;/b&gt; po klepnutí na &lt;b&gt;OK&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="59"/>
        <source>black</source>
        <translation>Černý</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="61"/>
        <source>transparent</source>
        <translation>Průhledný</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="179"/>
        <location filename="../src/widgets/textproducerwidget.cpp" line="212"/>
        <source>Edit your text using the Filters panel.</source>
        <translation>Upravte text pomocí panelu filtrů.</translation>
    </message>
</context>
<context>
    <name>TextViewerDialog</name>
    <message>
        <location filename="../src/dialogs/textviewerdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="35"/>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="64"/>
        <source>Save Text</source>
        <translation>Uložit text</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="65"/>
        <source>Text Documents (*.txt);;All Files (*)</source>
        <translation>Textové dokumenty (*.txt);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="67"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;Všechny soubory (*)</translation>
    </message>
</context>
<context>
    <name>TiledItemDelegate</name>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="123"/>
        <source>Duration: %1</source>
        <translation>Doba trvání: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="128"/>
        <source>Date: %1</source>
        <translation>Datum: %1</translation>
    </message>
</context>
<context>
    <name>TimeSpinner</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="70"/>
        <source>Decrement</source>
        <translation>Snížení</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="99"/>
        <source>Increment</source>
        <translation>Zvýšení</translation>
    </message>
</context>
<context>
    <name>TimelineDock</name>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="83"/>
        <location filename="../src/docks/timelinedock.cpp" line="94"/>
        <source>Timeline</source>
        <translation>Časová osa</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1704"/>
        <source>This track is locked</source>
        <translation>Tato stopa je zamknuta</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1709"/>
        <source>You cannot add a non-seekable source.</source>
        <translation>Nemůžete přidat neprohledávatelný zdroj</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2107"/>
        <location filename="../src/docks/timelinedock.cpp" line="2141"/>
        <source>Track %1 was not moved</source>
        <translation>Stopa %1 nebyla posunuta</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2112"/>
        <source>Can not move audio track above video track</source>
        <translation>Zvukovou stopu nelze přesunout nad stopu s obrazem</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2128"/>
        <source>Can not move video track below audio track</source>
        <translation>Obrazovou stopu nelze přesunout nad stopu se zvukem</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1434"/>
        <location filename="../src/docks/timelinedock.cpp" line="2269"/>
        <source>Align To Reference Track</source>
        <translation>Zarovnat se vzorovou stopu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="95"/>
        <source>Track Operations</source>
        <translation>Operace stopy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="107"/>
        <source>Track Height</source>
        <translation>Výška stopy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="112"/>
        <source>Selection</source>
        <translation>Výběr</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="125"/>
        <source>Edit</source>
        <translation>Upravit</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="142"/>
        <source>View</source>
        <translation>Pohled</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="148"/>
        <source>Marker</source>
        <translation>Značka</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="158"/>
        <source>Timeline Clip</source>
        <translation>Záběr časové osy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="182"/>
        <source>Timeline Controls</source>
        <translation>Ovládání časové osy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="186"/>
        <source>Timeline Menu</source>
        <translation>Nabídka pro časovou osu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="377"/>
        <source>Add Audio Track</source>
        <translation>Přidat zvukovou stopu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="386"/>
        <source>Add Video Track</source>
        <translation>Přidat obrazovou stopu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="395"/>
        <source>Insert Track</source>
        <translation>Vložit stopu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="404"/>
        <source>Remove Track</source>
        <translation> Odstranit stopu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="415"/>
        <source>Move Track Up</source>
        <translation>Posunout stopu nahoru</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="426"/>
        <source>Move Track Down</source>
        <translation>Posunout stopu dolů</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="437"/>
        <source>Show/Hide Selected Track</source>
        <translation>Zobrazit/Skrýt vybranou stopu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="453"/>
        <source>Lock/Unlock Selected Track</source>
        <translation>Zamknout/Odemknout vybranou stopu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="472"/>
        <source>Mute/Unmute Selected Track</source>
        <translation>Ztlumit/Zrušit ztlumení vybrané stopy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="488"/>
        <source>Blend/Unblend Selected Track</source>
        <translation>Smíchat/Rozmíchat vybranou stopu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="506"/>
        <source>Make Tracks Shorter</source>
        <translation>Udělat stopy kratší</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="515"/>
        <source>Make Tracks Taller</source>
        <translation>Udělat stopy vyšší</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="524"/>
        <source>Reset Track Height</source>
        <translation>Vrátit výšku stopy na výchozí</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="533"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="544"/>
        <source>Select All On Current Track</source>
        <translation>Vybrat vše v nynější stopě</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="555"/>
        <source>Select None</source>
        <translation>Nevybrat nic</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="567"/>
        <source>Select Next Clip</source>
        <translation>Vybrat další záběr</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="582"/>
        <source>Select Previous Clip</source>
        <translation>Vybrat předchozí záběr</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="597"/>
        <source>Select Clip Above</source>
        <translation>Vybrat záběr nad</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="618"/>
        <source>Select Clip Below</source>
        <translation>Vybrat záběr pod</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="639"/>
        <source>Set Current Track Above</source>
        <translation>Nastavit nynější stopu nad</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="648"/>
        <source>Set Current Track Below</source>
        <translation>Nastavit nynější stopu pod</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="657"/>
        <source>Select Clip Under Playhead</source>
        <translation>Vybrat záběr pod polohou přehrávání</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="672"/>
        <source>Cu&amp;t</source>
        <translation>Vyjmou&amp;t</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="693"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopírovat</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="722"/>
        <source>&amp;Paste</source>
        <translation>&amp;Vložit</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="736"/>
        <source>Nudge Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="751"/>
        <source>Nudge Forward is not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="773"/>
        <source>Nudge Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="783"/>
        <source>Nudge Backward is not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="805"/>
        <source>Append</source>
        <translation>Připojit</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="816"/>
        <source>Ripple Delete</source>
        <translation>Vytáhnout (smazat a posunout)</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="833"/>
        <source>Lift</source>
        <translation>Vyzvednout</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="851"/>
        <source>Overwrite</source>
        <translation>Přepsat</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="864"/>
        <source>Split At Playhead</source>
        <translation>Rozdělit v poloze přehrávání</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="921"/>
        <source>Split All Tracks At Playhead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="952"/>
        <source>Replace</source>
        <translation>Nahradit</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="971"/>
        <source>Create/Edit Marker</source>
        <translation>Vytvořit/Upravit značku</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="984"/>
        <source>Previous Marker</source>
        <translation>Předchozí značka</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="998"/>
        <source>Next Marker</source>
        <translation>Další značka</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1012"/>
        <source>Delete Marker</source>
        <translation>Smazat značku</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1023"/>
        <source>Cycle Marker Color</source>
        <translation>Kolovat barvu značky</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1039"/>
        <source>Create Marker Around Selected Clip</source>
        <translation>Vybrat značku kolem vybraného záběru</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1050"/>
        <source>Rectangle Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1061"/>
        <source>Automatically Add Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1072"/>
        <source>Snap</source>
        <translation>Přichytit</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1086"/>
        <source>Scrub While Dragging</source>
        <translation>Při tažení záběrů do nebo na časové ose přehrávat rychle snímek za snímkem. Časová poloha přehrávače sleduje vodorovnou polohu myši na časové ose</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1099"/>
        <source>Ripple</source>
        <translation>Vložit a posunout</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1113"/>
        <source>Ripple All Tracks</source>
        <translation>Vložit a posunout všechny stopy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1127"/>
        <source>Ripple Markers</source>
        <translation>Vložit a posunout značky</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1142"/>
        <source>Toggle Ripple And All Tracks</source>
        <translation>Přepnout vložit a posunout všechny stopy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1150"/>
        <source>Toggle Ripple, All Tracks, And Markers</source>
        <translation>Přepnout vložit, posunout všechny stopy a značky</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1159"/>
        <source>Show Audio Waveforms</source>
        <translation>Ukázat zvukové vlny</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1173"/>
        <source>Use Higher Performance Waveforms</source>
        <translation>Použít křivky pro vyšší výkon</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1189"/>
        <source>Show Video Thumbnails</source>
        <translation>Ukázat náhledy obrazu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1200"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1213"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1226"/>
        <source>Smooth</source>
        <translation>Plynulý</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1239"/>
        <source>Center the Playhead</source>
        <translation>Vystředit polohu přehrávání</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1253"/>
        <source>Scroll to Playhead on Zoom</source>
        <translation>Pžejít k poloze přehrávání při zvětšení</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1265"/>
        <source>Zoom Timeline Out</source>
        <translation>Oddálit časovou osu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1276"/>
        <source>Zoom Timeline In</source>
        <translation>Přiblížit časovou osu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1287"/>
        <source>Zoom Timeline To Fit</source>
        <translation>Přizpůsobit časovou osu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1299"/>
        <source>New Generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1307"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1309"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1313"/>
        <source>Animation</source>
        <translation>Animace</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1317"/>
        <source>Noise</source>
        <translation>Šum</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1320"/>
        <source>Color Bars</source>
        <translation>Barevné pruhy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1324"/>
        <source>Audio Tone</source>
        <translation>Zvukový tón</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1327"/>
        <source>Count</source>
        <translation>Počítání</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1330"/>
        <source>Blip Flash</source>
        <translation>Záblesk</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1353"/>
        <source>Properties</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1360"/>
        <source>Rejoin With Next Clip</source>
        <translation>Znovu připojit k dalšímu záběru</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1376"/>
        <source>Detach Audio</source>
        <translation>Odpojit zvuk</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1404"/>
        <source>Freeze Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1454"/>
        <source>Apply Copied Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1478"/>
        <source>Update Thumbnails</source>
        <translation>Obnovit náhledy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1502"/>
        <source>Rebuild Audio Waveform</source>
        <translation>Obnovit zvukovou vlnu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1526"/>
        <source>Ripple Trim Clip In</source>
        <translation>Zkrátit začátek záběru tažením a posunout</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1533"/>
        <source>Ripple Trim Clip Out</source>
        <translation>Zkrátit konec záběru tažením a posunout</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1540"/>
        <source>Group/Ungroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2367"/>
        <source>Append multiple to timeline</source>
        <translation>Připojit vícenásobně k časové ose</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2427"/>
        <source>Ripple delete transition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2476"/>
        <source>Lift transition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2551"/>
        <source>Cut %1 from timeline</source>
        <translation>Vyjmout %1 z časové osy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2553"/>
        <source>Remove %1 from timeline</source>
        <translation> Odstranit %1 z časové osy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2576"/>
        <source>Lift %1 from timeline</source>
        <translation>Vyzvednout %1 z časové osy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2927"/>
        <source>There is nothing in the Source player.</source>
        <translation>V přehrávači zdroje není nic</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2942"/>
        <source>You cannot replace a transition.</source>
        <translation>Nemůžete nahradit přechod.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2972"/>
        <source>Select a clip in the timeline to create a marker around it</source>
        <translation>Vyberte záběr na časové ose a vytvořte kolem něj značku</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2993"/>
        <source>Added marker: &quot;%1&quot;.</source>
        <translation>Přidaná značka: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3013"/>
        <source>Added marker: &quot;%1&quot;. Hold %2 and drag to create a range</source>
        <translation>Přidaná značka: &quot;%1&quot;. Podržte %2 a táhněte pro vytvoření rozsahu</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3129"/>
        <source>Failed to open </source>
        <translation>Nepodařilo se otevřít</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3162"/>
        <source>Dropped Files</source>
        <translation>Zahozené soubory</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3207"/>
        <source>You cannot freeze a frame of a transition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3226"/>
        <source>Freeze Frame is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3260"/>
        <source>Insert Freeze Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3264"/>
        <source>The play head is not over the selected clip.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3616"/>
        <source>Insert multiple into timeline</source>
        <translation>Vložit vícenásobně do časové osy</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3755"/>
        <source>Overwrite multiple onto timeline</source>
        <translation>Přepsat vícenásobně na časové ose</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="904"/>
        <location filename="../src/docks/timelinedock.cpp" line="936"/>
        <source>You cannot split a transition.</source>
        <translation>Nemůžete rozdělit přechod.</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/timelinedock.cpp" line="4171"/>
        <source>Replace %n timeline clips</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4224"/>
        <source>voiceover</source>
        <translation>hlasový projev</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4225"/>
        <source>Opus (*.opus);;All Files (*)</source>
        <translation>Opus (*.opus);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1336"/>
        <location filename="../src/docks/timelinedock.cpp" line="4227"/>
        <location filename="../src/docks/timelinedock.cpp" line="4343"/>
        <source>Record Audio</source>
        <translation>Záznam zvuku</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4241"/>
        <source>Record Audio: %1</source>
        <translation>Záznam zvuku: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4308"/>
        <source>Audio Recording In Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4318"/>
        <source>Record Audio error: check PulseAudio settings</source>
        <translation>Chyba záznamu zvuku: zkontrolujte nastavení PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4322"/>
        <source>Record Audio error: choose File &gt; Open Other &gt; Audio/Video Device</source>
        <translation>Chyba záznamu zvuku: zvolte Soubor &gt; Otevřít jiné &gt; zvukové/obrazové zařízení</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4349"/>
        <source>Saving audio recording...</source>
        <translation>Ukládání zvukového záznamu...</translation>
    </message>
</context>
<context>
    <name>TimelinePropertiesWidget</name>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="26"/>
        <source>Timeline</source>
        <translation>Časová osa</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="104"/>
        <source>Frame rate</source>
        <translation>Snímková rychlost</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="246"/>
        <source>Edit...</source>
        <translation>Upravit...</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="73"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="114"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="179"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="186"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="237"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="39"/>
        <source>Resolution</source>
        <translation>Rozlišení</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="227"/>
        <source>Scan mode</source>
        <translation>Režim snímání obrazu</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="169"/>
        <source>Aspect ratio</source>
        <translation>Poměr stran</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="193"/>
        <source>Colorspace</source>
        <translation>Barevný prostor</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="39"/>
        <source>%L1 fps</source>
        <translation>%L1 szs</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="41"/>
        <source>Progressive</source>
        <translation>Progresivní</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="43"/>
        <source>Interlaced</source>
        <translation>Prokládaný</translation>
    </message>
</context>
<context>
    <name>ToneProducerWidget</name>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="26"/>
        <source>Audio Tone</source>
        <translation>Zvukový tón</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>Kmitočet</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="51"/>
        <source> Hz</source>
        <translation> Hz</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="80"/>
        <source>Level</source>
        <translation>Úroveň</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="90"/>
        <source> dB</source>
        <translation> dB</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.cpp" line="98"/>
        <source>Tone: %1Hz %2dB</source>
        <translation>Ladění: %1Hz %2dB</translation>
    </message>
</context>
<context>
    <name>TrackHead</name>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="219"/>
        <source>Unmute</source>
        <translation>Zrušit ztlumení</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="219"/>
        <source>Mute</source>
        <translation>Ztlumit</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="236"/>
        <source>Show</source>
        <translation>Ukázat</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="236"/>
        <source>Hide</source>
        <translation>Skrýt</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="183"/>
        <source>Unlock track</source>
        <translation>Odemknout stopu</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="183"/>
        <source>Lock track</source>
        <translation>Zamknout stopu</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="255"/>
        <source>Filters</source>
        <translation>Filtry</translation>
    </message>
</context>
<context>
    <name>TrackPropertiesWidget</name>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="38"/>
        <source>Blend mode</source>
        <translation>Režim smíchání</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="38"/>
        <source>Track: %1</source>
        <translation>Stopa: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="45"/>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="77"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="46"/>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="78"/>
        <source>Over</source>
        <translation>Kladení nad sebe</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="47"/>
        <source>Add</source>
        <translation>Přidat</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="48"/>
        <source>Saturate</source>
        <translation>Sytost</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="49"/>
        <source>Multiply</source>
        <translation>Součin</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="50"/>
        <source>Screen</source>
        <translation>Obrazovka</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="51"/>
        <source>Overlay</source>
        <translation>Překrytí</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="52"/>
        <source>Darken</source>
        <translation>Ztmavení</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="53"/>
        <source>Dodge</source>
        <translation>Hustota barvy -</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="54"/>
        <source>Burn</source>
        <translation>Hustota barvy +</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="55"/>
        <source>Hard Light</source>
        <translation>Ostré světlo</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="56"/>
        <source>Soft Light</source>
        <translation>Tlumené světlo</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="57"/>
        <source>Difference</source>
        <translation>Rozdíl</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="58"/>
        <source>Exclusion</source>
        <translation>Vyloučení</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="59"/>
        <source>HSL Hue</source>
        <translation>Odstín HSL</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="60"/>
        <source>HSL Saturation</source>
        <translation>Sytost HSL</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="61"/>
        <source>HSL Color</source>
        <translation>Barva HSL</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="62"/>
        <source>HSL Luminosity</source>
        <translation>Svítivost HSL</translation>
    </message>
</context>
<context>
    <name>TranscodeDialog</name>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="38"/>
        <source>good</source>
        <translation>dobrý</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="48"/>
        <source>better</source>
        <translation>lepší</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="58"/>
        <source>best</source>
        <translation>nejlepší</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="94"/>
        <source>medium</source>
        <translation>střední</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="136"/>
        <source>Do not show this anymore.</source>
        <comment>Convert to edit-friendly format dialog</comment>
        <translation>Toto už vícekrát neukazovat.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="206"/>
        <source>Change the frame rate from its source.</source>
        <translation>Změňte snímkovou rychlost z jeho zdroje.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="262"/>
        <location filename="../src/dialogs/transcodedialog.ui" line="266"/>
        <source>Same as original</source>
        <translation>Stejný jako původní</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="271"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="276"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="155"/>
        <source>This is useful when the source video is HDR (High Dynamic Range), which requires tone-mapping to the old, standard range.</source>
        <translation>Toto je užitečné, pokud je zdrojové video v HDR (vysoký dynamický rozsah), což vyžaduje mapování tónů na starý standardní rozsah.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="249"/>
        <source>Frame rate conversion</source>
        <translation>Převod snímkové rychlosti</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="165"/>
        <source>This option converts only the trimmed portion of the source
clip plus a little instead of the entire clip. When this option is
used not all of the matching source clips are replaced, instead
only the currently selected one.</source>
        <translation>Tato volba převádí pouze oříznutou část zdrojového
záběru plus trochu namísto celého záběruu. Když je tato volba
použita, ne všechny odpovídající zdrojové záběry jsou nahrazeny,
pouze nyní vybraný.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="104"/>
        <source>BIG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="114"/>
        <source>&lt;span style=&quot; font-weight:700; color:#ff0000;&quot;&gt;HUGE&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="171"/>
        <source>Use sub-clip</source>
        <translation>Použít podzáběr</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="219"/>
        <source>Sample rate</source>
        <translation>Vzorkování</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="239"/>
        <source>If the source is interlaced, each interlaced field will be converted to a progressive frame resulting in double frame rate.</source>
        <translation>Pokud je zdroj prokládaný, každé prokládané pole se převede na progresivní snímek, což vede k dvojnásobné snímkové rychlosti.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="242"/>
        <source>Deinterlace</source>
        <translation>Odstranit prokládání</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="178"/>
        <source>Enable this to keep the Advanced section open for the next time this dialog appears.</source>
        <translation>Povolte pro ponechání sekce Pokročilé otevřenou, až se příště tento dialog opět objeví.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="181"/>
        <source>Keep Advanced open</source>
        <translation>Ponechat Pokročilé otevřeno</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="148"/>
        <source>Override the frame rate to a specific value.</source>
        <translation>Přepsat snímkovou rychlost na zadanou hodnotu.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="188"/>
        <source>Frame rate conversion method

Duplicate: Duplicate frames.
Blend: Blend frames.
Motion Compensation: Interpolate new frames using motion compensation. This method is very slow and may result in artifacts.</source>
        <translation>Způsob převodu snímkové rychlosti

Zdvojit: Zdvojit snímky.
Smíchat: Smíchat snímky.
Vyrovnání pohybu: Interpolace nových snímků pomocí vyrovnání pohybu. Tento způsob je velmi pomalý a může vést k artefaktům.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="209"/>
        <source>Override frame rate</source>
        <translation>Přepsat snímkovou rychlost</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="229"/>
        <source>Frames/sec</source>
        <translation>Snímků za sekundu</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="158"/>
        <source>Convert to BT.709 colorspace</source>
        <translation>Převést do barevného prostoru BT.709</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="34"/>
        <source>Convert to Edit-friendly...</source>
        <translation>Převést na přátelský pro úpravy...</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="51"/>
        <source>Duplicate (fast)</source>
        <translation>Zdvojit (rychle)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="52"/>
        <source>Blend</source>
        <translation>Smíchat</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="53"/>
        <source>Motion Compensation (slow)</source>
        <translation>Vyrovnání pohybu (pomalé)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="56"/>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="146"/>
        <source>Lossy: I-frame–only %1</source>
        <translation>Ztrátový: I-snímek–pouze %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="150"/>
        <source>Intermediate: %1</source>
        <translation>Prostřední: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="153"/>
        <source>Lossless: %1</source>
        <translation>Bezztrátový: %1</translation>
    </message>
</context>
<context>
    <name>Transcoder</name>
    <message>
        <location filename="../src/transcoder.cpp" line="58"/>
        <source>Sub-clip</source>
        <translation>Podzáběr</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="58"/>
        <source>Converted</source>
        <translation>Převedeno</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="66"/>
        <source>MP4 (*.mp4);;All Files (*)</source>
        <translation>MP4 (*.mp4);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="70"/>
        <source>MOV (*.mov);;All Files (*)</source>
        <translation>MOV (*.mov);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="74"/>
        <source>MKV (*.mkv);;All Files (*)</source>
        <translation>MKV (*.mkv);;Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="102"/>
        <location filename="../src/transcoder.cpp" line="138"/>
        <source>A job already exists for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="109"/>
        <location filename="../src/transcoder.cpp" line="120"/>
        <location filename="../src/transcoder.cpp" line="127"/>
        <source>Convert canceled</source>
        <translation>Převod zrušen</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="349"/>
        <source>Convert %1</source>
        <translation>Převést %1</translation>
    </message>
</context>
<context>
    <name>TranscribeAudioDialog</name>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="73"/>
        <source>Speech to Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="85"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="90"/>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="116"/>
        <source>Translate to English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="118"/>
        <source>Maximum line length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="128"/>
        <source>Include non-spoken sounds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="130"/>
        <source>Tracks with speech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="131"/>
        <source>Select tracks that contain speech to be transcribed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="180"/>
        <source>Whisper.cpp executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="190"/>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="213"/>
        <source>Find Whisper.cpp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="203"/>
        <source>GGML Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="232"/>
        <source>Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="326"/>
        <source>Path to Whisper.cpp executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="331"/>
        <source>Whisper.cpp executable not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="337"/>
        <source>Path to GGML model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="342"/>
        <source>GGML model not found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UndoButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/UndoButton.qml" line="28"/>
        <source>Reset to default</source>
        <translation>Nastavit znovu na výchozí</translation>
    </message>
</context>
<context>
    <name>UnlinkedFilesDialog</name>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="14"/>
        <source>Missing Files</source>
        <translation>Chybějící soubory</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="26"/>
        <source>There are missing files in your project. Double-click each row to locate a file.</source>
        <translation>Ve vašem projektu chybí soubory. Dvakrát klepněte na každý řádek pro nalezení souboru.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="78"/>
        <source>This looks at every file in a folder to see if it matches any of the missing files.</source>
        <translation>Toto se dívá na každý soubor ve složce, aby se vidělo, zda odpovídá některému z chybějících souborů.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="81"/>
        <source>Search in Folder...</source>
        <translation>Hledat ve složce...</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="43"/>
        <source>Missing</source>
        <translation>Chybí</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="44"/>
        <source>Replacement</source>
        <translation>Náhrada</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="58"/>
        <source>Open File</source>
        <translation>Otevřít soubor</translation>
    </message>
</context>
<context>
    <name>Video4LinuxWidget</name>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="36"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="43"/>
        <source>Set the path to the video device file</source>
        <translation>Nastavit cestu k souboru zařízení videa</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="46"/>
        <source>/dev/video0</source>
        <translation>/dev/video0</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="72"/>
        <source>Video4Linux</source>
        <translation>Video4Linux</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="82"/>
        <source>fps</source>
        <translation>fps</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="102"/>
        <source>Height</source>
        <translation>Výška</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="115"/>
        <source>Frame rate</source>
        <translation>Snímková rychlost</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="125"/>
        <source>Resolution</source>
        <translation>Rozlišení</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="135"/>
        <source>Device</source>
        <translation>Zařízení</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="145"/>
        <source>TV Tuner</source>
        <translation>TV tuner</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="157"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="167"/>
        <source>Set the television standard</source>
        <translation>Nastavit televizní standard</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="171"/>
        <source>Automatic</source>
        <translation>Automaticky</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="176"/>
        <source>NTSC</source>
        <translation>NTSC</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="181"/>
        <source>PAL</source>
        <translation>PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="186"/>
        <source>SECAM</source>
        <translation>SECAM</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="194"/>
        <source>Channel</source>
        <translation>Kanál</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="213"/>
        <source>Audio Input</source>
        <translation>Zvukový vstup</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="223"/>
        <source>Width</source>
        <translation>Šířka</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="236"/>
        <source>pixels</source>
        <translation>pixelů</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="249"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="257"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="262"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="267"/>
        <source>ALSA</source>
        <translation>ALSA</translation>
    </message>
</context>
<context>
    <name>VideoHistogramScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="103"/>
        <source>Luma</source>
        <translation>Svítivost</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="108"/>
        <source>Red</source>
        <translation>Červená</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="113"/>
        <source>Green</source>
        <translation>Zelená</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="118"/>
        <source>Blue</source>
        <translation>Modrá</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="205"/>
        <source>Value: %1
IRE: %2</source>
        <translation>Hodnota: %1
IRE: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="207"/>
        <source>Value: %1</source>
        <translation>Hodnota: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="215"/>
        <source>Video Histogram</source>
        <translation>Histogram obrazu</translation>
    </message>
</context>
<context>
    <name>VideoQualityJob</name>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="39"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="41"/>
        <source>Open original and encoded side-by-side in the Shotcut player</source>
        <translation>Otevřít vedle sebe původní a zakódovaný soubor v přehrávači Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="45"/>
        <source>View Report</source>
        <translation>Zobrazit zprávu</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="49"/>
        <source>Show In Files</source>
        <translation>Ukázat v souborech</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="53"/>
        <source>Show In Folder</source>
        <translation>Ukázat ve složce</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="57"/>
        <source>Measure %1</source>
        <translation>Měřit %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="96"/>
        <source>Video Quality Measurement</source>
        <translation>Měření jakosti obrazu</translation>
    </message>
</context>
<context>
    <name>VideoRgbParadeScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="132"/>
        <source>255</source>
        <translation>255</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="136"/>
        <source>191</source>
        <translation>191</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="140"/>
        <source>127</source>
        <translation>127</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="144"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="148"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="158"/>
        <source>Red</source>
        <translation>Červená</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="160"/>
        <source>Green</source>
        <translation>Zelená</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="162"/>
        <source>Blue</source>
        <translation>Modrá</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="173"/>
        <source>Channel: %1
Pixel: %2
Value: %3</source>
        <translation>Kanál: %1
Obrazový bod: %2
Hodnota: %3</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="175"/>
        <source>Channel: %1
Value: %2</source>
        <translation>Kanál: %1
Hodnota: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="182"/>
        <source>Video RGB Parade</source>
        <translation>Obrazová přehlídka RGB</translation>
    </message>
</context>
<context>
    <name>VideoRgbWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="128"/>
        <source>255</source>
        <translation>255</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="132"/>
        <source>191</source>
        <translation>191</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="136"/>
        <source>127</source>
        <translation>127</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="140"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="144"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="159"/>
        <source>Pixel: %1
Value: %2</source>
        <translation>Obrazový bod: %1
Hodnota: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="161"/>
        <source>Value: %1</source>
        <translation>Hodnota: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="168"/>
        <source>Video RGB Waveform</source>
        <translation>Obrazová vlna RGB</translation>
    </message>
</context>
<context>
    <name>VideoVectorScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videovectorscopewidget.cpp" line="53"/>
        <source>Video Vector</source>
        <translation>Obrazový vektor</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videovectorscopewidget.cpp" line="243"/>
        <source>U: %1
V: %2</source>
        <translation>U: %1
V: %2</translation>
    </message>
</context>
<context>
    <name>VideoWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="120"/>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="124"/>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="125"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="144"/>
        <source>Pixel: %1
IRE: %2</source>
        <translation>Pixel: %1
IRE: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="146"/>
        <source>IRE: %1</source>
        <translation>IRE: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="153"/>
        <source>Video Waveform</source>
        <translation>Obrazová vlna</translation>
    </message>
</context>
<context>
    <name>VideoZoomScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="123"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="125"/>
        <source>y</source>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="128"/>
        <source>R</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="130"/>
        <source>G</source>
        <translation>G</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="132"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="135"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="137"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="139"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="157"/>
        <source>Pick a pixel from the source player</source>
        <translation>Sebrat obrazový bod z přehrávače zdroje</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="164"/>
        <source>Lock/Unlock the selected pixel</source>
        <translation>Zamknout/Odemknout vybraný obrazový bod</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="273"/>
        <source>%1x</source>
        <translation>%1x</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="321"/>
        <source>Video Zoom</source>
        <translation>Zvětšení obrazu</translation>
    </message>
</context>
<context>
    <name>WhisperJob</name>
    <message>
        <location filename="../src/jobs/whisperjob.cpp" line="94"/>
        <source>SRT</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>audioloudnessscope</name>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="186"/>
        <source>Momentary Loudness.</source>
        <translation>Chvilková hlasitost.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="229"/>
        <source>Short-term Loudness.</source>
        <translation>Krátkodobá hlasitost.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="272"/>
        <source>Integrated Loudness.</source>
        <translation>Jednotná hlasitost.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="315"/>
        <source>Loudness Range.</source>
        <translation>Rozsah hlasitosti.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="358"/>
        <source>Peak.</source>
        <translation>Vrchol.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="401"/>
        <source>True Peak.</source>
        <translation>Opravdový vrchol.</translation>
    </message>
</context>
<context>
    <name>filterview</name>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="173"/>
        <source>Select a clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="193"/>
        <source>Add a filter</source>
        <translation>Přidat filtr</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="210"/>
        <source>Remove selected filter</source>
        <translation>Odstranit vybraný filtr</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="232"/>
        <source>Copy filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="247"/>
        <source>Paste filters</source>
        <translation>Vložit filtry</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="262"/>
        <source>Save a filter set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="284"/>
        <source>Move filter up</source>
        <translation>Posunout filtr nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="299"/>
        <source>Move filter down</source>
        <translation>Posunout filtr dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="326"/>
        <source>Deselect the filter</source>
        <translation>Zrušit výběr filtru</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Fill the screen with the Shotcut window.</source>
        <translation>Vyplnit obrazovku oknem Shotcutu.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="158"/>
        <source>Hide upgrade prompt and menu item.</source>
        <translation>Skrýt výzvu k povýšení a položku v nabídce</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="162"/>
        <source>Run Glaxnimate instead of Shotcut.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <source>Use GPU processing.</source>
        <translation>Použít zpracování GPU.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="169"/>
        <source>Clear Recent on Exit</source>
        <translation>Vyprázdnit nedávné při ukončení</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="174"/>
        <source>The directory for app configuration and data.</source>
        <translation>Adresář pro nastavení programu a data.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="175"/>
        <source>directory</source>
        <translation>Adresář</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="179"/>
        <source>The scale factor for a high-DPI screen</source>
        <translation>Měřítko pro obrazovku s vysokým rozlišením</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="181"/>
        <source>number</source>
        <translation>číslo</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="185"/>
        <source>A semicolon-separated list of scale factors for each screen</source>
        <translation>Středníkem oddělený seznam měřítek pro každou obrazovku</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="188"/>
        <source>list</source>
        <translation>seznam</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="192"/>
        <source>How to handle a fractional display scale: %1</source>
        <translation>Jak zacházet s měřítkem částečného zobrazení: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="194"/>
        <location filename="../src/main.cpp" line="202"/>
        <location filename="../src/main.cpp" line="210"/>
        <source>string</source>
        <translation>řetězec</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="200"/>
        <location filename="../src/main.cpp" line="208"/>
        <source>Which operating system audio API to use: %1</source>
        <translation>Které rozhraní API zvuku operačního systému použít: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="216"/>
        <source>Zero or more files or folders to open</source>
        <translation>Nulový počet nebo více souborů nebo složek k otevření</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="460"/>
        <source>Loading plugins...</source>
        <translation>Nahrávají se přídavné moduly...</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="437"/>
        <source>Expiring cache...</source>
        <translation>Vypršení platnosti vyrovnávací paměti...</translation>
    </message>
</context>
<context>
    <name>meta</name>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="22"/>
        <source>Alpha Channel: Adjust</source>
        <translation>Alfa kanál: Přizpůsobit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="23"/>
        <source>transparency shave shrink grow soft feather</source>
        <comment>search keywords for the Alpha Channel: Adjust video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="22"/>
        <source>Alpha Channel: View</source>
        <translation>Alfa kanál: Vidět</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="23"/>
        <source>transparency</source>
        <comment>search keywords for the Alpha Channel: View video filter</comment>
        <translation>Průhlednost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="7"/>
        <source>Balance</source>
        <translation>Vyvážení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="8"/>
        <source>pan channel mixer</source>
        <comment>search keywords for the Balance audio filter</comment>
        <translation>Plynule sledovat směšovač kanálů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="19"/>
        <location filename="../src/qml/filters/reframe/meta.qml" line="22"/>
        <source>Position</source>
        <translation>Poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="7"/>
        <source>Band Pass</source>
        <translation>Pásmo propustnosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the Band Pass audio filter</comment>
        <translation>Kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="18"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="18"/>
        <source>Center Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="26"/>
        <source>Bandwidth</source>
        <translation>Šířka pásma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/meta.qml" line="8"/>
        <source>Bass &amp; Treble</source>
        <translation>Hloubky a výšky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="7"/>
        <source>Copy Channel</source>
        <translation>Kopírování kanálu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="8"/>
        <source>duplicate</source>
        <comment>search keywords for the Copy Channel audio filter</comment>
        <translation>Zdvojit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="7"/>
        <source>Compressor</source>
        <translation>Zmenšovač dynamického rozsahu původního signálu (kompresor)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="8"/>
        <source>loudness dynamics range</source>
        <comment>search keywords for the Compressor audio filter</comment>
        <translation>Rozsah dynamiky hlasitosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="7"/>
        <source>Delay</source>
        <translation>Ozvěna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="8"/>
        <source>time echo</source>
        <comment>search keywords for the Delay audio filter</comment>
        <translation>Časová ozvěna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="7"/>
        <source>Expander</source>
        <translation>Zvětšovač dynamického rozsahu původního signálu (expander)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="8"/>
        <source>dynamics range</source>
        <comment>search keywords for the Expander audio filter</comment>
        <translation>Dynamický rozsah</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="8"/>
        <source>Fade In Audio</source>
        <translation>Postupně zesílit zvuk</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Fade In audio filter</comment>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="8"/>
        <source>Fade Out Audio</source>
        <translation>Postupně zeslabit zvuk</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Fade Out audio filter</comment>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="7"/>
        <source>Gain / Volume</source>
        <translation>Zesílení/Hlasitost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Gain/Volume audio filter</comment>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="20"/>
        <location filename="../src/qml/filters/brightness/meta.qml" line="20"/>
        <location filename="../src/qml/filters/contrast/meta.qml" line="21"/>
        <location filename="../src/qml/filters/dither/meta.qml" line="19"/>
        <location filename="../src/qml/filters/opacity/meta.qml" line="20"/>
        <location filename="../src/qml/filters/threshold/meta.qml" line="18"/>
        <source>Level</source>
        <translation>Úroveň</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="7"/>
        <source>High Pass</source>
        <translation>Horní pásmová propust</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the High Pass audio filter</comment>
        <translation>Kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="18"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="18"/>
        <source>Cutoff</source>
        <translation>Odstřihnutí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="34"/>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="34"/>
        <source>Rolloff rate</source>
        <translation>Rychlost sjetí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="41"/>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="33"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="33"/>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="25"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="41"/>
        <source>Wetness</source>
        <translation>Vlhkost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="7"/>
        <source>Limiter</source>
        <translation>Omezovač (limiter)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="8"/>
        <source>dynamics range loudness</source>
        <comment>search keywords for the Limiter audio filter</comment>
        <translation>Dynamický rozsah hlasitosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="7"/>
        <source>Low Pass</source>
        <translation>Dolní pásmová propust</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the Low Pass audio filter</comment>
        <translation>Kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="7"/>
        <source>Downmix</source>
        <translation>Sloučení signálů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="8"/>
        <source>stereo mixdown channel</source>
        <comment>search keywords for the Downmix audio filter</comment>
        <translation>Stereofonní kanál pro finální mixáž</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="8"/>
        <source>Mute</source>
        <translation>Ztlumit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="9"/>
        <source>silent silence volume</source>
        <comment>search keywords for the Mute audio filter</comment>
        <translation>Tichá hlasitost ticha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="7"/>
        <source>Normalize: One Pass</source>
        <translation>Normalizovat: Jeden průchod</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="8"/>
        <source>volume loudness gain dynamics</source>
        <comment>search keywords for the Normalize: One Pass audio filter</comment>
        <translation>Dynamika zesílení hlasitosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="7"/>
        <source>Normalize: Two Pass</source>
        <translation>Normalizovat: Dva průchody</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="9"/>
        <source>volume loudness gain dynamics</source>
        <comment>search keywords for the Normalize: Two Pass audio filter</comment>
        <translation>Dynamika zesílení hlasitosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="7"/>
        <source>Notch</source>
        <translation>Pásmová zádrž s úzkým kmitočtovým pásmem</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="8"/>
        <source>frequency pass</source>
        <comment>search keywords for the Notch audio filter</comment>
        <translation>Kmitočtová propust</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="7"/>
        <source>Pan</source>
        <translation>Vyvážení (panorama)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="8"/>
        <source>stereo balance channel mixer</source>
        <comment>search keywords for the Pan audio filter</comment>
        <translation>Směšovač stereofonních kanálů vyvážení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="7"/>
        <source>Reverb</source>
        <translation>Dozvuk</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="9"/>
        <source>delay time echo</source>
        <comment>search keywords for the Reverb audio filter</comment>
        <translation>Doba zpoždění ozvěny</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="18"/>
        <source>Room size</source>
        <translation>Místnost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="26"/>
        <source>Reverb time</source>
        <translation>Čas dozvuku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="34"/>
        <source>Damping</source>
        <translation>Tlumení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="42"/>
        <source>Input bandwidth</source>
        <translation>Šířka pásma vstupu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="50"/>
        <source>Dry signal level</source>
        <translation>Úroveň nezpracovaného signálu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="58"/>
        <source>Early reflection level</source>
        <translation>Úroveň prvotních odrazů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="66"/>
        <source>Tail level</source>
        <translation>Úroveň koncové části</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="7"/>
        <source>Swap Channels</source>
        <translation>Výměna kanálů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="9"/>
        <source>switch stereo</source>
        <comment>search keywords for the Swap Channels audio filter</comment>
        <translation>Přepnout stereo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="23"/>
        <source>Chroma Key: Simple</source>
        <translation>Barevné zakrývání: Jednoduché</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="24"/>
        <source>green blue screen</source>
        <comment>search keywords for the Chroma Key: Simple video filter</comment>
        <translation>Zelenomodrá obrazovka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="6"/>
        <source>Brightness</source>
        <translation>Jas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="8"/>
        <source>lightness value exposure</source>
        <comment>search keywords for the Brightness video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="6"/>
        <source>Color Grading</source>
        <translation>Srovnání barev</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="7"/>
        <source>correct shadows lift midtones gamma highlights gain hue lightness brightness value</source>
        <comment>search keywords for the Color Grading video filter</comment>
        <translation>Opravit stíny, zvednout střední tóny gama světla, zesílit hodnotu jasu světlosti odstínu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="17"/>
        <source>Shadows (Lift)</source>
        <translation>Stíny</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="22"/>
        <source>Midtones (Gamma)</source>
        <translation>Středové tóny (gamma)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="27"/>
        <source>Highlights (Gain)</source>
        <translation>Světlá místa (zesílení)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="6"/>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="7"/>
        <source>variation value</source>
        <comment>search keywords for the Contrast video filter</comment>
        <translation>Hodnota odchylky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="6"/>
        <source>Old Film: Dust</source>
        <translation>Starý film: Prach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="7"/>
        <source>noise dirt hair fiber</source>
        <comment>search keywords for the Old Film: Dust video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="7"/>
        <source>Text: Simple</source>
        <translation>Text: Jednoduchý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="8"/>
        <source>type font timecode timestamp date filename</source>
        <comment>search keywords for the Text: Simple video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="25"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="40"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="26"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="25"/>
        <source>Font color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="31"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="46"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="32"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="31"/>
        <source>Outline</source>
        <translation>Obrys</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="37"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="52"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="38"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="37"/>
        <source>Background</source>
        <translation>Pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="20"/>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="20"/>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="36"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="35"/>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="20"/>
        <location filename="../src/qml/filters/richtext/meta.qml" line="21"/>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="20"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="21"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="20"/>
        <source>Position / Size</source>
        <translation>Poloha/Velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="7"/>
        <source>Fade In Video</source>
        <translation>Roztmívat obraz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="8"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="8"/>
        <source>brightness lightness opacity alpha</source>
        <comment>search keywords for the Fade In video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="7"/>
        <source>Fade Out Video</source>
        <translation>Zatmívat obraz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="8"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="8"/>
        <source>brightness lightness opacity alpha</source>
        <comment>search keywords for the Fade Out video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="6"/>
        <source>Old Film: Grain</source>
        <translation>Starý film: Zrno</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="7"/>
        <source>dots particles noise dirt</source>
        <comment>search keywords for the Old Film: Grain video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="22"/>
        <source>Hue/Lightness/Saturation</source>
        <translation>Odstín/světlost/sytost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="23"/>
        <source>color value desaturate grayscale</source>
        <comment>search keywords for the Hue/Lightness/Saturation video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="34"/>
        <source>Hue</source>
        <translation>Odstín</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="41"/>
        <source>Lightness</source>
        <translation>Světlost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="48"/>
        <source>Saturation</source>
        <translation>Sytost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="6"/>
        <source>Invert Colors</source>
        <translation>Obrácení barev</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="7"/>
        <source>reverse opposite negative</source>
        <comment>search keywords for the Invert Colors video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="22"/>
        <source>Key Spill: Advanced</source>
        <translation>Čištění masky: Pokročilé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="23"/>
        <source>chroma alpha clean suppress</source>
        <comment>search keywords for the Key Spill: Advanced video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="22"/>
        <source>Lens Correction</source>
        <translation>Oprava soustavy čoček</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="23"/>
        <source>deform lens distort wide angle panoramic hemispherical fisheye</source>
        <comment>search keywords for the Lens Correction video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="34"/>
        <source>X Center</source>
        <translation>Střed X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="41"/>
        <source>Y Center</source>
        <translation>Střed Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="48"/>
        <source>Correction at Center</source>
        <translation>Oprava ve středu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="55"/>
        <source>Correction at Edges</source>
        <translation>Oprava na okrajích</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="6"/>
        <source>Old Film: Scratches</source>
        <translation>Starý film: Škrábance</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="7"/>
        <source>noise projector lines defect</source>
        <comment>search keywords for the Old Film: Scratches video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/meta.qml" line="22"/>
        <source>LUT (3D)</source>
        <translation>LUT (3D)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/meta.qml" line="23"/>
        <source>lookup table color</source>
        <comment>search keywords for the LUT (3D) video filter</comment>
        <translation>Vyhledávací tabulka barev</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/meta.qml" line="6"/>
        <source>Mask</source>
        <translation>Maska</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="7"/>
        <source>360: Rectilinear to Equirectangular</source>
        <translation>360: Obdélníkový na Rovnostranný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="8"/>
        <source>spherical projection</source>
        <comment>search keywords for the 360: Rectilinear to Equirectangular video filter</comment>
        <translation>Kulové promítání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="20"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="17"/>
        <location filename="../src/qml/filters/nosync/meta.qml" line="26"/>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="41"/>
        <source>Horizontal</source>
        <translation>Vodorovný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="27"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="24"/>
        <location filename="../src/qml/filters/nosync/meta.qml" line="19"/>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="34"/>
        <source>Vertical</source>
        <translation>Svislý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="7"/>
        <source>Mid-Side Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="8"/>
        <source>middle stereo microphone</source>
        <comment>search keywords for the Mid-Side Matrix audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="18"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="31"/>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="34"/>
        <source>Width</source>
        <translation>Šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/meta.qml" line="38"/>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="41"/>
        <source>Height</source>
        <translation>Výška</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="6"/>
        <source>Mirror</source>
        <translation>Zrcadlení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="7"/>
        <source>horizontal flip transpose flop</source>
        <comment>search keywords for the Mirror video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="22"/>
        <source>Mosaic</source>
        <translation>Mozaika</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="23"/>
        <source>pixelize pixelate</source>
        <comment>search keywords for the Mosaic video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="6"/>
        <source>Diffusion</source>
        <translation>Rozptyl</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="7"/>
        <source>blur smooth clean beauty</source>
        <comment>search keywords for the Diffusion video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="6"/>
        <source>Old Film: Projector</source>
        <translation>Starý film: Promítací přístroj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="7"/>
        <source>glitch flashing brightness vertical slip</source>
        <comment>search keywords for the Old Film: Projector video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="43"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="58"/>
        <location filename="../src/qml/filters/opacity/meta.qml" line="7"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="44"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="43"/>
        <source>Opacity</source>
        <translation>Neprůhlednost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta.qml" line="8"/>
        <source>alpha transparent translucent</source>
        <comment>search keywords for the Opacity video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="7"/>
        <source>Rotate and Scale</source>
        <translation>Otočit a změnit velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="7"/>
        <source>matte stencil alpha rectangle ellipse circle triangle diamond</source>
        <comment>search keywords for the Mask: Simple Shape video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="20"/>
        <source>Size &amp; Position</source>
        <translation>Velikost a poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="26"/>
        <location filename="../src/qml/filters/rotate/meta.qml" line="18"/>
        <source>Rotation</source>
        <translation>Otočení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="25"/>
        <source>Scale</source>
        <translation>Měřítko</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="33"/>
        <source>X offset</source>
        <translation>Posun x</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="37"/>
        <source>Y offset</source>
        <translation>Posun y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="22"/>
        <source>Chroma Key: Advanced</source>
        <translation>Barevné zakrývání: Pokročilé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="23"/>
        <source>green blue screen</source>
        <comment>search keywords for the Chroma Key: Advanced video filter</comment>
        <translation>Zelenomodrá obrazovka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="6"/>
        <source>Sepia Tone</source>
        <translation>Hnědý odstín</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="7"/>
        <source>color old photograph print</source>
        <comment>search keywords for the Sepia Tone video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/meta.qml" line="6"/>
        <source>Sketch</source>
        <translation>Náčrtek</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/meta.qml" line="7"/>
        <source>drawing painting cartoon</source>
        <comment>search keywords for the Sketch video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="23"/>
        <source>Key Spill: Simple</source>
        <translation>Čištění masky: Jednoduché</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="24"/>
        <source>chroma alpha clean suppress</source>
        <comment>search keywords for the Key Spill: Simple video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="6"/>
        <source>Stabilize</source>
        <translation>Ustálení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="7"/>
        <source>smooth deshake</source>
        <comment>search keywords for the Stabilize video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="6"/>
        <source>Old Film: %1</source>
        <translation>Starý film: %1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="7"/>
        <source>projector movie</source>
        <comment>search keywords for the Old Film: Technocolor video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/unpremultiply/meta.qml" line="22"/>
        <source>Unpremultiply Alpha</source>
        <translation>Zrušit přednásobení alfy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/unpremultiply/meta.qml" line="23"/>
        <source>disassociate associated straight</source>
        <comment>search keywords for the Unpremultiply Alpha video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="6"/>
        <source>Wave</source>
        <translation>Vlna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="7"/>
        <source>distort deform frequency water warp bend</source>
        <comment>search keywords for the Wave video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="7"/>
        <source>Crop: Circle</source>
        <translation>Oříznutí: Kruh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="8"/>
        <source>trim remove oval ellipse</source>
        <comment>search keywords for the Crop: Circle video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="26"/>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="18"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="6"/>
        <source>Halftone</source>
        <translation>Půltón</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="7"/>
        <source>360: Hemispherical to Equirectangular</source>
        <translation>360: Polokulovitý na rovnostranný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="9"/>
        <source>spherical projection dual fisheye</source>
        <comment>search keywords for the 360: Hemispherical to Equirectangular video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="48"/>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="19"/>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="24"/>
        <location filename="../src/qml/filters/halftone/meta.qml" line="19"/>
        <source>Radius</source>
        <translation>Poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="55"/>
        <source>Front X</source>
        <translation>Čelní X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="62"/>
        <source>Front Y</source>
        <translation>Čelní Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="69"/>
        <source>Front Up</source>
        <translation>Čelní nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="76"/>
        <source>Back X</source>
        <translation>Zadní X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="83"/>
        <source>Back Y</source>
        <translation>Zadní Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="90"/>
        <source>Back Up</source>
        <translation>Zadní nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="97"/>
        <source>Nadir Radius</source>
        <translation>Poloměr podnožníku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="104"/>
        <source>Nadir Start</source>
        <translation>Začátek podnožníku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="7"/>
        <source>noise dots newsprint</source>
        <comment>search keywords for the Halftone video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="26"/>
        <source>Cyan</source>
        <translation>Modrozelená</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="33"/>
        <source>Magenta</source>
        <translation>Červenorudá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="40"/>
        <source>Yellow</source>
        <translation>Žlutá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="7"/>
        <source>Spot Remover</source>
        <translation>Odstraňovač skvrn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="8"/>
        <source>delogo dirt clean watermark</source>
        <comment>search keywords for the Spot Remover video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/meta.qml" line="7"/>
        <source>Timer</source>
        <translation>Časovač</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/meta.qml" line="8"/>
        <source>text seconds timestamp</source>
        <comment>search keywords for the Timer video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="6"/>
        <source>Levels</source>
        <comment>Levels video filter</comment>
        <translation>Úrovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="7"/>
        <source>gamma value black white color</source>
        <comment>search keywords for the Levels video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="18"/>
        <source>Input Black</source>
        <translation>Vstupní černá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="25"/>
        <source>Input White</source>
        <translation>Vstupní bílá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="32"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="6"/>
        <source>Mask: Simple Shape</source>
        <translation>Maska: Jednoduchý tvar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_apply/meta.qml" line="6"/>
        <source>Mask: Apply</source>
        <translation>Maska: Použít</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_apply/meta.qml" line="7"/>
        <source>matte stencil alpha confine composite bounce</source>
        <comment>search keywords for the Mask: Apply video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="6"/>
        <source>Mask: From File</source>
        <translation>Maska: Ze souboru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="7"/>
        <source>matte stencil alpha luma wipe custom</source>
        <comment>search keywords for the Mask: From File video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="7"/>
        <source>Noise Gate</source>
        <translation>Propust šumu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="8"/>
        <source>hum hiss distortion clean</source>
        <comment>search keywords for the Noise Gate audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="18"/>
        <source>Key Filter: Low Frequency</source>
        <translation>Filtr klíče: Nízký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="25"/>
        <source>Key Filter: High Frequency</source>
        <translation>Filtr klíče: Vysoký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="32"/>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="20"/>
        <location filename="../src/qml/filters/threshold/meta.qml" line="6"/>
        <source>Threshold</source>
        <translation>Práh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="39"/>
        <source>Attack</source>
        <translation>Náběh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="46"/>
        <source>Hold</source>
        <translation>Držet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="53"/>
        <source>Decay</source>
        <translation>Slábnout</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="60"/>
        <source>Range</source>
        <translation>Rozsah</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/meta.qml" line="7"/>
        <source>Audio Waveform Visualization</source>
        <translation>Znázornění zvukové vlny</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/meta.qml" line="8"/>
        <source>music visualizer reactive</source>
        <comment>search keywords for the Audio Waveform Visualization video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="22"/>
        <source>Chroma Hold</source>
        <translation>Podržení chromy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="23"/>
        <source>color hue select choose pick</source>
        <comment>search keywords for the Chroma Hold video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="34"/>
        <source>Distance</source>
        <translation>Vzdálenost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="6"/>
        <source>Grid</source>
        <translation>Mřížka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="7"/>
        <source>repeat</source>
        <comment>search keywords for the Grid video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="18"/>
        <source>Rows</source>
        <translation>Řádky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="25"/>
        <source>Columns</source>
        <translation>Sloupce</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="22"/>
        <source>Distort</source>
        <translation>Zkreslit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="23"/>
        <source>deform wiggle wave</source>
        <comment>search keywords for the Distort video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="34"/>
        <source>Amplitude</source>
        <translation>Rozkmit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="41"/>
        <location filename="../src/qml/filters/glitch/meta.qml" line="34"/>
        <source>Frequency</source>
        <translation>Kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="48"/>
        <source>Velocity</source>
        <translation>Síla tónu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="22"/>
        <source>Glitch</source>
        <translation>Zádrhel</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="23"/>
        <source>defect broken distort</source>
        <comment>search keywords for the Glitch video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="41"/>
        <source>Block height</source>
        <translation>Výška bloku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="48"/>
        <source>Shift intensity</source>
        <translation>Síla posunu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="55"/>
        <source>Color intensity</source>
        <translation>Ostrost barvy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="22"/>
        <source>RGB Shift</source>
        <translation>Posun RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="23"/>
        <source>glitch chroma analog split</source>
        <comment>search keywords for the RGB Shift video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="22"/>
        <source>Blur: Exponential</source>
        <translation>Rozmazání: Exponenciální</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Exponential video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="7"/>
        <source>360: Equirectangular to Stereographic</source>
        <translation>360: Rovnostranný na Stereografický</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="8"/>
        <source>spherical projection tiny small planet</source>
        <comment>search keywords for the 360: Equirectangular to Stereographic video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="49"/>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="35"/>
        <location filename="../src/qml/filters/blur_gaussian/meta.qml" line="34"/>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="35"/>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="35"/>
        <source>Amount</source>
        <translation>Množství</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta.qml" line="22"/>
        <source>Blur: Gaussian</source>
        <translation>Rozmazání: Gaussovské</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="22"/>
        <source>Blur: Low Pass</source>
        <translation>Rozmazání: Dolní pásmová propust</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Low Pass video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="6"/>
        <source>Crop: Source</source>
        <translation>Oříznutí: Zdroj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="7"/>
        <source>trim remove edges</source>
        <comment>search keywords for the Crop: Source video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta.qml" line="6"/>
        <source>Flip</source>
        <translation>Převrátit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta.qml" line="7"/>
        <source>vertical flop transpose rotate</source>
        <comment>search keywords for the Flip video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="22"/>
        <source>Reduce Noise: HQDN3D</source>
        <translation>Omezit šum: HQDN3D</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="23"/>
        <source>denoise artifact dirt smooth</source>
        <comment>search keywords for the Reduce Noise: HQDN3D video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="34"/>
        <source>Spatial</source>
        <translation>Prostorový</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="41"/>
        <source>Temporal</source>
        <translation>Časový</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_fast/meta.qml" line="22"/>
        <source>Noise: Fast</source>
        <translation>Šum: Rychlý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_fast/meta.qml" line="23"/>
        <source>dirt grunge</source>
        <comment>search keywords for the Noise: Fast video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="22"/>
        <source>Noise: Keyframes</source>
        <translation>Šum: Klíčové snímky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="23"/>
        <source>dirt grunge</source>
        <comment>search keywords for the Noise: Keyframes video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="22"/>
        <source>Reduce Noise: Smart Blur</source>
        <translation>Omezit šum: Chytré rozmazání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="23"/>
        <source>denoise artifact clean</source>
        <comment>search keywords for the Reduce Noise: Smart Blur video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="7"/>
        <source>Crop: Rectangle</source>
        <translation>Oříznutí: Obdélník</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="8"/>
        <source>trim remove square</source>
        <comment>search keywords for the Crop: Rectangle video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="25"/>
        <source>Corner radius</source>
        <translation>Poloměr rohu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="32"/>
        <source>Padding color</source>
        <translation>Barva prázdného okraje</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/meta.qml" line="6"/>
        <source>Blend Mode</source>
        <translation>Režim smíchání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/meta.qml" line="7"/>
        <source>blending composite porter duff</source>
        <comment>search keywords for the Blend Mode video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/meta.qml" line="6"/>
        <source>Dither</source>
        <translation>Chvění</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/meta.qml" line="7"/>
        <source>noise dots</source>
        <comment>search keywords for the Dither video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="22"/>
        <source>Elastic Scale</source>
        <translation>Pružná stupnice</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="23"/>
        <source>stretch nonlinear</source>
        <comment>search keywords for the Elastic Scale video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="35"/>
        <source>Center</source>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="42"/>
        <source>Linear width</source>
        <translation>Lineární šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="49"/>
        <source>Linear scale factor</source>
        <translation>Lineární měřítko</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="56"/>
        <source>Non-Linear scale factor</source>
        <translation>Nelineární měřítko</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="6"/>
        <source>Posterize</source>
        <translation>Posterizace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="7"/>
        <source>reduce colors banding cartoon</source>
        <comment>search keywords for the Posterize video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="19"/>
        <source>Levels</source>
        <comment>Posterize filter</comment>
        <translation>Úrovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nervous/meta.qml" line="6"/>
        <source>Nervous</source>
        <translation>Podrážděný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nervous/meta.qml" line="7"/>
        <source>random shake twitch glitch</source>
        <comment>search keywords for the Nervous video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nosync/meta.qml" line="6"/>
        <source>No Sync</source>
        <translation>Žádné seřízení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nosync/meta.qml" line="7"/>
        <source>horizontal vertical synchronization slip analog</source>
        <comment>search keywords for the No Sync video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/trails/meta.qml" line="6"/>
        <source>Trails</source>
        <translation>Stopy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/trails/meta.qml" line="7"/>
        <source>temporal mix psychedelic motion blur</source>
        <comment>search keywords for the Trails video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="22"/>
        <source>Vertigo</source>
        <translation>Závrať</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="23"/>
        <source>temporal mix dizzy psychedelic</source>
        <comment>search keywords for the Vertigo video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="35"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="41"/>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="42"/>
        <source>Zoom</source>
        <translation>Zvětšení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="6"/>
        <source>Choppy</source>
        <translation>Zčeřený</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="7"/>
        <source>fps framerate</source>
        <comment>search keywords for the Choppy video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="19"/>
        <source>Repeat</source>
        <translation>Opakovat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/meta.qml" line="7"/>
        <source>Gradient</source>
        <translation>Přechod</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/meta.qml" line="8"/>
        <source>graduated color spectrum</source>
        <comment>search keywords for the Gradient video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/scanlines/meta.qml" line="6"/>
        <source>Scan Lines</source>
        <translation>Řádek obrazu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/scanlines/meta.qml" line="7"/>
        <source>analog horizontal television</source>
        <comment>search keywords for the Scan Lines video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="7"/>
        <source>360: Equirectangular Mask</source>
        <translation>360: Rovnostranná maska</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="9"/>
        <source>spherical matte stencil</source>
        <comment>search keywords for the 360: Equirectangular Mask video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="20"/>
        <source>Horizontal Start</source>
        <translation>Vodorovný začátek</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="27"/>
        <source>Horizontal End</source>
        <translation>Vodorovný konec</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="34"/>
        <source>Vertical Start</source>
        <translation>Svislý začátek</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="41"/>
        <source>Vertical End</source>
        <translation>Svislý konec</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="7"/>
        <source>360: Equirectangular to Rectilinear</source>
        <translation>360: Rovnostranný na Obdélníkový</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="9"/>
        <source>spherical projection</source>
        <comment>search keywords for the 360: Equirectangular to Rectilinear video filter</comment>
        <translation>Kulové promítání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="7"/>
        <source>Ambisonic Decoder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="9"/>
        <source>spatial surround binaural</source>
        <comment>search keywords for the Ambisonic Decoder audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="20"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="21"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="21"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="20"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="21"/>
        <source>Yaw</source>
        <translation>Yaw</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="27"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="28"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="28"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="27"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="28"/>
        <source>Pitch</source>
        <comment>rotation around the side-to-side axis (roll, pitch, yaw)</comment>
        <translation>Výška tónu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="34"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="35"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="35"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="34"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="35"/>
        <source>Roll</source>
        <translation>Rolovat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="42"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="42"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="41"/>
        <source>FOV</source>
        <comment>field of view</comment>
        <translation>Zorné pole</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="49"/>
        <location filename="../src/qml/filters/fisheye/meta.qml" line="22"/>
        <source>Fisheye</source>
        <translation>Rybí oko</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="22"/>
        <source>Corner Pin</source>
        <translation>Roh špendlík</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="23"/>
        <source>stretch distort pinch twist deform</source>
        <comment>search keywords for the Corner Pin video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="35"/>
        <source>Corners</source>
        <translation>Rohy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="40"/>
        <source>Stretch X</source>
        <translation>Protáhnout X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="47"/>
        <source>Stretch Y</source>
        <translation>Protáhnout Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="54"/>
        <source>Feathering</source>
        <translation>Měkký výběrový okraj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/meta.qml" line="7"/>
        <source>360: Stabilize</source>
        <translation>360: Stabilizace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/meta.qml" line="8"/>
        <source>spherical smooth deshake</source>
        <comment>search keywords for the 360: Stabilize video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="7"/>
        <source>360: Transform</source>
        <translation>360: Transformace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="9"/>
        <source>spherical yaw pitch roll</source>
        <comment>search keywords for the 360: Transform video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/meta.qml" line="23"/>
        <source>Reduce Noise: Wavelet</source>
        <translation>Snížení šumu: vlnka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/meta.qml" line="24"/>
        <source>vague denoise artifact dirt</source>
        <comment>search keywords for the Reduce Noise: Wavelet video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="7"/>
        <source>Text: Rich</source>
        <translation>Text: Formátovaný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="8"/>
        <source>type font format overlay</source>
        <comment>search keywords for the Text: Rich video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="26"/>
        <source>Background color</source>
        <translation>Barva pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="7"/>
        <source>Blur: Pad</source>
        <translation>Rozostření: Vsuvka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="8"/>
        <source>pillar echo fill</source>
        <comment>search keywords for the Blur: Pad video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_invert/meta.qml" line="7"/>
        <source>Invert</source>
        <translation>Obrátit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_invert/meta.qml" line="8"/>
        <source>phase</source>
        <comment>search keywords for the Invert audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/meta.qml" line="22"/>
        <source>Reduce Noise: Quantization</source>
        <translation>Snížení šumu: kvantizace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/meta.qml" line="23"/>
        <source>denoise artifact postprocess compress</source>
        <comment>search keywords for the Reduce Noise: Quantization video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="7"/>
        <source>Time Remap</source>
        <translation>Časové přemapování</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="8"/>
        <source>temporal speed ramp reverse fast slow motion</source>
        <comment>search keywords for the Time: Remap filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="21"/>
        <source>Time</source>
        <translation>Čas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/meta.qml" line="23"/>
        <source>Deband</source>
        <translation>Zrušit pásmo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/meta.qml" line="24"/>
        <source>mean average median contour</source>
        <comment>search keywords for the Deband video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="22"/>
        <source>GPS Text</source>
        <translation>Text GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="23"/>
        <source>gpx</source>
        <comment>search keywords for the GPS Text video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reflect/meta.qml" line="6"/>
        <source>Reflect</source>
        <translation>Odrazit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reflect/meta.qml" line="7"/>
        <source>mirror repeat</source>
        <comment>search keywords for the Reflect video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_chromakey/meta.qml" line="22"/>
        <source>Mask: Chroma Key</source>
        <translation>Maska: Klíčové zbarvení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_chromakey/meta.qml" line="23"/>
        <source>matte stencil alpha color</source>
        <comment>search keywords for the Mask: Chroma Key video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="7"/>
        <source>Equalizer: 15-Band</source>
        <translation>Ekvalizér: 15-pásmový</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: 15-Band audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="19"/>
        <source>Equalizer</source>
        <translation>Ekvalizér</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="7"/>
        <source>Equalizer: Parametric</source>
        <translation>Ekvalizér: Parametrický</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: Parametric audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/meta.qml" line="7"/>
        <source>Audio Level Visualization</source>
        <translation>Znázornění úrovně zvuku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/meta.qml" line="8"/>
        <source>music visualizer reactive</source>
        <comment>search keywords for the Audio Level Visualization video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="7"/>
        <source>Equalizer: 3-Band (Bass &amp; Treble)</source>
        <translation>Ekvalizér: 3-pásmový (hloubky a výšky)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: 3-Band audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="7"/>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="19"/>
        <source>Pitch</source>
        <comment>audio pitch or tone</comment>
        <translation>Výška tónu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="9"/>
        <source>frequency tone</source>
        <comment>search keywords for the Pitch audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/meta.qml" line="7"/>
        <source>Stereo Enhancer</source>
        <translation>Zvýrazňovač sterea</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/meta.qml" line="9"/>
        <source>channel spatial delay</source>
        <comment>search keywords for the Stereo Enhancer audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/meta.qml" line="6"/>
        <source>Mask: Draw</source>
        <translation>Maska: Kreslit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/meta.qml" line="7"/>
        <source>rotoscope matte stencil alpha</source>
        <comment>search keywords for the Mask: Draw video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/meta.qml" line="23"/>
        <source>deform lens distort wide angle panoramic hemispherical</source>
        <comment>search keywords for the Fisheye video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="22"/>
        <source>GPS Graphic</source>
        <translation>Grafické znázornění GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="23"/>
        <source>gpx sticker decal gauge map graph speedometer</source>
        <comment>search keywords for the GPS Graphic video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/threshold/meta.qml" line="7"/>
        <source>black white luma</source>
        <comment>search keywords for the Threshold video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/meta.qml" line="6"/>
        <source>Motion Tracker</source>
        <translation>Sledování pohybu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/meta.qml" line="8"/>
        <source>tracking</source>
        <comment>search keywords for the Motion Tracker video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/meta.qml" line="7"/>
        <source>Track Auto Fade Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/meta.qml" line="8"/>
        <source>click splice fade</source>
        <comment>search keywords for the Auto Fade audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/meta.qml" line="7"/>
        <source>Track Seam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/meta.qml" line="8"/>
        <source>click splice seam</source>
        <comment>search keywords for the Seam audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/meta.qml" line="6"/>
        <source>Declick Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/meta.qml" line="8"/>
        <source>declick crackle pop</source>
        <comment>search keywords for the Declick audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/meta.qml" line="7"/>
        <source>Track Auto Fade Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/meta.qml" line="8"/>
        <source>splice fade dip</source>
        <comment>search keywords for the Track Auto Fade Video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="7"/>
        <source>Ambisonic Encoder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="9"/>
        <source>spatial surround panner</source>
        <comment>search keywords for the Ambisonic Encoder audio filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="20"/>
        <source>Azimuth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="27"/>
        <source>Elevation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="6"/>
        <source>Drop Shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="7"/>
        <source></source>
        <comment>search keywords for the Drop Shadow video filter</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="31"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="38"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="22"/>
        <source>Vibrance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="23"/>
        <source>color intensity saturation vibe</source>
        <comment>search keywords for the Vibrance video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="34"/>
        <source>Intensity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="41"/>
        <source>Red</source>
        <translation>Červená</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="48"/>
        <source>Green</source>
        <translation>Zelená</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="55"/>
        <source>Blue</source>
        <translation>Modrá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="7"/>
        <source>Subtitle Burn In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="8"/>
        <source>subtitle overlay burn</source>
        <comment>search keywords for the Subtitle Burn In video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/meta.qml" line="7"/>
        <source>Reframe</source>
        <translation>Přesnímkovat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/meta.qml" line="8"/>
        <source>crop trim remove square vertical portrait</source>
        <comment>search keywords for the Reframe video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/meta.qml" line="7"/>
        <source>Gradient Map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/meta.qml" line="8"/>
        <source>color mapping intensity</source>
        <comment>search keywords for the Gradient Map video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="6"/>
        <source>HSL Primaries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="8"/>
        <source>hue saturation lightness color</source>
        <comment>search keywords for the HSL Primaries video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="18"/>
        <source>Overlap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="25"/>
        <source>Red Hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="32"/>
        <source>Red Saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="39"/>
        <source>Red Lightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="46"/>
        <source>Yellow Hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="53"/>
        <source>Yellow Saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="60"/>
        <source>Yellow Lightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="67"/>
        <source>Green Hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="74"/>
        <source>Green Saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="81"/>
        <source>Green Lightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="88"/>
        <source>Cyan Hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="95"/>
        <source>Cyan Saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="102"/>
        <source>Cyan Lightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="109"/>
        <source>Blue Hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="116"/>
        <source>Blue Saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="123"/>
        <source>Blue Lightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="130"/>
        <source>Magenta Hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="137"/>
        <source>Magenta Saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="144"/>
        <source>Magenta Lightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="6"/>
        <source>HSL Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="8"/>
        <source>hue saturation lightness color primaries</source>
        <comment>search keywords for the HSL Range video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="18"/>
        <source>Blend</source>
        <translation>Smíchat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="25"/>
        <source>Hue Shift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="32"/>
        <source>Saturation Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="39"/>
        <source>Lightness Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="46"/>
        <source>Hue Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="53"/>
        <source>Hue Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="7"/>
        <source>360: Cap Top &amp; Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="9"/>
        <source>spherical fill blur zenith nadir</source>
        <comment>search keywords for the 360: Cap Top &amp; Bottom video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="38"/>
        <source>topStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="45"/>
        <source>topEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="52"/>
        <source>topBlendIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="59"/>
        <source>topBlendOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="66"/>
        <source>topFadeIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="73"/>
        <source>topBlurWidthStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="80"/>
        <source>topBlurWidthEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="87"/>
        <source>topBlurHeightStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="94"/>
        <source>topBlurHeightEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="102"/>
        <source>bottomStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="109"/>
        <source>bottomEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="116"/>
        <source>bottomBlendIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="123"/>
        <source>bottomBlendOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="130"/>
        <source>bottomFadeIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="137"/>
        <source>bottomBlurWidthStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="144"/>
        <source>bottomBlurWidthEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="151"/>
        <source>bottomBlurHeightStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="158"/>
        <source>bottomBlurHeightEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="7"/>
        <source>360: Equirectangular Wrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="9"/>
        <source>spherical stretch</source>
        <comment>search keywords for the 360: Equirectangular Wrap video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="18"/>
        <source>hfov0</source>
        <translation>hfov0</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="25"/>
        <source>hfov1</source>
        <translation type="unfinished">hfov1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="32"/>
        <source>vfov0</source>
        <translation>vfov0</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="39"/>
        <source>vfov1</source>
        <translation type="unfinished">vfov1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="46"/>
        <source>blurStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="53"/>
        <source>blurEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/meta.qml" line="7"/>
        <source>360: Zenith Correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/meta.qml" line="8"/>
        <source>spherical level</source>
        <comment>search keywords for the 360: Zenith correction filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/meta.qml" line="6"/>
        <source>Clarity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/meta.qml" line="7"/>
        <source>histogram equalization constrast detail color distribution</source>
        <comment>search keywords for the Clarity video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="6"/>
        <source>Alpha Strobe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="7"/>
        <source>strobe alpha</source>
        <comment>search keywords for the Strobe video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="17"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_affine</name>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="7"/>
        <source>Size, Position &amp; Rotate</source>
        <translation>Velikost, poloha a otočení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="8"/>
        <source>transform zoom rotation distort fill move</source>
        <comment>search keywords for the Size, Position &amp; Rotate video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="21"/>
        <source>Size &amp; Position</source>
        <translation>Velikost a poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="26"/>
        <source>Rotation</source>
        <translation>Otočení</translation>
    </message>
</context>
<context>
    <name>meta_av</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="22"/>
        <source>Blur: Gaussian</source>
        <translation>Rozmazání: Gaussovské</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Box video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="35"/>
        <source>Amount</source>
        <translation>Množství</translation>
    </message>
</context>
<context>
    <name>meta_box_blur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="6"/>
        <source>Blur: Box</source>
        <translation>Rozmazání: Čtverec</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="7"/>
        <source>soften obscure hide directional</source>
        <comment>search keywords for the Blur: Box video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="18"/>
        <source>Width</source>
        <translation>Šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="25"/>
        <source>Height</source>
        <translation>Výška</translation>
    </message>
</context>
<context>
    <name>meta_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="6"/>
        <source>Blur: Box</source>
        <translation>Rozmazání: Čtverec</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="17"/>
        <source>Width</source>
        <translation>Šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="24"/>
        <source>Height</source>
        <translation>Výška</translation>
    </message>
</context>
<context>
    <name>meta_dance</name>
    <message>
        <location filename="../src/qml/filters/dance/meta_dance.qml" line="7"/>
        <source>Audio Dance Visualization</source>
        <translation>Zvukové znázornění tance</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/meta_dance.qml" line="8"/>
        <source>music visualizer reactive transform move size position rotate rotation</source>
        <comment>search keywords for the Audio Dance Visualization video filter</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_forward</name>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="8"/>
        <source>Speed: Forward Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="9"/>
        <source>temporal speed ramp fast slow motion</source>
        <comment>search keywords for the Speed filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="23"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
</context>
<context>
    <name>meta_forward_reverse</name>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="8"/>
        <source>Speed: Forward &amp; Reverse</source>
        <translation>Rychlost: Vpřed a vzad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="9"/>
        <source>temporal speed ramp fast slow motion reverse</source>
        <comment>search keywords for the Speed filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="24"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
</context>
<context>
    <name>meta_frei0r</name>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="6"/>
        <source>Glow</source>
        <translation>Záře</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="7"/>
        <source>shine blur</source>
        <comment>search keywords for the Glow video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="19"/>
        <source>Blur</source>
        <translation>Rozostření</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="6"/>
        <source>Saturation</source>
        <translation>Sytost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="7"/>
        <source>color desaturate grayscale chroma</source>
        <comment>search keywords for the Saturation video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="19"/>
        <source>Level</source>
        <translation>Úroveň</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="6"/>
        <source>Sharpen</source>
        <translation>Zaostření</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="7"/>
        <source>sharpness focus clear crisp</source>
        <comment>search keywords for the Sharpen video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="19"/>
        <source>Amount</source>
        <translation>Množství</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="26"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="6"/>
        <source>White Balance</source>
        <translation>Vyvážení bílé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="7"/>
        <source>color correct light temperature neutral</source>
        <comment>search keywords for the White Balance video filter</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/meta_frei0r_coloradj.qml" line="7"/>
        <source>Color Grading</source>
        <translation>Srovnání barev</translation>
    </message>
</context>
<context>
    <name>meta_lightshow</name>
    <message>
        <location filename="../src/qml/filters/lightshow/meta_lightshow.qml" line="7"/>
        <source>Audio Light Visualization</source>
        <translation>Zvukové znázornění světla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/meta_lightshow.qml" line="8"/>
        <source>music visualizer reactive color</source>
        <comment>search keywords for the Audio Light Visualization video filter</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_movit</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="6"/>
        <source>Blur</source>
        <translation>Rozmazání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="7"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="19"/>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="19"/>
        <source>Radius</source>
        <translation>Poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="6"/>
        <source>Brightness</source>
        <translation>Jas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="7"/>
        <source>lightness value</source>
        <comment>search keywords for the Brightness video filter</comment>
        <translation>Hodnota světelnosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="21"/>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="21"/>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="20"/>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="19"/>
        <source>Level</source>
        <translation>Úroveň</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="6"/>
        <source>Color Grading</source>
        <translation>Srovnání barev</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="7"/>
        <source>correct shadows lift midtones gamma highlights gain hue lightness brightness value</source>
        <comment>search keywords for the Color Grading video filter</comment>
        <translation>Opravit stíny, zvednout střední tóny gama světla, zesílit hodnotu jasu světlosti odstínu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="17"/>
        <source>Shadows (Lift)</source>
        <translation>Stíny</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="22"/>
        <source>Midtones (Gamma)</source>
        <translation>Středové tóny (gamma)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="27"/>
        <source>Highlights (Gain)</source>
        <translation>Světlá místa (zesílení)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="6"/>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="7"/>
        <source>variation value</source>
        <comment>search keywords for the Contrast video filter</comment>
        <translation>Hodnota odchylky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="6"/>
        <source>Glow</source>
        <translation>Záře</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="7"/>
        <source>shine blur</source>
        <comment>search keywords for the Glow video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="26"/>
        <source>Highlight blurriness</source>
        <translation>Rozmazanost světlého místa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="33"/>
        <source>Highlight cutoff</source>
        <translation>Přerušení zvýraznění</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="6"/>
        <source>Mirror</source>
        <translation>Zrcadlení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="7"/>
        <source>horizontal flip transpose flop</source>
        <comment>search keywords for the Mirror video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="7"/>
        <source>Opacity</source>
        <translation>Neprůhlednost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="8"/>
        <source>alpha transparent translucent</source>
        <comment>search keywords for the Opacity video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="6"/>
        <source>Saturation</source>
        <translation>Sytost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="7"/>
        <source>color desaturate grayscale chroma</source>
        <comment>search keywords for the Saturation video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="6"/>
        <source>Sharpen</source>
        <translation>Zaostření</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="7"/>
        <source>sharpness focus clear crisp</source>
        <comment>search keywords for the Sharpen video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="19"/>
        <source>Circle radius</source>
        <translation>Poloměr kruhu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="26"/>
        <source>Gaussian radius</source>
        <translation>Gaussův poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="33"/>
        <source>Correlation</source>
        <translation>Souvztažnost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="40"/>
        <source>Noise</source>
        <translation>Šum</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="6"/>
        <source>Vignette</source>
        <translation>Neostré okraje</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="7"/>
        <source>dark edges fade</source>
        <comment>search keywords for the Vignette video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="19"/>
        <source>Outer radius</source>
        <translation>Vnější poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="26"/>
        <source>Inner radius</source>
        <translation>Vnitřní poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="6"/>
        <source>White Balance</source>
        <translation>Vyvážení bílé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="7"/>
        <source>color correct light temperature neutral</source>
        <comment>search keywords for the White Balance video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta_movit.qml" line="6"/>
        <source>Flip</source>
        <translation>Převrátit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta_movit.qml" line="7"/>
        <source>vertical flop transpose rotate</source>
        <comment>search keywords for the Flip video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="6"/>
        <source>Crop: Source</source>
        <translation>Oříznutí: Zdroj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="7"/>
        <source>trim remove edges</source>
        <comment>search keywords for the Crop: Source video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="7"/>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="24"/>
        <source>Size &amp; Position</source>
        <translation>Velikost a poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="8"/>
        <source>transform zoom distort fill move</source>
        <comment>search keywords for the Size and Position filter</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="6"/>
        <source>Vignette</source>
        <translation>Neostré okraje</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="7"/>
        <source>dark edges fade</source>
        <comment>search keywords for the Vignette video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="18"/>
        <source>Radius</source>
        <translation>Poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="25"/>
        <source>Feathering</source>
        <translation>Měkký výběrový okraj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="32"/>
        <source>Opacity</source>
        <translation>Neprůhlednost</translation>
    </message>
</context>
<context>
    <name>meta_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/meta_spectrum.qml" line="7"/>
        <source>Audio Spectrum Visualization</source>
        <translation>Znázornění zvukového spektra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/meta_spectrum.qml" line="8"/>
        <source>music visualizer reactive frequency</source>
        <comment>search keywords for the Audio Spectrum Visualization video filter</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeline</name>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="178"/>
        <source>Output</source>
        <translation>Výstup</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="208"/>
        <source>Filters</source>
        <translation>Filtry</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="313"/>
        <source>Move %1</source>
        <translation>Posunout %1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="355"/>
        <source>Can not move audio track above video track</source>
        <translation>Zvukovou stopu nelze přesunout nad stopu s obrazem</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="357"/>
        <source>Can not move video track below audio track</source>
        <translation>Obrazovou stopu nelze přesunout nad stopu se zvukem</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="359"/>
        <source>Track %1 was not moved</source>
        <translation>Stopa %1 nebyla posunuta</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="706"/>
        <source>Insert</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="706"/>
        <source>Overwrite</source>
        <translation>Přepsat</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1028"/>
        <source>Do you want to insert an audio or video track?</source>
        <translation>Chcete vložit zvukovou nebo obrazovou stopu?</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1038"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1046"/>
        <source>Video</source>
        <translation>Obraz</translation>
    </message>
</context>
<context>
    <name>ui</name>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="58"/>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="296"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="353"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="46"/>
        <source>Mode</source>
        <translation>Režim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="82"/>
        <source>No Change</source>
        <translation>Žádná změna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="87"/>
        <source>Shave</source>
        <translation>Ostříhat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="92"/>
        <source>Shrink Hard</source>
        <translation>Silné zužování</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="97"/>
        <source>Shrink Soft</source>
        <translation>Mírné zužování</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="102"/>
        <source>Grow Hard</source>
        <translation>Silné roztažení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="107"/>
        <source>Grow Soft</source>
        <translation>Mírné roztažení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="112"/>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="98"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="150"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="138"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="189"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="570"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="118"/>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="158"/>
        <source>Threshold</source>
        <translation>Práh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="117"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="653"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="916"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="129"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="287"/>
        <source>Blur</source>
        <translation>Rozostření</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="136"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="547"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="543"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="618"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="693"/>
        <location filename="../src/qml/filters/blur_exponential/ui.qml" line="84"/>
        <location filename="../src/qml/filters/blur_lowpass/ui.qml" line="84"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="79"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="82"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="55"/>
        <location filename="../src/qml/filters/noise_fast/ui.qml" line="60"/>
        <location filename="../src/qml/filters/noise_keyframes/ui.qml" line="84"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="63"/>
        <source>Amount</source>
        <translation>Množství</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="164"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="171"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="445"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="405"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="124"/>
        <source>Invert</source>
        <translation>Obrátit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="50"/>
        <source>Display</source>
        <translation>Zobrazení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="66"/>
        <source>Gray Alpha</source>
        <translation>Šedá alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="71"/>
        <source>Red &amp; Gray Alpha</source>
        <translation>Červená a šedá alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="76"/>
        <source>Checkered Background</source>
        <translation>Kostkované pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="81"/>
        <source>Black Background</source>
        <translation>Černé pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="86"/>
        <source>Gray Background</source>
        <translation>Šedé pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="91"/>
        <source>White Background</source>
        <translation>Bílé pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="122"/>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="134"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="139"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="61"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="200"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="68"/>
        <source>Left</source>
        <translation>Vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="132"/>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="134"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="148"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="61"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="220"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="63"/>
        <source>Right</source>
        <translation>Vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="254"/>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="152"/>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="54"/>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="80"/>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="99"/>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="79"/>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="174"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="68"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="49"/>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="109"/>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="111"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="109"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="56"/>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="142"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="74"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="74"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="68"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="87"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="78"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="138"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="137"/>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="75"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="72"/>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="92"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="451"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="232"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="294"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="295"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="314"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="692"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="150"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="308"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="211"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="125"/>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="50"/>
        <location filename="../src/qml/filters/blur_exponential/ui.qml" line="65"/>
        <location filename="../src/qml/filters/blur_lowpass/ui.qml" line="65"/>
        <location filename="../src/qml/filters/brightness/ui.qml" line="138"/>
        <location filename="../src/qml/filters/choppy/ui.qml" line="62"/>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="69"/>
        <location filename="../src/qml/filters/color/ui.qml" line="177"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="144"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="304"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="99"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="185"/>
        <location filename="../src/qml/filters/deband/ui.qml" line="197"/>
        <location filename="../src/qml/filters/distort/ui.qml" line="77"/>
        <location filename="../src/qml/filters/dither/ui.qml" line="67"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="81"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="47"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="157"/>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="83"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="432"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="720"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="900"/>
        <location filename="../src/qml/filters/fspp/ui.qml" line="52"/>
        <location filename="../src/qml/filters/glitch/ui.qml" line="82"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="482"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="679"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="196"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="246"/>
        <location filename="../src/qml/filters/grain/ui.qml" line="48"/>
        <location filename="../src/qml/filters/grid/ui.qml" line="137"/>
        <location filename="../src/qml/filters/halftone/ui.qml" line="82"/>
        <location filename="../src/qml/filters/histeq/ui.qml" line="50"/>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="70"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="140"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="109"/>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="75"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="96"/>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="82"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="154"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="51"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="153"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="326"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="52"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="204"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="71"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="42"/>
        <location filename="../src/qml/filters/noise_fast/ui.qml" line="47"/>
        <location filename="../src/qml/filters/noise_keyframes/ui.qml" line="65"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="71"/>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="59"/>
        <location filename="../src/qml/filters/opacity/ui.qml" line="106"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="129"/>
        <location filename="../src/qml/filters/posterize/ui.qml" line="65"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="192"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="70"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="271"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="136"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="105"/>
        <location filename="../src/qml/filters/sepia/ui.qml" line="37"/>
        <location filename="../src/qml/filters/sketch/ui.qml" line="52"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="55"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="161"/>
        <location filename="../src/qml/filters/strobe/ui.qml" line="97"/>
        <location filename="../src/qml/filters/subtitle/ui.qml" line="83"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="47"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="70"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="290"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="117"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="109"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="50"/>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="108"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="70"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="81"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="85"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="42"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="79"/>
        <location filename="../src/qml/filters/white/ui.qml" line="64"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="72"/>
        <source>The size of the window, in milliseconds, which will be processed at once.</source>
        <translation>Velikost okna v milisekundách, které bude zpracováno najednou.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="101"/>
        <source>The strength of impulsive noise which is going to be removed. The lower value, the more samples will be detected as impulsive noise.</source>
        <translation>Síla impulsního šumu, který má být odstraněn. Čím nižší hodnota, tím více vzorků bude rozpoznáno jako impulsní šum.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="126"/>
        <source>Burst Fusion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="129"/>
        <source>Treat small bursts that are close together as one large burst. Units are percent of the window size. A higher percent will combine bursts that are farther apart.</source>
        <translation>Malá vytrysknutí, která jsou blízko sebe, považovat za jedno velké vytrysknutí. Jednotky jsou procenta velikosti okna. Vyšší procento spojí vytrysknutí, která jsou od sebe vzdálenější.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="32"/>
        <source>Fast Fade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="93"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="98"/>
        <source>Fade duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="97"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="102"/>
        <source>The duration of fade to apply at the begining and end of each clip</source>
        <translation>Doba trvání prolnutí, která se použije na začátku a na konci každého záběru.
</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="133"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="168"/>
        <source>Fade in</source>
        <translation>Roztmívat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="137"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="172"/>
        <source>Status indicator showing when a fade in has occured.</source>
        <translation>Stavový ukazatel ukazující, kdy došlo k roztmívání.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="163"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="198"/>
        <source>Fade out</source>
        <translation>Zatmívat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="167"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="202"/>
        <source>Status indicator showing when a fade out has occured.</source>
        <translation>Stavový ukazatel ukazující, kdy došlo k zatmívání.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="98"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="97"/>
        <source>Center frequency</source>
        <translation>Středový kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="125"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="124"/>
        <source>Bandwidth</source>
        <translation>Šířka pásma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="152"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="151"/>
        <source>Rolloff rate</source>
        <translation>Rychlost sjetí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="178"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="110"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="146"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="146"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="114"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="177"/>
        <source>Dry</source>
        <translation>Původní (nefiltrovaný) signál</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="188"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="156"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="156"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="124"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="187"/>
        <source>Wet</source>
        <translation>Filtrovaný signál</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="215"/>
        <source>Bass</source>
        <translation>Hloubky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="245"/>
        <source>Middle</source>
        <comment>Bass &amp; Treble audio filter</comment>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="275"/>
        <source>Treble</source>
        <translation>Výšky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Front left</source>
        <translation>Čelní levý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Front right</source>
        <translation>Čelní pravý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="117"/>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="102"/>
        <source>Center</source>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Low frequency</source>
        <translation>Nízký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Left surround</source>
        <translation>Levý okolní</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Right surround</source>
        <translation>Pravý okolní</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="54"/>
        <source>Copy from</source>
        <translation>Kopírovat z</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="65"/>
        <source>to</source>
        <translation>do</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="81"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="69"/>
        <source>RMS</source>
        <translation>RMS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="85"/>
        <source>The balance between the RMS and peak envelope followers. RMS is generally better for subtle, musical compression and peak is better for heavier, fast compression and percussion.</source>
        <translation>Rovnováha mezi obálkami RMS a vrcholy. RMS je obecně lepší pro jemnou hudební kompresi, a vrchol je lépe připůsoben rychlou silnější kompresi nebo bicí.
</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="95"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="83"/>
        <source>Peak</source>
        <translation>Vrchol</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="96"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="218"/>
        <source>Attack</source>
        <translation>Náběh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="129"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="117"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="125"/>
        <source>Release</source>
        <translation>Uvolnění</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="154"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="142"/>
        <source>The point at which the compressor will start to kick in.</source>
        <translation>Bod, na kterém kompresor začne zmenšovat dynamický rozsah původního signálu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="176"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="164"/>
        <source>Ratio</source>
        <translation>Poměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="180"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="168"/>
        <source>The gain reduction ratio used when the signal level exceeds the threshold.</source>
        <translation>Poměr zmenšení zesílení použitý, když úroveň signálu překročí práh.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="201"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="189"/>
        <source>Knee radius</source>
        <translation>Poloměr kolene</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="205"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="193"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="315"/>
        <source>The distance from the threshold where the knee curve starts.</source>
        <translation>Vzdálenost od prahu, kde začíná kolenová křivka.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="227"/>
        <source>Makeup gain</source>
        <translation>Vyrovnávací zesílení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="231"/>
        <source>The gain of the makeup input signal.</source>
        <translation>Zesílení použité na signál pro vyrovnání celkové ztráty na hlasitosti.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="270"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="166"/>
        <source>Gain Reduction</source>
        <translation>Snížení zesílení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="274"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="170"/>
        <source>Status indicator showing the gain reduction applied by the compressor.</source>
        <translation>Stavový ukazatel ukazující snížení zesílení použité kompresorem.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="294"/>
        <source>About dynamic range compression</source>
        <translation>O zmenšení dynamického rozsahu signálu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="62"/>
        <source>Delay</source>
        <translation>Ozvěna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="66"/>
        <source>The neutral delay time is 2 seconds.
Times above 2 seconds will have reduced quality.
Times below will have increased CPU usage.</source>
        <translation>Neutrální čas zpoždění je 2 sekundy.
Doby trvání delší než 2 sekundy budou mít zmenšenou jakost.
Doby trvání pod zvýší zatížení procesoru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="88"/>
        <source>Feedback</source>
        <translation>Navrácení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="73"/>
        <source>The balance between the RMS and peak envelope followers.
RMS is generally better for subtle, musical compression.
Peak is better for heavier, fast compression and percussion.</source>
        <translation>Rovnováha mezi RMS a následovníky obálek vrcholů.
RMS je obecně lepší pro jemnou hudební kompresi,
Vrchol je lépe přizpůsoben rychlou silnější kompresi a bicí.
</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="215"/>
        <source>Attenuation</source>
        <translation>Útlum</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="219"/>
        <source>The gain of the output signal.
Used to correct for excessive amplitude caused by the extra dynamic range.</source>
        <translation>Zesílení výstupního signálu.
Používá se k opravě přehnaného rozkmitu způsobeného mimořádným dynamickým rozsahem.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="67"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="72"/>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="62"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="67"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="271"/>
        <source>Duration</source>
        <translation>Doba trvání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="166"/>
        <location filename="../src/qml/filters/brightness/ui.qml" line="162"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="167"/>
        <location filename="../src/qml/filters/opacity/ui.qml" line="131"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="89"/>
        <source>Level</source>
        <translation>Úroveň</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="93"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="93"/>
        <source>Cutoff frequency</source>
        <translation>Kmitočet ukončení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="73"/>
        <source>Input gain</source>
        <translation>Vstupní zesílení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="77"/>
        <source>Gain that is applied to the input stage. Can be used to trim gain to bring it roughly under the limit or to push the signal against the limit.</source>
        <translation>Zesílení, které je použito na vstupní úroveň. Dá se použít k ořezání zesílení, aby se dostalo zhruba pod mez, nebo k postrčení signálu proti mezi.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="99"/>
        <source>Limit</source>
        <translation>Omezení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="103"/>
        <source>The maximum output amplitude. Peaks over this level will be attenuated as smoothly as possible to bring them as close as possible to this level.</source>
        <translation>Největší výstupní rozkmit. Vrcholové hodnoty nad touto zvukovou hladinou budou zeslabeny tak jemně, jak jen je to možné, aby byly přivedeny na tuto úroveň zvuku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="129"/>
        <source>The time taken for the limiter&apos;s attenuation to return to 0 dB&apos;s.</source>
        <translation>Čas vzatý zeslabením limiteru (komprese dynamiky - zmenšení dynamického rozsahu zpracovávaného signálu, limiter - kompresní poměr nastaven na maximum) pro návrat na 0 dB.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="100"/>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="67"/>
        <source>Target Loudness</source>
        <translation>Cílový hlasitost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="104"/>
        <source>The target loudness of the output in LUFS.</source>
        <translation>Cílová hlasitost výstupu v LUFS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="125"/>
        <source>Analysis Window</source>
        <translation>Okno rozboru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="129"/>
        <source>The amount of history to use to calculate the input loudness.</source>
        <translation>Množství historie pro užití na spočítání vstupní hlasitosti.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="150"/>
        <source>Maximum Gain</source>
        <translation>Nejvyšší zesílení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="154"/>
        <source>The maximum that the gain can be increased.</source>
        <translation>Nejvyšší hodnota, na niž může být zesílení zvýšeno.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="175"/>
        <source>Minimum Gain</source>
        <translation>Nejnižší zesílení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="179"/>
        <source>The maximum that the gain can be decreased.</source>
        <translation>Nejnižší hodnota, na niž může být zesílení sníženo.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="200"/>
        <source>Maximum Rate</source>
        <translation>Nejvyšší hodnota</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="204"/>
        <source>The maximum rate that the gain can be changed.</source>
        <translation>Nejvyšší hodnota, na niž může být zesílení změněno.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="230"/>
        <source>Reset on discontinuity</source>
        <translation>Obnovit při přerušení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="234"/>
        <source>Reset the measurement if a discontinuity is detected - such as seeking or clip change.</source>
        <translation>Obnovit měření, pokud je zjištěna nespojitost - například hledání nebo změna záběru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="260"/>
        <source>Input Loudness</source>
        <translation>Vstupní hlasitost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="264"/>
        <source>Status indicator showing the loudness measured on the input.</source>
        <translation>Stavový ukazatel ukazující hlasitost měřenou na výstupu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="283"/>
        <source>Output Gain</source>
        <translation>Výstupní zesílení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="287"/>
        <source>Status indicator showing the gain being applied.</source>
        <translation>Stavový ukazatel ukazující používané zesílení.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="122"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="304"/>
        <source>Reset</source>
        <translation>Obnovit výchozí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="308"/>
        <source>Status indicator showing when the loudness measurement is reset.</source>
        <translation>Stavový ukazatel ukazující, když je měření hlasitosti nastaveno znovu na výchozí hodnotu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="26"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="35"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="30"/>
        <source>Analyzing...</source>
        <translation>Vyhodnocuje se...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="30"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="38"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="32"/>
        <source>Analysis complete.</source>
        <translation>Rozbor dokončen.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="33"/>
        <source>%1 LUFS</source>
        <translation>%1 LUFS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="36"/>
        <source>%1 dB</source>
        <translation>%1 dB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="38"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="34"/>
        <source>Click &quot;Analyze&quot; to use this filter.</source>
        <translation>Klepněte na Vyhodnotit pro použití tohoto filtru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="97"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="360"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="165"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="376"/>
        <source>Analyze</source>
        <translation>Vyhodnotit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="128"/>
        <source>Detected Loudness:</source>
        <translation>Zjištěná hlasitost:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="132"/>
        <source>The loudness calculated by the analysis.</source>
        <translation>Hlasitost vypočtená na základě rozboru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="143"/>
        <source>Normalization Gain:</source>
        <translation>Zesílení normalizace:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="147"/>
        <source>The gain applied to normalize to the Target Loudness.</source>
        <translation>Zesílení použité k normalizaci na cílovou hlasitost.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="126"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="175"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="491"/>
        <source>Channel</source>
        <translation>Kanál</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="83"/>
        <source>Quick fix</source>
        <translation>Rychlá oprava</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="91"/>
        <source>Small hall</source>
        <translation>Malá hala</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="99"/>
        <source>Large hall</source>
        <translation>Velká hala</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="107"/>
        <source>Sewer</source>
        <translation>Kanál</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="115"/>
        <source>Church</source>
        <translation>Kostel</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="156"/>
        <source>Room size</source>
        <translation>Místnost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="160"/>
        <source>The size of the room, in meters. Excessively large, and excessively small values will make it sound a bit unrealistic. Values of around 30 sound good.</source>
        <translation>Velikost místnosti v metrech. Nadměrně velké a nepřiměřeně malé hodnoty dávají málo realistický zvuk. Hodnoty okolo 30 zní dobře.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="187"/>
        <source>Reverb time</source>
        <translation>Čas dozvuku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="215"/>
        <source>Damping</source>
        <translation>Tlumení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="219"/>
        <source>This controls the high frequency damping (a lowpass filter), values near 1 will make it sound very bright, values near 0 will make it sound very dark.</source>
        <translation>Ovládání zeslabení vysokých kmitočtů (filtr spodní pásmové propusti), hodnoty blízké 1 povedou k velice jasnému zvuku, hodnoty blízké 0 vrátí velmi temný zvuk.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="247"/>
        <source>Input bandwidth</source>
        <translation>Šířka pásma vstupu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="251"/>
        <source>This is like a damping control for the input, it has a similar effect to the damping control, but is subtly different.</source>
        <translation>Podobné ovládání tlumení pro vstup, má podobný účinek na ovládání tlumení, ale je velmi lehce odlišné.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="279"/>
        <source>Dry signal level</source>
        <translation>Úroveň nezpracovaného signálu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="283"/>
        <source>The amount of dry signal to be mixed with the reverberated signal.</source>
        <translation>Množství nezpracovaného signálu ke smíchání se signálem, na nějž byl použit dozvuk.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="311"/>
        <source>Early reflection level</source>
        <translation>Úroveň prvotních odrazů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="342"/>
        <source>Tail level</source>
        <translation>Úroveň koncové části</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="346"/>
        <source>The quantity of early reflections (scatter reflections directly from the source).</source>
        <translation>Množství prvotních odrazů (odrazy rozptýlené přímo od zdroje)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="375"/>
        <source>About reverb</source>
        <translation>O dozvuku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="55"/>
        <source>Swap</source>
        <translation>Vyměnit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="66"/>
        <source>with</source>
        <translation>pomocí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="66"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="109"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="68"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="118"/>
        <source>Key color</source>
        <translation>Barva masky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="86"/>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="110"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="88"/>
        <source>Distance</source>
        <translation>Vzdálenost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="203"/>
        <source>Shadows (Lift)</source>
        <translation>Stíny</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="241"/>
        <source>Midtones (Gamma)</source>
        <translation>Středové tóny (gamma)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="279"/>
        <source>Highlights (Gain)</source>
        <translation>Světlá místa (zesílení)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/ui.qml" line="140"/>
        <source>Center bias</source>
        <translation>Vychýlení středu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="503"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="160"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="78"/>
        <source>Top</source>
        <translation>Nahoře</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="566"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="829"/>
        <source>Fade</source>
        <translation>Prolínání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="601"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="864"/>
        <source>In</source>
        <translation>Začátek záběru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="627"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="890"/>
        <source>Out</source>
        <translation>Konec záběru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="662"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="925"/>
        <source>Width at start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="688"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="951"/>
        <source>Height at start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="714"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="977"/>
        <source>Width at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="740"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="1003"/>
        <source>Height at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="766"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="180"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="73"/>
        <source>Bottom</source>
        <translation>Dole</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="239"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="291"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="60"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1584"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="370"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="471"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="231"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="301"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="265"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="204"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="187"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="61"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="87"/>
        <source>Bottom Left</source>
        <translation>Dole vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="65"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="91"/>
        <source>Bottom Right</source>
        <translation>Dole vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="69"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>Top Left</source>
        <translation>Nahoře vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="73"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>Top Right</source>
        <translation>Nahoře vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="77"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="206"/>
        <source>Lower Third</source>
        <translation>Spodní třetina</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="81"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="222"/>
        <source>Slide In From Left</source>
        <translation>Skouznout zleva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="83"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="224"/>
        <source>Slide In From Right</source>
        <translation>Skouznout zprava</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="85"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="226"/>
        <source>Slide In From Top</source>
        <translation>Skouznout shora</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="87"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="228"/>
        <source>Slide In From Bottom</source>
        <translation>Skouznout zdola</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="91"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="232"/>
        <source>Slide Out Left</source>
        <translation>Vykouznout doleva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="93"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="234"/>
        <source>Slide Out Right</source>
        <translation>Vykouznout doprava</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="95"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="236"/>
        <source>Slide Out Top</source>
        <translation>Vykouznout nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="97"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="238"/>
        <source>Slide Out Bottom</source>
        <translation>Vykouznout dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="101"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="242"/>
        <source>Slow Zoom In</source>
        <translation>Pomalu přiblížit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="103"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="244"/>
        <source>Slow Zoom Out</source>
        <translation>Pomalu oddálit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="105"/>
        <source>Slow Pan Left</source>
        <translation>Pomalu najíždět vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="106"/>
        <source>Slow Move Left</source>
        <translation>Pomalu posunovat vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="108"/>
        <source>Slow Pan Right</source>
        <translation>Pomalu najíždět vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="109"/>
        <source>Slow Move Right</source>
        <translation>Pomalu posunovat vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="111"/>
        <source>Slow Pan Up</source>
        <translation>Pomalu najíždět nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="112"/>
        <source>Slow Move Up</source>
        <translation>Pomalu posunovat nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="114"/>
        <source>Slow Pan Down</source>
        <translation>Pomalu najíždět dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="115"/>
        <source>Slow Move Down</source>
        <translation>Pomalu posunovat dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="117"/>
        <source>Slow Zoom In, Pan Up Left</source>
        <translation>Pomalu přiblížit, najíždět nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="118"/>
        <source>Slow Zoom In, Move Up Left</source>
        <translation>Pomalu přiblížit, posunovat nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="120"/>
        <source>Slow Zoom In, Pan Down Right</source>
        <translation>Pomalu přiblížit, najíždět nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="121"/>
        <source>Slow Zoom In, Move Down Right</source>
        <translation>Pomalu přiblížit, posunovat dolů vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="123"/>
        <source>Slow Zoom Out, Pan Up Right</source>
        <translation>Pomalu oddálit, najíždět nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="124"/>
        <source>Slow Zoom Out, Move Up Right</source>
        <translation>Pomalu oddálit, posunovat nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="126"/>
        <source>Slow Zoom Out, Pan Down Left</source>
        <translation>Pomalu oddálit, najíždět nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="127"/>
        <source>Slow Zoom Out, Move Down Left</source>
        <translation>Pomalu přiblížit, posunovat dolů vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="187"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="709"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="277"/>
        <source>Insert field</source>
        <translation>Pole pro vkládání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="299"/>
        <source># (Hash sign)</source>
        <translation># (Hash znak)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="304"/>
        <source>Timecode (drop frame)</source>
        <translation>Časový kód (zahodit snímek)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="309"/>
        <source>Timecode (non-drop frame)</source>
        <translation>Časový kód (nezahodit snímek)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="339"/>
        <source>File base name</source>
        <translation>Základní název souboru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="314"/>
        <source>Frame #</source>
        <comment>Frame number</comment>
        <translation>Snímek #</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="319"/>
        <source>File date</source>
        <translation>Datum souboru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="324"/>
        <source>Creation date</source>
        <translation>Datum vytvoření</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="329"/>
        <source>File name and path</source>
        <translation>Název a cesta k souboru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="334"/>
        <source>File name</source>
        <translation>Název souboru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="130"/>
        <source>Bar</source>
        <translation>Proužek</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="130"/>
        <source>Segment</source>
        <translation>Díl</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="138"/>
        <source>Graph Colors</source>
        <translation>Barvy grafu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="168"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1447"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="126"/>
        <source>Thickness</source>
        <translation>Tloušťka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="192"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="216"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1529"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="313"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="367"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="390"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="156"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="222"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="310"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="188"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="144"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="146"/>
        <source>Position</source>
        <translation>Poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="293"/>
        <source>Mirror the levels.</source>
        <translation>Zrcadlit úrovně.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="305"/>
        <source>Reverse the levels.</source>
        <translation>Obrátit úrovně.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="314"/>
        <source>Channels</source>
        <translation>Kanály</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="337"/>
        <source>Segments</source>
        <translation>Díly</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="360"/>
        <source>Segment Gap</source>
        <translation>Dílová mezera</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="98"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="92"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="98"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="95"/>
        <source>Adjust opacity instead of fade with black</source>
        <translation>Přizpůsobit neprůhlednost namísto prolínání s černou</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="61"/>
        <source>Noise</source>
        <translation>Šum</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="80"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="503"/>
        <source>Brightness</source>
        <translation>Jas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="92"/>
        <source>Hue</source>
        <translation>Odstín</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1428"/>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="101"/>
        <source> °</source>
        <comment>degrees</comment>
        <translation> °</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="119"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="118"/>
        <source>Lightness</source>
        <translation>Světlost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="146"/>
        <source>Saturation</source>
        <translation>Sytost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="135"/>
        <source>Target color</source>
        <translation>Cílová barva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="162"/>
        <source>Mask type</source>
        <translation>Typ masky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Color Distance</source>
        <translation>Barevná odchylka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Transparency</source>
        <translation>Průhlednost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Edge Inwards</source>
        <translation>Zahrnutý okraj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Edge Outwards</source>
        <translation>Vyloučený okraj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="182"/>
        <source>Tolerance</source>
        <translation>Dovolená odchylka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="128"/>
        <source>&lt;b&gt;Low Shelf&lt;/b&gt;</source>
        <translation>&lt;b&gt;Nízký práh&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="204"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="281"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="359"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="437"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="515"/>
        <source>Gain</source>
        <translation>Zesílení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="228"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="539"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="202"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="315"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="329"/>
        <source>Slope</source>
        <translation>Sklon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="251"/>
        <source>&lt;b&gt;Band 1&lt;/b&gt;</source>
        <translation>&lt;b&gt;Pásmo 1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="305"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="383"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="461"/>
        <source>Bandwidth</source>
        <comment>Parametric equalizer bandwidth</comment>
        <translation>Šířka pásma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="316"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="394"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="472"/>
        <source> octaves</source>
        <translation>oktávy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="329"/>
        <source>&lt;b&gt;Band 2&lt;/b&gt;</source>
        <translation>&lt;b&gt;Pásmo 2&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="407"/>
        <source>&lt;b&gt;Band 3&lt;/b&gt;</source>
        <translation>&lt;b&gt;Pásmo 3&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="485"/>
        <source>&lt;b&gt;High Shelf&lt;/b&gt;</source>
        <translation>&lt;b&gt;Vysoký práh&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="222"/>
        <source>Hue gate</source>
        <translation>Filtr odstínu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="242"/>
        <source>Saturation threshold</source>
        <translation>Práh sytosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="262"/>
        <source>Operation 1</source>
        <translation>Operace 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="50"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="427"/>
        <source>Blend mode</source>
        <translation>Režim smíchání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="65"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="442"/>
        <source>Over</source>
        <translation>Kladení nad sebe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="70"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="447"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>None</source>
        <translation>Žádná</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="80"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="457"/>
        <source>Saturate</source>
        <translation>Sytost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="85"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="462"/>
        <source>Multiply</source>
        <translation>Součin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="90"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="467"/>
        <source>Screen</source>
        <translation>Obrazovka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="95"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="472"/>
        <source>Overlay</source>
        <translation>Překrytí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="100"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="477"/>
        <source>Darken</source>
        <translation>Ztmavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="105"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="482"/>
        <source>Dodge</source>
        <translation>Hustota barvy -</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="110"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="487"/>
        <source>Burn</source>
        <translation>Hustota barvy +</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="115"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="492"/>
        <source>Hard Light</source>
        <translation>Ostré světlo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="120"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="497"/>
        <source>Soft Light</source>
        <translation>Tlumené světlo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="125"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="502"/>
        <source>Difference</source>
        <translation>Rozdíl</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="130"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="507"/>
        <source>Exclusion</source>
        <translation>Vyloučení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="135"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="512"/>
        <source>HSL Hue</source>
        <translation>Odstín HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="140"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="517"/>
        <source>HSL Saturation</source>
        <translation>Sytost HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="145"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="522"/>
        <source>HSL Color</source>
        <translation>Barva HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="150"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="527"/>
        <source>HSL Luminosity</source>
        <translation>Svítivost HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>De-Key</source>
        <translation>Obrysové obrážení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>Desaturate</source>
        <translation>Odsycení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>Adjust Luma</source>
        <translation>Upravení lumy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="282"/>
        <source>Amount 1</source>
        <translation>Množství 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="302"/>
        <source>Operation 2</source>
        <translation>Operace 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="322"/>
        <source>Amount 2</source>
        <translation>Množství 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="346"/>
        <source>Show mask</source>
        <translation>Ukázat masku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="359"/>
        <source>Send mask to alpha channel</source>
        <translation>Poslat masku do kanálu alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="101"/>
        <source>X Center</source>
        <translation>Střed X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="130"/>
        <source>Y Center</source>
        <translation>Střed Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="159"/>
        <source>Correction at Center</source>
        <translation>Oprava ve středu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="188"/>
        <source>Correction at Edges</source>
        <translation>Oprava na okrajích</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="87"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="64"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="265"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="90"/>
        <source>Width</source>
        <translation>Šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/ui.qml" line="100"/>
        <source>Darkness</source>
        <translation>Temnost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="43"/>
        <source>No File Loaded</source>
        <translation>Nenahrán žádný soubor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="45"/>
        <source>No 3D LUT file loaded.
Click &quot;Open&quot; to load a file.</source>
        <translation>Nenahrán žádný soubor LUT 3D.
Klepněte na Otevřít pro nahrání souboru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="81"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="121"/>
        <source>Open...</source>
        <translation>Otevřít...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="84"/>
        <source>Open 3D LUT File</source>
        <translation>Otevřít soubor LUT 3D</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="488"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="343"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="344"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="791"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="181"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="418"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="248"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="189"/>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="101"/>
        <source>Interpolation</source>
        <translation>Interpolace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="305"/>
        <source>Stereo</source>
        <translation>Stereo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="314"/>
        <source>Binaural</source>
        <translation>Binaurální</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="323"/>
        <source>Quad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="354"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="366"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="368"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="820"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="537"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="271"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="204"/>
        <source>Yaw</source>
        <translation>Yaw</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="400"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="410"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="412"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="864"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="612"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="315"/>
        <source>Pitch</source>
        <comment>rotation around the side-to-side axis (roll, pitch, yaw)</comment>
        <translation>Výška tónu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="446"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="454"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="456"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="909"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="687"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="359"/>
        <source>Roll</source>
        <translation>Rolovat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="541"/>
        <source>Paste Parameters</source>
        <translation>Vložit parametry</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="498"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="500"/>
        <source>FOV</source>
        <comment>field of view</comment>
        <translation>Zorné pole</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="501"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="503"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="985"/>
        <source>Field of view</source>
        <translation>Zorné pole</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="590"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="592"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="414"/>
        <source>Copy Parameters</source>
        <translation>Kopírovat parametry</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="982"/>
        <source>FOV</source>
        <translation>Zorné pole</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="545"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="450"/>
        <source>Fisheye</source>
        <translation>Rybí oko</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="403"/>
        <source>Nearest</source>
        <translation>Nejbližší</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <source>Trilinear</source>
        <translation>Tříčará</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <source>Tetrahedral</source>
        <translation>Čtyřstěnná</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="173"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="348"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="202"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="349"/>
        <source>Operation</source>
        <translation>Operace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="336"/>
        <source>Corner 1 X</source>
        <translation>Roh 1 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="431"/>
        <source>Corner 2 X</source>
        <translation>Roh 2 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="483"/>
        <source>Corner 3 X</source>
        <translation>Roh 3 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="535"/>
        <source>Corner 4 X</source>
        <translation>Roh 4 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="587"/>
        <source>Stretch X</source>
        <translation>Protáhnout X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="645"/>
        <source>Interpolator</source>
        <translation>Interpolátor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Nearest Neighbor</source>
        <translation>Nejbližší soused</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="557"/>
        <source>Bilinear</source>
        <translation>Bilineární</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Bicubic Smooth</source>
        <translation>Bikubické hladké</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Bicubic Sharp</source>
        <translation>Bikubické ostré</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="572"/>
        <source>Spline 4x4</source>
        <translation>Spline křivka 4x4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="577"/>
        <source>Spline 6x6</source>
        <translation>Spline křivka 6x6</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="667"/>
        <source>Alpha Operation</source>
        <translation>Operace alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="226"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="533"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="369"/>
        <source>Maximum</source>
        <translation>Nejvyšší hodnota</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="231"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="538"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="374"/>
        <source>Minimum</source>
        <translation>Nejnižší hodnota</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <source>Opaque</source>
        <translation>Neprůhledný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="221"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="528"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="364"/>
        <source>Overwrite</source>
        <translation>Přepsat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="694"/>
        <source>Feathering</source>
        <translation>Měkký výběrový okraj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="75"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="480"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="452"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="236"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="543"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="379"/>
        <source>Add</source>
        <translation>Přidat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="241"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="548"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="384"/>
        <source>Subtract</source>
        <translation>Odečíst</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="194"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="369"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="241"/>
        <source>Shape</source>
        <translation>Tvar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Rectangle</source>
        <translation>Obdélník</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Ellipse</source>
        <translation>Elipsa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Triangle</source>
        <translation>Trojúhelník</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="266"/>
        <source>Diamond</source>
        <translation>Diamant</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="273"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="362"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="204"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="164"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="215"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="120"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="116"/>
        <source>Horizontal</source>
        <translation>Vodorovný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="514"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="777"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="279"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="373"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="446"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1395"/>
        <source>Start</source>
        <translation>Začít</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="540"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="803"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="323"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="417"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="404"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="483"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="557"/>
        <source>End</source>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="105"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="109"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="222"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="230"/>
        <source>Linear</source>
        <translation>Lineární</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="241"/>
        <source>Radial</source>
        <translation>Paprskovitý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="277"/>
        <source>Colors</source>
        <translation>Barvy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="441"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="248"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="240"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="91"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="87"/>
        <source>Vertical</source>
        <translation>Svislý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="290"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="119"/>
        <source>Height</source>
        <translation>Výška</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1413"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="315"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="530"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="158"/>
        <source>Rotation</source>
        <translation>Otočení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="336"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="566"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="596"/>
        <source>Softness</source>
        <translation>Měkkost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="814"/>
        <source>Alignment</source>
        <translation>Zarovnání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="953"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="597"/>
        <source>Lens</source>
        <translation>Čočka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="959"/>
        <source>Projection</source>
        <translation>Promítání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1029"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1352"/>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="63"/>
        <location filename="../src/qml/filters/halftone/ui.qml" line="104"/>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="33"/>
        <source>Radius</source>
        <translation>Poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1072"/>
        <source>Front</source>
        <translation>Čelní</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1078"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1215"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="157"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1121"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1258"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="405"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="457"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="509"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="561"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="616"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="185"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="768"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1209"/>
        <source>Back</source>
        <translation>Zadní</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1346"/>
        <source>Nadir</source>
        <translation>Podnožník</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="133"/>
        <source>Cyan</source>
        <translation>Modrozelená</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="162"/>
        <source>Magenta</source>
        <translation>Červenorudá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="54"/>
        <source>Blurriness</source>
        <translation>Rozmazanost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="72"/>
        <source>Vertical amount</source>
        <translation>Svislé množství</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="90"/>
        <source>Vertical frequency</source>
        <translation>Svislý kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="109"/>
        <source>Brightness up</source>
        <translation>Jas nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="127"/>
        <source>Brightness down</source>
        <translation>Jas dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="145"/>
        <source>Brightness frequency</source>
        <translation>Častost jasu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="164"/>
        <source>Uneven develop up</source>
        <translation>Více nepravidelností provedení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="182"/>
        <source>Uneven develop down</source>
        <translation>Méně nepravidelností provedení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="200"/>
        <source>Uneven develop duration</source>
        <translation>Doba trvání nepravidelností provedení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="326"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="549"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="169"/>
        <source> deg</source>
        <comment>degrees</comment>
        <translation>stupňů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="454"/>
        <source>Add or remove fisheye effect</source>
        <translation>Přidání nebo odstranění efektu rybího oka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="466"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="501"/>
        <source>Focal ratio</source>
        <translation>Ohniskový poměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="506"/>
        <source>The amount of lens distortion</source>
        <translation>Míra zkreslení čočky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="531"/>
        <source>Quality</source>
        <translation>Kvalita</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="535"/>
        <source>Resample quality</source>
        <translation>Kvalita převzorkování</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="552"/>
        <source>Nearest neighbor</source>
        <translation>Nejbližší soused</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="562"/>
        <source>Bicubic smooth</source>
        <translation>Bikubické hladké</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="567"/>
        <source>Bicubic sharp</source>
        <translation>Bikubické ostré</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="582"/>
        <source>Lanczos 16x16</source>
        <translation>Lanczos 16x16</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="601"/>
        <source>Select a lens distortion pattern that best matches your camera</source>
        <translation>Vyberte vzor zkreslení čočky, který nejlépe odpovídá vašemu fotoaparátu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="619"/>
        <source>Equidistant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="624"/>
        <source>Orthographic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="629"/>
        <source>Equiarea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="634"/>
        <source>Stereographic</source>
        <translation>Stereografický</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="643"/>
        <source>Non-Linear scale</source>
        <translation>Nelineární měřítko</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="657"/>
        <source>The image will be stretched/squished to fix camera scaling between 4:3 and 16:9
Like used in GoPro&apos;s superview</source>
        <translation>Obraz bude roztažen/zkrácen, aby se opravilo měřítko kamery mezi poměrem 4:3 a 16:9.
Stejně jako v superzobrazení v GoPro</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="673"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="707"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1723"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="187"/>
        <source>Scale</source>
        <translation>Měřítko</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="677"/>
        <source>Use negative values for up-scaled videos
Use positive values for down-scaled videos</source>
        <translation>Použijte záporných hodnot pro zvětšená videa
Pro zmenšená videa použijte kladné hodnoty</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="724"/>
        <source>Preset scale methods
Lock pixels at specific locations</source>
        <translation>Přednastavené postupy změny velikosti
Uzamknutí obrazových bodů na určitých místech</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="744"/>
        <source>Scale to Fill</source>
        <translation>Velikost pro vyplnění</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="749"/>
        <source>Keep Center Scale</source>
        <translation>Zachovávat střední velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="754"/>
        <source>Scale to Fit</source>
        <translation>Přizpůsobit velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="759"/>
        <source>Manual Scale</source>
        <translation>Ruční velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="782"/>
        <source>Scale Y separately
This changes video aspect ratio</source>
        <translation>Samostatná velikost Y
Tím se změní poměr stran videa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="789"/>
        <source>Crop</source>
        <translation>Ořezání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="801"/>
        <source>Remove distorted edges</source>
        <translation>Odstranit zkreslené okraje</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="820"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="962"/>
        <source>Manual</source>
        <translation>Ruční</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="825"/>
        <source>User set zoom/scale
Sides of image are not fixed</source>
        <translation>Uživatelské nastavení zvětšení/velikost
Strany obrazu nejsou pevné</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="852"/>
        <source>Y ratio</source>
        <translation>Poměr Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="857"/>
        <source>Separate Y scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="887"/>
        <source>Aspect</source>
        <translation>Poměr stran</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="904"/>
        <source>Preset pixel aspect ratio</source>
        <translation>Přednastavený poměr stran pixelů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="944"/>
        <source>Manual Aspect</source>
        <translation>Ruční poměr stran</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="967"/>
        <source>User set pixel aspect ratios
Change top/side distortion bias</source>
        <translation>Poměry stran obrazových bodů nastavené uživatelem
Změna zkreslení horní/boční strany</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="998"/>
        <source>Cameras</source>
        <translation>Kamery</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1012"/>
        <source>Camera</source>
        <translation>Kamera</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1032"/>
        <source>Record mode</source>
        <translation>Režim záznamu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1053"/>
        <source>Result</source>
        <translation>Výsledek</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1073"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="234"/>
        <source>X offset</source>
        <translation>Posun x</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="272"/>
        <source>Y offset</source>
        <translation>Posun y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="208"/>
        <source>Full Screen</source>
        <translation>Na celou obrazovku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="212"/>
        <source>Scroll Down</source>
        <translation>Posunout dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="214"/>
        <source>Scroll Up</source>
        <translation>Posunout nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="216"/>
        <source>Scroll Right</source>
        <translation>Posunout vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="218"/>
        <source>Scroll Left</source>
        <translation>Posunout vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="305"/>
        <source>Click in the rectangle atop the video to edit the text.</source>
        <translation>Klepněte v obdélníku nahoře obrazu pro upravení textu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="396"/>
        <source>Background size</source>
        <translation>Velikost pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="459"/>
        <source>Text size</source>
        <translation>Velikost textu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="524"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="310"/>
        <source>Background color</source>
        <translation>Barva pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="556"/>
        <source>Overflow</source>
        <translation>Přetečení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="570"/>
        <source>Automatic</source>
        <translation>Automaticky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="583"/>
        <source>Visible</source>
        <translation>Viditelný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="595"/>
        <source>Hidden</source>
        <translation>Skryto</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="144"/>
        <source>Color space</source>
        <translation>Barevný prostor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="156"/>
        <source>Red-Green-Blue</source>
        <translation>Červená-zelená-modrá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="167"/>
        <source>Hue-Chroma-Intensity</source>
        <translation>Odstín-chroma-síla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="181"/>
        <source>Red delta</source>
        <translation>Červená delta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="181"/>
        <source>Hue delta</source>
        <translation>Delta odstínu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Green delta</source>
        <translation>Zelená delta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Chroma delta</source>
        <translation>Delta chromy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="221"/>
        <source>Blue delta</source>
        <translation>Modrá delta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="221"/>
        <source>Intensity delta</source>
        <translation>Delta síly</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="256"/>
        <source>Box</source>
        <translation>Krabice</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="261"/>
        <source>Ellipsoid</source>
        <translation>Elipsoid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="280"/>
        <source>Edge</source>
        <translation>Okraj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="295"/>
        <source>Hard</source>
        <comment>Chroma Key Advanced filter</comment>
        <translation>Tvrdý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="300"/>
        <source>Fat</source>
        <translation>Silný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="305"/>
        <source>Normal</source>
        <translation>Normální</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="310"/>
        <source>Thin</source>
        <translation>Tenký</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="53"/>
        <source>Yellow-Blue</source>
        <translation>Žlutomodrá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="71"/>
        <source>Cyan-Red</source>
        <translation>Modrozelenočervená</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="65"/>
        <source>Line Width</source>
        <translation>Šířka čáry</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="85"/>
        <source>Line Height</source>
        <translation>Výška čáry</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="105"/>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="86"/>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="91"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="98"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1302"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1366"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="383"/>
        <location filename="../src/qml/filters/sketch/ui.qml" line="126"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="68"/>
        <source>Blur Radius</source>
        <translation>Poloměr rozmazání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="72"/>
        <source>The radius of the gaussian blur.</source>
        <translation>Poloměr Gaussova rozmazání.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="93"/>
        <source>Blur Strength</source>
        <translation>Síla rozmazání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="97"/>
        <source>The strength of the gaussian blur.</source>
        <translation>Síla Gaussova rozmazání.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="122"/>
        <source>If the difference between the original pixel and the blurred pixel is less than threshold, the pixel will be replaced with the blurred pixel.</source>
        <translation>Pokud je rozdíl mezi původním obrazovým bodem (pixel) a rozmazaným obrazovým bodem menší než prahová hodnota, obrazový bod bude nahrazen rozmazaným obrazovým bodem.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="50"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="60"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="152"/>
        <source>Green</source>
        <translation>Zelená</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="58"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="89"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="179"/>
        <source>Blue</source>
        <translation>Modrá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="125"/>
        <source>Red</source>
        <translation>Červená</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <source>Value</source>
        <translation>Hodnota</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="198"/>
        <source>Histogram</source>
        <translation>Histogram</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="227"/>
        <source>Input Black</source>
        <translation>Vstupní černá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="251"/>
        <source>Input White</source>
        <translation>Vstupní bílá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="275"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="299"/>
        <source>Output Black</source>
        <translation>Výstupní černá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="320"/>
        <source>Output White</source>
        <translation>Výstupní bílá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="27"/>
        <source>Click Analyze to use this filter.</source>
        <translation>Klepněte na Vyhodnotit pro použití tohoto filtru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="90"/>
        <source>Select a file to store analysis results.</source>
        <translation>Vyberte soubor pro ukládání výsledků rozboru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="116"/>
        <source>&lt;b&gt;Analyze Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Volby pro vyhodnocení&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="121"/>
        <source>Shakiness</source>
        <translation>Roztřesenost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="142"/>
        <source>Accuracy</source>
        <translation>Přesnost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="184"/>
        <source>&lt;b&gt;Filter Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Volby pro filtr&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="492"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="189"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="118"/>
        <source>Zoom</source>
        <translation>Zvětšení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="248"/>
        <source>Stabilization file:</source>
        <translation>Stabilizační soubor:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="252"/>
        <source>The stabilization file generated by the analysis.</source>
        <translation>Stabilizační soubor vytvořený rozborem.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="189"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="291"/>
        <source>File for motion analysis</source>
        <translation>Soubor pro rozbor pohybu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="390"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="168"/>
        <source>Browse...</source>
        <translation>Procházet...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="395"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="172"/>
        <source>Start Offset</source>
        <translation>Posun začátku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="407"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="181"/>
        <source>seconds</source>
        <translation>sekund</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="438"/>
        <source>Analysis</source>
        <translation>Rozbor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="448"/>
        <source>Apply transform</source>
        <translation>Použít proměnu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="454"/>
        <source>Sample Radius</source>
        <translation>Poloměr vzorku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="477"/>
        <source>Search Radius</source>
        <translation>Poloměr hledání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="523"/>
        <source>Track Points</source>
        <translation>Body sledování</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="530"/>
        <source>Use backwards-facing track points</source>
        <translation>Použít body sledování dozadu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="566"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="641"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="716"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="215"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="212"/>
        <source>Smoothing</source>
        <translation>Vyhlazení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="589"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="664"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="739"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="233"/>
        <source>Time Bias</source>
        <translation>Časové zkreslení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="70"/>
        <source> Red</source>
        <translation>Červená</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="191"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="79"/>
        <source>Yellow</source>
        <translation>Žlutá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/ui.qml" line="96"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="60"/>
        <source>Amplitude</source>
        <translation>Rozkmit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="180"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="257"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="335"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="413"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="491"/>
        <location filename="../src/qml/filters/distort/ui.qml" line="125"/>
        <location filename="../src/qml/filters/glitch/ui.qml" line="101"/>
        <source>Frequency</source>
        <translation>Kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/ui.qml" line="154"/>
        <source>Velocity</source>
        <translation>Síla tónu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="68"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Podržte %1 pro tažení klíčového snímku pouze svisle nebo %2 pro tažení pouze vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="50"/>
        <source>Forward</source>
        <translation>Vpřed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="52"/>
        <source>Freeze</source>
        <translation>Zmrazit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="53"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="54"/>
        <source>%L1s</source>
        <translation>%L1s</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="205"/>
        <source>Set Speed After</source>
        <translation>Nastavit rychlost před</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="205"/>
        <source>Set Speed Before</source>
        <translation>Nastavit rychlost po</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="242"/>
        <source>Modify current mapping</source>
        <translation>Upravit nynější přiřazení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="247"/>
        <source>Lock current mapping</source>
        <translation>Uzamknout nynější přiřazení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="257"/>
        <source>&quot;Modify current mapping&quot; will modify the input time at the current position.
&quot;Lock current mapping&quot; will lock the input time at the current position and modify the value of an adjacent keyframe</source>
        <translation>&quot;Upravit nynější přiřazení&quot; změní vstupní čas v nynější poloze.
&quot;Uzamknout nynější přiřazení&quot; uzamkne vstupní čas v nynější poloze a změní hodnotu sousedního klíčového snímku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="265"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="273"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="309"/>
        <source>Time</source>
        <translation>Čas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="313"/>
        <source>Map the specified input time to the current time. Use keyframes to vary the time mappings over time.</source>
        <translation>Namapujte zadaný vstupní čas na nynější čas. Použijte klíčové snímky k měnění časového mapování.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="345"/>
        <source>Set the input time to achieve a desired speed before the current frame.</source>
        <translation>Nastavte vstupní čas tak, abyste dosáhli požadované rychlosti před nynějším snímkem.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="361"/>
        <source>Set the input time to achieve a desired speed after the current frame.</source>
        <translation>Nastavte vstupní čas tak, abyste dosáhli požadované rychlosti po nynějším snímku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="379"/>
        <source>Image mode</source>
        <translation>Režim obrázků</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="383"/>
        <source>Use the specified image selection mode. Nearest will output the image that is nearest to the mapped time. Blend will blend all images that occur during the mapped time.</source>
        <translation>Použijte zadaný režim výběru obrázku. Nejbližší zobrazí obrázek, který je nejblíže mapovanému času. Smíchání sloučí všechny obrázky, které se vyskytnou během mapovaného času.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="128"/>
        <source>Hue Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="131"/>
        <source>The center of the color range to be changed.</source>
        <translation>Střed barevného rozsahu, který se má změnit.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="157"/>
        <source>Hue Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="160"/>
        <source>The width of the color range to be changed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="260"/>
        <source>Pick the center hue from a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="592"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="855"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="265"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="408"/>
        <source>Blend</source>
        <translation>Smíchat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="268"/>
        <source>The amount of blending to apply to the edges of the color range.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="297"/>
        <source>The amount to shift the Hue of the color range.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="326"/>
        <source>The amount to scale the saturation of the color range.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="355"/>
        <source>The amount to scale the lightness of the color range.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="424"/>
        <source>Enable pitch compensation</source>
        <translation>Povolit vyrovnání výšky tónu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="452"/>
        <source>Speed:</source>
        <translation>Rychlost:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="482"/>
        <source>Input Time:</source>
        <translation>Vstupní čas:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="497"/>
        <source>Output Time:</source>
        <translation>Výstupní čas:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="338"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="89"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="78"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="456"/>
        <source>The instantaneous speed of the last frame that was processed.</source>
        <translation>Okamžitá rychlost posledního zpracovaného snímku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="467"/>
        <source>Direction:</source>
        <translation>Směr:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="471"/>
        <source>The instantaneous direction of the last frame that was processed.</source>
        <translation>Okamžitý směr posledního zpracovaného snímku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="486"/>
        <source>The original clip time of the frame.</source>
        <translation>Původní čas záběru snímku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="501"/>
        <source>The mapped output time for the input frame.</source>
        <translation>Namapovaný výstupní čas pro vstupní snímek.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="102"/>
        <source>Deform horizontally?</source>
        <translation>Změnit tvar vodorovně?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="119"/>
        <source>Deform vertically?</source>
        <translation>Změnit tvar svisle?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="81"/>
        <source>Neutral color</source>
        <translation>Neutrální barva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="111"/>
        <source>Color temperature</source>
        <translation>Teplota barvy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="183"/>
        <source>degrees</source>
        <translation>stupňů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="147"/>
        <source>Format</source>
        <translation>Formát</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="161"/>
        <source>HH:MM:SS</source>
        <translation>HH:MM:SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="166"/>
        <source>HH:MM:SS.S</source>
        <translation>HH:MM:SS.S</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="171"/>
        <source>MM:SS</source>
        <translation>MM:SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="176"/>
        <source>MM:SS.SS</source>
        <translation>MM:SS.SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="181"/>
        <source>MM:SS.SSS</source>
        <translation>MM:SS.SSS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="186"/>
        <source>SS</source>
        <translation>SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="191"/>
        <source>SS.S</source>
        <translation>SS.S</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="196"/>
        <source>SS.SS</source>
        <translation>SS.SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="201"/>
        <source>SS.SSS</source>
        <translation>SS.SSS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="290"/>
        <source>A value of 0 will run the timer to the end of the filter</source>
        <translation>Hodnota 0 spustí časovač až do konce filtru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="332"/>
        <source>When the direction is Down, the timer will count down to Offset.
When the direction is Up, the timer will count up starting from Offset.</source>
        <translation>Když je směr dolů, časovač bude odpočítávat po posun.
Když je směr nahoru, časovač bude počítat počínaje posunem.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="359"/>
        <source>Timer seconds per playback second. Scales Duration but does not affect Start Delay or Offset.</source>
        <translation>Časovač sekund na sekundu přehrávání. Změní dobu trvání, ale neovlivňuje zpoždění začátku ani posun.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="122"/>
        <source>Minimal strength</source>
        <translation>Nejmenší síla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="133"/>
        <source>Average strength</source>
        <translation>Průměrná síla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="144"/>
        <source>Blue sky</source>
        <translation>Modrá obloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="155"/>
        <source>Red sky</source>
        <translation>Červená obloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="166"/>
        <source>Full range to limited range</source>
        <translation> Plný rozsah až omezený rozsah</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="210"/>
        <source>Contrast threshold</source>
        <translation>Práh kontrastu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="214"/>
        <source>Banding similarity within first component
Y (luma) in YCbCr mode
Red in RGB mode</source>
        <translation>Podobnost pásem v rámci první složky
Y (jas) v režimu YCbCr
Červená v režimu RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="233"/>
        <source>Blue threshold</source>
        <translation>Modrý práh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="237"/>
        <source>Banding similarity within second component
Cb (blue) in YCbCr mode
Green in RGB mode</source>
        <translation>Podobnost pásem v rámci druhé složky
Cb (modrá) v režimu YCbCr
Zelená v režimu RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="256"/>
        <source>Red threshold</source>
        <translation>Červený práh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="260"/>
        <source>Banding similarity within third component
Cr (red) in YCbCr mode
Blue in RGB mode</source>
        <translation>Podobnost pásem v rámci třetí složky
Cr (červená) v režimu YCbCr
Modrá v režimu RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="279"/>
        <source>Alpha threshold</source>
        <translation>Práh alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="283"/>
        <source>Banding similarity within fourth component</source>
        <translation>Podobnost pásem v rámci čtvrté složky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="308"/>
        <source>Link thresholds</source>
        <translation>Práh propojení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="317"/>
        <source>Pixel range</source>
        <translation>Rozsah obrazových bodů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="321"/>
        <source>The size of bands being targeted</source>
        <translation>Velikost cílových pásem</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="348"/>
        <source>Randomize pixel range between zero and value</source>
        <translation>Náhodný rozsah obrazových bodů mezi nulou a hodnotou</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="357"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="208"/>
        <source>Direction</source>
        <translation>Směr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="361"/>
        <source>Up = 270°
Down = 90°
Left = 180°
Right = 0° or 360°
All = 360° + Randomize</source>
        <translation>Nahoru = 270°
Dolů = 90°
Vlevo = 180°
Vpravo = 0° nebo 360°
Vše = 360° + náhodný výběr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="388"/>
        <source>Randomize direction between zero degrees and value</source>
        <translation>Náhodný směr mezi nulovými stupni a hodnotou</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="403"/>
        <source>Measure similarity using average of neighbors</source>
        <translation>Měření podobnosti pomocí průměru sousedů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="407"/>
        <source>Compare to thresholds using average versus exact neighbor values</source>
        <translation>Porovnání s prahy za použití průměrných a přesných sousedních hodnot</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="425"/>
        <source>All components required to trigger deband</source>
        <translation>Všetky složky potřebné ke spuštění zrušení pásma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="429"/>
        <source>Deband only if all pixel components (including alpha) are within thresholds</source>
        <translation>Zrušit pásmo jen tehdy, pokud jsou všechny složky pixelů (včetně alfa) v rámci prahových hodnot</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1164"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1301"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="222"/>
        <source>Up</source>
        <translation>Nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="227"/>
        <source>Down</source>
        <translation>Dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="234"/>
        <source>Start Delay</source>
        <translation>Zpoždění začátku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="253"/>
        <source>The timer will be frozen from the beginning of the filter until the Start Delay time has elapsed.</source>
        <translation>Časovač bude zmrazen od začátku filtru, dokud neuplyne čas zpoždění spuštění.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="265"/>
        <source>Set start to begin at the current position</source>
        <translation>Nastavit začátek tak, aby začínal v nynější poloze</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="290"/>
        <source>The timer will be frozen after the Duration has elapsed.</source>
        <translation>Časovač bude zmrazen po uplynutí doby trvání.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="307"/>
        <source>Set duration to end at the current position</source>
        <translation>Nastavit dobu trvání tak, aby končila v nynější poloze</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="500"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="258"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="313"/>
        <source>Offset</source>
        <translation>Posun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="149"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="223"/>
        <source>File</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="285"/>
        <source>Custom...</source>
        <translation>Vlastní...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="280"/>
        <source>Bar Horizontal</source>
        <translation>Pruh vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="290"/>
        <source>Bar Vertical</source>
        <translation>Pruh svisle</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="295"/>
        <source>Barn Door Horizontal</source>
        <translation>Vrata od stodoly vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="300"/>
        <source>Barn Door Vertical</source>
        <translation>Vrata od stodoly svisle</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="305"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Vrata od stodoly diagonálně JZ-SV</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="310"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Vrata od stodoly diagonálně SZ-JV</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="315"/>
        <source>Diagonal Top Left</source>
        <translation>Diagonálně nahoru vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="320"/>
        <source>Diagonal Top Right</source>
        <translation>Diagonálně nahoru vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="325"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Vodopád matrice vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="330"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Vodopád matrice svisle</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="335"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Had matrice vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="340"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Had matrice souběžně vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="345"/>
        <source>Matrix Snake Vertical</source>
        <translation>Had matrice svisle</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="350"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Had matrice souběžně svisle</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="355"/>
        <source>Barn V Up</source>
        <translation>Vrata od stodoly svisle nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="360"/>
        <source>Iris Circle</source>
        <translation>Kruh s duhou</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="365"/>
        <source>Double Iris</source>
        <translation>Dvojitá duha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="370"/>
        <source>Iris Box</source>
        <translation>Rámeček s duhou</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="375"/>
        <source>Box Bottom Right</source>
        <translation>Rámeček dole vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="380"/>
        <source>Box Bottom Left</source>
        <translation>Rámeček dole vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="385"/>
        <source>Box Right Center</source>
        <translation>Rámeček vpravo na střed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="390"/>
        <source>Clock Top</source>
        <translation>Hodiny nahoře</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="262"/>
        <source>Set a mask from another file&apos;s brightness or alpha.</source>
        <translation>Nastavit masku z jasu nebo alfy dalšího souboru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="238"/>
        <source>Open Mask File</source>
        <translation>Otevřít soubor s maskou</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="189"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="464"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="48"/>
        <source>Reverse</source>
        <translation>Obrátit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="511"/>
        <source>Alpha</source>
        <translation>Alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="96"/>
        <source>Waveform Color</source>
        <translation>Barva vlny</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="154"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="112"/>
        <source>Background Color</source>
        <translation>Barva pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="235"/>
        <source>Fill the area under the waveform.</source>
        <translation>Vyplnit oblast pod křivkou.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="247"/>
        <source>Combine all channels into one waveform.</source>
        <translation>Spojit všechny kanály do jedné vlny.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="69"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="252"/>
        <source>Window</source>
        <translation>Okno</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/ui.qml" line="166"/>
        <source>Rows</source>
        <translation>Řádky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/ui.qml" line="206"/>
        <source>Columns</source>
        <translation>Sloupce</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="130"/>
        <source>Block height</source>
        <translation>Výška bloku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="159"/>
        <source>Shift intensity</source>
        <translation>Síla posunu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="188"/>
        <source>Color intensity</source>
        <translation>Ostrost barvy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="89"/>
        <source>Spatial</source>
        <translation>Prostorový</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="118"/>
        <source>Temporal</source>
        <translation>Časový</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="353"/>
        <source>Apply to Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="379"/>
        <source>Corner radius</source>
        <translation>Poloměr rohu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="407"/>
        <source>Padding color</source>
        <translation>Barva prázdného okraje</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="86"/>
        <source>Levels</source>
        <comment>Dither video filter</comment>
        <translation>Úrovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="115"/>
        <source>Matrix</source>
        <translation>Matice</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>2x2 Magic Square</source>
        <translation>Kouzelný čtverec 2x2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Magic Square</source>
        <translation>Kouzelný čtverec 4x4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Ordered</source>
        <translation>Přikázáno 4x4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Lines</source>
        <translation>4x4 řádky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>6x6 90 Degree Halftone</source>
        <translation>6x6 90 stupňů polotón</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>6x6 Ordered</source>
        <translation>Přikázáno 6x6</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>8x8 Ordered</source>
        <translation>Přikázáno 8x8</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-3 Clustered</source>
        <translation>Skupinový příkaz 3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-4 Ordered</source>
        <translation>Skupinový příkaz 4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-8 Ordered</source>
        <translation>Skupinový příkaz 8</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="106"/>
        <source>Horizontal center position of the linear area.</source>
        <translation>Vodorovné středové umístění lineární oblasti.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="135"/>
        <source>Linear width</source>
        <translation>Lineární šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="139"/>
        <source>Width of the linear area.</source>
        <translation>Šířka lineární oblasti.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="168"/>
        <source>Linear scale factor</source>
        <translation>Lineární škálovací faktor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="172"/>
        <source>Amount the linear area is scaled.</source>
        <translation>Množství lineární oblasti je škálováno.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="201"/>
        <source>Non-Linear scale factor</source>
        <translation>Nelineární měřítko</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="205"/>
        <source>Amount the outer left and outer right areas are scaled non linearly.</source>
        <translation>Množství vnější levé a pravé oblasti je škálováno nelineárně.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/threshold/ui.qml" line="141"/>
        <source>Compare with alpha channel</source>
        <translation>Porovnat s kanálem alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/ui.qml" line="91"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="65"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="73"/>
        <source> frames</source>
        <translation> snímků</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/ui.qml" line="81"/>
        <source>Repeat</source>
        <translation>Opakovat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="121"/>
        <source>Key Filter: Low Frequency</source>
        <translation>Filtr klíče: Nízký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="150"/>
        <source>Key Filter: High Frequency</source>
        <translation>Filtr klíče: Vysoký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="184"/>
        <source>Output key only</source>
        <translation>Jen výstupní klíč</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="246"/>
        <source>Hold</source>
        <translation>Držet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="274"/>
        <source>Decay</source>
        <translation>Slábnout</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="302"/>
        <source>Range</source>
        <translation>Rozsah</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="161"/>
        <source>Octave Shift</source>
        <translation>Oktávový posun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="165"/>
        <source>Specify the pitch shift in octaves.
-1 shifts down an octave.
+1 shifts up an octave.
0 is unchanged.</source>
        <translation>Zadejte posun výšky tónu v oktávách.
-1 posune o oktávu dolů.
+1 posune o oktávu nahoru.
0 je nezměněno.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="205"/>
        <source>Specify the speed change that should be compensated for.
2x will halve the pitch to compensate for the speed being doubled.</source>
        <translation>Zadejte změnu rychlosti, již je třeba vyrovnat.
2x zmenší výšku tónu na polovinu, aby se vyrovnala zdvojená rychlost.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="201"/>
        <source>Speed Compensation</source>
        <translation>Vyrovnání rychlosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="69"/>
        <source>Light</source>
        <translation>Lehké</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="75"/>
        <source>Medium</source>
        <translation>Střední</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="81"/>
        <source>Heavy</source>
        <translation>Těžký</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="121"/>
        <source>Method</source>
        <translation>Metoda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Soft</source>
        <translation>Měkký</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Garrote</source>
        <translation>Přiškrtit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Hard</source>
        <comment>Remove Noise Wavelet filter</comment>
        <translation>Tvrdý</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="141"/>
        <source>Decompose</source>
        <translation>Rozklad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="175"/>
        <source>Percent</source>
        <translation>Procento</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="193"/>
        <source>Max decompositions for the current video mode</source>
        <translation>Největší rozklad pro nynější obrazový režim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="199"/>
        <source>More information</source>
        <translation>Více informací</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/ui.qml" line="84"/>
        <source>Levels</source>
        <comment>Posterize filter</comment>
        <translation>Úrovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="113"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="430"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="143"/>
        <source>Transparent</source>
        <translation>Průhledný</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="408"/>
        <source>Show grid</source>
        <translation>Ukázat mřížku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/ui.qml" line="65"/>
        <source>Quantization</source>
        <translation>Kvantizace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/ui.qml" line="83"/>
        <location filename="../src/qml/filters/histeq/ui.qml" line="63"/>
        <source>Strength</source>
        <translation>Síla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="105"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="40"/>
        <source>No File Loaded.</source>
        <translation>Nenahrán žádný soubor.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="107"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="42"/>
        <source>No GPS file loaded.
Click &quot;Open&quot; to load a file.</source>
        <translation>Nenahrán žádný soubor GPS.
Klepněte na Otevřít pro nahrání souboru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="401"/>
        <source>Select GPS File</source>
        <translation>Vybrat soubor GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="443"/>
        <source>Select Background Image</source>
        <translation>Vybrat obrázek na pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="463"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="218"/>
        <source>Open file</source>
        <translation>Otevřít soubor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="221"/>
        <source>Open GPS File</source>
        <translation>Otevřít soubor GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="503"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="238"/>
        <source>&lt;b&gt;GPS options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Volby pro GPS&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="510"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="245"/>
        <source>GPS offset</source>
        <translation>Posun GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="514"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="249"/>
        <source>This is added to video time to sync with gps time.</source>
        <translation>Tento čas se přidává k času obrazu, aby se sladil s časem GPS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="533"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="266"/>
        <source>+ : Adds time to video (use if GPS is ahead).
 - : Subtracts time from video (use if video is ahead).</source>
        <translation>+ : Přidá čas k obrazu (použijte, pokud je GPS napřed).
- : Odečte čas od obrazu (použijte, pokud je obraz pozadu).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="574"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="307"/>
        <source>Number of days to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Počet dnů, které se mají připočítat/odpočítat k/od času obrazu pro jeho synchronizaci.
Rada: ke změně hodnot můžete použít kolečko myši.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="613"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="346"/>
        <source>Number of hours to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Počet hodin, které se mají připočítat/odpočítat k/od času obrazu pro jeho synchronizaci.
Rada: ke změně hodnot můžete použít kolečko myši.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="652"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="385"/>
        <source>Number of minutes to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Počet minut, které se mají připočítat/odpočítat k/od času obrazu pro jeho synchronizaci.
Rada: ke změně hodnot můžete použít kolečko myši.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="691"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="424"/>
        <source>Number of seconds to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Počet sekund, které se mají připočítat/odpočítat k/od času obrazu pro jeho synchronizaci.
Rada: ke změně hodnot můžete použít kolečko myši.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="710"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="443"/>
        <source>Sync start of GPS to start of video file.
Tip: use this if you started GPS and video recording at the same time.</source>
        <translation>Seřízení začátku GPS se začátkem souboru s obrazem.
Rada: Použijte to, pokud jste spustil GPS a nahrávání obrazu ve stejném čase.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="749"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="482"/>
        <source>Sync start of GPS to current video time.
Tip: use this if you recorded the moment of the first GPS fix.</source>
        <translation>Seřízení začátku GPS se začátkem souboru s obrazem.
Rada: Použijte to, pokud jste spustil GPS a nahrávání obrazu ve stejném čase.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="759"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="492"/>
        <source>GPS smoothing</source>
        <translation>Vyrovnávání GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="763"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="496"/>
        <source>Average nearby GPS points to smooth out errors.</source>
        <translation>Průměrné body GPS v okolí pro vyhlazení chyb.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="889"/>
        <source>&lt;b&gt;Graph data&lt;/b&gt;</source>
        <translation>&lt;b&gt;Údaje v grafu&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="894"/>
        <source>Data source</source>
        <translation>Zdroj dat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="898"/>
        <source>Choose which data type is used for graph drawing.</source>
        <translation>Zvolte, který typ dat se použije pro vykreslení grafu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Location (2D map)</source>
        <translation>Poloha (2D mapa)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Altitude</source>
        <translation>Nadmořská výška</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Heart rate</source>
        <translation>Srdeční tep</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="919"/>
        <source>Graph type</source>
        <translation>Typ grafu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="923"/>
        <source>Graph types can add advanced interactions.</source>
        <translation>Typy grafů mohou přidávat pokročilé interakce.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Follow dot (cropped)</source>
        <translation>Sledovat tečku (oříznuto)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Speedometer</source>
        <translation>Rychloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="941"/>
        <source>Standard = just a static map.
Follow dot = centers on the current location.
Speedometer = draws a simple speedometer.</source>
        <translation>Standardní = pouze statická mapa.
Sledovat tečku = soustředí se na nynější polohu.
Rychloměr = vykreslí jednoduchý rychloměr.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="947"/>
        <source>Trim time</source>
        <translation>Čas oříznutí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="951"/>
        <source>Hides part of the graph at beginning or end.
This does not recompute min/max for any field.</source>
        <translation>Skryje část grafu na začátku nebo na konci.
Nepřepočítává min/max pro žádné pole.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="978"/>
        <source>Hides part of the beginning of the graph.</source>
        <translation>Skryje část začátku grafu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1022"/>
        <source>Hides part of the end of the graph.</source>
        <translation>Skryje část konce grafu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1039"/>
        <source>Crop horizontal</source>
        <translation>Oříznout vodorovně</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1043"/>
        <source>Zooms in on the graph on the horizontal axis (longitude if map, time if simple graph).
The number is either a percentage or a numeric value interpreted as the legend type.
This field is not applicable for Speedometer type.</source>
        <translation>Přiblíží graf na vodorovné ose (zeměpisná výška v případě mapy, čas v případě jednoduchého grafu).
Číslo je buď procento, nebo číselná hodnota vyložená jako typ popisku.
Toto pole neplatí pro typ rychloměru..</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1065"/>
        <source>Crops the graph from the left side.</source>
        <translation>Ořízne graf z levé strany.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1108"/>
        <source>Crops the graph from the right side. This value is ignored if mode is Follow dot.</source>
        <translation>Ořízne graf z pravé strany. Tato hodnota je přehlížena, pokud je režim Sledovat tečku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1116"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1225"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1116"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1225"/>
        <source>value</source>
        <translation>Hodnota</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1126"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1235"/>
        <source>The crop values are interpreted as a percentage of total or as an absolute value (in legend unit).</source>
        <translation>Hodnoty ořezu jsou vyloženy jako procento z celkového množství nebo jako absolutní hodnota (v jednotce popisku).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1130"/>
        <source>Input for horizontal crops can be a percentage or an absolute value.</source>
        <translation>Vstupem pro vodorovné ořezy může být procento nebo absolutní hodnota.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1147"/>
        <source>Crop vertical</source>
        <translation>Oříznout svisle</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1151"/>
        <source>Zooms in on the graph on the vertical axis (latitude if map, value if simple graph).
The number is either a percentage or a numeric value interpreted as the legend type.
This field affects min/max values on the Speedometer type.</source>
        <translation>Přiblíží graf na svislé ose (zeměpisná šířka v případě mapy, hodnota v případě jednoduchého grafu).
Číslo je buď procento, nebo číselná hodnota vyložená jako typ popisku.
Toto pole ovlivňuje min/max hodnoty u typu rychloměru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1174"/>
        <source>Crops the graph from the bottom side.</source>
        <translation>Ořízne graf ze spodní strany.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1217"/>
        <source>Crops the graph from the top side. This value is ignored if mode is Follow dot.</source>
        <translation>Ořízne graf z horní strany. Tato hodnota je přehlížena, pokud je režim Sledovat tečku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1239"/>
        <source>Input for vertical crops can be a percentage or an absolute value.</source>
        <translation>Vstupem pro svislé ořezy může být procento nebo absolutní hodnota.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1257"/>
        <source>&lt;b&gt;Graph design&lt;/b&gt;</source>
        <translation>&lt;b&gt;Návrh grafu&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1262"/>
        <source>Color style</source>
        <translation>Styl barvy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1266"/>
        <source>Choose how you want to color the graph line.</source>
        <translation>Zvolte, jak chcete obarvit čáru grafu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>One color</source>
        <translation>Jedna barva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Two colors</source>
        <translation>Dvě barvy</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Solid past, thin future</source>
        <translation>Pevná minulost, slabá budoucnost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Solid future, thin past</source>
        <translation>Pevná budoucnost, slabá minulost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Vertical gradient</source>
        <translation>Svislý přechod</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Horizontal gradient</source>
        <translation>Vodorovný přechod</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by duration</source>
        <translation>Barva podle doby trvání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by altitude</source>
        <translation>Barva podle nadmořské výšky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by heart rate</source>
        <translation>Barva podle tepové rychlosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by speed</source>
        <translation>Barva podle rychlosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by speed (max 100km/h)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by grade (max 90°)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by grade (max 20°)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1306"/>
        <source>Color by Altitude/HR only work if there are recorded values in the gps file.
For speedometer type, only first 2 colors are used.</source>
        <translation>Barva podle nadmořské výšky/HR pracuje pouze v případě, že jsou v souboru GPS zaznamenány hodnoty.
Pro typ rychloměru se používají pouze první 2 barvy.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1348"/>
        <source>Now dot</source>
        <translation>Nyní tečku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1352"/>
        <source>Draw a dot showing current position on the graph.
For speedometer type, this is the needle.</source>
        <translation>Nakreslete do grafu tečku znázorňující nynější polohu.
U rychloměru je to ručička.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1370"/>
        <source>Set the color of the inside of the now dot (or needle).</source>
        <translation>Nastavte barvu vnitřní strany bodu (nebo jehly).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1394"/>
        <source>Now text</source>
        <translation>Nyní text</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1399"/>
        <source>Draw a large white text showing the current value.
The legend unit (if present) will be appended at the end.</source>
        <translation>Nakreslete velký bílý text ukazující nynější hodnotu.
Jednotka legendy (pokud je přítomna) se připojí na konec.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1417"/>
        <source>Rotate the entire graph. Speedometer also rotates internal text.</source>
        <translation>Otočení celého grafu. Rychloměr otáčí i vnitřní text.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1451"/>
        <source>Set the thickness of the graph line. Does not affect speedometer.</source>
        <translation>Nastavení tloušťky čáry grafu. Nemá vliv na rychloměr.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1481"/>
        <source>Draw legend</source>
        <translation>Kreslení popisku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1485"/>
        <source>Draw 5 horizontal white lines with individual values for graph readability. 2D map also draws vertical (longitude) lines.
For speedometer this draws text for divisions.</source>
        <translation>Nakreslete 5 vodorovných bílých čar s jednotlivými hodnotami, aby byl graf čitelný. 2D mapa kreslí také svislé (délkové) čáry.
U rychloměru to kreslí text pro dělení.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1498"/>
        <source>Unit</source>
        <translation>Jednotka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1502"/>
        <source>This will be used in legend text if active and in absolute value math.</source>
        <translation>Tento údaj se použije v textu popisku, pokud je zapnut, a v matematice absolutních hodnot.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1514"/>
        <source>Defaults are km/h (speed) and meters (altitude).
 Available options: km/h, mi/h, nm/h (kn), m/s, ft/s.</source>
        <translation>Výchozí hodnoty jsou km/h (rychlost) a metry (nadmořská výška).
Dostupné možnosti: km/h, mi/h, nm/h (kn), m/s, ft/s.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1648"/>
        <source>Sets the height to the correct map aspect ratio or 1:1.</source>
        <translation>Nastaví výšku na správný poměr stran mapy nebo na 1:1.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1655"/>
        <source>&lt;b&gt;Background options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Volby pro pozadí&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1660"/>
        <source>Image path</source>
        <translation>Cesta k obrázku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1664"/>
        <source>Choose an image to overlay behind the graph. Tip: you can use an actual map image to make the GPS track more interesting.</source>
        <translation>Vyberte obrázek pro vrstvu za grafem. Tip: Pro zajímavější zobrazení GPS stopy můžete použít skutečný obrázek mapy.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1696"/>
        <source>GPS file center is: </source>
        <translation>Středisko souboru GPS je:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1699"/>
        <source>Get the center coordinate of GPS map. This does not change with trim or crop.
TIP:OpenStreetMap website can save the current standard map centered on searched location (but only at screen resolution).
Google Earth for desktop can center on a coordinate and save a 4K image of it. Disable the Terrain layer for best results.</source>
        <translation>Získejte středovou souřadnici mapy GPS. Tato souřadnice se nemění při zkracování nebo ořezávání.
RADA: Internetová stránka OpenStreetMap umí uložit současnou běžnou mapu se středem na hledaném místě (ale pouze v rozlišení obrazovky).
Aplikace Google Earth pro stolní počítače umí vystředit na souřadnici a uložit její obrázek ve formátu 4K. Pro dosažení nejlepších výsledků vypněte vrstvu Terén.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1710"/>
        <source>Browse for an image file to be assigned as graph background.</source>
        <translation>Vyhledejte soubor s obrázkem, který chcete přiřadit jako pozadí grafu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1727"/>
        <source>Increase or decrease the size of the background image.
Values smaller than 1 will zoom into image.</source>
        <translation>Zvětšení nebo zmenšení velikosti obrázku na pozadí.
Hodnoty menší než 1 zvětší obrázek.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="584"/>
        <source>Processing start</source>
        <translation>Začátek zpracování</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="589"/>
        <source>Distances are calculated since the start of the gps file, use this field to reset them (GPS time).</source>
        <translation>Vzdálenosti jsou vypočítávány od začátku gps souboru. Použijte toto pole pro obnovení výchozích hodnot (čas GPS)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="606"/>
        <source>Insert date and time formatted exactly as: YYYY-MM-DD HH:MM:SS (GPS time).</source>
        <translation>Vložte datum a čas formátovaný přesně takto: RRRR-MM-DD HH:MM:SS (GPS čas).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="621"/>
        <source>Set start of GPS processing to current video time.</source>
        <translation>Nastavte začátek GPS zpracovávání na nynější čas obrazu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="674"/>
        <source>&lt;b&gt;Text options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Volby pro text&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="792"/>
        <source>Insert GPS field</source>
        <translation>Vložení pole GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="881"/>
        <source>Extra arguments can be added inside keywords:
Distance units: m [km|ft|mi].
Speed units: km/h [mi/h|m/s|ft/s].
Time default: %Y-%m-%d %H:%M:%S, extra offset can be added as +/-seconds (+3600).
Extra keyword: RAW (prints only values from file).</source>
        <translation>Další argumenty mohou být přidány uvnitř klíčových slov:
Jednotky vzdálenosti: m [km|ft|mi].
Jednotky rychlosti: km/h [mi/h|m/s|ft/s].
Defaultní čas: %R-%m-%d %H:%M:%S, časový rozdíl může být přidán jako +/-sekundy (+3600).
Klíčové slovo navíc: RAW (vydá ze souboru pouze hodnoty).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS latitude</source>
        <translation>GPS zeměpisná šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS longitude</source>
        <translation>GPS zeměpisná délka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation (m)</source>
        <translation>Nadmořská výška (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Speed (km/h)</source>
        <translation>Rychlost (km/h)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance (m)</source>
        <translation>Vzdálenost (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS date-time</source>
        <translation>Datum a čas GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Video file date-time</source>
        <translation>Datum a čas souboru s obrazem</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Heart-rate (bpm)</source>
        <translation>Tepová frekvence (úzm)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Bearing (degrees)</source>
        <translation>Zaměření (stupně)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Bearing (compass)</source>
        <translation>Zaměření (kompas)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation gain (m)</source>
        <translation>Přírůstek výšky (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation loss (m)</source>
        <translation>Úbytek výšky (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance uphill (m)</source>
        <translation>Vzdálenost stoupání (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance downhill (m)</source>
        <translation>Vzdálenost klesání (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance flat (m)</source>
        <translation>Vzdálenost na rovině (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Cadence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Temperature (C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Grade (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Grade (degrees)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Vertical speed (m/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>3D Speed (km/h)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="803"/>
        <source>Power (W)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="895"/>
        <source>&lt;b&gt;Advanced options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Pokročilé volby&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="848"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="634"/>
        <source>Video speed</source>
        <translation>Rychlost obrazu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="852"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="639"/>
        <source>If the current video is sped up (timelapse) or slowed down use this field to set the speed.</source>
        <translation>Jestliže je nynější video zrychleno (timelapse) nebo zpomaleno, použijte toto pole pro určení rychlosti videa.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="875"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="660"/>
        <source>Fractional times are also allowed (0.25 = 4x slow motion, 5 = 5x timelapse).</source>
        <translation>Zlomky času jsou také povoleny (0.25 = 4x zpomaleno, 5 = 5x zrychleno).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="900"/>
        <source>Update speed</source>
        <translation>Obnovit rychlost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="905"/>
        <source>Set how many text updates to show per second.
Set to 0 to only print real points (no interpolation).</source>
        <translation>Nastavte, kolik aktualizací textu se zobrazí za sekundu.
Nastavte na 0, chcete-li zobrazit pouze skutečné body (bez interpolace).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="923"/>
        <source>Fractional times are also allowed (0.25 = update every 4 seconds, 5 = 5 updates per second).</source>
        <translation>Povoleny jsou také zlomkové časy (0,25 = aktualizace každé 4 sekundy, 5 = 5 aktualizací za sekundu).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="933"/>
        <source> per second</source>
        <translation>za sekundu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1770"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="960"/>
        <source>Video start time:</source>
        <translation>Začáteční čas obrazu:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1775"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="965"/>
        <source>Detected date-time for the video file.</source>
        <translation>Zjištěné datum a čas pro soubor s obrazem.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1793"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="983"/>
        <source>GPS start time:</source>
        <translation>Začáteční čas GPS:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1798"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="988"/>
        <source>Detected date-time for the GPS file.</source>
        <translation>Zjištěné datum a čas pro soubor s GPS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1809"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="999"/>
        <source>This time will be used for synchronization.</source>
        <translation>Tento čas bude použit pro seřízení.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="599"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="111"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="259"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="622"/>
        <source>Tip: Mask other video filters by adding filters after this one followed by &lt;b&gt;Mask: Apply&lt;/b&gt;</source>
        <translation>Rada: Maskujte další filtry obrazu přidáním filtrů za tento a za ním &lt;b&gt;Maska: Použít&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="128"/>
        <source>50 Hz</source>
        <translation>50 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="198"/>
        <source>100 Hz</source>
        <translation>100 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="222"/>
        <source>156 Hz</source>
        <translation>156 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="246"/>
        <source>220 Hz</source>
        <translation>220 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="270"/>
        <source>311 Hz</source>
        <translation>311 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="294"/>
        <source>440 Hz</source>
        <translation>440 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="318"/>
        <source>622 Hz</source>
        <translation>622 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="342"/>
        <source>880 Hz</source>
        <translation>880 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="366"/>
        <source>1250 Hz</source>
        <translation>1250 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="390"/>
        <source>1750 Hz</source>
        <translation>1750 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="414"/>
        <source>2500 Hz</source>
        <translation>2500 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="438"/>
        <source>3500 Hz</source>
        <translation>3500 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="462"/>
        <source>5000 Hz</source>
        <translation>5000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="486"/>
        <source>10000 Hz</source>
        <translation>10000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="510"/>
        <source>20000 Hz</source>
        <translation>20000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="130"/>
        <source>Low</source>
        <translation>Nízká</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="188"/>
        <source>Mid</source>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="212"/>
        <source>High</source>
        <translation>Vysoký</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="87"/>
        <source>Source</source>
        <translation>Zdroj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <source>Middle (L+R)</source>
        <translation>Střední (L+P)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <source>Side (L-R)</source>
        <translation>Strana (L-P)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="117"/>
        <source>Left delay</source>
        <translation>Zpoždění vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="143"/>
        <source>Left delay gain</source>
        <translation>Zesílení zpoždění vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="169"/>
        <source>Right delay</source>
        <translation>Zpoždění vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="195"/>
        <source>Right delay gain</source>
        <translation>Zesílení zpoždění vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="221"/>
        <source>Output gain</source>
        <translation>Výstupní zesílení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="103"/>
        <source>New...</source>
        <translation>Nový...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="114"/>
        <source>New Animation File</source>
        <translation>Nový soubor animace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="124"/>
        <source>Open Animation File</source>
        <translation>Otevřít soubor animace</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="134"/>
        <source>Click &lt;b&gt;New...&lt;/b&gt; or &lt;b&gt;Open...&lt;/b&gt; to use this filter</source>
        <translation>Pro použití tohoto filtru klepněte na &lt;b&gt;Nový...&lt;/b&gt; nebo &lt;b&gt;Otevřít...&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="149"/>
        <source>Edit...</source>
        <translation>Upravit...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="154"/>
        <source>Reload</source>
        <translation>Nahrát znovu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="124"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="139"/>
        <source>Region To Track</source>
        <translation>Oblast ke sledování</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="148"/>
        <source>Set the region of interest to track.</source>
        <translation>Nastavte oblast zájmu, kterou chcete sledovat.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="267"/>
        <source>Algorithm</source>
        <translation>Algoritmus</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="270"/>
        <source>Chooses the way (rules) the tracking is calculated.</source>
        <translation>Vybírá způsob (pravidla) výpočtu sledování.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="348"/>
        <source>Show preview</source>
        <translation>Ukázat náhled</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="88"/>
        <source>Discontinuity threshold</source>
        <translation>Práh nespojitosti</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="92"/>
        <source>The threshold to apply a seam to splices</source>
        <translation>Práh pro použití švu na spoje</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="128"/>
        <source>Seam applied</source>
        <translation>Použitý šev</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="132"/>
        <source>Status indicator showing when a splice has been seamed.</source>
        <translation>Stavový ukazatel ukazující, kdy byl spoj sešit.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="36"/>
        <source>Fade to White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="123"/>
        <source>Fade color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="181"/>
        <source>Azimuth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="225"/>
        <source>Elevation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/ui.qml" line="82"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="98"/>
        <source>Intensity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/ui.qml" line="113"/>
        <source>Subtitle Track</source>
        <translation>Stopa titulků</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="153"/>
        <source>Horizontal 4:3</source>
        <translation>Vodorovné 4:3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="158"/>
        <source>Horizontal 16:9</source>
        <translation>Vodorovné 16:9</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="163"/>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="170"/>
        <source>Vertical 9:16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="140"/>
        <source>Sepia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="146"/>
        <source>Thermal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="205"/>
        <source>Color #%1</source>
        <translation>Barva #%1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="211"/>
        <source>Color: %1
Click to select, drag to change position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="344"/>
        <source>Stop</source>
        <translation>Zastavit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="159"/>
        <source>Overlap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="186"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="294"/>
        <source>Hue Shift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="192"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="355"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="518"/>
        <source>Reds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="218"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="381"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="544"/>
        <source>Yellows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="244"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="407"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="570"/>
        <source>Greens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="270"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="433"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="596"/>
        <source>Cyans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="296"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="459"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="622"/>
        <source>Blues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="322"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="485"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="648"/>
        <source>Magentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="349"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="323"/>
        <source>Saturation Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="512"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="352"/>
        <source>Lightness Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="520"/>
        <source>Blur Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="111"/>
        <source>File for zenith correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="209"/>
        <source>Smooth yaw instead of locking it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/ui.qml" line="116"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ui_av</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="70"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="89"/>
        <source>Amount</source>
        <translation>Množství</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="126"/>
        <source>Blur alpha</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ui_box_blur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="70"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="90"/>
        <source>Width</source>
        <translation>Šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="119"/>
        <source>Height</source>
        <translation>Výška</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="152"/>
        <source>Blur alpha</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ui_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="138"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="169"/>
        <source>Width</source>
        <translation>Šířka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="208"/>
        <source>Height</source>
        <translation>Výška</translation>
    </message>
</context>
<context>
    <name>ui_dance</name>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="71"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="84"/>
        <source>Initial Zoom</source>
        <translation>Počáteční zvětšení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="88"/>
        <source>The amount to zoom the image before any motion occurs.</source>
        <translation>Množství pro přiblížení obrázku, předtím než se objeví nějaký pohyb.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="108"/>
        <source>Oscillation</source>
        <translation>Kolísání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="112"/>
        <source>Oscillation can be useful to make the image move back and forth during long periods of sound.</source>
        <translation>Kmitání může být užitečné k tomu, aby se obrázek během dlouhých údobí zvuku pohnul dozadu a dopředu.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="132"/>
        <source>Zoom</source>
        <translation>Zvětšení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="136"/>
        <source>The amount that the audio affects the zoom of the image.</source>
        <translation>Množství, při kterém zvuk ovlivní přiblížení obrázku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="156"/>
        <source>Up</source>
        <translation>Nahoru</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="160"/>
        <source>The amount that the audio affects the upward offset of the image.</source>
        <translation>Množství, při kterém zvuk ovlivní posun obrázku směrem nahoru.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="180"/>
        <source>Down</source>
        <translation>Dolů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="184"/>
        <source>The amount that the audio affects the downward offset of the image.</source>
        <translation>Množství, při kterém zvuk ovlivní posun obrázku směrem dolů.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="204"/>
        <source>Left</source>
        <translation>Vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="208"/>
        <source>The amount that the audio affects the left offset of the image.</source>
        <translation>Množství, při kterém zvuk ovlivní posun obrázku směrem doleva.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="228"/>
        <source>Right</source>
        <translation>Vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="232"/>
        <source>The amount that the audio affects the right offset of the image.</source>
        <translation>Množství, při kterém zvuk ovlivní posun obrázku směrem doprava.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="252"/>
        <source>Clockwise</source>
        <translation>Po směru hodinových ručiček</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="256"/>
        <source>The amount that the audio affects the clockwise rotation of the image.</source>
        <translation>Množství, při kterém zvuk ovlivní otočení obrázku po směru hodinových ručiček.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="267"/>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="291"/>
        <source> deg</source>
        <translation>stupňů</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="276"/>
        <source>Counterclockwise</source>
        <translation>Proti směru hodinových ručiček</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="280"/>
        <source>The amount that the audio affects the counterclockwise rotation of the image.</source>
        <translation>Množství, při kterém zvuk ovlivní otočení obrázku proti směru hodinových ručiček.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="300"/>
        <source>Low Frequency</source>
        <translation>Nízký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="304"/>
        <source>The low end of the frequency range to be used to influence the image motion.</source>
        <translation>Nejnižší konec rozsahu kmitočtu, který se použije k ovlivnění pohybu obrázku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="328"/>
        <source>High Frequency</source>
        <translation>Vysoký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="332"/>
        <source>The high end of the frequency range to be used to influence the image motion.</source>
        <translation>Nejvyšší konec rozsahu kmitočtu, který se použije k ovlivnění pohybu obrázku.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="356"/>
        <source>Threshold</source>
        <translation>Práh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="360"/>
        <source>The minimum amplitude of sound that must occur within the frequency range to cause the image to move.</source>
        <translation>Nejmenší rozkmit zvuku, ke kterému musí dojít uvnitř kmitočtového rozsahu, aby došlo k pohybu obrázku.</translation>
    </message>
</context>
<context>
    <name>ui_frei0r</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_frei0r.qml" line="65"/>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="97"/>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="100"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="130"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="116"/>
        <source>Blur</source>
        <translation>Rozmazání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="81"/>
        <source>Grayscale</source>
        <translation>Odstíny šedi</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="123"/>
        <source>Level</source>
        <translation>Úroveň</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_frei0r.qml" line="84"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="148"/>
        <source>Amount</source>
        <translation>Množství</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="173"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
</context>
<context>
    <name>ui_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="56"/>
        <source>Mode</source>
        <translation>Režim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Shadows (Lift)</source>
        <translation>Stíny</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Midtones (Gamma)</source>
        <translation>Středové tóny (gamma)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Highlights (Gain)</source>
        <translation>Světlá místa (zesílení)</translation>
    </message>
</context>
<context>
    <name>ui_lightshow</name>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="79"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="96"/>
        <source>Waveform Color</source>
        <translation>Barva vlny</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="112"/>
        <source>Position</source>
        <translation>Poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="153"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="194"/>
        <source>Oscillation</source>
        <translation>Kolísání</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="198"/>
        <source>Oscillation can be useful to make the light blink during long periods of sound.</source>
        <translation>Kmitání může být užitečné k tomu, aby světlo během dlouhých údobí zvuku  blikalo.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="218"/>
        <source>Low Frequency</source>
        <translation>Nízký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="222"/>
        <source>The low end of the frequency range to be used to influence the light.</source>
        <translation>Nejnižší konec rozsahu kmitočtu, který se použije k ovlivnění světla.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="246"/>
        <source>High Frequency</source>
        <translation>Vysoký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="250"/>
        <source>The high end of the frequency range to be used to influence the light.</source>
        <translation>Nejvyšší konec rozsahu kmitočtu, který se použije k ovlivnění světla.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="274"/>
        <source>Threshold</source>
        <translation>Práh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="278"/>
        <source>The minimum amplitude of sound that must occur within the frequency range to cause the light to change.</source>
        <translation>Nejmenší rozkmit zvuku, ke kterému musí dojít uvnitř kmitočtového rozsahu, aby došlo ke změně světla.</translation>
    </message>
</context>
<context>
    <name>ui_movit</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="118"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="149"/>
        <source>Radius</source>
        <translation>Poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="163"/>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="121"/>
        <source>Level</source>
        <translation>Úroveň</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="95"/>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="139"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="129"/>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="98"/>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="136"/>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="127"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="175"/>
        <source>Highlight blurriness</source>
        <translation>Rozmazanost světlého místa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="201"/>
        <source>Highlight cutoff</source>
        <translation>Přerušení zvýraznění</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="79"/>
        <source>Grayscale</source>
        <translation>Odstíny šedi</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="155"/>
        <source>Circle radius</source>
        <translation>Poloměr kruhu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="181"/>
        <source>Gaussian radius</source>
        <translation>Gaussův poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="207"/>
        <source>Correlation</source>
        <translation>Souvztažnost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="232"/>
        <source>Noise</source>
        <translation>Šum</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="147"/>
        <source>Outer radius</source>
        <translation>Vnější poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="171"/>
        <source>Inner radius</source>
        <translation>Vnitřní poloměr</translation>
    </message>
</context>
<context>
    <name>ui_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="137"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="158"/>
        <source>Radius</source>
        <translation>Poloměr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="182"/>
        <source>Feathering</source>
        <translation>Měkký výběrový okraj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="212"/>
        <source>Non-linear feathering</source>
        <translation>Měkký výběrový okraj (nelineární)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="222"/>
        <source>Opacity</source>
        <translation>Neprůhlednost</translation>
    </message>
</context>
<context>
    <name>ui_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="103"/>
        <source>Preset</source>
        <translation>Přednastavení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="120"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Line</source>
        <translation>Čára</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Bar</source>
        <translation>Proužek</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Segment</source>
        <translation>Díl</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="149"/>
        <source>Spectrum Color</source>
        <translation>Barva spektra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="165"/>
        <source>Background Color</source>
        <translation>Barva pozadí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="179"/>
        <source>Thickness</source>
        <translation>Tloušťka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="199"/>
        <source>Position</source>
        <translation>Poloha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="246"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="300"/>
        <source>Fill the area under the spectrum.</source>
        <translation>Vyplnit oblast pod spektrem.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="312"/>
        <source>Mirror the spectrum.</source>
        <translation>Zrcadlit spektrum.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="324"/>
        <source>Reverse the spectrum.</source>
        <translation>Obrátit spektrum.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="329"/>
        <source>Tension</source>
        <translation>Napětí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="348"/>
        <source>Segments</source>
        <translation>Díly</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="371"/>
        <source>Segment Gap</source>
        <translation>Dílová mezera</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="394"/>
        <source>Bands</source>
        <translation>Pásma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="413"/>
        <source>Low Frequency</source>
        <translation>Nízký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="417"/>
        <source>The low end of the frequency range of the spectrum.</source>
        <translation>Nejnižší konec rozsahu kmitočtu spektra.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="441"/>
        <source>High Frequency</source>
        <translation>Vysoký kmitočet</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="445"/>
        <source>The high end of the frequency range of the spectrum.</source>
        <translation>Nejvyšší konec rozsahu kmitočtu spektra.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="469"/>
        <source>Threshold</source>
        <translation>Práh</translation>
    </message>
</context>
<context>
    <name>vui</name>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="213"/>
        <source>Hold Shift while dragging any corner to drag all corners</source>
        <translation>Podržením klávesy Shift při přetahování libovolného rohu přetáhnete všechny rohy.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="276"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="318"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="360"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="402"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="366"/>
        <source>Text size</source>
        <translation>Velikost textu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="385"/>
        <source>Text color</source>
        <translation>Barva textu</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="487"/>
        <source>Collapse Toolbar</source>
        <translation>Sbalit nástrojový pruh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="487"/>
        <source>Expand Toolbar</source>
        <translation>Rozbalit nástrojový pruh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="270"/>
        <source>Menu</source>
        <translation>Nabídka</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="596"/>
        <source>Left</source>
        <translation>Vlevo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="607"/>
        <source>Center</source>
        <translation>Střed</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="618"/>
        <source>Right</source>
        <translation>Vpravo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="629"/>
        <source>Justify</source>
        <translation>Zarovnat do bloku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="640"/>
        <source>Bold</source>
        <translation>Tučné</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="651"/>
        <source>Italic</source>
        <translation>Kurzíva</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="662"/>
        <source>Underline</source>
        <translation>Podtržení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="812"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="820"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="331"/>
        <location filename="../src/qml/filters/richtext/vui.qml" line="673"/>
        <source>Font</source>
        <translation>Písmo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="746"/>
        <source>Insert Table</source>
        <translation>Vložit tabulku</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="686"/>
        <source>Decrease Indent</source>
        <translation>Zmenšit odsazení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="695"/>
        <source>Insert Indent</source>
        <translation>Vložit odsazení</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="758"/>
        <source>Rows</source>
        <translation>Řádky</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="775"/>
        <source>Columns</source>
        <translation>Sloupce</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="791"/>
        <source>Border</source>
        <translation>Okraj</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/vui.qml" line="26"/>
        <location filename="../src/qml/filters/gpsgraphic/vui.qml" line="26"/>
        <location filename="../src/qml/filters/gradient/vui.qml" line="109"/>
        <location filename="../src/qml/filters/lightshow/vui.qml" line="26"/>
        <location filename="../src/qml/filters/mask_alphaspot/vui.qml" line="108"/>
        <location filename="../src/qml/filters/pillar_echo/vui.qml" line="82"/>
        <location filename="../src/qml/filters/reframe/vui.qml" line="86"/>
        <location filename="../src/qml/filters/spot_remover/vui.qml" line="82"/>
        <location filename="../src/qml/filters/tracker/vui.qml" line="48"/>
        <location filename="../src/qml/filters/waveform/vui.qml" line="26"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Klepněte v obdélníku + držte klávesu Shift pro tažení</translation>
    </message>
</context>
<context>
    <name>vui_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/vui_spectrum.qml" line="26"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Klepněte v obdélníku + držte klávesu Shift pro tažení</translation>
    </message>
</context>
</TS>
