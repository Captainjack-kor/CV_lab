<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ga">
<context>
    <name>AbstractJob</name>
    <message>
        <location filename="../src/jobs/abstractjob.cpp" line="53"/>
        <source>Pause This Job</source>
        <translation>Cuir an jab seo ar sos</translation>
    </message>
    <message>
        <location filename="../src/jobs/abstractjob.cpp" line="56"/>
        <source>Resume This Job</source>
        <translation>Atosaigh an jab seo</translation>
    </message>
</context>
<context>
    <name>ActionsDialog</name>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="238"/>
        <source>Actions and Shortcuts</source>
        <translation>Gníomhartha agus Aicearraí</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="246"/>
        <source>search</source>
        <translation>cuardaigh</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="260"/>
        <source>Clear search</source>
        <translation>Glan cuardach</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="295"/>
        <source>Click on the selected shortcut to show the editor</source>
        <translation>Cliceáil ar an aicearra roghnaithe chun an t- eagarthóir a thaispeáint</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="301"/>
        <source>Reserved shortcuts can not be edited</source>
        <translation>Ní féidir aicearraí forchoimeádta a chur in eagar</translation>
    </message>
</context>
<context>
    <name>ActionsModel</name>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="188"/>
        <source>Shortcut %1 is used by %2</source>
        <translation>Aicearra %1 in úsáid ag %2</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="198"/>
        <source>Shortcut %1 is reserved for use by %2</source>
        <translation>Tá aicearra %1 curtha in áirithe le húsáid ag %2</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="233"/>
        <source>Action</source>
        <translation>Gníomh</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="235"/>
        <source>Shortcut 1</source>
        <translation>Aicearra 1</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="237"/>
        <source>Shortcut 2</source>
        <translation>Aicearra 2</translation>
    </message>
</context>
<context>
    <name>AddEncodePresetDialog</name>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>Dialóg</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="25"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="52"/>
        <source>File name extension</source>
        <translation>Iarmhír ainm comhaid</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="59"/>
        <source>for example, mp4</source>
        <translation>mar shampla, mp4</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="84"/>
        <source>Make final changes to the preset including removing items you do not want to include, or copy/paste the clipboard.</source>
        <translation>Déan athruithe deiridh ar an réamhshocrú lena n-áirítear míreanna nach mian leat a chur san áireamh a bhaint, nó an ghearrthaisce a chóipeáil/a ghreamú.</translation>
    </message>
</context>
<context>
    <name>AlignAudioDialog</name>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="234"/>
        <source>Reference audio track</source>
        <translation>Rian fuaime tagartha</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="251"/>
        <source>Speed adjustment range</source>
        <translation>Raon coigeartaithe luais</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="254"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="255"/>
        <source>Narrow</source>
        <translation>Caol</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="257"/>
        <source>Normal</source>
        <translation>Gnáth</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="259"/>
        <source>Wide</source>
        <translation>Leathan</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="260"/>
        <source>Very wide</source>
        <translation>An-leathan</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="303"/>
        <source>Process</source>
        <translation>Próiseas</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="306"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="309"/>
        <source>Process + Apply</source>
        <translation>Próiseas + Cuir Iarratas i bhFeidhm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="347"/>
        <source>This clip will be skipped because it is on the reference track.</source>
        <translation>Scipeálfar an ghearrthóg seo toisc go bhfuil sé ar an mbóthar tagartha.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="353"/>
        <source>This item can not be aligned.</source>
        <translation>Ní féidir an mhír seo a ailíniú.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="365"/>
        <source>Align Audio</source>
        <translation>Ailínigh Fuaim</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="482"/>
        <source>Analyze Reference Track</source>
        <translation>Déan anailís ar an Rian Tagartha</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="490"/>
        <source>Analyze Clips</source>
        <translation>Déan anailís ar Ghearrthóga</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="500"/>
        <source>Alignment not found.</source>
        <translation>Níor aimsíodh ailíniú.</translation>
    </message>
</context>
<context>
    <name>AlignClipsModel</name>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="202"/>
        <source>Clip</source>
        <translation>Gearrthóg</translation>
    </message>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="204"/>
        <source>Offset</source>
        <translation>Fritháireamh</translation>
    </message>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="206"/>
        <source>Speed</source>
        <translation>Luas</translation>
    </message>
</context>
<context>
    <name>AlsaWidget</name>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="26"/>
        <source>ALSA Audio</source>
        <translation>Fuaime ALSA</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="54"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="61"/>
        <source>PCM Device</source>
        <translation>Gléas PCM</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="71"/>
        <source>default</source>
        <translation>réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="78"/>
        <source>Channels</source>
        <translation>Cainéil</translation>
    </message>
</context>
<context>
    <name>AttachedFiltersModel</name>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="236"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="238"/>
        <source>Time</source>
        <translation>Am</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="240"/>
        <source>GPU</source>
        <translation>GPU</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="242"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="491"/>
        <source>This file has B-frames, which is not supported by %1.</source>
        <translation>Tá frámaí B sa chomhad seo, nach dtacaíonn %1 leis.</translation>
    </message>
</context>
<context>
    <name>AudioLoudnessScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="85"/>
        <source>Momentary Loudness</source>
        <translation>Callánacht ar feadh meandair</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="88"/>
        <source>Short Term Loudness</source>
        <translation>Callánacht Gearrthéarmach</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="91"/>
        <source>Integrated Loudness</source>
        <translation>Callánacht Comhtháite</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="94"/>
        <source>Loudness Range</source>
        <translation>Raon Callánachta</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="97"/>
        <source>Peak</source>
        <translation>Buaic</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="100"/>
        <source>True Peak</source>
        <translation>Fíor-Bhuaic</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="106"/>
        <source>Configure Graphs</source>
        <translation>Cumraigh Graif</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="114"/>
        <source>Reset</source>
        <translation>Athshocraigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="115"/>
        <source>Reset the measurement.</source>
        <translation>Athshocraigh an tomhas.</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="122"/>
        <source>Time Since Reset</source>
        <translation>Am ó Athshocraigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="178"/>
        <source>Audio Loudness</source>
        <translation>Treise Fuaime</translation>
    </message>
</context>
<context>
    <name>AudioPeakMeterScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="90"/>
        <source>Audio Peak Meter</source>
        <translation>Buaicmhéadar Fuaime</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="107"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="107"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>LF</source>
        <translation>LF</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>Ls</source>
        <translation>Ls</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>Rs</source>
        <translation>Rs</translation>
    </message>
</context>
<context>
    <name>AudioSpectrumScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiospectrumscopewidget.cpp" line="217"/>
        <source>Audio Spectrum</source>
        <translation>Speictream Fuaime</translation>
    </message>
</context>
<context>
    <name>AudioSurroundScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="70"/>
        <source>Audio Surround</source>
        <translation>Timpeallú Fuaime</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="252"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="265"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="279"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="293"/>
        <source>LS</source>
        <translation>LS</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="306"/>
        <source>RS</source>
        <translation>RS</translation>
    </message>
</context>
<context>
    <name>AudioVectorScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="90"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="91"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="99"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="100"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="93"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="95"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="94"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="96"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="103"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="105"/>
        <source>Ls</source>
        <translation>Ls</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="104"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="106"/>
        <source>Rs</source>
        <translation>Rs</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="110"/>
        <source>LFE</source>
        <translation>LFE</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="215"/>
        <source>Audio Vector</source>
        <translation>Veicteoir fuaime</translation>
    </message>
</context>
<context>
    <name>AudioWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="181"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="182"/>
        <source>-inf</source>
        <translation>-inf</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="265"/>
        <source>Sample: %1
</source>
        <translation>Sampla: %1
</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="273"/>
        <source>Ch: %1: %2 (%3 dBFS)</source>
        <translation>Ch: %1:% 2 (%3 dBFS)</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="298"/>
        <source>Audio Waveform</source>
        <translation>Tonnchruth Fuaime</translation>
    </message>
</context>
<context>
    <name>AvformatProducerWidget</name>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="60"/>
        <source>Comments:</source>
        <translation>Tuairimí:</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="174"/>
        <source>Speed</source>
        <translation>Luas</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="120"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="289"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="569"/>
        <source>Broadcast Limited (MPEG)</source>
        <translation>Craoladh Teoranta (MPEG)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="574"/>
        <source>Full (JPEG)</source>
        <translation>Iomlán (JPEG)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="472"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="697"/>
        <source>Track</source>
        <translation>Amhrán</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="460"/>
        <source>Aspect ratio</source>
        <translation>Cóimheas gné</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="525"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="295"/>
        <source>Scan mode</source>
        <translation>Modh scanadh</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="600"/>
        <source>Interlaced</source>
        <translation>Idirfhighte</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="605"/>
        <source>Progressive</source>
        <translation>Forásach</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="374"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="414"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="783"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="813"/>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="184"/>
        <source>Timeline</source>
        <translation>Amlíne</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="199"/>
        <source>Speed Presets</source>
        <translation>Réamhshocruithe Luais</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="251"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="258"/>
        <source>Apply pitch compensation when the speed is changed.</source>
        <translation>Cuir cúiteamh páirce i bhfeidhm nuair a athraítear an luas.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="261"/>
        <source>Pitch Compensation</source>
        <translation>Cúiteamh Páirce</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="315"/>
        <source>Rotation</source>
        <translation>Rothlú</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="379"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="419"/>
        <source>Resolution</source>
        <translation>Rún</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="384"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="424"/>
        <source>Frame rate</source>
        <translation>Ráta fráma</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="389"/>
        <source>Pixel format</source>
        <translation>Formáid picteilíní</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="394"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="434"/>
        <source>Color space</source>
        <translation>Dath spás</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="399"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="439"/>
        <source>Color transfer</source>
        <translation>Aistriú datha</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="404"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="803"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="943"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="409"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="808"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="948"/>
        <source>Value</source>
        <translation>Luach</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="429"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="798"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="828"/>
        <source>Format</source>
        <translation>Formáid</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="614"/>
        <source>Bottom Field First</source>
        <translation>Bun Réimse Ar dtús</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="619"/>
        <source>Top Field First</source>
        <translation>Barr Réimse Ar dtús</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="645"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="650"/>
        <source>90</source>
        <translation>90</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="655"/>
        <source>180</source>
        <translation>180</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="660"/>
        <source>270</source>
        <translation>270</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="668"/>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="691"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="788"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="818"/>
        <source>Channels</source>
        <translation>Cainéil</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="793"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="823"/>
        <source>Sample rate</source>
        <translation>Ráta samplach</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="836"/>
        <source>Adjust the audio/video synchronization. The center position is equivalent to no alteration.</source>
        <translation>Coigeartaigh an sioncrónú fuaime / físe. Is ionann suíomh an ionaid agus gan aon athrú.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="855"/>
        <source>Sync</source>
        <translation>Sioncronú</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="880"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="909"/>
        <source>Metadata</source>
        <translation>Meiteashonraí</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="979"/>
        <source>Properties Menu</source>
        <translation>Roghchlár Airíonna</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1032"/>
        <source>Show In Folder</source>
        <translation>Taispeáin I bhFillteán</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1062"/>
        <source>Extract Subtitles...</source>
        <translation>Bain Fotheidil amach...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1095"/>
        <source>Reset</source>
        <translation>Athshocraigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1100"/>
        <source>Set Equirectangular...</source>
        <translation>Socraigh Cothrománach...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1105"/>
        <source>Measure Video Quality...</source>
        <translation>Tomhais Cáilíocht Físeáin...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1113"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1116"/>
        <source>Export GPX</source>
        <translation>Easpórtáil GPX</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1121"/>
        <source>View Bitrate...</source>
        <translation>Amharc ar Ráta Giotán...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1124"/>
        <source>View Bitrate</source>
        <translation>Amharc ar Ráta Giotán</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1129"/>
        <source>Show In Files</source>
        <translation>Taispeáin I gComhaid</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1000"/>
        <source>Convert to Edit-friendly</source>
        <translation>Tiontaigh go Edit-friendly</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="305"/>
        <source>Color range</source>
        <translation>Raon datha</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1003"/>
        <source>Convert...</source>
        <translation>Tiontaigh...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1037"/>
        <source>Copy Full File Path</source>
        <translation>Cóipeáil Conair Iomlán an Chomhaid</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1042"/>
        <source>More Information...</source>
        <translation>Tuilleadh Eolais...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1047"/>
        <source>Start Integrity Check Job</source>
        <translation>Tosaigh Post Seiceála Ionracais</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1052"/>
        <source>Convert to Edit-friendly...</source>
        <translation>Tiontaigh go Éasca le hEagar...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1067"/>
        <source>Set Creation Time...</source>
        <translation>Socraigh Am Cruthaithe...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1075"/>
        <source>Disable Proxy</source>
        <translation>Díchumasaigh Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1080"/>
        <source>Make Proxy</source>
        <translation>Déan Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1085"/>
        <source>Delete Proxy</source>
        <translation>Scrios Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1090"/>
        <source>Copy Hash Code</source>
        <translation>Cóipeáil Cód Hash</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="993"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="861"/>
        <source>Reverse...</source>
        <translation>Droim ar ais...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1057"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1127"/>
        <source>Extract Sub-clip...</source>
        <translation>Bain fo-ghearrthóg amach...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="347"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="418"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="376"/>
        <source>unknown (%1)</source>
        <translation>anaithnid (%1)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="452"/>
        <source>All</source>
        <translation>Gach</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="498"/>
        <source>(PROXY)</source>
        <translation>(SEACHFHREASTALAÍ)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="541"/>
        <source>(variable)</source>
        <translation>(athróg)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1010"/>
        <source>Proxy</source>
        <translation>Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="134"/>
        <source> Do you want to convert it to an edit-friendly format?

If yes, choose a format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, it automatically replaces clips, or you can double-click the job to open it.
</source>
        <translation>Ar mhaith leat é a thiontú go formáid atá furasta a chur in eagar?

Má tá, roghnaigh formáid thíos agus ansin cliceáil OK chun ainm comhaid a roghnú. Tar éis ainm comhaid a roghnú, cruthaítear post. Nuair a dhéantar é, cuireann sé gearrthóga in ionad go huathoibríoch, nó is féidir leat cliceáil faoi dhó ar an bpost chun é a oscailt.
</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="781"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="856"/>
        <source>Choose an edit-friendly format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, double-click the job to open it.
</source>
        <translation>Roghnaigh formáid atá éasca le heagarthóireacht thíos agus ansin cliceáil OK chun ainm comhaid a roghnú. Tar éis ainm comhaid a roghnú, cruthaítear post. Nuair a bheidh sé déanta, cliceáil faoi dhó ar an bpost chun é a oscailt.
</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="970"/>
        <source>MP4 (*.mp4);;All Files (*)</source>
        <translation>MP4 (*.mp4);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1015"/>
        <source>MOV (*.mov);;All Files (*)</source>
        <translation>MOV (*.mov);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1032"/>
        <source>MKV (*.mkv);;All Files (*)</source>
        <translation>MKV (*.mkv);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1085"/>
        <source>Convert %1</source>
        <translation>Tiontaigh %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1036"/>
        <source>Reversed</source>
        <translation>Droim ar ais</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1066"/>
        <source>Reverse canceled</source>
        <translation>Cealaithe droim ar ais</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1095"/>
        <source>Reverse %1</source>
        <translation>Aisiompaigh %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1464"/>
        <source>Choose the Other Video</source>
        <translation>Roghnaigh an físeán eile</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1517"/>
        <source>Measure %1</source>
        <translation>Tomhais %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1126"/>
        <source>Sub-clip</source>
        <translation>Fo-chlip</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1128"/>
        <source>%1 (*.%2);;All Files (*)</source>
        <translation>%1 (*.%2);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1200"/>
        <source>Extract sub-clip %1</source>
        <translation>Bain fo-ghearrthóg %1 amach</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1219"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1269"/>
        <source>Track %1</source>
        <translation>Amhrán %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1221"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1271"/>
        <source>Track %1 (%2)</source>
        <translation>Amhrán %1 (%2)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1225"/>
        <source>Export Subtitles...</source>
        <translation>Easpórtáil Fotheidil...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1227"/>
        <source>No subtitles found</source>
        <translation>Níor aimsíodh fotheidil ar bith</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1286"/>
        <source>Extract subtitles %1</source>
        <translation>Bain fotheidil amach %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1399"/>
        <source>The hash code below is already copied to your clipboard:

</source>
        <translation>Tá an cód hash thíos cóipeáilte chuig do ghearrthaisce cheana féin:

</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1443"/>
        <source>Set Equirectangular Projection</source>
        <translation>Socraigh Teilgean Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1455"/>
        <source>Successfully wrote %1</source>
        <translation>D&apos;éirigh le scríobh %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1457"/>
        <source>An error occurred saving the projection.</source>
        <translation>Tharla earráid agus an teilgean á sábháil.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1577"/>
        <source>Bitrate %1</source>
        <translation>Ráta giotán %1</translation>
    </message>
</context>
<context>
    <name>AvfoundationProducerWidget</name>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="26"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="107"/>
        <source>Audio/Video Device</source>
        <translation>Gléas Fuaime/Físe</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="39"/>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="58"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="83"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="84"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="90"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="99"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="47"/>
        <source>Video Input</source>
        <translation>Ionchur Físeáin</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="66"/>
        <source>Audio Input</source>
        <translation>Ionchur Fuaime</translation>
    </message>
</context>
<context>
    <name>BitrateDialog</name>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="48"/>
        <source>Bitrate Viewer</source>
        <translation>Amharcán Giotán</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="66"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="74"/>
        <source>Average</source>
        <translation>Meán</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="135"/>
        <source>Bitrates for %1 ~~ Avg. %2 Min. %3 Max. %4 Kb/s</source>
        <translation>Giotán le haghaidh %1 ~~ Meánlíon.%2 Min.%3 Max.%4 Kb/s</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="179"/>
        <source>Save Bitrate Graph</source>
        <translation>Sábháil Graf Ráta Giotán</translation>
    </message>
</context>
<context>
    <name>BitrateViewerJob</name>
    <message>
        <location filename="../src/jobs/bitrateviewerjob.cpp" line="34"/>
        <source>Open</source>
        <translation>Oscail</translation>
    </message>
</context>
<context>
    <name>BlipProducerWidget</name>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="26"/>
        <source>Blip Flash</source>
        <translation>Splanc Blipe</translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>Minicíocht</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/widgets/blipproducerwidget.cpp" line="67"/>
        <source> second(s)</source>
        <translation>
            <numerusform>soicind</numerusform>
            <numerusform>soicindí</numerusform>
            <numerusform>soicindí</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.cpp" line="89"/>
        <source>Period: %1s</source>
        <translation>Tréimhse: %1s</translation>
    </message>
</context>
<context>
    <name>ClockSpinner</name>
    <message>
        <location filename="../src/qml/filters/timer/ClockSpinner.qml" line="121"/>
        <source>Decrement</source>
        <translation>Laghdú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ClockSpinner.qml" line="150"/>
        <source>Increment</source>
        <translation>Incrimint</translation>
    </message>
</context>
<context>
    <name>ColorBarsWidget</name>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="26"/>
        <source>Color Bars</source>
        <translation>Barraí Dath</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="38"/>
        <source>Type</source>
        <translation>Cineál</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="55"/>
        <source>100% PAL color bars</source>
        <translation>Barraí datha PAL 100%</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="60"/>
        <source>100% PAL color bars with red</source>
        <translation>Barraí datha PAL 100% le dearg</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="65"/>
        <source>95% BBC PAL color bars</source>
        <translation>95% barraí dath BBC PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="70"/>
        <source>75% EBU color bars</source>
        <translation>75% barraí dath EBU</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="75"/>
        <source>SMPTE color bars</source>
        <translation>Barraí datha SMPTE</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="80"/>
        <source>Philips PM5544</source>
        <translation>Philips PM5544</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="85"/>
        <source>FuBK</source>
        <translation>FuBK</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="90"/>
        <source>Simplified FuBK</source>
        <translation>FuBK Simplithe</translation>
    </message>
</context>
<context>
    <name>ColorPicker</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="58"/>
        <source>Click to open color dialog</source>
        <translation>Cliceáil chun dialóg datha a oscailt</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="89"/>
        <source>Pick a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation>Roghnaigh dath ar an scáileán. Tríd an gcnaipe luiche a bhrú agus ansin do luch a bhogadh is féidir leat cuid den scáileán a roghnú as a bhfaighidh tú meándath.</translation>
    </message>
</context>
<context>
    <name>ColorProducerWidget</name>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="20"/>
        <source>Color</source>
        <translation>Dath</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="30"/>
        <source>Comments:</source>
        <translation>Tuairimí:</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="61"/>
        <source>Color...</source>
        <translation>Dath...</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="74"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="58"/>
        <source>black</source>
        <translation>dubh</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="60"/>
        <source>transparent</source>
        <translation>trédhearcach</translation>
    </message>
</context>
<context>
    <name>CopyFiltersDialog</name>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="44"/>
        <source>Copy Filters</source>
        <translation>Cóipeáil Scagairí</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="57"/>
        <source>Enter a name to save a filter set, or
leave blank to use the clipboard:</source>
        <translation>Iontráil ainm chun tacar scagaire a shábháil, nó
Fág bán chun an ghearrthaisce a úsáid:</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="64"/>
        <source>optional</source>
        <translation>roghnach</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="84"/>
        <source>OK</source>
        <translation>Ceart go leor</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="89"/>
        <source>Cancel</source>
        <translation>Cealaigh</translation>
    </message>
</context>
<context>
    <name>CountProducerWidget</name>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="26"/>
        <source>Count</source>
        <translation>Áireamh</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="41"/>
        <source>Direction</source>
        <translation>Treo</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="74"/>
        <source>Style</source>
        <translation>Stíl</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="107"/>
        <source>Sound</source>
        <translation>Fuaim</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="110"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Silent - No sound&lt;/p&gt;&lt;p&gt;2-Pop - A 1kHz beep exactly two seconds before the out point&lt;/p&gt;&lt;p&gt;Frame 0 - A 1kHz beep at frame 0 of every second&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ciúin - Gan fuaim&lt;/p&gt;&lt;p&gt;2-Pop - A 1kHz bíp díreach dhá soicind roimh an bpointe amach&lt;/p&gt;&lt;p&gt;Fráma 0 - A 1kHz bíp ag fráma 0 de gach soicind&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="143"/>
        <source>Background</source>
        <translation>Cúlra</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="146"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;None - No background&lt;/p&gt;&lt;p&gt;Clock  - Film style clock animation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tada - Gan chúlra&lt;/p&gt;&lt;p&gt;Clog  - Beochan clog ar stíl scannán&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="179"/>
        <source>Drop Frame</source>
        <translation>Fráma Buail</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="182"/>
        <source>Use SMPTE style drop-frame counting for non-integer frame rates. The clock and timecode will advance two frames every minute if necessary to keep time with wall clock time.</source>
        <translation>Bain úsáid as comhaireamh fráma titim stíl SMPTE le haghaidh rátaí fráma neamh-slánuimhir. Cuirfidh an clog agus an t-amchód dhá fhráma chun cinn gach nóiméad más gá chun am a choinneáil le ham clog balla.</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="189"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="41"/>
        <source>Down</source>
        <translation>Síos</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="42"/>
        <source>Up</source>
        <translation>Suas</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="45"/>
        <source>Seconds</source>
        <translation>Soicind</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="46"/>
        <source>Seconds + 1</source>
        <translation>Soicind + 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="47"/>
        <source>Frames</source>
        <translation>Frámaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="48"/>
        <source>Timecode</source>
        <translation>Amchód</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="49"/>
        <location filename="../src/widgets/countproducerwidget.cpp" line="57"/>
        <source>Clock</source>
        <translation>Clog</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="52"/>
        <source>2-Pop</source>
        <translation>2-Pop</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="53"/>
        <source>Silent</source>
        <translation>Ciúin</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="54"/>
        <source>Frame 0</source>
        <translation>Fráma 0</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="58"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="225"/>
        <source>Count: %1 %2</source>
        <translation>Líon: %1 %2</translation>
    </message>
</context>
<context>
    <name>CurveComboBox</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="36"/>
        <source>Natural</source>
        <translation>Nádúrtha</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="40"/>
        <source>S-Curve</source>
        <translation>S-Cuar</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="44"/>
        <source>Fast-Slow</source>
        <translation>Tapa-Mall</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="48"/>
        <source>Slow-Fast</source>
        <translation>Mall-tapa</translation>
    </message>
</context>
<context>
    <name>CustomProfileDialog</name>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="14"/>
        <source>Add Custom Video Mode</source>
        <translation>Cuir Mód Físe Saincheaptha Leis</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="29"/>
        <source>Colorspace</source>
        <translation>Spás datha</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="58"/>
        <source>ITU-R BT.2020</source>
        <translation>ITU-R BT.2020</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="81"/>
        <source>Resolution</source>
        <translation>Rún</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="112"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="182"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="201"/>
        <source>Interlaced</source>
        <translation>Idirfhighte</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="206"/>
        <source>Progressive</source>
        <translation>Forásach</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="229"/>
        <source>Aspect ratio</source>
        <translation>Cóimheas gné</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="260"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="348"/>
        <source>Frames/sec</source>
        <translation>Frámaí/soic</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="449"/>
        <source>Scan mode</source>
        <translation>Modh scanadh</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="481"/>
        <source>&lt;small&gt;(Leave Name blank to skip saving a preset and use a temporary or project-specific Video Mode.)&lt;/small&gt;</source>
        <translation>&lt;small&gt;(Fág an tAinm bán chun réamhshocrú a shábháil agus Mód Físe sealadach nó tionscadal-sonrach a úsáid.)&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.cpp" line="134"/>
        <source>Video Mode Frames/sec</source>
        <translation>Frámaí Mód Físe/soic</translation>
    </message>
</context>
<context>
    <name>DecklinkProducerWidget</name>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="26"/>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="85"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="57"/>
        <source>Device</source>
        <translation>Gléas</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="67"/>
        <source>Signal mode</source>
        <translation>Mód comhartha</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="85"/>
        <source>Please be aware that not every card model supports automatic signal detection, and not all cards support all of the signal modes.</source>
        <translation>Bí ar an eolas nach dtacaíonn gach samhail cárta le brath comhartha uathoibríoch, agus ní thacaíonn gach cárta le gach ceann de na modhanna comhartha.</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="31"/>
        <source>Detect Automatically</source>
        <translation>Braith go huathoibríoch</translation>
    </message>
</context>
<context>
    <name>DirectShowVideoWidget</name>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="26"/>
        <location filename="../src/widgets/directshowvideowidget.cpp" line="166"/>
        <source>Audio/Video Device</source>
        <translation>Gléas Fuaime/Físe</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="52"/>
        <location filename="../src/widgets/directshowvideowidget.ui" line="81"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="60"/>
        <source>Video Input</source>
        <translation>Ionchur Físeáin</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="70"/>
        <source>Audio Input</source>
        <translation>Ionchur Fuaime</translation>
    </message>
</context>
<context>
    <name>DurationDialog</name>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="17"/>
        <source>Set Duration</source>
        <translation>Socraigh Fad</translation>
    </message>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="25"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
</context>
<context>
    <name>EditMarkerDialog</name>
    <message>
        <location filename="../src/dialogs/editmarkerdialog.cpp" line="31"/>
        <source>Edit Marker</source>
        <translation>Cuir Marcóir in Eagar</translation>
    </message>
</context>
<context>
    <name>EditMarkerWidget</name>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="46"/>
        <source>Set the name for this marker.</source>
        <translation>Socraigh ainm an mharcóra seo.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="49"/>
        <source>Color...</source>
        <translation>Dath...</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="57"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="62"/>
        <source>Set the start time for this marker.</source>
        <translation>Socraigh am tosaithe an mharcóra seo.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="69"/>
        <source>End</source>
        <translation>Críoch</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="74"/>
        <source>Set the end time for this marker.</source>
        <translation>Socraigh an t-am deiridh don mharcóir seo.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="78"/>
        <source>Duration:</source>
        <translation>Fad ama:</translation>
    </message>
</context>
<context>
    <name>EncodeDock</name>
    <message>
        <location filename="../src/docks/encodedock.ui" line="18"/>
        <source>Export</source>
        <translation>Easpórtáil</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="45"/>
        <source>&lt;b&gt;Presets&lt;/b&gt;</source>
        <translation>&lt;b&gt;Réamhshocruithe&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="58"/>
        <source>search</source>
        <translation>cuardaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="89"/>
        <source>Add current settings as a new custom preset</source>
        <translation>Cuir socruithe reatha leis mar réamhshocrú saincheaptha nua</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="103"/>
        <source>Delete currently selected preset</source>
        <translation>Scrios an réamhshocrú roghnaithe faoi láthair</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="169"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Export Help&lt;/span&gt;&lt;/p&gt;&lt;p&gt;The defaults create a H.264/AAC MP4 file, which is suitable for most users and purposes. Choose a &lt;span style=&quot; font-weight:600;&quot;&gt;Preset&lt;/span&gt; at the left before deciding to use the &lt;span style=&quot; font-weight:600;&quot;&gt;Advanced&lt;/span&gt; mode. The &lt;span style=&quot; font-weight:600;&quot;&gt;Advanced&lt;/span&gt; mode does not prevent creating an invalid combination of options!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cabhair Easpórtála&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cruthaíonn na réamhshocruithe comhad H.264/AAC MP4, atá oiriúnach d&apos;fhormhór na n-úsáideoirí agus na gcríoch. Roghnaigh &lt;span style=&quot; font-weight:600;&quot;&gt;Réamhshocraithe&lt;/span&gt; ar chlé sula gcinnfidh tú an modh &lt;span style=&quot; font-weight:600;&quot;&gt;Mód&lt;/span&gt; casta. Ní chuireann an modh &lt;span style=&quot; font-weight:600;&quot;&gt;casta&lt;/span&gt; ar chomhcheangal roghanna neamhbhailí a chruthú!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="187"/>
        <source>From</source>
        <translation>Ó</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="217"/>
        <source>Format</source>
        <translation>Formáid</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="253"/>
        <source>Use hardware encoder</source>
        <translation>Úsáid ionchódóir crua-earraí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="260"/>
        <source>Configure...</source>
        <translation>Cumraigh...</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="294"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="485"/>
        <source>Interpolation</source>
        <translation>Idirshuíomh</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="539"/>
        <source>Field order</source>
        <translation>Ord allamuigh</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="549"/>
        <source>Aspect ratio</source>
        <translation>Cóimheas gné</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="723"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="579"/>
        <source>Scan mode</source>
        <translation>Modh scanadh</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="664"/>
        <source>Interlaced</source>
        <translation>Idirfhighte</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="669"/>
        <source>Progressive</source>
        <translation>Forásach</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="617"/>
        <source>Resolution</source>
        <translation>Rún</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="569"/>
        <source>Frames/sec</source>
        <translation>Frámaí/soic</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="916"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="824"/>
        <source>Bottom Field First</source>
        <translation>Bun Réimse Ar dtús</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="829"/>
        <source>Top Field First</source>
        <translation>Barr Réimse Ar dtús</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="858"/>
        <source>One Field (fast)</source>
        <translation>Réimse amháin (tapa)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="863"/>
        <source>Linear Blend (fast)</source>
        <translation>Cumasc Líneach (tapa)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="868"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF - ama amháin (go maith)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="559"/>
        <source>Deinterlacer</source>
        <translation>Dídhéantóir Idirmheasctha</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="501"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>Comharsa is Cóngaraí (tapa)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="506"/>
        <source>Bilinear (good)</source>
        <translation>Délíneach (go maith)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="511"/>
        <source>Bicubic (better)</source>
        <translation>Bicúbach (níos fearr)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="811"/>
        <source>Use preview scaling</source>
        <translation>Úsáid scálú réamhamhairc</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="599"/>
        <source>This enables multiple image processing threads.
Sometimes, this can be a problem, and you can
test if turning this off helps. For example, some
interlaced AVCHD in conjunction with the YADIF
deinterlacer has been reported as problematic
with parallel processing enabled.</source>
        <translation>Cuireann sé seo ar chumas snáitheanna próiseála íomhá il.
Uaireanta, d&apos;fhéadfadh sé seo a bheith ina fhadhb, agus is féidir leat
má chabhraíonn sé seo a chasadh as. Mar shampla,
AVCHD idirnasctha i gcomhar leis an YADIF
tuairiscíodh go raibh fadhbanna ag baint le
le próiseáil chomhthreomhar cumasaithe.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="330"/>
        <source>Reframe</source>
        <translation>Athfhráma</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="589"/>
        <source>Color range</source>
        <translation>Raon datha</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="607"/>
        <source>Parallel processing</source>
        <translation>Próiseáil chomhthreomhar</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="630"/>
        <source>Broadcast Limited (MPEG)</source>
        <translation>Craoladh Teoranta (MPEG)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="635"/>
        <source>Full (JPEG)</source>
        <translation>Iomlán (JPEG)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="873"/>
        <source>YADIF - temporal + spatial (better)</source>
        <translation>YADIF - ama + spásúil (níos fearr)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="878"/>
        <source>BWDIF (best)</source>
        <translation>BWDIF (is fearr)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="955"/>
        <location filename="../src/docks/encodedock.ui" line="964"/>
        <location filename="../src/docks/encodedock.ui" line="1647"/>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="994"/>
        <source>GOP</source>
        <translation>GOP</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1006"/>
        <source>GOP = group of pictures, which is the maximum key frame interval</source>
        <translation>GOP = grúpa pictiúr, a bhfuil an t-eatramh fráma eochair uasta</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1019"/>
        <source>frames</source>
        <translation>frámaí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1039"/>
        <source>A fixed GOP means that keyframes will
not be inserted at detected scene changes.</source>
        <translation>Ciallaíonn GOP seasta go mbeidh eochairfhrámaí
a chur isteach ag athruithe radhairc a braitheadh.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1043"/>
        <source>Fixed</source>
        <translation>Seasta</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1067"/>
        <location filename="../src/docks/encodedock.ui" line="1689"/>
        <source>The average bit rate</source>
        <translation>An meánráta giotán</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1220"/>
        <location filename="../src/docks/encodedock.ui" line="1772"/>
        <source>b/s</source>
        <translation>b/s</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1242"/>
        <source>Disable video</source>
        <translation>Díchumasaigh an físeán</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1249"/>
        <source>Dual pass</source>
        <translation>Pas dé</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1256"/>
        <source>B frames</source>
        <translation>Frámaí B</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1268"/>
        <source>B frames are the bidirectional &quot;delta&quot; pictures
in temporal compression</source>
        <translation>Is iad frámaí B na pictiúir déthreo &quot;delta&quot;
i gcomhbhrú ama</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1307"/>
        <source>Codec threads</source>
        <translation>Snáitheanna codec</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1322"/>
        <source>(0 = auto)</source>
        <translation>(0 = carr)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1344"/>
        <location filename="../src/docks/encodedock.ui" line="1814"/>
        <source>Rate control</source>
        <translation>Rialú rátaí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1357"/>
        <location filename="../src/docks/encodedock.ui" line="1827"/>
        <source>Average Bitrate</source>
        <translation>Meánráta Giotán</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1362"/>
        <location filename="../src/docks/encodedock.ui" line="1832"/>
        <source>Constant Bitrate</source>
        <translation>Ráta Giotán Tairiseach</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1367"/>
        <location filename="../src/docks/encodedock.ui" line="1837"/>
        <source>Quality-based VBR</source>
        <translation>VBR bunaithe ar cháilíocht</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1372"/>
        <source>Constrained VBR</source>
        <translation>VBR srianta</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1395"/>
        <source>Buffer size</source>
        <translation>Méid an mhaoláin</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1417"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1439"/>
        <location filename="../src/docks/encodedock.ui" line="1860"/>
        <source>Quality</source>
        <translation>Cáilíocht</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1451"/>
        <location filename="../src/docks/encodedock.ui" line="1872"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1467"/>
        <location filename="../src/docks/encodedock.ui" line="1888"/>
        <source>TextLabel</source>
        <translation>Lipéad Téacs</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1489"/>
        <location filename="../src/docks/encodedock.ui" line="1677"/>
        <source>Bitrate</source>
        <translation>Ráta Giotán</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1500"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1509"/>
        <source>Channels</source>
        <translation>Cainéil</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1521"/>
        <source>The number of audio channels in the output.</source>
        <translation>Líon na gcainéal fuaime san aschur.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1525"/>
        <source>1 (mono)</source>
        <translation>1 (mona)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1530"/>
        <source>2 (stereo)</source>
        <translation>2 (steirió)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1535"/>
        <source>4 (quad/Ambisonics)</source>
        <translation>4 (cuad/Ambisonics)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1540"/>
        <source>6 (5.1 surround)</source>
        <translation>6 (5.1 timpeall)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1615"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1637"/>
        <source>Sample rate</source>
        <translation>Ráta samplach</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1794"/>
        <source>Disable audio</source>
        <translation>Díchumasaigh fuaim</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1911"/>
        <source>Other</source>
        <translation>Eile</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1927"/>
        <source>Disable subtitles</source>
        <translation>Díchumasaigh fotheidil</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1960"/>
        <location filename="../src/docks/encodedock.cpp" line="1328"/>
        <location filename="../src/docks/encodedock.cpp" line="1839"/>
        <location filename="../src/docks/encodedock.cpp" line="2331"/>
        <source>Export File</source>
        <translation>Easpórtáil Comhad</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1970"/>
        <source>Reset options to defaults</source>
        <translation>Athshocraigh roghanna go réamhshocruithe</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1973"/>
        <source>Reset</source>
        <translation>Athshocraigh</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1980"/>
        <source>Advanced</source>
        <translation>Ard</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1990"/>
        <source>Always start in Advanced mode</source>
        <translation>Tosaigh i mód Casta i gcónaí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="2000"/>
        <location filename="../src/docks/encodedock.cpp" line="2035"/>
        <location filename="../src/docks/encodedock.cpp" line="2042"/>
        <location filename="../src/docks/encodedock.cpp" line="2154"/>
        <source>Stream</source>
        <translation>Sruth</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="2027"/>
        <location filename="../src/docks/encodedock.cpp" line="1822"/>
        <location filename="../src/docks/encodedock.cpp" line="1923"/>
        <location filename="../src/docks/encodedock.cpp" line="1933"/>
        <source>Stop Capture</source>
        <translation>Stad Gabháil</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="135"/>
        <source>Automatic from extension</source>
        <translation>Uathoibríoch ó iarmhír</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="143"/>
        <location filename="../src/docks/encodedock.cpp" line="153"/>
        <source>Default for format</source>
        <translation>Réamhshocrú formáide</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="465"/>
        <source>Timeline</source>
        <translation>Amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="472"/>
        <location filename="../src/docks/encodedock.cpp" line="478"/>
        <source>Source</source>
        <translation>Foinse</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="483"/>
        <location filename="../src/docks/encodedock.cpp" line="490"/>
        <source>Marker</source>
        <translation>Marcóir</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="501"/>
        <source>You must enter numeric values using &apos;%1&apos; as the decimal point.</source>
        <translation>Ní mór duit luachanna uimhriúla a iontráil le &apos;%1&apos; mar phointe deachúil.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="510"/>
        <location filename="../src/docks/encodedock.cpp" line="1769"/>
        <location filename="../src/docks/encodedock.cpp" line="1770"/>
        <source>Custom</source>
        <translation>Saincheaptha</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="546"/>
        <source>Stock</source>
        <translation>Stoc</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="549"/>
        <source>Default</source>
        <translation>Réamhshocrú</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1395"/>
        <source>You cannot write to a file that is in your project.
Try again with a different folder or file name.</source>
        <translation>Ní féidir leat scríobh chuig comhad atá i do thionscadal.
Bain triail eile as le fillteán nó ainm comhaid eile.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1493"/>
        <source>Shotcut found filters that require analysis jobs that have not run.
Do you want to run the analysis jobs now?</source>
        <translation>Fuair Shotcut scagairí a dteastaíonn poist anailíse uathu nach bhfuil ar siúl.
An bhfuil fonn ort na poist anailíse a reáchtáil anois?</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1839"/>
        <location filename="../src/docks/encodedock.cpp" line="2333"/>
        <source>Capture File</source>
        <translation>Comhad Gabhála</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1841"/>
        <source>Export Files</source>
        <translation>Easpórtáil Comhaid</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1856"/>
        <source>%1 (*.%2);;All Files (*)</source>
        <translation>%1 (*.%2);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1858"/>
        <source>Determined by Export (*)</source>
        <translation>Arna chinneadh ag Easpórtáil (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2030"/>
        <location filename="../src/docks/encodedock.cpp" line="2052"/>
        <source>Stop Stream</source>
        <translation>Stad Sruth</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2044"/>
        <source>Enter the network protocol scheme, address, port, and parameters as an URL:</source>
        <translation>Iontráil an scéim prótacal líonra, seoladh, calafort, agus paraiméadair mar URL:</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2087"/>
        <source>Add Export Preset</source>
        <translation>Cuir Réamhshocraithe Easpórtála Leis</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2131"/>
        <source>Delete Preset</source>
        <translation>Scrios Réamhshocrú</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2132"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>An bhfuil tú cinnte gur mian leat %1 a scriosadh?</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2260"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2315"/>
        <source>KiB (%1s)</source>
        <translation>KiB (%1s)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2463"/>
        <source>Detect</source>
        <translation>Braith</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2520"/>
        <source>(auto)</source>
        <translation>(carr)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2566"/>
        <source>Detecting hardware encoders...</source>
        <translation>Ionchódóirí crua-earraí á mbrath...</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2623"/>
        <source>Nothing found</source>
        <translation>Níor aimsíodh aon rud</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2625"/>
        <source>Found %1</source>
        <translation>Aimsíodh %1</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2848"/>
        <source>Your project is missing some files.

Save your project, close it, and reopen it.
Shotcut will attempt to repair your project.</source>
        <translation>Tá roinnt comhad in easnamh ar do thionscadal.

Sábháil do thionscadal, dún é, agus athoscail é.
Déanfaidh Shotcut iarracht do thionscadal a dheisiú.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2897"/>
        <source>Aspect ratio does not match project Video Mode, which causes black bars.</source>
        <translation>Ní cóimheas Gné mheaitseáil tionscadal Video Mód, a cúiseanna barraí dubh.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2935"/>
        <source>Frame rate is higher than project Video Mode, which causes frames to repeat.</source>
        <translation>Tá ráta fráma níos airde ná Mód Video tionscadail, rud is cúis le frámaí a athdhéanamh.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2461"/>
        <source>Configure Hardware Encoding</source>
        <translation>Cumraigh Ionchódú crua-earraí</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="468"/>
        <source>Current Playlist Bin</source>
        <translation>Bosca Seinmliosta Reatha</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="469"/>
        <source>Each Playlist Bin Item</source>
        <translation>Gach mír bosca bruscair seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1842"/>
        <source>Export Each Playlist Bin Item</source>
        <translation>Easpórtáil gach mír bosca bruscair seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1887"/>
        <source>Export canceled</source>
        <translation>Cealaíodh easpórtáil</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2485"/>
        <source>Export Frames/sec</source>
        <translation>Easpórtáil Frámaí/soic</translation>
    </message>
</context>
<context>
    <name>EncodeJob</name>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="46"/>
        <source>Open</source>
        <translation>Oscail</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="48"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>Oscail an comhad aschuir san imreoir Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="52"/>
        <location filename="../src/jobs/encodejob.cpp" line="53"/>
        <source>Show In Files</source>
        <translation>Taispeáin I gComhaid</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="57"/>
        <location filename="../src/jobs/encodejob.cpp" line="58"/>
        <source>Show In Folder</source>
        <translation>Taispeáin I bhFillteán</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="62"/>
        <source>Measure Video Quality...</source>
        <translation>Tomhais Cáilíocht Físeáin...</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="66"/>
        <source>Set Equirectangular...</source>
        <translation>Socraigh Cothrománach...</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="75"/>
        <source>Video Quality Report</source>
        <translation>Tuarascáil ar Chaighdeán Físe</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="76"/>
        <source>Text Documents (*.txt);;All Files (*)</source>
        <translation>Doiciméid Téacs (*.txt);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="138"/>
        <source>Set Equirectangular Projection</source>
        <translation>Socraigh Teilgean Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="152"/>
        <source>Successfully wrote %1</source>
        <translation>D&apos;éirigh le scríobh %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="154"/>
        <source>An error occurred saving the projection.</source>
        <translation>Tharla earráid agus an teilgean á sábháil.</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="182"/>
        <source>Export job failed; trying again without Parallel processing.</source>
        <translation>Theip ar easpórtáil an phoist; ag iarraidh arís gan próiseáil Chomhthreomhar.</translation>
    </message>
</context>
<context>
    <name>FfmpegJob</name>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="43"/>
        <source>Open</source>
        <translation>Oscail</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="48"/>
        <source>Check %1</source>
        <translation>Seiceáil %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="77"/>
        <source>FFmpeg Log</source>
        <translation>Logchomhad FFmpeg</translation>
    </message>
</context>
<context>
    <name>FfprobeJob</name>
    <message>
        <location filename="../src/jobs/ffprobejob.cpp" line="52"/>
        <source>More Information</source>
        <translation>Tuilleadh Eolais</translation>
    </message>
</context>
<context>
    <name>FileDateDialog</name>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="46"/>
        <source>%1 File Date</source>
        <translation>Dáta an Chomhaid %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="102"/>
        <source>Current Value</source>
        <translation>Luach Reatha</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="106"/>
        <source>Now</source>
        <translation>Anois</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="112"/>
        <source>System - Modified</source>
        <translation>Córas - Athraithe</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="113"/>
        <source>System - Created</source>
        <translation>Córas - Cruthaithe</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="123"/>
        <source>Metadata - Creation Time</source>
        <translation>Meiteashonraí - Am Cruthaithe</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="130"/>
        <source>Metadata - QuickTime date</source>
        <translation>Meiteashonraí - QuickTime dáta</translation>
    </message>
</context>
<context>
    <name>FilesDock</name>
    <message>
        <location filename="../src/docks/filesdock.ui" line="18"/>
        <location filename="../src/docks/filesdock.cpp" line="597"/>
        <source>Files</source>
        <translation>Comhaid</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="61"/>
        <source>Location</source>
        <translation>Suíomh</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="90"/>
        <source>Add the current folder to the saved locations</source>
        <translation>Cuir an fillteán reatha leis na suíomhanna sábháilte</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="110"/>
        <source>Remove the selected location</source>
        <translation>Bain an suíomh roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="502"/>
        <source>Home</source>
        <comment>The user&apos;s home folder in the file system</comment>
        <translation>Baile</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="503"/>
        <source>Current Project</source>
        <translation>Tionscadal Reatha</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="504"/>
        <source>Documents</source>
        <translation>Doiciméid</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="509"/>
        <source>Movies</source>
        <comment>The system-provided videos folder called Movies on macOS</comment>
        <translation>Scannáin</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="513"/>
        <source>Music</source>
        <translation>Ceol</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="516"/>
        <source>Pictures</source>
        <comment>The system-provided photos folder</comment>
        <translation>Pictiúir</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="520"/>
        <source>Volumes</source>
        <comment>The macOS file system location where external drives and network shares are mounted</comment>
        <translation>Imleabhair</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="525"/>
        <source>Videos</source>
        <translation>Físeáin</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="607"/>
        <source>Select</source>
        <translation>Roghnaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="611"/>
        <source>Files Controls</source>
        <translation>Rialtáin Comhad</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="616"/>
        <source>Files Menu</source>
        <translation>Roghchlár na gComhad</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="642"/>
        <location filename="../src/docks/filesdock.cpp" line="652"/>
        <source>Files Filters</source>
        <translation>Scagairí Comhad</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="675"/>
        <source>Only show files whose name contains some text</source>
        <translation>Ná taispeáin ach comhaid a bhfuil téacs éigin ina n-ainm</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="676"/>
        <source>search</source>
        <translation>cuardaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="785"/>
        <source>Tiles</source>
        <translation>Tíleanna</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="786"/>
        <source>View as tiles</source>
        <translation>Féach mar tíleanna</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="798"/>
        <source>Icons</source>
        <translation>Deilbhíní</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="799"/>
        <source>View as icons</source>
        <translation>Féach orthu mar dheilbhíní</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="811"/>
        <source>Details</source>
        <translation>Sonraí</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="812"/>
        <source>View as details</source>
        <translation>Féach ar mar shonraí</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="824"/>
        <source>Open In Shotcut</source>
        <translation>Oscail i Shotcut</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="825"/>
        <source>Open the clip in the Source player</source>
        <translation>Oscail an ghearrthóg san imreoir Foinse</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="833"/>
        <source>System Default</source>
        <translation>Réamhshocrú an Chórais</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="847"/>
        <source>Other...</source>
        <translation>Eile...</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="855"/>
        <source>Remove...</source>
        <translation>Bain...</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="863"/>
        <source>Show In File Manager</source>
        <translation>Taispeáin i mBainisteoir Comhad</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="873"/>
        <source>Update Thumbnails</source>
        <translation>Nuashonraigh Mionsamhlacha</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="881"/>
        <source>Select All</source>
        <translation>Roghnaigh Uile</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="892"/>
        <source>Select None</source>
        <translation>Roghnaigh Dada</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="903"/>
        <source>Open Previous</source>
        <translation>Oscail Roimhe Seo</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="915"/>
        <source>Open Next</source>
        <translation>Oscail Ar Aghaidh</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="927"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="928"/>
        <source>Show or hide video files</source>
        <translation>Taispeáin nó folaigh comhaid físe</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="933"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="934"/>
        <source>Show or hide audio files</source>
        <translation>Taispeáin nó folaigh comhaid fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="939"/>
        <source>Image</source>
        <translation>Íomhá</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="940"/>
        <source>Show or hide image files</source>
        <translation>Taispeáin nó folaigh comhaid íomhá</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="945"/>
        <source>Other</source>
        <translation>Eile</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="946"/>
        <source>Show or hide other kinds of files</source>
        <translation>Taispeáin nó folaigh cineálacha eile comhaid</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="951"/>
        <source>Folders</source>
        <translation>Fillteáin</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="952"/>
        <source>Hide or show the list of folders</source>
        <translation>Folaigh nó taispeáin liosta na bhfillteán</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="963"/>
        <source>Go Up</source>
        <translation>Téigh Suas</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="964"/>
        <source>Show the parent folder</source>
        <translation>Taispeáin an máthairfhillteán</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="982"/>
        <source>Refresh Folders</source>
        <translation>Athnuaigh Fillteáin</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1003"/>
        <source>Search</source>
        <translation>Cuardach</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1027"/>
        <source>Open With</source>
        <translation>Oscail Le</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1279"/>
        <source>Executable Files (*.exe);;All Files (*)</source>
        <translation>Comhaid Inrite (*.exe);; Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1284"/>
        <source>Choose Executable</source>
        <translation>Roghnaigh Inrite</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1308"/>
        <source>Remove From Open With</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/filesdock.cpp" line="1329"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n mír</numerusform>
            <numerusform>%n mhír</numerusform>
            <numerusform>%n mhír</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1371"/>
        <source>Add Location</source>
        <translation>Cuir Suíomh Leis</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1372"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1390"/>
        <source>Delete Location</source>
        <translation>Scrios Suíomh</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1391"/>
        <source>Are you sure you want to remove %1?</source>
        <translation>An bhfuil tú cinnte gur mhaith leat %1 a bhaint?</translation>
    </message>
</context>
<context>
    <name>FilesModel</name>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="238"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="239"/>
        <source>Image</source>
        <translation>Íomhá</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="240"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="241"/>
        <source>Other</source>
        <translation>Eile</translation>
    </message>
</context>
<context>
    <name>FilesTileDelegate</name>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="412"/>
        <source>Date: %1</source>
        <translation>Dáta: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="421"/>
        <source>Size: %1</source>
        <translation>Méid: %1</translation>
    </message>
</context>
<context>
    <name>FilterController</name>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="119"/>
        <source>(DEPRECATED)</source>
        <translation>(DEPRECATED)</translation>
    </message>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="342"/>
        <source>Only one %1 filter is allowed.</source>
        <translation>Ní cheadaítear ach scagaire %1 amháin.</translation>
    </message>
</context>
<context>
    <name>FilterMenu</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="77"/>
        <source>search</source>
        <translation>cuardaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="121"/>
        <source>Clear search</source>
        <translation>Glan cuardach</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="177"/>
        <source>Show favorite filters</source>
        <translation>Taispeáin na scagairí is fearr leat</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="200"/>
        <source>Show GPU video filters</source>
        <translation>Taispeáin scagairí físeán GPU</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="221"/>
        <source>Show video filters</source>
        <translation>Taispeáin scagairí físeáin</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="242"/>
        <source>Show audio filters</source>
        <translation>Taispeáin scagairí fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="253"/>
        <source>Time</source>
        <translation>Am</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="264"/>
        <source>Show time filters</source>
        <translation>Taispeáin scagairí ama</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="274"/>
        <source>Sets</source>
        <translation>Seiteanna</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="285"/>
        <source>Show filter sets</source>
        <translation>Taispeáin tacair scagaire</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="140"/>
        <source>Close menu</source>
        <translation>Dún an roghchlár</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="371"/>
        <source>Delete a custom filter set by right-clicking it.</source>
        <translation>Scrios scagaire saincheaptha atá leagtha síos trí chliceáil ar dheis air.</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="165"/>
        <source>Favorite</source>
        <translation>Rogha</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="210"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="231"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
</context>
<context>
    <name>FilterMenuDelegate</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="112"/>
        <source>Delete Filter Set</source>
        <translation>Scrios Tacar Scagaire</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="124"/>
        <source>Are you sure you want to delete this?
%1</source>
        <translation>An bhfuil tú cinnte go bhfuil fonn ort é seo a scriosadh?
%1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="139"/>
        <source>OK</source>
        <translation>Ceart go leor</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="149"/>
        <source>Cancel</source>
        <translation>Cealaigh</translation>
    </message>
</context>
<context>
    <name>FiltersDock</name>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="49"/>
        <source>Filters</source>
        <translation>Scagairí</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="214"/>
        <source>Add</source>
        <translation>Cuir</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="216"/>
        <source>Choose a filter to add</source>
        <translation>Roghnaigh scagaire le cur leis</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="228"/>
        <source>Remove</source>
        <translation>Bain</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="230"/>
        <source>Remove selected filter</source>
        <translation>Bain an scagaire roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="237"/>
        <source>Copy Enabled</source>
        <translation>Cóipeáil Cumasaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="238"/>
        <source>Copy checked filters to the clipboard</source>
        <translation>Cóipeáil na scagairí seiceáilte chuig an ngearrthaisce</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="245"/>
        <source>Copy Current</source>
        <translation>Cóipeáil Reatha</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="246"/>
        <source>Copy current filter to the clipboard</source>
        <translation>Cóipeáil an scagaire reatha go dtí an ghearrthaisce</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="253"/>
        <source>Copy All</source>
        <translation>Cóipeáil Uile</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="254"/>
        <source>Copy all filters to the clipboard</source>
        <translation>Cóipeáil na scagairí go léir chuig an ngearrthaisce</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="261"/>
        <source>Paste Filters</source>
        <translation>Greamaigh Scagairí</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="262"/>
        <source>Paste the filters from the clipboard</source>
        <translation>Greamaigh na scagairí ón ngearrthaisce</translation>
    </message>
</context>
<context>
    <name>FrameRateWidget</name>
    <message>
        <location filename="../src/widgets/frameratewidget.cpp" line="74"/>
        <source>Convert Frames/sec</source>
        <translation>Convert Frames/sec</translation>
    </message>
</context>
<context>
    <name>GlaxnimateIpcServer</name>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="642"/>
        <source>Preparing Glaxnimate preview....</source>
        <translation>Réamhamharc Glaxnimate á ullmhú....</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="695"/>
        <source>The Glaxnimate program was not found.

Click OK to open a file dialog to choose its location.
Click Cancel if you do not have Glaxnimate.</source>
        <translation>Níor aimsíodh an clár Glaxnimate.

Cliceáil OK chun dialóg comhaid a oscailt chun a shuíomh a roghnú.
Cliceáil Cealaigh mura bhfuil Glaxnimate agat.</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="705"/>
        <source>Find Glaxnimate</source>
        <translation>Aimsigh Glaxnimate</translation>
    </message>
</context>
<context>
    <name>GlaxnimateProducerWidget</name>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="20"/>
        <source>Animation</source>
        <translation>Beochan</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="30"/>
        <source>Comments:</source>
        <translation>Tuairimí:</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="61"/>
        <source>Background color...</source>
        <translation>Dath an chúlra...</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="76"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="103"/>
        <source>Edit...</source>
        <translation>Cuir in eagar...</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="110"/>
        <source>Reload</source>
        <translation>Athlódáil</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="132"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="71"/>
        <source>black</source>
        <translation>dubh</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="73"/>
        <source>transparent</source>
        <translation>trédhearcach</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="204"/>
        <source>animation</source>
        <translation>beochan</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="205"/>
        <source>Glaxnimate (*.rawr);;All Files (*)</source>
        <translation>Glaxnimate (*.rawr);; Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="207"/>
        <source>New Animation</source>
        <translation>Beochan Nua</translation>
    </message>
</context>
<context>
    <name>GoPro2GpxJob</name>
    <message>
        <location filename="../src/jobs/gopro2gpxjob.cpp" line="34"/>
        <source>Export GPX</source>
        <translation>Easpórtáil GPX</translation>
    </message>
</context>
<context>
    <name>GradientControl</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="122"/>
        <source>Color #%1</source>
        <translation>Dath #%1</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="128"/>
        <source>Color: %1
Click to change</source>
        <translation>Dath: %1
Cliceáil chun athrú</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="178"/>
        <source>colors</source>
        <comment>gradient control</comment>
        <translation>dathanna</translation>
    </message>
</context>
<context>
    <name>ImageProducerWidget</name>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="27"/>
        <source>Comments:</source>
        <translation>Tuairimí:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="61"/>
        <source>Resolution</source>
        <translation>Rún</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="70"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="82"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="134"/>
        <source>Pixel aspect ratio</source>
        <translation>Cóimheas gné picteilín</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="165"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="193"/>
        <source>Image sequence</source>
        <translation>Seicheamh íomhá</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="200"/>
        <source>Repeat</source>
        <translation>Déan arís</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="218"/>
        <source> frames</source>
        <translation>frámaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="234"/>
        <source>per picture</source>
        <translation>in aghaidh an phictiúr</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="261"/>
        <source>Properties Menu</source>
        <translation>Roghchlár Airíonna</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="303"/>
        <source>Copy Full File Path</source>
        <translation>Cóipeáil Conair Iomlán an Chomhaid</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="308"/>
        <source>Show In Folder</source>
        <translation>Taispeáin I bhFillteán</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="341"/>
        <source>Show In Files</source>
        <translation>Taispeáin I gComhaid</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="313"/>
        <source>Set Creation Time...</source>
        <translation>Socraigh Am Cruthaithe...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="321"/>
        <source>Disable Proxy</source>
        <translation>Díchumasaigh Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="326"/>
        <source>Make Proxy</source>
        <translation>Déan Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="331"/>
        <source>Delete Proxy</source>
        <translation>Scrios Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="336"/>
        <source>Copy Hash Code</source>
        <translation>Cóipeáil Cód Hash</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="122"/>
        <source>Make the current duration value the default value</source>
        <translation>Déan an luach ré reatha an luach réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="125"/>
        <source>Set Default</source>
        <translation>Socraigh Réamhshocrú</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="247"/>
        <source>Reset</source>
        <translation>Athshocraigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="99"/>
        <source>(PROXY)</source>
        <translation>(Seachfhreastalaí)</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="288"/>
        <source>Getting length of image sequence...</source>
        <translation>Fad seicheamh íomhá á fháil...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="311"/>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="333"/>
        <source>Reloading image sequence...</source>
        <translation>Sraith íomhánna á athlódáil...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="466"/>
        <source>The hash code below is already copied to your clipboard:

</source>
        <translation>Tá an cód hash thíos cóipeáilte chuig do ghearrthaisce cheana féin:

</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="254"/>
        <source>Proxy</source>
        <translation>Seachfhreastalaí</translation>
    </message>
</context>
<context>
    <name>IsingWidget</name>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="26"/>
        <source>Ising Model</source>
        <translation>An tSamhail Ising</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="41"/>
        <source>Noise Temperature</source>
        <translation>Teocht Torainn</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="106"/>
        <source>Border Growth</source>
        <translation>Fás Teorann</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="174"/>
        <source>Spontaneous Growth</source>
        <translation>Fás Spontáineach</translation>
    </message>
</context>
<context>
    <name>JobQueue</name>
    <message>
        <location filename="../src/jobqueue.cpp" line="59"/>
        <source>pending</source>
        <translation>ar feitheamh</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="63"/>
        <source>Estimated Hours:Minutes:Seconds</source>
        <translation>Uaireanta Measta: Miontuairiscí: Soicind</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="92"/>
        <source>paused</source>
        <translation>ar sos</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="120"/>
        <source>Elapsed Hours:Minutes:Seconds</source>
        <translation>Uaireanta Caite: Miontuairiscí: Soicind</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="123"/>
        <source>stopped</source>
        <translation>stoptha</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="126"/>
        <source>failed</source>
        <translation>theip</translation>
    </message>
</context>
<context>
    <name>JobsDock</name>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="18"/>
        <source>Jobs</source>
        <translation>Jabanna</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="115"/>
        <source>Stop automatically processing the next pending job in
the list. This does not stop a currently running job. Right-
-click a job to open a menu to stop a currently running job.</source>
        <translation>Stop go huathoibríoch ag próiseáil an chéad jab eile ar feitheamh i
an liosta. Ní stopann sé seo le post reatha. Ar dheis-
-cliceáil jab chun roghchlár a oscailt chun stop a chur le post reatha.</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="130"/>
        <source>Remove all of the completed and failed jobs from the list</source>
        <translation>Bain gach ceann de na poist chomhlánaithe agus teipthe ón liosta</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="133"/>
        <source>Clean</source>
        <translation>Glan</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="104"/>
        <source>Jobs Menu</source>
        <translation>Roghchlár Jabanna</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="120"/>
        <source>Pause Queue</source>
        <translation>Cuir an Scuaine ar sos</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="156"/>
        <source>Stop This Job</source>
        <translation>Stop an jab seo</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="159"/>
        <source>Stop the currently selected job</source>
        <translation>Stop an jab atá roghnaithe faoi láthair</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="164"/>
        <source>View Log</source>
        <translation>Amharc ar an Logchomhad</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="167"/>
        <source>View the messages of MLT and FFmpeg </source>
        <translation>Féach ar theachtaireachtaí MLT agus FFmpeg </translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="172"/>
        <source>Run</source>
        <translation>Rith</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="175"/>
        <source>Restart a stopped job</source>
        <translation>Atosaigh jab stoptha</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="180"/>
        <source>Remove</source>
        <translation>Bain</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="185"/>
        <location filename="../src/docks/jobsdock.ui" line="188"/>
        <source>Remove Finished</source>
        <translation>Bain Críochnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.cpp" line="153"/>
        <source>Job Log</source>
        <translation>Logchomhad Poist</translation>
    </message>
</context>
<context>
    <name>KeyframeClip</name>
    <message>
        <location filename="../src/qml/views/keyframes/KeyframeClip.qml" line="245"/>
        <source>Confirm Removing Advanced Keyframes</source>
        <translation>Deimhnigh go bhfuil ardfhrámaí á mbaint</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/KeyframeClip.qml" line="246"/>
        <source>This will remove all advanced keyframes to enable simple keyframes.&lt;p&gt;Do you still want to do this?</source>
        <translation>Bainfidh sé seo gach eochairfhráma chun cinn chun eochairfhrámaí simplí a chumasú. &lt;p&gt;An bhfuil fonn ort é seo a dhéanamh fós?</translation>
    </message>
</context>
<context>
    <name>KeyframesButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="58"/>
        <source>Use Keyframes for this parameter</source>
        <translation>Úsáid Eochairfhrámaí don pharaiméadar seo</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="45"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Coinnigh %1 chun eochairfhráma a tharraingt ingearach amháin nó %2 chun cothrománach a tharraingt amháin</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="64"/>
        <source>Confirm Removing Keyframes</source>
        <translation>Deimhnigh go bhfuil eochairfhrámaí á mbaint</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="65"/>
        <source>This will remove all keyframes for this parameter.&lt;p&gt;Do you still want to do this?</source>
        <translation>Bainfidh sé seo gach eochairfhráma don pharaiméadar seo. &lt;p&gt;An bhfuil fonn ort é seo a dhéanamh fós?</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="80"/>
        <source>Confirm Removing Simple Keyframes</source>
        <translation>Deimhnigh go bhfuil eochairfhrámaí simplí á mbaint</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="81"/>
        <source>This will remove all simple keyframes for all parameters.&lt;p&gt;Simple keyframes will be converted to advanced keyframes.&lt;p&gt;Do you still want to do this?</source>
        <translation>Bainfidh sé seo gach eochairfhráma simplí do gach paraiméadar. &lt;p&gt;Beidh keyframes simplí a thiontú go keyframes chun cinn. &lt;p&gt;An bhfuil fonn ort é seo a dhéanamh fós?</translation>
    </message>
</context>
<context>
    <name>KeyframesDock</name>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="48"/>
        <location filename="../src/docks/keyframesdock.cpp" line="62"/>
        <source>Keyframes</source>
        <translation>Frámaí eochair</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="71"/>
        <source>View</source>
        <translation>Amharc</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="78"/>
        <source>Keyframe</source>
        <translation>Eochairfhráma</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="79"/>
        <source>From Previous</source>
        <translation>Ó Roimhe Seo</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="84"/>
        <source>Ease Out</source>
        <translation>Éascaigh Amach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="101"/>
        <source>To Next</source>
        <translation>Go Ar Aghaidh</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="106"/>
        <source>Ease In</source>
        <translation>Éascaigh Isteach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="121"/>
        <source>Ease In/Out</source>
        <translation>Éascaigh Isteach / Amach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="141"/>
        <source>Keyframes Clip</source>
        <translation>Gearrthóg Keyframes</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="149"/>
        <source>Keyframes Controls</source>
        <translation>Rialuithe Eochairfhrámaí</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="153"/>
        <source>Keyframes Menu</source>
        <translation>Roghchlár na bhFrámaí Eochracha</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="223"/>
        <source>Set Filter Start</source>
        <translation>Socraigh Tús Scagaire</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="242"/>
        <source>Set Filter End</source>
        <translation>Socraigh Deireadh an Scagaire</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="261"/>
        <source>Set First Simple Keyframe</source>
        <translation>Socraigh an Chéad Eochairfhráma Simplí</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="280"/>
        <source>Set Second Simple Keyframe</source>
        <translation>Socraigh an Dara Eochairfhráma Simplí</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="299"/>
        <source>Scrub While Dragging</source>
        <translation>Scrobarnach Agus Tarraingthe</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="312"/>
        <source>Zoom Keyframes Out</source>
        <translation>Zúmáil Eochairfhrámaí Amach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="323"/>
        <source>Zoom Keyframes In</source>
        <translation>Súmáil eochairfhrámaí isteach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="334"/>
        <source>Zoom Keyframes To Fit</source>
        <translation>Zúmáil Eochairfhrámaí le Feistiú</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="350"/>
        <location filename="../src/docks/keyframesdock.cpp" line="596"/>
        <source>Hold</source>
        <translation>Coinnigh</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="367"/>
        <location filename="../src/docks/keyframesdock.cpp" line="613"/>
        <source>Linear</source>
        <translation>Líneach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="384"/>
        <location filename="../src/docks/keyframesdock.cpp" line="630"/>
        <source>Smooth</source>
        <translation>Go réidh</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="406"/>
        <source>Ease Out Sinusoidal</source>
        <translation>Éasca Amach Sinusoidal</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="423"/>
        <source>Ease Out Quadratic</source>
        <translation>Éasca Amach Quadratic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="440"/>
        <source>Ease Out Cubic</source>
        <translation>Éasca Amach Ciúbach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="457"/>
        <source>Ease Out Quartic</source>
        <translation>Éasca Amach Quartic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="474"/>
        <source>Ease Out Quintic</source>
        <translation>Éasca Amach Quintic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="491"/>
        <source>Ease Out Exponential</source>
        <translation>Éasca Amach Easpónantúil</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="508"/>
        <source>Ease Out Circular</source>
        <translation>Éasca Amach Ciorclán</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="525"/>
        <source>Ease Out Back</source>
        <translation>Éasca Amach Ar ais</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="550"/>
        <source>Ease Out Elastic</source>
        <translation>Éasca Amach Leaisteacha</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="575"/>
        <source>Ease Out Bounce</source>
        <translation>Éasca Amach Preab</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="652"/>
        <source>Ease In Sinusoidal</source>
        <translation>Éasca I Sinusoidal</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="668"/>
        <source>Ease In Quadratic</source>
        <translation>Éasca I Quadratic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="684"/>
        <source>Ease In Cubic</source>
        <translation>Éasca I Ciúbach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="700"/>
        <source>Ease In Quartic</source>
        <translation>Éasca I Quartic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="716"/>
        <source>Ease In Quintic</source>
        <translation>Éasca I Quintic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="732"/>
        <source>Ease In Exponential</source>
        <translation>Éasca I Easpónantúil</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="748"/>
        <source>Ease In Circular</source>
        <translation>Éasca I Ciorclán</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="764"/>
        <source>Ease In Back</source>
        <translation>Éasca Ar Ais</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="788"/>
        <source>Ease In Elastic</source>
        <translation>Éasca I Leaisteacha</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="812"/>
        <source>Ease In Bounce</source>
        <translation>Éasca I Preab</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="828"/>
        <source>Ease In/Out Sinusoidal</source>
        <translation>Éasca Isteach/Amach Sinusoidal</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="845"/>
        <source>Ease In/Out Quadratic</source>
        <translation>Éasca Isteach/Amach Quadratic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="862"/>
        <source>Ease In/Out Cubic</source>
        <translation>Éasca Isteach/Amach Ciúbach</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="879"/>
        <source>Ease In/Out Quartic</source>
        <translation>Éasca Isteach/Amach Quartic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="896"/>
        <source>Ease In/Out Quintic</source>
        <translation>Éasca Isteach/Amach Quintic</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="913"/>
        <source>Ease In/Out Exponential</source>
        <translation>Éasca Isteach/Amach Easpónantúil</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="930"/>
        <source>Ease In/Out Circular</source>
        <translation>Éasca Isteach/Amach Ciorclán</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="947"/>
        <source>Ease In/Out Back</source>
        <translation>Éasca Isteach/Amach Ar Ais</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="972"/>
        <source>Ease In/Out Elastic</source>
        <translation>Éasca Isteach/Amach Leaisteacha</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="997"/>
        <source>Ease In/Out Bounce</source>
        <translation>Ease In/Out Preab</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1014"/>
        <source>Remove</source>
        <translation>Bain</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1025"/>
        <source>Rebuild Audio Waveform</source>
        <translation>Atógáil Tonnta Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1037"/>
        <source>Seek Previous Keyframe</source>
        <translation>Lorg eochairfhráma roimhe seo</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1053"/>
        <source>Seek Next Keyframe</source>
        <translation>An Chéad Eochairfhráma Eile a Lorg</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1069"/>
        <source>Toggle Keyframe At Playhead</source>
        <translation>Scoránaigh eochairfhráma ag Playhead</translation>
    </message>
</context>
<context>
    <name>KeyframesModel</name>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="74"/>
        <source>Hold</source>
        <translation>Coinnigh</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="71"/>
        <source>Linear</source>
        <translation>Líneach</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="80"/>
        <location filename="../src/models/keyframesmodel.cpp" line="174"/>
        <source>Smooth</source>
        <translation>Go réidh</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="83"/>
        <source>Ease In Sinusoidal</source>
        <translation>Éasca I Sinusoidal</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="86"/>
        <source>Ease Out Sinusoidal</source>
        <translation>Éasca Amach Sinusoidal</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="89"/>
        <source>Ease In/Out Sinusoidal</source>
        <translation>Éasca Isteach/Amach Sinusoidal</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="92"/>
        <source>Ease In Quadratic</source>
        <translation>Éasca I Quadratic</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="95"/>
        <source>Ease Out Quadratic</source>
        <translation>Éasca Amach Quadratic</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="98"/>
        <source>Ease In/Out Quadratic</source>
        <translation>Éasca Isteach/Amach Ceathrúnach</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="101"/>
        <source>Ease In Cubic</source>
        <translation>Éasca I Ciúbach</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="104"/>
        <source>Ease Out Cubic</source>
        <translation>Éasca Amach Ciúbach</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="107"/>
        <source>Ease In/Out Cubic</source>
        <translation>Éasca Isteach/Amach Ciúbach</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="110"/>
        <source>Ease In Quartic</source>
        <translation>Éasca I Quartic</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="113"/>
        <source>Ease Out Quartic</source>
        <translation>Éasca Amach Quartic</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="116"/>
        <source>Ease In/Out Quartic</source>
        <translation>Éasca Isteach/Amach Quartic</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="119"/>
        <source>Ease In Quintic</source>
        <translation>Éasca I Quintic</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="122"/>
        <source>Ease Out Quintic</source>
        <translation>Éasca Amach Quintic</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="125"/>
        <source>Ease In/Out Quintic</source>
        <translation>Éasca Isteach/Amach Quintic</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="128"/>
        <source>Ease In Exponential</source>
        <translation>Éasca I Easpónantúil</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="131"/>
        <source>Ease Out Exponential</source>
        <translation>Éasca Amach Easpónantúil</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="134"/>
        <source>Ease In/Out Exponential</source>
        <translation>Éasca Isteach/Amach Easpónantúil</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="137"/>
        <source>Ease In Circular</source>
        <translation>Éasca I Ciorclán</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="140"/>
        <source>Ease Out Circular</source>
        <translation>Éasca Amach Ciorclán</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="143"/>
        <source>Ease In/Out Circular</source>
        <translation>Éasca Isteach/Amach Ciorclán</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="146"/>
        <source>Ease In Back</source>
        <translation>Éasca Ar Ais</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="149"/>
        <source>Ease Out Back</source>
        <translation>Éasca Amach Ar ais</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="152"/>
        <source>Ease In/Out Back</source>
        <translation>Éasca Isteach/Amach Ar Ais</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="155"/>
        <source>Ease In Elastic</source>
        <translation>Éasca I Leaisteacha</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="158"/>
        <source>Ease Out Elastic</source>
        <translation>Éasca Amach Leaisteacha</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="161"/>
        <source>Ease In/Out Elastic</source>
        <translation>Éasca Isteach/Amach Leaisteacha</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="164"/>
        <source>Ease In Bounce</source>
        <translation>Éasca I Preab</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="167"/>
        <source>Ease Out Bounce</source>
        <translation>Éasca Amach Preab</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="170"/>
        <source>Ease In/Out Bounce</source>
        <translation>Ease In/Out Preab</translation>
    </message>
</context>
<context>
    <name>LissajousWidget</name>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="26"/>
        <source>Lissajous</source>
        <translation>Lissajous</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="41"/>
        <source>X Ratio</source>
        <translation>Cóimheas X</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="106"/>
        <source>Y Ratio</source>
        <translation>Y Cóimheas</translation>
    </message>
</context>
<context>
    <name>ListSelectionDialog</name>
    <message>
        <location filename="../src/dialogs/listselectiondialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialóg</translation>
    </message>
</context>
<context>
    <name>LumaMixTransition</name>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="25"/>
        <source>Transition</source>
        <translation>Trasdul</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="351"/>
        <source>Preview</source>
        <translation>Réamhamharc</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="360"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="92"/>
        <source>Dissolve</source>
        <translation>Tuaslaig</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="97"/>
        <source>Cut</source>
        <translation>Gearr</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="107"/>
        <source>Bar Horizontal</source>
        <translation>Barra Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="112"/>
        <source>Bar Vertical</source>
        <translation>Barra Ingearach</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="117"/>
        <source>Barn Door Horizontal</source>
        <translation>Doras Feirme Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="122"/>
        <source>Barn Door Vertical</source>
        <translation>Doras Feirme Ingearach</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="127"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Doras na Seanchreime Diagánach SW-NE</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="132"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Doras na Seanchreime Diagánach NW-SE</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="137"/>
        <source>Diagonal Top Left</source>
        <translation>Diagánach Barr Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="142"/>
        <source>Diagonal Top Right</source>
        <translation>Diagánach Barr Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="147"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Maitrís Eas Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="152"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Maitrís Eas Ingearach</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="157"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Nathair na Matrics Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="162"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Nathair na Matrics Cothrománach Comhthreomhar</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="167"/>
        <source>Matrix Snake Vertical</source>
        <translation>Nathair na Matrics Ingearach</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="172"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Nathair na Matrics Ingearach Comhthreomhar</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="177"/>
        <source>Barn V Up</source>
        <translation>Scioból V Suas</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="182"/>
        <source>Iris Circle</source>
        <translation>Ciorcal Iris</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="187"/>
        <source>Double Iris</source>
        <translation>Iris Dúbailte</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="192"/>
        <source>Iris Box</source>
        <translation>Bosca Iris</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="197"/>
        <source>Box Bottom Right</source>
        <translation>Bosca Bun ar dheis</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="202"/>
        <source>Box Bottom Left</source>
        <translation>Bosca Bun ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="207"/>
        <source>Box Right Center</source>
        <translation>Bosca Lár ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="212"/>
        <source>Clock Top</source>
        <translation>Clog Barr</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="370"/>
        <source>Get custom transitions on our Web site.</source>
        <translation>Faigh aistrithe saincheaptha ar ár suíomh Gréasáin.</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="102"/>
        <source>Custom...</source>
        <translation>Saincheaptha...</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="243"/>
        <source>TextLabel</source>
        <translation>Lipéad Téacs</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="341"/>
        <source>Swap the appearance of the A and B clips</source>
        <translation>Babhtáil cuma na gearrthóga A agus B</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="344"/>
        <source>Invert Wipe</source>
        <translation>Scrios Inbhéartaigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="39"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="234"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="240"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="261"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="265"/>
        <source>Softness</source>
        <translation>Bog</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="52"/>
        <source>Change the softness of the edge of the wipe</source>
        <translation>Athraigh bogas imeall an wipe</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="68"/>
        <location filename="../src/widgets/lumamixtransition.ui" line="311"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="222"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="232"/>
        <source>Save the custom transition as a favorite</source>
        <translation>Sábháil an t-aistriú saincheaptha mar is fearr leat</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="252"/>
        <source>Automatically fade-out the audio of clip A
and fade-in the audio of clip B over the
duration of the transition.</source>
        <translation>Go huathoibríoch céimnithe amach an fhuaim gearrthóg A
agus céimnithe-i fuaime gearrthóg B thar an
fad an aistrithe.</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="257"/>
        <source>Cross-fade</source>
        <translation>Tras-céimnithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="271"/>
        <source>Do not alter the audio levels during the
course of the transition. Instead, set a
fixed mixing level, or choose only clip A&apos;s
audio (0%) or clip B&apos;s audio (100%).</source>
        <translation>Ná hathraigh na leibhéil fuaime le linn na
le linn an aistrithe. Ina ionad sin, socraigh
leibhéal measctha seasta, nó ná roghnaigh ach gearrthóg A
fuaime (0%) nó gearrthóg B fuaime (100%).</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="277"/>
        <source>Mix:</source>
        <translation>Measc:</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="287"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="304"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="64"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="237"/>
        <source>Position</source>
        <translation>Seasamh</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="106"/>
        <source>Preview Not Available</source>
        <translation>Níl réamhamharc ar fáil</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="247"/>
        <source>Open File</source>
        <translation>Oscail Comhad</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Shotcut</source>
        <translation>Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>&amp;File</source>
        <translation>&amp;Comhad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>&amp;View</source>
        <translation>&amp;Amharc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Layout</source>
        <translation>Leagan Amach</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>&amp;Edit</source>
        <translation>&amp;Cuir in eagar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>&amp;Help</source>
        <translation>&amp;Cabhair</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="145"/>
        <source>Audio Channels</source>
        <translation>Cainéil Fuaime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="246"/>
        <source>Deinterlacer</source>
        <translation>Dídhéantóir Idirmheasctha</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="256"/>
        <source>Interpolation</source>
        <translation>Idirshuíomh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="154"/>
        <source>Video Mode</source>
        <translation>Mód Físe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="265"/>
        <source>External Monitor</source>
        <translation>Monatóir Seachtrach</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="160"/>
        <source>Language</source>
        <translation>Teanga</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="165"/>
        <source>Theme</source>
        <translation>Téama</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="173"/>
        <source>Display Method</source>
        <translation>Modh Taispeána</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="199"/>
        <source>App Data Directory</source>
        <translation>Eolaire Sonraí Feidhmchláir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="206"/>
        <source>Preview Scaling</source>
        <translation>Scálú Réamhamhairc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="224"/>
        <source>Proxy</source>
        <translation>Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Storage</source>
        <translation>Stóráil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Toolbar</source>
        <translation>Barra Uirlisí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="378"/>
        <source>&amp;Open File...</source>
        <translation>&amp;Oscail Comhad...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>E&amp;xit</source>
        <translation>&amp; Sábháil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="395"/>
        <source>Quit the application</source>
        <translation>Scoir den fheidhmchlár</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <source>&amp;About Shotcut</source>
        <translation>&amp;Maidir le Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>About Qt</source>
        <translation>Maidir le Qt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="419"/>
        <source>Open Other...</source>
        <translation>Oscail Eile...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="422"/>
        <source>Open a device, stream or generator</source>
        <translation>Oscail gléas, sruth nó gineadóir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="437"/>
        <source>&amp;Save</source>
        <translation>&amp;Sábháil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <source>Save project as a MLT XML file</source>
        <translation>Sábháil tionscadal mar chomhad XML MLT</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>Save &amp;As...</source>
        <translation>Sábháil Mar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="454"/>
        <source>Save project to a different MLT XML file</source>
        <translation>Sábháil tionscadal i gcomhad XML MLT eile</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="51"/>
        <location filename="../src/mainwindow.ui" line="466"/>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Export</source>
        <translation>Easpórtáil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Job Priority</source>
        <translation>Tosaíocht an Phoist</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="478"/>
        <source>&amp;Undo</source>
        <translation>&amp;Cealaigh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="487"/>
        <source>&amp;Redo</source>
        <translation>&amp;Athdhéan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="492"/>
        <source>Forum...</source>
        <translation>Forum...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="497"/>
        <source>FAQ...</source>
        <translation>Ceisteanna Coitianta...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="506"/>
        <location filename="../src/mainwindow.cpp" line="3922"/>
        <source>Enter Full Screen</source>
        <translation>Iontráil an Scáileán Iomlán</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="518"/>
        <source>Peak Meter</source>
        <translation>Buaicmhéadar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="530"/>
        <location filename="../src/mainwindow.cpp" line="401"/>
        <location filename="../src/mainwindow.cpp" line="2408"/>
        <source>Properties</source>
        <translation>Airíonna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <location filename="../src/mainwindow.cpp" line="2417"/>
        <source>Recent</source>
        <translation>le déanaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <location filename="../src/mainwindow.ui" line="548"/>
        <source>Playlist</source>
        <translation>Seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <source>History</source>
        <translation>Stair</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="568"/>
        <source>Realtime (frame dropping)</source>
        <translation>Realtime (frame dropping)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="579"/>
        <source>Progressive</source>
        <translation>Forásach</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="587"/>
        <source>GPU Effects (unstable)</source>
        <translation>GPU Effects (unstable)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="590"/>
        <source>Use GPU filters</source>
        <translation>Úsáid scagairí GPU</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="601"/>
        <source>1 (mono)</source>
        <translation>1 (mona)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="609"/>
        <source>2 (stereo)</source>
        <translation>2 (steirió)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="636"/>
        <source>One Field (fast)</source>
        <translation>Réimse amháin (tapa)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="644"/>
        <source>Linear Blend (fast)</source>
        <translation>Cumasc Líneach (tapa)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="652"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF - ama amháin (go maith)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>Comharsa is Cóngaraí (tapa)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="687"/>
        <source>Bilinear (good)</source>
        <translation>Délíneach (go maith)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="695"/>
        <source>Bicubic (better)</source>
        <translation>Bicúbach (níos fearr)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="714"/>
        <location filename="../src/mainwindow.ui" line="847"/>
        <location filename="../src/mainwindow.cpp" line="2613"/>
        <source>Automatic</source>
        <translation>Uathoibríoch</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="725"/>
        <location filename="../src/mainwindow.ui" line="1191"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="733"/>
        <source>Use JACK Audio</source>
        <translation>Úsáid Fuaim JACK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="742"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <source>Filters</source>
        <translation>Scagairí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <source>Add...</source>
        <translation>Cuir leis...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="758"/>
        <source>System</source>
        <translation>Córas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="761"/>
        <source>Use the user or platform style, colors, and icons.</source>
        <translation>Bain úsáid as stíl, dathanna agus deilbhíní an úsáideora nó an ardáin.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="769"/>
        <source>Fusion Dark</source>
        <translation>Comhleá Dorcha</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="777"/>
        <source>Fusion Light</source>
        <translation>Solas Comhleá</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="782"/>
        <source>Tutorials...</source>
        <translation>Ranganna Teagaisc...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <location filename="../src/mainwindow.ui" line="791"/>
        <location filename="../src/mainwindow.cpp" line="2427"/>
        <source>Timeline</source>
        <translation>Amlíne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="796"/>
        <location filename="../src/mainwindow.ui" line="799"/>
        <source>Restore Default Layout</source>
        <translation>Athchóirigh an Leagan Amach Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="807"/>
        <source>Show Title Bars</source>
        <translation>Taispeáin Barraí Teidil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="815"/>
        <source>Show Toolbar</source>
        <translation>Taispeáin Barra Uirlisí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="820"/>
        <source>Upgrade...</source>
        <translation>Uasghrádú...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="825"/>
        <source>Open MLT XML As Clip...</source>
        <translation>Oscail MLT XML Mar Ghearrthóg...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="828"/>
        <source>Open a MLT XML project file as a virtual clip</source>
        <translation>Oscail comhad tionscadail MLT XML mar ghearrthóg fhíorúil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="836"/>
        <source>Scrub Audio</source>
        <translation>Fuaim Scrobarnach</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="871"/>
        <source>Software (Mesa)</source>
        <extracomment>Do not translate &quot;Mesa&quot;</extracomment>
        <translation>Bogearraí (Mesa)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>Low</source>
        <translation>Íseal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="887"/>
        <source>Normal</source>
        <translation>Gnáth</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="897"/>
        <source>Application Log...</source>
        <translation>Logchomhad Feidhmchláir...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="905"/>
        <location filename="../src/mainwindow.ui" line="996"/>
        <location filename="../src/mainwindow.ui" line="999"/>
        <source>Project</source>
        <translation>Tionscadal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="1329"/>
        <source>Player</source>
        <translation>Seinnteoir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="913"/>
        <source>User Interface</source>
        <translation>Comhéadan Úsáideora</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="921"/>
        <source>Close</source>
        <translation>Dún</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1144"/>
        <source>Notes</source>
        <translation>Nótaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1358"/>
        <source>Markers as Chapters...</source>
        <translation>Marcóirí mar Chaibidlí...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1361"/>
        <location filename="../src/mainwindow.ui" line="1364"/>
        <location filename="../src/mainwindow.cpp" line="5861"/>
        <source>Export Chapters</source>
        <translation>Caibidlí Easpórtála</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1369"/>
        <source>Audio/Video Device...</source>
        <translation>Gléas Fuaime/Físe...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="971"/>
        <location filename="../src/mainwindow.ui" line="1269"/>
        <source>Set...</source>
        <translation>Socraigh...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Other Versions</source>
        <translation>Leaganacha Eile</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>&amp;Player</source>
        <translation>&amp;Imreoir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="141"/>
        <source>&amp;Settings</source>
        <translation>&amp;Socruithe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Time Format</source>
        <translation>Formáid Ama</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Backup</source>
        <translation>Cúltaca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="381"/>
        <source>Open a video, audio, image, or project file</source>
        <translation>Oscail físeán, fuaim, íomhá, nó comhad tionscadail</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="521"/>
        <source>Audio Peak Meter</source>
        <translation>Buaicmhéadar Fuaime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="617"/>
        <source>4 (quad/Ambisonics)</source>
        <translation>4 (cuad/Ambisonics)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="625"/>
        <source>6 (5.1 surround)</source>
        <translation>6 (5.1 timpeall)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="660"/>
        <source>YADIF - temporal + spatial (better)</source>
        <translation>YADIF - ama + spásúil (níos fearr)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="668"/>
        <source>BWDIF (best)</source>
        <translation>BWDIF (is fearr)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Lanczos (best)</source>
        <translation>Lanczos (is fearr)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="892"/>
        <source>Resources...</source>
        <translation>Acmhainní...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="976"/>
        <location filename="../src/mainwindow.ui" line="1277"/>
        <source>Show...</source>
        <translation>Taispeáin...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="979"/>
        <source>Show</source>
        <translation>Taispeáin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="988"/>
        <location filename="../src/mainwindow.ui" line="991"/>
        <source>Keyframes</source>
        <translation>Frámaí eochair</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>New</source>
        <translation>Nua</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1002"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1018"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1021"/>
        <source>Switch to the audio layout</source>
        <translation>Athraigh go dtí an leagan amach fuaime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1024"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1032"/>
        <source>Logging</source>
        <translation>Logáil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1035"/>
        <source>Switch to the logging layout</source>
        <translation>Athraigh go dtí an leagan amach logála</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1038"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1046"/>
        <source>Editing</source>
        <translation>Eagarthóireacht</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1049"/>
        <source>Switch to the editing layout</source>
        <translation>Athraigh go leagan amach na heagarthóireachta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1052"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1060"/>
        <source>FX</source>
        <translation>FX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <source>Switch to the effects layout</source>
        <translation>Athraigh go leagan amach na n-éifeachtaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1066"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <source>New Generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1135"/>
        <source>Markers</source>
        <translation>Marcóirí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1153"/>
        <source>Subtitles</source>
        <translation>Fotheidil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1183"/>
        <source>1080p</source>
        <translation type="unfinished">1080p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Timecode (Drop-Frame)</source>
        <translation>Amchód (Fráma Buail)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1221"/>
        <source>Frames</source>
        <translation>Frámaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1229"/>
        <source>Clock</source>
        <translation>Clog</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1237"/>
        <source>Timecode (Non-Drop Frame)</source>
        <translation>Amchód (Fráma Neamh-Titim)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1242"/>
        <source>Topics</source>
        <translation>Topaicí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1250"/>
        <source>Synchronization...</source>
        <translation>Sioncrónú...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1253"/>
        <source>Synchronization</source>
        <translation>Sioncrónú</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Use Proxy</source>
        <translation>Úsáid Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1272"/>
        <source>Set the proxy storage folder</source>
        <translation>Socraigh an fillteán stórála seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1280"/>
        <source>Show the proxy storage folder</source>
        <translation>Taispeáin an fillteán stórála seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1291"/>
        <source>Use Project Folder</source>
        <translation>Úsáid Fillteán Tionscadail</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1294"/>
        <source>Store proxies in the project folder if defined</source>
        <translation>Stóráil proxies san fhillteán tionscadail má shainmhínítear é</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1302"/>
        <source>Use Hardware Encoder</source>
        <translation>Úsáid Ionchódóir Crua-earraí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1307"/>
        <source>Configure Hardware Encoder...</source>
        <translation>Cumraigh Ionchódóir Crua-earraí...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1318"/>
        <source>Switch to the color layout</source>
        <translation>Athraigh go leagan amach na ndathanna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1321"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1332"/>
        <source>Switch to the player only layout</source>
        <translation>Athraigh go leagan amach an imreora amháin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1335"/>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1348"/>
        <source>Playlist Project</source>
        <translation>Tionscadal Seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1353"/>
        <source>Clip-only Project</source>
        <translation>Tionscadal Gearrthóg amháin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1374"/>
        <source>Reset...</source>
        <translation>Athshocraigh...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1379"/>
        <location filename="../src/mainwindow.ui" line="1382"/>
        <source>Backup and Save</source>
        <translation>Cúltaca agus Sábháil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1393"/>
        <source>Manually</source>
        <translation>De láimh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1401"/>
        <source>Hourly</source>
        <translation>In aghaidh na huaire</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1409"/>
        <source>Daily</source>
        <translation>Gach lá</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1420"/>
        <source>Weekly</source>
        <translation>Seachtainiúil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1425"/>
        <source>Show Project in Folder</source>
        <translation>Taispeáin Tionscadal i bhFillteán</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1436"/>
        <source>Pause After Seek</source>
        <translation>Sos tar éis lorg</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1445"/>
        <source>Files</source>
        <translation>Comhaid</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1076"/>
        <location filename="../src/mainwindow.ui" line="1081"/>
        <source>Remove...</source>
        <translation>Bain...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="509"/>
        <source>F11</source>
        <translation>Guthán: 011 2017</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="932"/>
        <source>EDL...</source>
        <translation>EDL...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="943"/>
        <source>Frame...</source>
        <translation>Fráma...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <source>Video...</source>
        <translation>Físeán...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="960"/>
        <location filename="../src/mainwindow.ui" line="963"/>
        <source>Export Video</source>
        <translation>Easpórtáil Físeán</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1007"/>
        <source>Actions and Shortcuts...</source>
        <translation>Gníomhartha agus Aicearraí...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <source>Clear Recent on Exit</source>
        <translation>Glan Le Déanaí ar Scoir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <source>Show Text Under Icons</source>
        <translation>Taispeáin Téacs faoi Dheilbhíní</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1117"/>
        <source>Show Small Icons</source>
        <translation>Taispeáin Deilbhíní Beaga</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1126"/>
        <source>Jobs</source>
        <translation>Jabanna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1161"/>
        <source>540p</source>
        <translation>540p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1172"/>
        <source>720p</source>
        <translation>720p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1202"/>
        <source>360p</source>
        <translation>360p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <source>Error: This program requires the SDL 2 library.

Please install it using your package manager. It may be named libsdl2-2.0-0, SDL2, or similar.</source>
        <translation>Earráid: Éilíonn an clár seo leabharlann SDL 2.

Suiteáil é le do bhainisteoir pacáiste. D&apos;fhéadfadh sé a bheith ainmnithe libsdl2-2.0-0, SDL2, nó a leithéid.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1162"/>
        <source>Screen %1 (%2 x %3 @ %4 Hz)</source>
        <translation>Scáileán %1 (%2 x %3 @ %4 Hz)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1198"/>
        <source>Off</source>
        <translation>As</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1201"/>
        <source>Internal</source>
        <translation>Inmheánach</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1204"/>
        <source>External</source>
        <translation>Seachtrach</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1227"/>
        <source>DeckLink Keyer</source>
        <translation>DeckLink Keyer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1315"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Color</source>
        <translation>Dath</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1491"/>
        <source>Text</source>
        <translation>Téacs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1498"/>
        <source>Animation</source>
        <translation>Beochan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1503"/>
        <source>Noise</source>
        <translation>Torann</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1508"/>
        <source>Color Bars</source>
        <translation>Barraí Dath</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1513"/>
        <source>Audio Tone</source>
        <translation>Ton Fuaime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1518"/>
        <source>Count</source>
        <translation>Áireamh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1523"/>
        <source>Blip Flash</source>
        <translation>Flash blip</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1548"/>
        <location filename="../src/mainwindow.cpp" line="1550"/>
        <location filename="../src/mainwindow.cpp" line="1988"/>
        <location filename="../src/mainwindow.cpp" line="1996"/>
        <location filename="../src/mainwindow.cpp" line="2019"/>
        <location filename="../src/mainwindow.cpp" line="2079"/>
        <location filename="../src/mainwindow.cpp" line="4659"/>
        <location filename="../src/mainwindow.cpp" line="4672"/>
        <location filename="../src/mainwindow.cpp" line="5637"/>
        <source>Failed to open </source>
        <translation>Theip ar oscailt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1583"/>
        <source>The file you opened uses GPU effects, but GPU effects are not enabled.</source>
        <translation>Úsáideann an comhad a d&apos;oscail tú éifeachtaí GPU, ach ní chumasaítear éifeachtaí GPU.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1595"/>
        <source>The file you opened uses CPU effects that are incompatible with GPU effects, but GPU effects are enabled.
Do you want to disable GPU effects and restart?</source>
        <translation>Úsáideann an comhad a d&apos;oscail tú éifeachtaí LAP nach bhfuil comhoiriúnach le héifeachtaí GPU, ach cumasaítear éifeachtaí GPU.
An bhfuil fonn ort maisíochtaí GPU a dhíchumasú agus a atosú?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1618"/>
        <source>Repaired</source>
        <translation>Deisithe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1619"/>
        <source>Save Repaired XML</source>
        <translation>Sábháil XML Deisithe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1656"/>
        <source>Repairing the project failed.</source>
        <translation>Theip ar dheisiú an tionscadail.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1669"/>
        <source>Shotcut noticed some problems in your project.
Do you want Shotcut to try to repair it?

If you choose Yes, Shotcut will create a copy of your project
with &quot;- Repaired&quot; in the file name and open it.</source>
        <translation>Thug Shotcut faoi deara roinnt fadhbanna i do thionscadal.
Ar mhaith leat Shotcut chun iarracht a dhéanamh é a dheisiú?

Má roghnaíonn tú Tá, cruthóidh Shotcut cóip de do thionscadal
le &quot;- Deisithe&quot; in ainm an chomhaid agus é a oscailt.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1704"/>
        <source>Auto-saved files exist. Do you want to recover them now?</source>
        <translation>Tá comhaid uathshábháilte ann. Ar mhaith leat iad a ghnóthú anois?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1776"/>
        <source>You cannot add a project to itself!</source>
        <translation>Ní féidir leat tionscadal a chur leis féin!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1814"/>
        <source>There was an error saving. Please try again.</source>
        <translation>Tharla earráid a shábháil. Bain triail eile as.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1899"/>
        <source>This project file requires a newer version!

It was made with version </source>
        <translation>Tá leagan níos nuaí de dhíth ar an gcomhad tionscadail seo!

Rinneadh é le leagan </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1930"/>
        <source>You are running low on available memory!

Please close other applications or web browser tabs and retry.
Or save and restart Shotcut.</source>
        <translation>Tá tú ag rith go híseal ar an gcuimhne atá ar fáil!

Dún feidhmchláir eile nó cluaisíní brabhsálaí gréasáin agus bain triail eile as.
Nó Shotcut a shábháil agus a atosú.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1982"/>
        <source>Opening %1</source>
        <translation>%1 á oscailt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2121"/>
        <location filename="../src/mainwindow.cpp" line="4646"/>
        <source>Open File</source>
        <translation>Oscail Comhad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2123"/>
        <source>All Files (*);;MLT XML (*.mlt)</source>
        <translation>Gach Comhad (*);;MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2391"/>
        <source>Preferences</source>
        <translation>Sainroghanna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2401"/>
        <source>Rename Clip</source>
        <translation>Athainmnigh Gearrthóg</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2410"/>
        <source>Find</source>
        <translation>Aimsigh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2419"/>
        <source>Reload</source>
        <translation>Athlódáil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2429"/>
        <source>Rerun Filter Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="2443"/>
        <source>This will start %n analysis job(s). Continue?</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2461"/>
        <source>No filters to analyze.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2602"/>
        <source>Untitled</source>
        <translation>Gan teideal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2607"/>
        <source>%1x%2 %3fps %4ch</source>
        <translation>%1x%2 %3fps %4ch</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2634"/>
        <source>About %1</source>
        <translation>Maidir le %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2763"/>
        <source>Non-Broadcast</source>
        <translation>Neamh-Chraoladh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2768"/>
        <source>DVD Widescreen NTSC</source>
        <translation>DVD Scáileán Leathan NTSC</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2769"/>
        <source>DVD Widescreen PAL</source>
        <translation>PAL Scáileán Leathan DVD</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2780"/>
        <source>Square 1080p 30 fps</source>
        <translation>Cearnóg 1080p 30 fps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2781"/>
        <source>Square 1080p 60 fps</source>
        <translation>Cearnóg 1080p 60 fps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2782"/>
        <source>Vertical HD 30 fps</source>
        <translation>Ingearach HD 30 fps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2783"/>
        <source>Vertical HD 60 fps</source>
        <translation>Ingearach HD 60 fps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2784"/>
        <source>Custom</source>
        <translation>Saincheaptha</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2815"/>
        <location filename="../src/mainwindow.cpp" line="3110"/>
        <source>Saved %1</source>
        <translation>Sábhála %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3101"/>
        <location filename="../src/mainwindow.cpp" line="3124"/>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <source>Save XML</source>
        <translation>Sábháil XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3220"/>
        <source>Timeline is not loaded</source>
        <translation>Níl an amlíne luchtaithe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3230"/>
        <source>Range marker not found under the timeline cursor</source>
        <translation>Raon marcóir gan aimsiú faoin cúrsóir amlíne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3295"/>
        <source>There are incomplete jobs.
Do you still want to exit?</source>
        <translation>Tá poist neamhiomlána ann.
An bhfuil fonn ort imeacht fós?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3307"/>
        <source>An export is in progress.
Do you still want to exit?</source>
        <translation>Tá easpórtáil ar siúl.
An bhfuil fonn ort imeacht fós?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4448"/>
        <source>Saved backup %1</source>
        <translation>Cúltaca %1 sábháilte</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3186"/>
        <source>Do you also want to change the Video Mode to %1 x %2?</source>
        <translation>Do you also want to change the Video Mode to %1 x %2?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4101"/>
        <source>Opened Files</source>
        <translation>Oscail Comhaid</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4183"/>
        <source>GPU effects are experimental and do not work good on all computers. Plan to do some testing after turning this on.
At this time, a project created with GPU effects cannot be converted to a CPU-only project later.

Do you want to enable GPU effects and restart Shotcut?</source>
        <translation>GPU effects are experimental and do not work good on all computers. Plan to do some testing after turning this on.
At this time, a project created with GPU effects cannot be converted to a CPU-only project later.

Do you want to enable GPU effects and restart Shotcut?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5281"/>
        <source>Add To Timeline</source>
        <translation>Cuir le Amlíne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5837"/>
        <source>Include ranges (Duration &gt; 1 frame)?</source>
        <translation>Cuir raonta san áireamh (Fad &gt; fhráma 1)?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5848"/>
        <source>Choose Markers</source>
        <translation>Roghnaigh Marcóirí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5865"/>
        <source>Text (*.txt);;All Files (*)</source>
        <translation>Téacs (*.txt);; Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5920"/>
        <source>Failed to open export-chapters.js</source>
        <translation>Theip ar oscailt export-chapters.js</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5961"/>
        <source>This will reset &lt;b&gt;all&lt;/b&gt; settings, and Shotcut must restart afterwards.
Do you want to reset and restart now?</source>
        <translation>Athshocróidh sé seo &lt;b&gt;gach&lt;/b&gt; socrú, agus ní mór do Shotcut atosú ina dhiaidh sin.
An bhfuil fonn ort athshocrú agus atosú anois?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1623"/>
        <location filename="../src/mainwindow.cpp" line="3128"/>
        <source>MLT XML (*.mlt)</source>
        <translation>MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <source>View Mode</source>
        <translation>Mód Amharc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3268"/>
        <source>The project has been modified.
Do you want to save your changes?</source>
        <translation>Athraíodh an tionscadal.
An bhfuil fonn ort do chuid athruithe a shábháil?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3925"/>
        <source>Exit Full Screen</source>
        <translation>Scoir den Scáileán Iomlán</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <source>Turn Proxy On</source>
        <translation>Cas an seachfhreastalaí air</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <source>Turn Proxy Off</source>
        <translation>Cas an seachfhreastalaí as</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5601"/>
        <source>Converting</source>
        <translation>Athrú</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5617"/>
        <source>Do you want to create missing proxies for every file in this project?

You must reopen your project after all proxy jobs are finished.</source>
        <translation>An bhfuil fonn ort proxies ar iarraidh a chruthú do gach comhad sa tionscadal seo?

Ní mór duit do thionscadal a athoscailt tar éis gach post seachfhreastalaí a bheith críochnaithe.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5655"/>
        <source>Proxy Folder</source>
        <translation>Fillteán Seachfhreastalaí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5673"/>
        <source>Do you want to move all files from the old folder to the new folder?</source>
        <translation>An bhfuil fonn ort gach comhad a bhogadh ón seanfhillteán go dtí an fillteán nua?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5681"/>
        <source>Moving Files</source>
        <translation>Comhaid á mbogadh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3937"/>
        <source>GPU effects are not supported</source>
        <translation>Ní thacaítear le héifeachtaí GPU</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>Set Loop Range</source>
        <translation>Socraigh Raon na Lúibe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="474"/>
        <source>Thumbnails</source>
        <translation>Mionsamhlacha</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <source>Scrolling</source>
        <translation>Scrollaigh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1043"/>
        <source>Audio API</source>
        <translation>API Fuaime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1064"/>
        <source>default</source>
        <translation>réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1071"/>
        <source>You must restart Shotcut to change the audio API.
Do you want to restart now?</source>
        <translation>Ní mór duit Shotcut a atosú chun an API fuaime a athrú.
An bhfuil fonn ort atosú anois?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1189"/>
        <source>SDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>HLG HDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>DeckLink Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3957"/>
        <source>Click here to check for a new version of Shotcut.</source>
        <translation>Cliceáil anseo chun leagan nua de Shotcut a sheiceáil.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4072"/>
        <source>Open Files</source>
        <translation>Oscail Comhaid</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4131"/>
        <source>You must restart Shotcut to switch to the new language.
Do you want to restart now?</source>
        <translation>Ní mór duit Shotcut a atosú chun aistriú go dtí an teanga nua.
An bhfuil fonn ort atosú anois?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4174"/>
        <source>Failed to connect to JACK.
Please verify that JACK is installed and running.</source>
        <translation>Theip ar cheangal le JACK.
Deimhnigh le do thoil go bhfuil JACK suiteáilte agus ag rith.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4203"/>
        <source>Shotcut must restart to disable GPU effects.

Disable GPU effects and restart?</source>
        <translation>Ní mór shotcut atosú chun éifeachtaí GPU a dhíchumasú.

Díchumasaigh maisíochtaí GPU agus atosaigh?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4425"/>
        <source>You must restart %1 to switch to the new theme.
Do you want to restart now?</source>
        <translation>Ní mór duit %1 a atosú chun athrú go dtí an téama nua.
An bhfuil fonn ort atosú anois?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4468"/>
        <source>&lt;p&gt;Please review your entire project after making this change.&lt;/p&gt;&lt;p&gt;Shotcut does not automatically adjust things that are sensitive to size and position if you change resolution or aspect ratio.&lt;/p&lt;br&gt;The timing of edits and keyframes may be slightly different if you change frame rate.&lt;/p&gt;&lt;p&gt;It is a good idea to use &lt;b&gt;File &gt; Backup and Save&lt;/b&gt; before or after this operation.&lt;/p&gt;&lt;p&gt;Do you want to change the &lt;b&gt;Video Mode&lt;/b&gt; now?&lt;/p&gt;</source>
        <translation>&lt;p&gt;Déan athbhreithniú ar do thionscadal iomlán tar éis an t-athrú seo a dhéanamh.&lt;/p&gt;&lt;p&gt;Ní Shotcut choigeartú go huathoibríoch rudaí atá íogair do mhéid agus seasamh má athraíonn tú réiteach nó cóimheas gné.&lt;/p&lt;br&gt;D&apos;fhéadfadh uainiú na n-athruithe agus na bpríomhfhrámaí a bheith beagán difriúil má athraíonn tú ráta fráma.&lt;/p&gt;&lt;p&gt;Is smaoineamh maith é &lt;b&gt;Comhad &gt; Cúltaca a úsáid agus Sábháil&lt;/b&gt; roimh an oibríocht seo nó ina dhiaidh.&lt;/p&gt;&lt;p&gt;An bhfuil fonn ort an &lt;b&gt;Mód Físe&lt;/b&gt; a athrú anois?&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4482"/>
        <source>Do not show this anymore.</source>
        <comment>Change video mode warning dialog</comment>
        <translation>Ná taispeáin é seo a thuilleadh.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4493"/>
        <source>Shotcut must restarto change external monitoring.
Do you want to restart now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4623"/>
        <source>Do you want to automatically check for updates in the future?</source>
        <translation>An bhfuil fonn ort seiceáil go huathoibríoch le haghaidh nuashonruithe amach anseo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4630"/>
        <source>Do not show this anymore.</source>
        <comment>Automatic upgrade check dialog</comment>
        <translation>Ná taispeáin é seo a thuilleadh.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4648"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4702"/>
        <source>You must restart Shotcut to change the display method.
Do you want to restart now?</source>
        <translation>Ní mór duit Shotcut a atosú chun an modh taispeána a athrú.
An bhfuil fonn ort atosú anois?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4732"/>
        <source>Application Log</source>
        <translation>Logchomhad Iarratais</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4735"/>
        <source>Previous</source>
        <translation>Roimhe Seo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4797"/>
        <source>Shotcut version %1 is available! Click here to get it.</source>
        <translation>Tá leagan shotcut %1 ar fáil! Cliceáil anseo chun é a fháil.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <source>You are running the latest version of Shotcut.</source>
        <translation>Tá an leagan is déanaí de Shotcut á rith agat.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4817"/>
        <source>Failed to read version.json when checking. Click here to go to the Web site.</source>
        <translation>Theip ar léamh version.json agus tú ag seiceáil. Cliceáil anseo chun dul chuig an suíomh Gréasáin.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="935"/>
        <location filename="../src/mainwindow.ui" line="938"/>
        <location filename="../src/mainwindow.cpp" line="4837"/>
        <source>Export EDL</source>
        <translation>Easpórtáil EDL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4841"/>
        <source>EDL (*.edl);;All Files (*)</source>
        <translation>EDL (*.edl);; Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4888"/>
        <location filename="../src/mainwindow.cpp" line="5917"/>
        <source>A JavaScript error occurred during export.</source>
        <translation>Tharla earráid JavaScript le linn easpórtála.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4891"/>
        <source>Failed to open export-edl.js</source>
        <translation>Theip ar oscailt export-edl.js</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4922"/>
        <source>Export frame from proxy?</source>
        <translation>Easpórtáil fráma ó sheachfhreastalaí?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4923"/>
        <source>This frame may be from a lower resolution proxy instead of the original source.

Do you still want to continue?</source>
        <translation>D&apos;fhéadfadh an fráma seo a bheith ó sheachvótálaí réitigh níos ísle in ionad na foinse bunaidh.

An bhfuil fonn ort leanúint ar aghaidh fós?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="946"/>
        <location filename="../src/mainwindow.ui" line="949"/>
        <location filename="../src/mainwindow.cpp" line="4935"/>
        <source>Export Frame</source>
        <translation>Easpórtáil Fráma</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4941"/>
        <source>Unable to export frame.</source>
        <translation>Ní féidir fráma a easpórtáil.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4949"/>
        <source>You must restart Shotcut to change the data directory.
Do you want to continue?</source>
        <translation>Ní mór duit Shotcut a atosú chun an chomhadlann sonraí a athrú.
An bhfuil fonn ort leanúint ar aghaidh?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4960"/>
        <source>Data Directory</source>
        <translation>Comhadlann Sonraí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5170"/>
        <source>Add Custom Layout</source>
        <translation>Cuir Leagan Amach Saincheaptha Leis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5171"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5210"/>
        <source>Remove Video Mode</source>
        <translation>Bain Mód Físeáin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5227"/>
        <source>Remove Layout</source>
        <translation>Bain Leagan Amach</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5381"/>
        <source>GPU effects are EXPERIMENTAL, UNSTABLE and UNSUPPORTED! Unsupported means do not report bugs about it.

Do you want to disable GPU effects and restart Shotcut?</source>
        <translation>Tá éifeachtaí GPU TURGNAMHACH, UNSTABLE agus UNSUPPORTED! Ní thuairiscíonn modhanna gan tacaíocht fabhtanna faoi.

An bhfuil fonn ort éifeachtaí GPU a dhíchumasú agus Shotcut a atosú?</translation>
    </message>
</context>
<context>
    <name>MarkersDock</name>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="129"/>
        <source>Markers</source>
        <translation>Marcóirí</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="200"/>
        <source>Add a marker at the current time</source>
        <translation>Cuir marcóir leis ag an am reatha</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="209"/>
        <source>Remove the selected marker</source>
        <translation>Bain an marcóir roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="218"/>
        <source>Deselect the marker</source>
        <translation>Díroghnaigh an marcóir</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="191"/>
        <source>Markers Menu</source>
        <translation>Roghchlár marcóirí</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="165"/>
        <source>Remove All Markers</source>
        <translation>Bain Gach Marcóir</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="167"/>
        <source>Columns</source>
        <translation>Colúin</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="168"/>
        <source>Color</source>
        <translation>Dath</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="171"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="174"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="177"/>
        <source>End</source>
        <translation>Críoch</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="180"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="186"/>
        <source>Markers Controls</source>
        <translation>Rialuithe Marcóirí</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="228"/>
        <source>search</source>
        <translation>cuardaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="236"/>
        <source>Clear search</source>
        <translation>Glan cuardach</translation>
    </message>
</context>
<context>
    <name>MarkersModel</name>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="788"/>
        <source>Color</source>
        <translation>Dath</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="790"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="792"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="794"/>
        <source>End</source>
        <translation>Críoch</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="796"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
</context>
<context>
    <name>MeltJob</name>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="47"/>
        <source>View XML</source>
        <translation>Amharc ar XML</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="48"/>
        <source>View the MLT XML for this job</source>
        <translation>Féach ar an MLT XML don phost seo</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="57"/>
        <source>Open</source>
        <translation>Oscail</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="59"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>Oscail an comhad aschuir san imreoir Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="63"/>
        <location filename="../src/jobs/meltjob.cpp" line="68"/>
        <location filename="../src/jobs/meltjob.cpp" line="69"/>
        <source>Show In Folder</source>
        <translation>Taispeáin I bhFillteán</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="64"/>
        <source>Show In Files</source>
        <translation>Taispeáin I gComhaid</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="192"/>
        <source>MLT XML</source>
        <translation>MLT XML</translation>
    </message>
</context>
<context>
    <name>Mlt::VideoWidget</name>
    <message>
        <location filename="../src/videowidget.cpp" line="196"/>
        <source>You cannot drag from Project.</source>
        <translation>Ní féidir leat tarraingt ó Project.</translation>
    </message>
    <message>
        <location filename="../src/videowidget.cpp" line="199"/>
        <source>You cannot drag a non-seekable source</source>
        <translation>Ní féidir leat foinse nach féidir a lorg a tharraingt</translation>
    </message>
</context>
<context>
    <name>MltClipProducerWidget</name>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="47"/>
        <source>Resolution</source>
        <translation>Rún</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="53"/>
        <source>Aspect ratio</source>
        <translation>Cóimheas gné</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="59"/>
        <source>Frame rate</source>
        <translation>Ráta fráma</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="65"/>
        <source>Scan mode</source>
        <translation>Modh scanadh</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="71"/>
        <source>Colorspace</source>
        <translation>Spás datha</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="77"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="150"/>
        <source>%L1 fps</source>
        <translation>%L1 fps</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="153"/>
        <source>Progressive</source>
        <translation>Forásach</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="155"/>
        <source>Interlaced</source>
        <translation>Idirfhighte</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="202"/>
        <source>Subclip profile does not match project profile.
This may provide unexpected results</source>
        <translation>Ní mheaitseálann próifíl subclip próifíl an tionscadail.
D&apos;fhéadfadh sé seo torthaí gan choinne a sholáthar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="207"/>
        <source>Subclip profile matches project profile.</source>
        <translation>Meaitseálann próifíl subclip próifíl an tionscadail.</translation>
    </message>
</context>
<context>
    <name>MotionTrackerDialog</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="39"/>
        <source>Load Keyframes from Motion Tracker</source>
        <translation>Luchtaigh Eochairfhrámaí ón Rianaire Gluaisne</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="55"/>
        <source>Motion tracker</source>
        <translation>Lorgaire gluaisne</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="75"/>
        <source>Adjust</source>
        <translation>Coigeartaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="92"/>
        <source>Relative Position</source>
        <translation>Suíomh Coibhneasta</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="96"/>
        <source>Offset Position</source>
        <translation>Ionad Fritháirimh</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="100"/>
        <source>Absolute Position</source>
        <translation>Ionad Absalóideach</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="104"/>
        <source>Size And Position</source>
        <translation>Méid agus Suíomh</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="123"/>
        <source>From start</source>
        <translation>Ó thús</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="128"/>
        <source>Current position</source>
        <translation>Staid reatha</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="142"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="154"/>
        <source>Reset</source>
        <translation>Athshocraigh</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="165"/>
        <source>Cancel</source>
        <translation>Cealaigh</translation>
    </message>
</context>
<context>
    <name>MotionTrackerModel</name>
    <message>
        <location filename="../src/models/motiontrackermodel.cpp" line="180"/>
        <source>Tracker %1</source>
        <translation>Lorgaire %1</translation>
    </message>
</context>
<context>
    <name>MultiFileExportDialog</name>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="63"/>
        <source>Directory</source>
        <translation>Comhadlann</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="76"/>
        <source>Prefix</source>
        <translation>Réimír</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="77"/>
        <source>export</source>
        <translation>easpórtáil</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="82"/>
        <source>Field 1</source>
        <translation>Réimse 1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="92"/>
        <source>Field 2</source>
        <translation>Réimse 2</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="102"/>
        <source>Field 3</source>
        <translation>Réimse 3</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="113"/>
        <source>Extension</source>
        <translation>Síneadh</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="207"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="208"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="209"/>
        <source>Index</source>
        <translation>Innéacs</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="210"/>
        <source>Date</source>
        <translation>Dáta</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="211"/>
        <source>Hash</source>
        <translation>Hash</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="234"/>
        <source>Empty File Name</source>
        <translation>Ainm comhaid folamh</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="236"/>
        <source>Directory does not exist: %1</source>
        <translation>Níl comhadlann ann: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="243"/>
        <source>File Exists: %1</source>
        <translation>Tá an comhad ann: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="248"/>
        <source>Duplicate File Name: %1</source>
        <translation>Ainm Comhaid Dúblach: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="274"/>
        <source>Fix file name errors before export.</source>
        <translation>Deisigh earráidí ainm comhaid roimh easpórtáil.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="281"/>
        <source>Export Directory</source>
        <translation>Easpórtáil Comhadlann</translation>
    </message>
</context>
<context>
    <name>MultitrackModel</name>
    <message>
        <location filename="../src/models/multitrackmodel.cpp" line="115"/>
        <source>(PROXY)</source>
        <translation>(Seachfhreastalaí)</translation>
    </message>
    <message>
        <location filename="../src/models/multitrackmodel.cpp" line="2653"/>
        <source>Error: Shotcut could not find the %1 plugin on your system.

Please install the %2 plugins.</source>
        <translation>Earráid: Níorbh fhéidir le Shotcut breiseán %1 a aimsiú ar do chóras.

Suiteáil breiseáin% 2 le do thoil.</translation>
    </message>
</context>
<context>
    <name>NetworkProducerWidget</name>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="26"/>
        <source>Network Stream</source>
        <translation>Sruth Líonra</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="41"/>
        <source>&amp;URL</source>
        <translation>&amp;URL</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="57"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
</context>
<context>
    <name>NewProjectFolder</name>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="20"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="61"/>
        <source>Projects</source>
        <translation>Tionscadail</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="188"/>
        <location filename="../src/widgets/newprojectfolder.ui" line="205"/>
        <source>PushButton</source>
        <translation>PushButton</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="231"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="372"/>
        <source>Remove</source>
        <translation>Bain</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="218"/>
        <source>A folder with this name will be created containing
a project file with the same name.</source>
        <translation>Cruthófar fillteán leis an ainm seo ina mbeidh
comhad tionscadail leis an ainm céanna.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="159"/>
        <source>Projects folder</source>
        <translation>Fillteán na dtionscadal</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="263"/>
        <source>Project name</source>
        <translation>Ainm an tionscadail</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="253"/>
        <source>Video mode</source>
        <translation>Mód físe</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="201"/>
        <source>This is the folder to contain Shotcut project folders.
A folder will be created in this folder for each project.</source>
        <translation>Is é seo an fillteán a bhfuil fillteáin tionscadail Shotcut.
Cruthófar fillteán san fhillteán seo do gach tionscadal.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="315"/>
        <source>Automatic means the resolution and frame rate are based on the &lt;b&gt;first&lt;/b&gt; file you &lt;b&gt;add&lt;/b&gt; to your project. If the first file is not a video clip (for example, image or audio), then it will be 1920x1080p 25 fps.</source>
        <translation>Ciallaíonn uathoibríoch go bhfuil an taifeach agus an ráta fráma bunaithe ar an &lt;b&gt;gcéad&lt;/b&gt; chomhad &lt;b&gt;a chuireann tú le&lt;/b&gt; do thionscadal. Mura gearrthóg físe é an chéad chomhad (mar shampla, íomhá nó fuaim), ansin beidh sé 1920x1080p 25 fps.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="143"/>
        <source>New Project</source>
        <translation>Tionscadal Nua</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="357"/>
        <source>Automatic</source>
        <translation>Uathoibríoch</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="362"/>
        <source>Add...</source>
        <translation>Cuir leis...</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="367"/>
        <source>Remove...</source>
        <translation>Bain...</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="130"/>
        <source>Projects Folder</source>
        <translation>Fillteán Tionscadal</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="167"/>
        <source>Custom</source>
        <translation>Saincheaptha</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="184"/>
        <source>Remove Video Mode</source>
        <translation>Bain Mód Físeáin</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="213"/>
        <source>The project name cannot include a slash.</source>
        <translation>Ní féidir slais a chur in ainm an tionscadail.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="229"/>
        <source>There is already a project with that name.
Try again with a different name.</source>
        <translation>Tá tionscadal leis an ainm sin cheana féin.
Bain triail eile as le hainm eile.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="238"/>
        <source>Unable to create folder %1
Perhaps you do not have permission.
Try again with a different folder.</source>
        <translation>Ní féidir fillteán %1 a chruthú
B&apos;fhéidir nach bhfuil cead agat.
Bain triail eile as le fillteán eile.</translation>
    </message>
</context>
<context>
    <name>NoiseWidget</name>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="26"/>
        <source>Noise</source>
        <translation>Torann</translation>
    </message>
</context>
<context>
    <name>NotesDock</name>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="79"/>
        <source>Notes</source>
        <translation>Nótaí</translation>
    </message>
</context>
<context>
    <name>OpenOtherDialog</name>
    <message>
        <location filename="../src/openotherdialog.ui" line="17"/>
        <source>Open Other</source>
        <translation>Oscail Eile</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.ui" line="55"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="32"/>
        <source>Add To Timeline</source>
        <translation>Cuir le Amlíne</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="38"/>
        <location filename="../src/openotherdialog.cpp" line="143"/>
        <source>Network</source>
        <translation>Líonra</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="43"/>
        <source>Device</source>
        <translation>Gléas</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="45"/>
        <location filename="../src/openotherdialog.cpp" line="145"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="49"/>
        <location filename="../src/openotherdialog.cpp" line="135"/>
        <source>Video4Linux</source>
        <translation>Físeán4linux</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="51"/>
        <location filename="../src/openotherdialog.cpp" line="137"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="53"/>
        <location filename="../src/openotherdialog.cpp" line="139"/>
        <source>ALSA Audio</source>
        <translation>Fuaime ALSA</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="56"/>
        <location filename="../src/openotherdialog.cpp" line="59"/>
        <location filename="../src/openotherdialog.cpp" line="141"/>
        <source>Audio/Video Device</source>
        <translation>Gléas Fuaime/Físe</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="64"/>
        <source>Generator</source>
        <translation>Gineadóir</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="66"/>
        <location filename="../src/openotherdialog.cpp" line="147"/>
        <source>Color</source>
        <translation>Dath</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="69"/>
        <source>Text</source>
        <translation>Téacs</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="74"/>
        <location filename="../src/openotherdialog.cpp" line="149"/>
        <source>Animation</source>
        <translation>Beochan</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="78"/>
        <location filename="../src/openotherdialog.cpp" line="151"/>
        <source>Noise</source>
        <translation>Torann</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="82"/>
        <location filename="../src/openotherdialog.cpp" line="153"/>
        <source>Ising</source>
        <translation>Iseach</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="87"/>
        <location filename="../src/openotherdialog.cpp" line="155"/>
        <source>Lissajous</source>
        <translation>Lissajous</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="91"/>
        <location filename="../src/openotherdialog.cpp" line="157"/>
        <source>Plasma</source>
        <translation>Plasma</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="95"/>
        <location filename="../src/openotherdialog.cpp" line="159"/>
        <source>Color Bars</source>
        <translation>Barraí Dath</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="99"/>
        <location filename="../src/openotherdialog.cpp" line="161"/>
        <source>Audio Tone</source>
        <translation>Ton Fuaime</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="103"/>
        <location filename="../src/openotherdialog.cpp" line="163"/>
        <source>Count</source>
        <translation>Áireamh</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="107"/>
        <location filename="../src/openotherdialog.cpp" line="165"/>
        <source>Blip Flash</source>
        <translation>Flash blip</translation>
    </message>
</context>
<context>
    <name>ParameterHead</name>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="151"/>
        <source>Seek to previous keyframe</source>
        <translation>Iarracht a dhéanamh eochairfhráma roimhe seo</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="151"/>
        <source>Seek backwards</source>
        <translation>Lorg siar</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="171"/>
        <source>Add a keyframe at play head</source>
        <translation>Cuir eochairfhráma leis ag ceann an tsúgartha</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="199"/>
        <source>Delete the selected keyframe</source>
        <translation>Scrios an eochairfhráma roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="228"/>
        <source>Seek to next keyframe</source>
        <translation>Déan iarracht an chéad eochairfhráma eile a lorg</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="228"/>
        <source>Seek forwards</source>
        <translation>Lorg ar aghaidh</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="245"/>
        <source>Unlock track</source>
        <translation>Díghlasáil rian</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="245"/>
        <source>Lock track</source>
        <translation>Glasáil rian</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="256"/>
        <source>Zoom keyframe values</source>
        <translation>Luachanna eochairfhráma zúmála</translation>
    </message>
</context>
<context>
    <name>PlasmaWidget</name>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="26"/>
        <source>Plasma</source>
        <translation>Plasma</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="41"/>
        <source>Speed 1</source>
        <translation>Luas 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="112"/>
        <source>Speed 2</source>
        <translation>Luas 2</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="180"/>
        <source>Speed 3</source>
        <translation>Luas 3</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="252"/>
        <source>Speed 4</source>
        <translation>Luas 4</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="323"/>
        <source>Move 1</source>
        <translation>Bog 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="391"/>
        <source>Move 2</source>
        <translation>Bog 2</translation>
    </message>
</context>
<context>
    <name>Player</name>
    <message>
        <location filename="../src/player.cpp" line="91"/>
        <source>Source</source>
        <translation>Foinse</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="92"/>
        <source>Project</source>
        <translation>Tionscadal</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="155"/>
        <source>Adjust the audio volume</source>
        <translation>Coigeartaigh an toirt fuaime</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="177"/>
        <source>Silence the audio</source>
        <translation>Ciúnas an fhuaim</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="196"/>
        <source>Current position</source>
        <translation>Staid reatha</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="202"/>
        <source>Total Duration</source>
        <translation>Fad Iomlán</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="380"/>
        <source>In Point</source>
        <translation>I bPointe</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="388"/>
        <source>Selected Duration</source>
        <translation>Fad Roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="242"/>
        <source>Zoom Fit</source>
        <translation>Súmáil Oiriúnach</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="191"/>
        <source>Current/Total Times</source>
        <translation>Amanna Reatha/Iomlána</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="210"/>
        <source>Player Controls</source>
        <translation>Rialtáin Imreora</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="221"/>
        <location filename="../src/player.cpp" line="375"/>
        <source>Player Options</source>
        <translation>Roghanna Imreora</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="248"/>
        <source>Zoom 10%</source>
        <translation>Súmáil 10%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="254"/>
        <source>Zoom 25%</source>
        <translation>Súmáil 25%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="260"/>
        <source>Zoom 50%</source>
        <translation>Súmáil 50%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="267"/>
        <source>Zoom 100%</source>
        <translation>Súmáil 100%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="273"/>
        <source>Zoom 200%</source>
        <translation>Súmáil 200%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="311"/>
        <source>Toggle zoom</source>
        <translation>Scoránaigh súmáil</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="318"/>
        <source>2x2 Grid</source>
        <translation>Greille 2x2</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="323"/>
        <source>3x3 Grid</source>
        <translation>Greille 3x3</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="327"/>
        <source>4x4 Grid</source>
        <translation>Greille 4x4</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="331"/>
        <source>16x16 Grid</source>
        <translation>Greille 16x16</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="339"/>
        <source>10 Pixel Grid</source>
        <translation>10 Greille Picteilíní</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="462"/>
        <source>Play/Pause</source>
        <translation>Seinn/Sos</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="466"/>
        <source>Toggle play or pause</source>
        <translation>Scoránaigh an súgradh nó cuir ar sos é</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="477"/>
        <source>Loop</source>
        <translation>Lúb</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="483"/>
        <source>Toggle player looping</source>
        <translation>Scoránaigh lúbadh an imreora</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="487"/>
        <source>Loop All</source>
        <translation>Lúb Gach Rud</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="488"/>
        <source>Loop back to the beginning when the end is reached</source>
        <translation>Lúb siar go dtí an tús nuair a shroichtear an deireadh</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="495"/>
        <source>Loop Marker</source>
        <translation>Marcóir Lúibe</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="496"/>
        <source>Loop around the marker under the cursor in the timeline</source>
        <translation>Lúb timpeall an mharcóra faoin gcúrsóir san amlíne</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="507"/>
        <source>Loop Selection</source>
        <translation>Roghnú Lúb</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="508"/>
        <source>Loop around the selected clips</source>
        <translation>Lúb timpeall na gearrthóga roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="516"/>
        <source>Nothing selected</source>
        <translation>Níl aon rud roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="521"/>
        <source>Loop Around Cursor</source>
        <translation>Lúb Timpeall an Chúrsóra</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="522"/>
        <source>Loop around the current cursor position</source>
        <translation>Lúb timpeall ar shuíomh reatha an chúrsóra</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="551"/>
        <source>Skip to the next point</source>
        <translation>Scipeáil go dtí an chéad phointe eile</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="574"/>
        <source>Skip to the previous point</source>
        <translation>Scipeáil chuig an bpointe roimhe seo</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="599"/>
        <source>Play quickly backwards</source>
        <translation>Seinn go tapa ar gcúl</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="609"/>
        <source>Play quickly forwards</source>
        <translation>Seinn go tapa ar aghaidh</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="613"/>
        <source>Seek Start</source>
        <translation>Tosaigh a Lorg</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="618"/>
        <source>Seek End</source>
        <translation>Lorg Deireadh</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="628"/>
        <source>Next Frame</source>
        <translation>An Chéad Fhráma Eile</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="634"/>
        <source>Previous Frame</source>
        <translation>An Fráma Roimhe Seo</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="640"/>
        <source>Forward One Second</source>
        <translation>Ar Aghaidh Soicind Amháin</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="645"/>
        <source>Backward One Second</source>
        <translation>Ar gcúl soicind amháin</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="650"/>
        <source>Forward Two Seconds</source>
        <translation>Ar Aghaidh Dhá Shoicind</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="655"/>
        <source>Backward Two Seconds</source>
        <translation>Ar gcúl Dhá Shoicind</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="660"/>
        <source>Forward Five Seconds</source>
        <translation>Ar Aghaidh Cúig Shoicind</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="665"/>
        <source>Backward Five Seconds</source>
        <translation>Ar gcúl Cúig Shoicind</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="670"/>
        <source>Forward Ten Seconds</source>
        <translation>Ar Aghaidh Deich Soicind</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="675"/>
        <source>Backward Ten Seconds</source>
        <translation>Ar gcúl Deich Soicind</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="680"/>
        <source>Forward Jump</source>
        <translation>Léim Ar Aghaidh</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="687"/>
        <source>Backward Jump</source>
        <translation>Léim ar gcúl</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="694"/>
        <source>Set Jump Time</source>
        <translation>Socraigh Am Léime</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="705"/>
        <source>Trim Clip In</source>
        <translation>Bearr Clip Isteach</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="718"/>
        <source>Trim Clip Out</source>
        <translation>Bearr Clip Amach</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="731"/>
        <source>Set Time Position</source>
        <translation>Socraigh Ionad Ama</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="761"/>
        <source>Pause playback</source>
        <translation>Cuir athsheinm ar sos</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="763"/>
        <location filename="../src/player.cpp" line="768"/>
        <location filename="../src/player.cpp" line="773"/>
        <source>Player</source>
        <translation>Seinnteoir</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="765"/>
        <source>Focus Player</source>
        <translation>Seinnteoir Fócais</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="770"/>
        <source>Toggle Filter Overlay</source>
        <translation>Scoránaigh Forleagan Scagaire</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="923"/>
        <source>Not Seekable</source>
        <translation>Ní féidir a leithéid a dhéanamh</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="335"/>
        <source>20 Pixel Grid</source>
        <translation>20 Greille Picteilíní</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="279"/>
        <source>Zoom 300%</source>
        <translation>Súmáil 300%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="285"/>
        <source>Zoom 400%</source>
        <translation>Súmáil 400%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="291"/>
        <source>Zoom 500%</source>
        <translation>Súmáil 500%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="297"/>
        <source>Zoom 750%</source>
        <translation>Súmáil 750%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="303"/>
        <source>Zoom 1000%</source>
        <translation>Súmáil 1000%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="343"/>
        <source>80/90% Safe Areas</source>
        <translation>80/90% Limistéir Shábháilte</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="347"/>
        <source>EBU R95 Safe Areas</source>
        <translation>EBU R95 Limistéir Shábháilte</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="352"/>
        <source>Snapping</source>
        <translation>Snapáil</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="362"/>
        <source>Toggle grid display on the player</source>
        <translation>Scoránaigh taispeáint na greille ar an seinnteoir</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="738"/>
        <source>Switch Source/Project</source>
        <translation>Athraigh Foinse/Tionscadal</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="758"/>
        <source>Pause</source>
        <translation>Sos</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="545"/>
        <source>Skip Next</source>
        <translation>Ná bac leis an gcéad cheann eile</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="568"/>
        <source>Skip Previous</source>
        <translation>Ná bac leis an méid a bhí ann roimhe seo</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="593"/>
        <source>Rewind</source>
        <translation>Atosaigh</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="603"/>
        <source>Fast Forward</source>
        <translation>Fast Ar Aghaidh</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="369"/>
        <source>Volume</source>
        <translation>Imleabhar</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="370"/>
        <source>Show the volume control</source>
        <translation>Taispeáin an rialú toirte</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1278"/>
        <source>Proxy and preview scaling are ON at %1p</source>
        <translation>Tá scálú seachfhreastalaí agus réamhamhairc AR ag %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1283"/>
        <source>Proxy is ON at %1p</source>
        <translation>Tá an seachfhreastalaí AR ag %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1288"/>
        <source>Preview scaling is ON at %1p</source>
        <translation>Tá scálú réamhamhairc AR ag %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1403"/>
        <source>Unmute</source>
        <translation>Díbhalbhaigh</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1372"/>
        <location filename="../src/player.cpp" line="1412"/>
        <source>Mute</source>
        <translation>Balbhaigh</translation>
    </message>
</context>
<context>
    <name>PlaylistDock</name>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="18"/>
        <location filename="../src/docks/playlistdock.cpp" line="382"/>
        <source>Playlist</source>
        <translation>Seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="59"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; a playlist item to open it in the player.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can freely preview clips without necessarily adding them to the playlist or closing it.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To trim or adjust a playlist item &lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; to open it, make the changes, and click the &lt;span style=&quot; font-weight:600;&quot;&gt;Update&lt;/span&gt; icon.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drag-n-drop&lt;/span&gt; to rearrange the items.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Dúbailte-cliceáil&lt;/span&gt; mír seinmliosta chun é a oscailt san imreoir.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;féidir leat gearrthóga a réamhamharc faoi shaoirse gan iad a chur leis an seinmliosta nó é a dhúnadh.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Chun mír seinmliosta a bhearradh nó a choigeartú &lt;span style=&quot; font-weight:600;&quot;&gt;dúbailte-cliceáil chun é a oscailt, déan na hathruithe, agus cliceáil ar an deilbhín &lt;span style=&quot; font-weight:600;&quot;&gt;Update&lt;/span&gt; icon.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drag-n-drop&lt;/span&gt; chun na míreanna a athshocrú.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="127"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Double-click a playlist item to open it in the player.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cliceáil faoi dhó ar mhír seinmliosta chun é a oscailt sa seinnteoir.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="601"/>
        <source>Add the Source to the playlist</source>
        <translation>Cuir an Fhoinse leis an seinnliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="612"/>
        <source>Remove cut</source>
        <translation>Bain gearradh</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="630"/>
        <source>Update</source>
        <translation>Nuashonrú</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="642"/>
        <source>View as tiles</source>
        <translation>Féach mar tíleanna</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="655"/>
        <source>View as icons</source>
        <translation>Féach orthu mar dheilbhíní</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="668"/>
        <source>View as details</source>
        <translation>Féach ar mar shonraí</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="607"/>
        <source>Remove</source>
        <translation>Bain</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="720"/>
        <source>Set Creation Time...</source>
        <translation>Socraigh Am Cruthaithe...</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="706"/>
        <location filename="../src/docks/playlistdock.cpp" line="707"/>
        <source>Insert</source>
        <translation>Ionsáigh</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="451"/>
        <source>Playlist Menu</source>
        <translation>Roghchlár Seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="599"/>
        <source>Append</source>
        <translation>Cuir leis</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="681"/>
        <source>Open the clip in the Source player</source>
        <translation>Oscail an ghearrthóg san imreoir Foinse</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="691"/>
        <source>Go to the start of this clip in the Project player</source>
        <translation>Téigh go dtí tús an ghearrthóg seo sa seinnteoir Tionscadail</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="728"/>
        <source>Remove All</source>
        <translation>Bain Gach Rud</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="729"/>
        <source>Remove all items from the playlist</source>
        <translation>Bain gach mír ón seinnliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="805"/>
        <source>Hidden</source>
        <translation>I bhfolach</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="817"/>
        <source>In and Out - Left/Right</source>
        <translation>Isteach agus Amach - Clé/Deas</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="833"/>
        <source>In and Out - Top/Bottom</source>
        <translation>Isteach agus Amach - Barr / Bun</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="850"/>
        <source>In Only - Small</source>
        <translation>In Amháin - Beag</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="866"/>
        <source>In Only - Large</source>
        <translation>I Amháin - Mór</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="772"/>
        <source>Add Selected to Timeline</source>
        <translation>Cuir Roghnaithe leis an Amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="779"/>
        <source>Add Selected to Slideshow</source>
        <translation>Cuir roghnaithe leis an taispeántas sleamhnán</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="883"/>
        <source>Play After Open</source>
        <translation>Seinn tar éis Oscailte</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="734"/>
        <source>Select All</source>
        <translation>Roghnaigh Uile</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="740"/>
        <source>Select None</source>
        <translation>Roghnaigh Dada</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="712"/>
        <source>Update Thumbnails</source>
        <translation>Nuashonraigh Mionsamhlacha</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="786"/>
        <source>Sort By Name</source>
        <translation>Sórtáil de réir Ainm</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="794"/>
        <source>Sort By Date</source>
        <translation>Sórtáil de réir dáta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="667"/>
        <source>Details</source>
        <translation>Sonraí</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="412"/>
        <source>Select</source>
        <translation>Roghnaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="429"/>
        <location filename="../src/docks/playlistdock.cpp" line="1134"/>
        <source>Bins</source>
        <translation>Boscaí Bruscair</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="436"/>
        <source>Columns</source>
        <translation>Colúin</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="446"/>
        <source>Playlist Controls</source>
        <translation>Rialuithe Seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="480"/>
        <location filename="../src/docks/playlistdock.cpp" line="484"/>
        <source>Playlist Filters</source>
        <translation>Scagairí Seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="508"/>
        <source>Only show files whose name, path, or comment contains some text</source>
        <translation>Ná taispeáin ach comhaid a bhfuil téacs éigin ina n-ainm, ina gcosán nó ina dtrácht</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="509"/>
        <source>search</source>
        <translation>cuardaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="623"/>
        <source>Add files to playlist</source>
        <translation>Cuir comhaid leis an seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="641"/>
        <source>Tiles</source>
        <translation>Tíleanna</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="654"/>
        <source>Icons</source>
        <translation>Deilbhíní</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="680"/>
        <source>Open</source>
        <translation>Oscail</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="690"/>
        <source>GoTo</source>
        <translation>GoTo</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="696"/>
        <source>Copy</source>
        <translation>Cóip</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="697"/>
        <source>Open a copy of the clip in the Source player</source>
        <translation>Oscail cóip den ghearrthóg sa seinnteoir foinseach</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="748"/>
        <source>Move Up</source>
        <translation>Bog Suas</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="760"/>
        <source>Move Down</source>
        <translation>Bog Síos</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="891"/>
        <source>Open Previous</source>
        <translation>Oscail Roimhe Seo</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="904"/>
        <source>Open Next</source>
        <translation>Oscail Ar Aghaidh</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="917"/>
        <source>Select Clip 1</source>
        <translation>Roghnaigh Gearrthóg 1</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="929"/>
        <source>Select Clip 2</source>
        <translation>Roghnaigh Gearrthóg 2</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="941"/>
        <source>Select Clip 3</source>
        <translation>Roghnaigh Gearrthóg 3</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="953"/>
        <source>Select Clip 4</source>
        <translation>Roghnaigh Gearrthóg 4</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="965"/>
        <source>Select Clip 5</source>
        <translation>Roghnaigh Gearrthóg 5</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="977"/>
        <source>Select Clip 6</source>
        <translation>Roghnaigh Gearrthóg 6</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="989"/>
        <source>Select Clip 7</source>
        <translation>Roghnaigh Gearrthóg 7</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1001"/>
        <source>Select Clip 8</source>
        <translation>Roghnaigh Gearrthóg 8</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1013"/>
        <source>Select Clip 9</source>
        <translation>Roghnaigh Gearrthóg 9</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1025"/>
        <source>Thumbnails</source>
        <translation>Mionsamhlacha</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1034"/>
        <source>Clip</source>
        <translation>Gearrthóg</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1043"/>
        <source>In</source>
        <translation>I</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1052"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1061"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1070"/>
        <source>Date</source>
        <translation>Dáta</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1079"/>
        <source>Type</source>
        <translation>Cineál</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1088"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1089"/>
        <source>Show or hide video files</source>
        <translation>Taispeáin nó folaigh comhaid físe</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1094"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1095"/>
        <source>Show or hide audio files</source>
        <translation>Taispeáin nó folaigh comhaid fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1100"/>
        <source>Image</source>
        <translation>Íomhá</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1101"/>
        <source>Show or hide image files</source>
        <translation>Taispeáin nó folaigh comhaid íomhá</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1106"/>
        <source>Other</source>
        <translation>Eile</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1107"/>
        <source>Show or hide other kinds of files</source>
        <translation>Taispeáin nó folaigh cineálacha eile comhaid</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1112"/>
        <location filename="../src/docks/playlistdock.cpp" line="1113"/>
        <source>New Bin</source>
        <translation>Bosca Bruscair Nua</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1124"/>
        <location filename="../src/docks/playlistdock.cpp" line="1164"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1135"/>
        <source>Show or hide the list of bins</source>
        <translation>Taispeáin nó folaigh liosta na mboscaí bruscair</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1144"/>
        <location filename="../src/docks/playlistdock.cpp" line="1145"/>
        <source>Remove Bin</source>
        <translation>Bain Bosca Bruscair</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1156"/>
        <location filename="../src/docks/playlistdock.cpp" line="1157"/>
        <source>Rename Bin</source>
        <translation>Athainmnigh an Bosca Bruscair</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1178"/>
        <source>Search</source>
        <translation>Cuardach</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="1213"/>
        <source>Replace %n playlist items</source>
        <translation>
            <numerusform>Ionadaigh %n mír seinmliosta</numerusform>
            <numerusform>Ionadaigh %n míreanna seinmliosta</numerusform>
            <numerusform>Ionadaigh %n míreanna seinmliosta</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="2138"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n mír</numerusform>
            <numerusform>%n mhír</numerusform>
            <numerusform>%n mhír</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="433"/>
        <source>Sort</source>
        <translation>Sórtáil</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1536"/>
        <location filename="../src/docks/playlistdock.cpp" line="1768"/>
        <source>You cannot insert a playlist into a playlist!</source>
        <translation>Ní féidir seinnliosta a chur isteach i seinnliosta!</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="1553"/>
        <source>Remove %n playlist items</source>
        <translation>
            <numerusform>Bain %n mír seinmliosta</numerusform>
            <numerusform>Bain %n míreanna seinmliosta</numerusform>
            <numerusform>Bain %n míreanna seinmliosta</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="622"/>
        <location filename="../src/docks/playlistdock.cpp" line="1312"/>
        <source>Add Files</source>
        <translation>Cuir Comhaid leis</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1266"/>
        <source>Appending</source>
        <translation>Ag cur leis</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1322"/>
        <location filename="../src/docks/playlistdock.cpp" line="1331"/>
        <source>Failed to open </source>
        <translation>Theip ar oscailt</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1395"/>
        <source>Dropped Files</source>
        <translation>Comhaid Tite</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1857"/>
        <source>Generating</source>
        <translation>Giniúint</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="2076"/>
        <source>Open File</source>
        <translation>Oscail Comhad</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="2078"/>
        <source>All Files (*);;MLT XML (*.mlt)</source>
        <translation>Gach Comhad (*);;MLT XML (*.mlt)</translation>
    </message>
</context>
<context>
    <name>PlaylistIconView</name>
    <message>
        <location filename="../src/widgets/playlisticonview.cpp" line="175"/>
        <source>P</source>
        <comment>The first letter or symbol of &quot;proxy&quot;</comment>
        <translation>P</translation>
    </message>
</context>
<context>
    <name>PlaylistModel</name>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="269"/>
        <source>(PROXY)</source>
        <translation>(Seachfhreastalaí)</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="409"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="411"/>
        <source>Image</source>
        <translation>Íomhá</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="413"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="415"/>
        <source>Other</source>
        <translation>Eile</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="494"/>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="496"/>
        <source>Thumbnails</source>
        <translation>Mionsamhlacha</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="498"/>
        <source>Clip</source>
        <translation>Gearrthóg</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="500"/>
        <source>In</source>
        <translation>I</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="502"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="504"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="506"/>
        <source>Date</source>
        <translation>Dáta</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="508"/>
        <source>Type</source>
        <translation>Cineál</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="510"/>
        <source>Comment</source>
        <translation>Nóta Tráchta</translation>
    </message>
</context>
<context>
    <name>PlaylistProxyModel</name>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>All</source>
        <translation>Gach</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Duplicates</source>
        <translation>Dúblaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Not In Timeline</source>
        <translation>Gan a bheith in amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Not In a Bin</source>
        <translation>Ní In Araid</translation>
    </message>
</context>
<context>
    <name>Preset</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="43"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="73"/>
        <source>Save</source>
        <translation>Sábháil</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="87"/>
        <source>Delete</source>
        <translation>Scrios</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="111"/>
        <source>Save Preset</source>
        <translation>Sábháil Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="121"/>
        <source>Name:</source>
        <translation>Ainm:</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="147"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="185"/>
        <source>OK</source>
        <translation>Ceart go leor</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="152"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="197"/>
        <source>Cancel</source>
        <translation>Cealaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="165"/>
        <source>Delete Preset</source>
        <translation>Scrios Réamhshocrú</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="175"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>An bhfuil tú cinnte gur mian leat %1 a scriosadh?</translation>
    </message>
</context>
<context>
    <name>ProducerPreviewWidget</name>
    <message>
        <location filename="../src/widgets/producerpreviewwidget.cpp" line="168"/>
        <source>Play</source>
        <translation>Seinn</translation>
    </message>
</context>
<context>
    <name>PulseAudioWidget</name>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="26"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
</context>
<context>
    <name>QImageJob</name>
    <message>
        <location filename="../src/jobs/qimagejob.cpp" line="34"/>
        <source>Make proxy for %1</source>
        <translation>Déan seachfhreastalaí do %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="38"/>
        <source>Append playlist item %1</source>
        <translation>Iarcheangail mír seinmliosta %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="65"/>
        <source>Insert playist item %1</source>
        <translation>Ionsáigh mír sheinnteora %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="92"/>
        <source>Update playlist item %1</source>
        <translation>Nuashonraigh mír seinmliosta %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="135"/>
        <source>Remove playlist item %1</source>
        <translation>Bain mír seinmliosta %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="158"/>
        <source>Clear playlist</source>
        <translation>Glan an seinmliosta</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="203"/>
        <source>Move item from %1 to %2</source>
        <translation>Bog mír ó %1 go% 2</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="226"/>
        <source>Sort playlist by %1</source>
        <translation>Sórtáil seinmliosta de réir %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="273"/>
        <source>Trim playlist item %1 in</source>
        <translation>Bearr seinmliosta mír %1 in</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="311"/>
        <source>Trim playlist item %1 out</source>
        <translation>Bearr seinmliosta mír %1 amach</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="350"/>
        <source>Replace playlist item %1</source>
        <translation>Ionadaigh mír seinmliosta %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="381"/>
        <source>Add new bin: %1</source>
        <translation>Cuir bosca bruscair nua leis: %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/playlistcommands.cpp" line="427"/>
        <source>Move %n item(s) to bin: %1</source>
        <translation>
            <numerusform>Bog %n mír go bosca bruscair: % 1</numerusform>
            <numerusform>Bog %n míreanna go bosca bruscair: % 1</numerusform>
            <numerusform>Bog %n míreanna go bosca bruscair: % 1</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="462"/>
        <source>Remove bin: %1</source>
        <translation>Bain bosca bruscair: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="464"/>
        <source>Rename bin: %1</source>
        <translation>Athainmnigh bosca bruscair: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="97"/>
        <source>Append to track</source>
        <translation>Iarcheangail le rianú</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="103"/>
        <source>Append to Timeline</source>
        <translation>Iarcheangail leis an Amlíne</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="105"/>
        <source>Preparing</source>
        <translation>Ag ullmhú</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="120"/>
        <source>Appending</source>
        <translation>Ag cur leis</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="136"/>
        <source>Finishing</source>
        <translation>Críochnú</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="166"/>
        <source>Insert into track</source>
        <translation>Ionsáigh i rian</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="185"/>
        <location filename="../src/commands/timelinecommands.cpp" line="251"/>
        <source>Add Files</source>
        <translation>Cuir Comhaid leis</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="238"/>
        <source>Overwrite onto track</source>
        <translation>Forscríobh ar an mbóthar</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="287"/>
        <source>Lift from track</source>
        <translation>Ardaitheoir ón rian</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="321"/>
        <source>Remove from track</source>
        <translation>Bain ón rian</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="402"/>
        <source>Group %n clips</source>
        <translation>
            <numerusform>Grúpa %n gearrthóg</numerusform>
            <numerusform>Grúpa %n gearrthóg</numerusform>
            <numerusform>Grúpa %n gearrthóg</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="455"/>
        <source>Ungroup %n clips</source>
        <translation>
            <numerusform>Díghrúpáil %n gearrthóg</numerusform>
            <numerusform>Díghrúpáil %n gearrthóg</numerusform>
            <numerusform>Díghrúpáil %n gearrthóg</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="496"/>
        <source>Change track name</source>
        <translation>Athraigh ainm an amhráin</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="521"/>
        <source>Merge adjacent clips</source>
        <translation>Cumaisc gearrthóga cóngaracha</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="544"/>
        <source>Toggle track mute</source>
        <translation>Scoránaigh balbhú an rian</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="565"/>
        <source>Toggle track hidden</source>
        <translation>Scoránaigh an rian i bhfolach</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="590"/>
        <source>Change track compositing</source>
        <translation>Athraigh comhshuí an amhráin</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="615"/>
        <source>Lock track</source>
        <translation>Glasáil rian</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="676"/>
        <source>Move %n timeline clips</source>
        <translation>
            <numerusform>Bog %n gearrthóg amlíne</numerusform>
            <numerusform>Bog %n gearrthóg amlíne</numerusform>
            <numerusform>Bog %n gearrthóg amlíne</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="678"/>
        <source>Move timeline clip</source>
        <translation>Bog gearrthóg amlíne</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="903"/>
        <source>Trim clip in point</source>
        <translation>Bearr gearrthóg i bpointe</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1013"/>
        <source>Trim clip out point</source>
        <translation>Bearr gearrthóg amach pointe</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1118"/>
        <source>Split clip</source>
        <translation>Gearrthóg scoilte</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1120"/>
        <source>Split clips</source>
        <translation>Gearrthóga scoilte</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1157"/>
        <source>Adjust fade in</source>
        <translation>Coigeartaigh céimnithe isteach</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1192"/>
        <source>Adjust fade out</source>
        <translation>Coigeartaigh céimnithe amach</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1238"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1429"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1620"/>
        <source>Add transition</source>
        <translation>Cuir aistriú leis</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1321"/>
        <source>Trim transition in point</source>
        <translation>Bearr trasdul i bpointe</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1373"/>
        <source>Trim transition out point</source>
        <translation>Bearr pointe aistrithe amach</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1485"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1552"/>
        <source>Remove transition</source>
        <translation>Bain an t-aistriú</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1664"/>
        <source>Add video track</source>
        <translation>Cuir rian físe leis</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1666"/>
        <source>Add audio track</source>
        <translation>Cuir rian fuaime leis</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1710"/>
        <source>Insert audio track</source>
        <translation>Ionsáigh rian fuaime</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1712"/>
        <source>Insert video track</source>
        <translation>Ionsáigh rian físe</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1749"/>
        <source>Remove audio track</source>
        <translation>Bain rian fuaime</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1751"/>
        <source>Remove video track</source>
        <translation>Bain rian físe</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1821"/>
        <source>Move track down</source>
        <translation>Bog an rian síos</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1823"/>
        <source>Move track up</source>
        <translation>Bog an rian suas</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1847"/>
        <source>Change track blend mode</source>
        <translation>Athraigh mód cumaisc rian</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1889"/>
        <source>Change clip properties</source>
        <translation>Athraigh airíonna gearrthóg</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1958"/>
        <source>Detach Audio</source>
        <translation>Dícheangail Fuaime</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2109"/>
        <source>Replace timeline clip</source>
        <translation>Ionadaigh gearrthóg amlíne</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2138"/>
        <source>Align clips to reference track</source>
        <translation>Ailínigh gearrthóga leis an rian tagartha</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2219"/>
        <source>Apply copied filters</source>
        <translation>Cuir scagairí cóipeáilte i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4084"/>
        <source>You cannot add a project to itself!</source>
        <translation>Ní féidir leat tionscadal a chur leis féin!</translation>
    </message>
    <message>
        <location filename="../src/mltxmlchecker.cpp" line="118"/>
        <source>The file is not a MLT XML file.</source>
        <translation>Ní comhad XML MLT é an comhad.</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="95"/>
        <location filename="../src/util.cpp" line="142"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1050"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1140"/>
        <source>Unable to write file %1
Perhaps you do not have permission.
Try again with a different folder.</source>
        <translation>Ní féidir comhad %1 a scríobh
B&apos;fhéidir nach bhfuil cead agat.
Bain triail eile as le fillteán eile.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="159"/>
        <source>Transition</source>
        <translation>Trasdul</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="161"/>
        <source>Track: %1</source>
        <translation>Rian: %1</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="163"/>
        <source>Output</source>
        <translation>Aschur</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="326"/>
        <source>The value you entered is very similar to the common,
more standard %1 = %2/1001.

Do you want to use %1 = %2/1001 instead?</source>
        <translation>Tá an luach a d&apos;iontráil tú an-chosúil leis an
níos caighdeánaí %1 =% 2/1001.

An bhfuil fonn ort %1 =% 2/1001 a úsáid ina ionad?</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="717"/>
        <source>The drive you chose only has %1 MiB of free space.
Do you still want to continue?</source>
        <translation>Níl ach  %1 MiB de spás saor ag an tiomántán a roghnaigh tú.
An bhfuil fonn ort leanúint ar aghaidh fós?</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="725"/>
        <source>Do not show this anymore.</source>
        <comment>Export free disk space warning dialog</comment>
        <translation>Ná taispeáin é seo a thuilleadh.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="761"/>
        <source>unknown (%1)</source>
        <translation>anaithnid (%1)</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="764"/>
        <source>NA</source>
        <translation>MAIDIR LE</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="815"/>
        <source>This file uses color transfer characteristics %1, which may result in incorrect colors or brightness in Shotcut.</source>
        <translation>Úsáideann an comhad seo saintréithe aistrithe datha %1, a bhféadfadh dathanna míchearta nó gile i Shotcut a bheith mar thoradh air.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="820"/>
        <source>This file is variable frame rate, which is not reliable for editing.</source>
        <translation>Is ráta fráma athraitheach é an comhad seo, nach bhfuil iontaofa le haghaidh eagarthóireachta.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="824"/>
        <source>This file does not support seeking and cannot be used for editing.</source>
        <translation>Ní thacaíonn an comhad seo le lorg agus ní féidir é a úsáid le haghaidh eagarthóireachta.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="827"/>
        <source>This file format (HDV) is not reliable for editing.</source>
        <translation>Níl an fhormáid comhaid seo (HDV) iontaofa le haghaidh eagarthóireachta.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="843"/>
        <source> Do you want to convert it to an edit-friendly format?

If yes, choose a format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, it automatically replaces clips, or you can double-click the job to open it.
</source>
        <translation>Ar mhaith leat é a thiontú go formáid atá furasta a chur in eagar?

Má tá, roghnaigh formáid thíos agus ansin cliceáil OK chun ainm comhaid a roghnú. Tar éis ainm comhaid a roghnú, cruthaítear post. Nuair a dhéantar é, cuireann sé gearrthóga in ionad go huathoibríoch, nó is féidir leat cliceáil faoi dhó ar an bpost chun é a oscailt.</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="30"/>
        <location filename="../src/widgets/textproducerwidget.cpp" line="29"/>
        <source>transparent</source>
        <comment>Open Other &gt; Color</comment>
        <translation>trédhearcach</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3114"/>
        <source>Drop Files</source>
        <translation>Comhaid Titim</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3121"/>
        <source>Failed to open </source>
        <translation>Theip ar oscailt</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3137"/>
        <source>Not adding non-seekable file: </source>
        <translation>Gan comhad neamh-in-lorgtha a chur leis: </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1250"/>
        <source>Generating Playlist for Bin</source>
        <translation>Seinmliosta á ghiniúint don bhosca bruscair</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1855"/>
        <source>Generate Slideshow</source>
        <translation>Gin Taispeántas Sleamhnán</translation>
    </message>
    <message>
        <location filename="../src/proxymanager.cpp" line="366"/>
        <source>Make proxy for %1</source>
        <translation>Déan seachfhreastalaí do %1</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="67"/>
        <source>Converting Thumbnails</source>
        <translation>Mionsamhlacha á dTiontú</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="86"/>
        <source>Please wait for this one-time update to the thumbnail cache...</source>
        <translation>Fan leis an nuashonrú aonuaire seo ar an taisce mionsamhlacha...</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="30"/>
        <source>Delete marker: %1</source>
        <translation>Scrios marcóir: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="49"/>
        <source>Add marker: %1</source>
        <translation>Cuir marcóir leis: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="73"/>
        <source>Move marker: %1</source>
        <translation>Bog marcóir: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="75"/>
        <source>Edit marker: %1</source>
        <translation>Cuir marcóir in eagar: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="115"/>
        <source>Clear markers</source>
        <translation>Marcóirí soiléire</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="43"/>
        <source>transparent</source>
        <comment>Open Other &gt; Animation</comment>
        <translation>trédhearcach</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="637"/>
        <source>Edit With Glaxnimate</source>
        <translation>Cuir in eagar le Glaxnimate</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="43"/>
        <source>Playlist Clip: %1</source>
        <translation>Gearrthóg Seinmliosta: %1</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="46"/>
        <source>Track: %1, Clip: %2 (transition)</source>
        <translation>Rian: %1, Gearrthóg:% 2 (aistriú)</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="50"/>
        <source>Track: %1, Clip: %2</source>
        <translation>Amhrán: %1, Gearrthóg:% 2</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="289"/>
        <source>%1x%2</source>
        <translation>%1x%2</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="107"/>
        <source>Add %1 filter</source>
        <translation>Cuir scagaire %1 leis</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="109"/>
        <source>Add %1 filter set</source>
        <translation>Cuir tacar scagaire %1 leis</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="173"/>
        <source>Remove %1 filter</source>
        <translation>Bain scagaire %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="207"/>
        <source>Move %1 filter</source>
        <translation>Bog scagaire %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="247"/>
        <source>Disable %1 filter</source>
        <translation>Díchumasaigh scagaire %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="249"/>
        <source>Enable %1 filter</source>
        <translation>Cumasaigh scagaire %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="305"/>
        <source>Paste filters</source>
        <translation>Greamaigh scagairí</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="359"/>
        <source>Change %1 filter</source>
        <translation>Athraigh scagaire %1</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="361"/>
        <source>Change %1 filter: %2</source>
        <translation>Athraigh %1 scagaire:% 2</translation>
    </message>
    <message>
        <location filename="../src/models/audiolevelstask.cpp" line="183"/>
        <source>generating audio waveforms for</source>
        <translation>tonnchruthanna fuaime a ghiniúint le haghaidh</translation>
    </message>
    <message>
        <location filename="../src/models/audiolevelstask.cpp" line="266"/>
        <source>Done</source>
        <translation>Déanta</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="188"/>
        <source>add keyframe</source>
        <translation>cuir eochairfhráma leis</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="203"/>
        <source>remove keyframe</source>
        <translation>bain eochairfhráma</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="220"/>
        <source>modify keyframe</source>
        <translation>mionathraigh eochairfhráma</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="35"/>
        <source>Add subtitle track: %1</source>
        <translation>Cuir rian fotheideal leis: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="55"/>
        <source>Remove subtitle track: %1</source>
        <translation>Bain rian fotheidil: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="83"/>
        <source>Edit subtitle track: %1</source>
        <translation>Cuir rian fotheideal in eagar: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="106"/>
        <source>Add subtitle</source>
        <translation>Cuir fotheideal leis</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="108"/>
        <source>Add %n subtitles</source>
        <translation>
            <numerusform>Cuir %n fotheidil leis</numerusform>
            <numerusform>Cuir %n fotheidil leis</numerusform>
            <numerusform>Cuir %n fotheidil leis</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="162"/>
        <source>Remove %n subtitles</source>
        <translation>
            <numerusform>Bain %n fotheidil</numerusform>
            <numerusform>Bain %n fotheidil</numerusform>
            <numerusform>Bain %n fotheidil</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="301"/>
        <source>Move %n subtitles</source>
        <translation>
            <numerusform>Bog %n fotheidil</numerusform>
            <numerusform>Bog %n fotheidil</numerusform>
            <numerusform>Bog %n fotheidil</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="160"/>
        <source>Remove subtitle</source>
        <translation>Bain fotheideal</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="190"/>
        <source>Edit subtitle text</source>
        <translation>Cuir téacs fotheideal in eagar</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="225"/>
        <source>Change subtitle start</source>
        <translation>Athraigh tús an fhotheidil</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="259"/>
        <source>Change subtitle end</source>
        <translation>Athraigh deireadh an fhotheidil</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="299"/>
        <source>Move subtitle</source>
        <translation>Bog fotheideal</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/subtitlesdock.cpp" line="504"/>
        <source>Imported %1 subtitle item(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="606"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="621"/>
        <source>Importing subtitles...</source>
        <translation>Fotheidil á n- iompórtáil...</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/subtitlesdock.cpp" line="642"/>
        <source>Imported %n subtitle item(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="494"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="637"/>
        <source>No subtitles found to import</source>
        <translation>Níor aimsíodh fotheidil ar bith le hiompórtáil</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="311"/>
        <location filename="../src/models/subtitlesmodel.cpp" line="326"/>
        <source>Import %1 subtitle items</source>
        <translation>Iompórtáil %1 míreanna fotheideal</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="366"/>
        <source>Append subtitle</source>
        <translation>Iarcheangail fotheideal</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1335"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1059"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1149"/>
        <source>A job already exists for %1</source>
        <translation>Tá post le haghaidh %1 cheana féin</translation>
    </message>
</context>
<context>
    <name>QmlApplication</name>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="133"/>
        <source>Select a filter to copy</source>
        <translation>Roghnaigh scagaire le cóipeáil</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="212"/>
        <source>&lt;p&gt;Do you really want to add filters to &lt;b&gt;Output&lt;/b&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timeline &gt; Output&lt;/b&gt; is currently selected. Adding filters to &lt;b&gt;Output&lt;/b&gt; affects ALL clips in the timeline including new ones that will be added.&lt;/p&gt;</source>
        <translation>&lt;p&gt;An bhfuil tú cinnte gur mian leat scagairí a chur le &lt;b&gt;Aschur&lt;/b&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Amlíne &gt; Roghnaítear aschur&lt;/b&gt; faoi láthair. Bíonn tionchar ag scagairí a chur le &lt;b&gt;Aschur&lt;/b&gt; ar GACH gearrthóg san amlíne lena n-áirítear cinn nua a chuirfear leis.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="222"/>
        <source>Do not show this anymore.</source>
        <comment>confirm output filters dialog</comment>
        <translation>Ná taispeáin é seo a thuilleadh.</translation>
    </message>
</context>
<context>
    <name>QmlEditMenu</name>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="32"/>
        <source>Undo</source>
        <translation>Cealaigh</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="38"/>
        <source>Redo</source>
        <translation>Athdhéan</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="47"/>
        <source>Cut</source>
        <translation>Gearr</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="53"/>
        <source>Copy</source>
        <translation>Cóip</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="58"/>
        <source>Paste</source>
        <translation>Greamaigh</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="64"/>
        <source>Paste Text Only</source>
        <translation>Greamaigh Téacs amháin</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="70"/>
        <source>Delete</source>
        <translation>Scrios</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="76"/>
        <source>Clear</source>
        <translation>Glan</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="84"/>
        <source>Select All</source>
        <translation>Roghnaigh Uile</translation>
    </message>
</context>
<context>
    <name>QmlFilter</name>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="394"/>
        <source>(defaults)</source>
        <translation>(réamhshocraithe)</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="518"/>
        <source>Analyze %1</source>
        <translation>Anailís %1</translation>
    </message>
</context>
<context>
    <name>QmlMarkerMenu</name>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="62"/>
        <source>Edit...</source>
        <translation>Cuir in eagar...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="67"/>
        <source>Delete</source>
        <translation>Scrios</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="72"/>
        <source>Choose Color...</source>
        <translation>Roghnaigh Dath...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="86"/>
        <source>Choose Recent Color</source>
        <translation>Roghnaigh Dath Le Déanaí</translation>
    </message>
</context>
<context>
    <name>QmlRichText</name>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="141"/>
        <source>Cannot save: </source>
        <translation>Ní féidir sábháil: </translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="172"/>
        <source>Row</source>
        <translation>Ró</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="174"/>
        <source>Column</source>
        <translation>Colún</translation>
    </message>
</context>
<context>
    <name>QmlRichTextMenu</name>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="30"/>
        <source>File</source>
        <translation>Comhad</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="32"/>
        <source>Open...</source>
        <translation>Oscail...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="36"/>
        <source>Save As...</source>
        <translation>Sábháil Mar...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="40"/>
        <source>Edit</source>
        <translation>Cuir in eagar</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="42"/>
        <source>Undo</source>
        <translation>Cealaigh</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="47"/>
        <source>Redo</source>
        <translation>Athdhéan</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="54"/>
        <source>Cut</source>
        <translation>Gearr</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="59"/>
        <source>Copy</source>
        <translation>Cóip</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="64"/>
        <source>Paste</source>
        <translation>Greamaigh</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="69"/>
        <source>Paste Text Only</source>
        <translation>Greamaigh Téacs amháin</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="74"/>
        <source>Select All</source>
        <translation>Roghnaigh Uile</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="79"/>
        <source>Insert Table</source>
        <translation>Ionsáigh Tábla</translation>
    </message>
</context>
<context>
    <name>RecentDock</name>
    <message>
        <location filename="../src/docks/recentdock.ui" line="24"/>
        <source>Recent</source>
        <translation>le déanaí</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="46"/>
        <source>Show only files with name matching text</source>
        <translation>Ná taispeáin ach comhaid le téacs meaitseála ainm</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="49"/>
        <source>search</source>
        <translation>cuardaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="76"/>
        <location filename="../src/docks/recentdock.ui" line="79"/>
        <source>Remove</source>
        <translation>Bain</translation>
    </message>
</context>
<context>
    <name>ResourceDialog</name>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="35"/>
        <source>Resources</source>
        <translation>Acmhainní</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="47"/>
        <source>Convert Selected</source>
        <translation>Tiontaigh roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="98"/>
        <source>No resources to convert</source>
        <translation>Níl aon acmhainní le tiontú</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="103"/>
        <source>Choose an edit-friendly format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, double-click the job to open it.
</source>
        <translation>Roghnaigh formáid atá éasca le heagarthóireacht thíos agus ansin cliceáil OK chun ainm comhaid a roghnú. Tar éis ainm comhaid a roghnú, cruthaítear post. Nuair a bheidh sé déanta, cliceáil faoi dhó ar an bpost chun é a oscailt.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="108"/>
        <source>Convert...</source>
        <translation>Tiontaigh...</translation>
    </message>
</context>
<context>
    <name>ResourceModel</name>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="266"/>
        <source>%1MB</source>
        <translation>%1MB</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="281"/>
        <source>%1 %2x%3 %4fps</source>
        <translation>%1 %2x%3 %4fps</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="392"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="394"/>
        <source>Size</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="396"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="398"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
</context>
<context>
    <name>SaveDefaultButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SaveDefaultButton.qml" line="27"/>
        <source>Set as default</source>
        <translation>Socraigh mar réamhshocrú</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../src/dialogs/saveimagedialog.cpp" line="47"/>
        <source>PNG (*.png);;BMP (*.bmp);;JPEG (*.jpg *.jpeg);;PPM (*.ppm);;TIFF (*.tif *.tiff);;WebP (*.webp);;All Files (*)</source>
        <translation>PNG (*.png);;BMP (*.bmp);;JPEG (*.jpg *.jpeg);;PPM (*.ppm);;TIFF (*.tif *.tiff);;WebP (*. webp);;Gach Comhad (*)</translation>
    </message>
</context>
<context>
    <name>ScopeController</name>
    <message>
        <location filename="../src/controllers/scopecontroller.cpp" line="41"/>
        <source>Scopes</source>
        <translation>Scóip</translation>
    </message>
</context>
<context>
    <name>ServicePresetWidget</name>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="25"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="45"/>
        <source>Save</source>
        <translation>Sábháil</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="52"/>
        <source>Delete</source>
        <translation>Scrios</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="80"/>
        <source>(defaults)</source>
        <translation>(réamhshocraithe)</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="87"/>
        <source>Save Preset</source>
        <translation>Sábháil Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="88"/>
        <source>Name:</source>
        <translation>Ainm:</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="173"/>
        <source>Delete Preset</source>
        <translation>Scrios Réamhshocrú</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="174"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>An bhfuil tú cinnte gur mian leat %1 a scriosadh?</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="58"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="59"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="66"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="67"/>
        <source>Set to default</source>
        <translation>Socraigh mar réamhshocrú</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="76"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="77"/>
        <source>Clear shortcut</source>
        <translation>Glan aicearra</translation>
    </message>
</context>
<context>
    <name>ShotcutActions</name>
    <message>
        <location filename="../src/actions.cpp" line="52"/>
        <source>Other</source>
        <translation>Eile</translation>
    </message>
</context>
<context>
    <name>ShotcutSettings</name>
    <message>
        <location filename="../src/settings.cpp" line="104"/>
        <source>Old (before v23) Layout</source>
        <translation>Sean (roimh v23) Leagan Amach</translation>
    </message>
</context>
<context>
    <name>SimplePropertyUI</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SimplePropertyUI.qml" line="15"/>
        <source>Custom Properties</source>
        <translation>Airíonna an Chustaim</translation>
    </message>
</context>
<context>
    <name>SizePositionUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="338"/>
        <source>Bottom Left</source>
        <translation>Bun ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="342"/>
        <source>Bottom Right</source>
        <translation>Bun ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="346"/>
        <source>Top Left</source>
        <translation>Barr ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="350"/>
        <source>Top Right</source>
        <translation>Barr Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="356"/>
        <source>Slide In From Left</source>
        <translation>Sleamhnán Isteach Ó Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="358"/>
        <source>Slide In From Right</source>
        <translation>Sleamhnán Isteach Ó Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="360"/>
        <source>Slide In From Top</source>
        <translation>Sleamhnán Isteach Ó Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="362"/>
        <source>Slide In From Bottom</source>
        <translation>Sleamhnán Isteach Ó Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="366"/>
        <source>Slide Out Left</source>
        <translation>Sleamhnán Amach Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="368"/>
        <source>Slide Out Right</source>
        <translation>Sleamhnán Amach Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="370"/>
        <source>Slide Out Top</source>
        <translation>Sleamhnán Amach Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="372"/>
        <source>Slide Out Bottom</source>
        <translation>Sleamhnán Amach Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="377"/>
        <source>Slow Zoom In</source>
        <translation>Súmáil Mhall Isteach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="379"/>
        <source>Slow Zoom Out</source>
        <translation>Súmáil Mall Amach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="381"/>
        <source>Slow Pan Left</source>
        <translation>Pan Mall Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="382"/>
        <source>Slow Move Left</source>
        <translation>Bog Mall Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="384"/>
        <source>Slow Pan Right</source>
        <translation>Pan Mall Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="385"/>
        <source>Slow Move Right</source>
        <translation>Bog Mall Ar Dheas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="387"/>
        <source>Slow Pan Up</source>
        <translation>Pan Mall Suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="388"/>
        <source>Slow Move Up</source>
        <translation>Bog Suas Mall</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="390"/>
        <source>Slow Pan Down</source>
        <translation>Pan Mall síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="391"/>
        <source>Slow Move Down</source>
        <translation>Bog mall síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="393"/>
        <source>Slow Zoom In, Pan Up Left</source>
        <translation>Súmáil Mall Isteach, Pan Suas Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="394"/>
        <source>Slow Zoom In, Move Up Left</source>
        <translation>Súmáil Mall Isteach, Bog Suas ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="396"/>
        <source>Slow Zoom In, Pan Down Right</source>
        <translation>Súmáil Mall Isteach, Pan Síos Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="397"/>
        <source>Slow Zoom In, Move Down Right</source>
        <translation>Súmáil Mall Isteach, Bog Síos Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="399"/>
        <source>Slow Zoom Out, Pan Up Right</source>
        <translation>Súmáil Mall Amach, Pan Suas Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="400"/>
        <source>Slow Zoom Out, Move Up Right</source>
        <translation>Súmáil Mall Amach, Bog Suas Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="402"/>
        <source>Slow Zoom Out, Pan Down Left</source>
        <translation>Súmáil Mall Amach, Pan Síos Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="403"/>
        <source>Slow Zoom Out, Move Down Left</source>
        <translation>Súmáil Mall Amach, Bog Síos Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="405"/>
        <source>Slow Zoom In, Hold Bottom</source>
        <translation>Súmáil Mall Isteach, Coinnigh Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="407"/>
        <source>Slow Zoom In, Hold Top</source>
        <translation>Súmáil Mall Isteach, Coinnigh Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="409"/>
        <source>Slow Zoom In, Hold Left</source>
        <translation>Súmáil Mall Isteach, Coinnigh Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="411"/>
        <source>Slow Zoom In, Hold Right</source>
        <translation>Súmáil Mhall Isteach, Coinnigh Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="413"/>
        <source>Slow Zoom Out, Hold Bottom</source>
        <translation>Súmáil Mall Amach, Coinnigh Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="415"/>
        <source>Slow Zoom Out, Hold Top</source>
        <translation>Súmáil Mall Amach, Coinnigh Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="417"/>
        <source>Slow Zoom Out, Hold Left</source>
        <translation>Súmáil Mall Amach, Coinnigh Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="419"/>
        <source>Slow Zoom Out, Hold Right</source>
        <translation>Súmáil Mall Amach, Coinnigh Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="487"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="522"/>
        <source>Position</source>
        <translation>Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="632"/>
        <source>Size</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="707"/>
        <source>Zoom</source>
        <translation>Súmáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="755"/>
        <source>Size mode</source>
        <translation>Mód méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="762"/>
        <source>Fit</source>
        <translation>Oiriúnaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="776"/>
        <source>Fill</source>
        <translation>Líon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="796"/>
        <source>Distort</source>
        <translation>Saobhadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="824"/>
        <source>Horizontal fit</source>
        <translation>Oiriúnach cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="831"/>
        <source>Left</source>
        <translation>Ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="843"/>
        <source>Center</source>
        <translation>Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="855"/>
        <source>Right</source>
        <translation>Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="879"/>
        <source>Vertical fit</source>
        <translation>Oiriúnach ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="886"/>
        <source>Top</source>
        <translation>Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="898"/>
        <source>Middle</source>
        <comment>Size and Position video filter</comment>
        <translation>Lár</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="910"/>
        <source>Bottom</source>
        <translation>Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="934"/>
        <source>Rotation</source>
        <translation>Rothlú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="947"/>
        <source> °</source>
        <comment>degrees</comment>
        <translation> °</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="974"/>
        <source>Background color</source>
        <translation>Dath an chúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="425"/>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="430"/>
        <source>Shake 1 Second - Scaled</source>
        <translation>Croith 1 Dara - Scála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="427"/>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="432"/>
        <source>Shake 1 Second - Unscaled</source>
        <translation>Croith 1 Soicind - Gan scála</translation>
    </message>
</context>
<context>
    <name>SizePositionVUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionVUI.qml" line="156"/>
        <source>Click in rectangle + hold Shift to drag, Wheel to zoom, or %1+Wheel to rotate</source>
        <translation>Cliceáil i dronuilleog + coinnigh Shift le tarraing, Roth chun súmáil isteach, nó %1+ Roth le rothlú</translation>
    </message>
</context>
<context>
    <name>SlideshowGeneratorDialog</name>
    <message numerus="yes">
        <location filename="../src/dialogs/slideshowgeneratordialog.cpp" line="33"/>
        <source>Slideshow Generator - %n Clips</source>
        <translation>
            <numerusform>Gineadóir Taispeána Sleamhnán - %n Gearrthóg</numerusform>
            <numerusform>Gineadóir Taispeána Sleamhnán - %n Gearrthóg</numerusform>
            <numerusform>Gineadóir Taispeána Sleamhnán - %n Gearrthóg</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>SlideshowGeneratorWidget</name>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="58"/>
        <source>Clip duration</source>
        <translation>Fad gearrthóg</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="60"/>
        <source>Set the duration of each clip in the slideshow.</source>
        <translation>Socraigh fad gach gearrthóg sa taispeántas sleamhnán.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="69"/>
        <source>Aspect ratio conversion</source>
        <translation>Comhshó cóimheas gné</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="71"/>
        <source>Pad Black</source>
        <translation>Pad Dubh</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="72"/>
        <source>Crop Center</source>
        <translation>Gearradh ar an Lár</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="73"/>
        <source>Crop and Pan</source>
        <translation>Gearradh agus Peanáil</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="77"/>
        <source>Pad Blur</source>
        <translation>Pad Doiléirigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="80"/>
        <source>Choose an aspect ratio conversion method.</source>
        <translation>Roghnaigh modh comhshó cóimheas gné.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="89"/>
        <source>Zoom effect</source>
        <translation>Éifeacht súmáil</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="92"/>
        <source>Set the percentage of the zoom-in effect.
0% will result in no zoom effect.</source>
        <translation>Socraigh céatadán na héifeachta súmáil isteach.
Ní bheidh aon éifeacht súmáil isteach mar thoradh ar 0%.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="100"/>
        <source>Transition duration</source>
        <translation>Fad an aistrithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="103"/>
        <source>Set the duration of the transition.
May not be longer than half the duration of the clip.
If the duration is 0, no transition will be created.</source>
        <translation>Socraigh fad an aistrithe.
Ní fhéadfaidh sé a bheith níos faide ná leath ré an ghearrthóg.
Más é 0 an ré, ní chruthófar aon aistriú.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="116"/>
        <source>Transition type</source>
        <translation>Cineál aistrithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="119"/>
        <source>Random</source>
        <translation>Randamach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="120"/>
        <source>Cut</source>
        <translation>Gearr</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="121"/>
        <source>Dissolve</source>
        <translation>Tuaslaig</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="122"/>
        <source>Bar Horizontal</source>
        <translation>Barra Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="123"/>
        <source>Bar Vertical</source>
        <translation>Barra Ingearach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="124"/>
        <source>Barn Door Horizontal</source>
        <translation>Doras Barn Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="125"/>
        <source>Barn Door Vertical</source>
        <translation>Doras Barn Ingearach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="126"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Doras na Seanchreime Diagánach SW-NE</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="127"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Doras na Seanchreime Diagánach NW-SE</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="128"/>
        <source>Diagonal Top Left</source>
        <translation>Diagánach Barr Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="129"/>
        <source>Diagonal Top Right</source>
        <translation>Diagánach Barr Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="130"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Maitrís Eas Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="131"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Maitrís Eas Ingearach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="132"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Nathair na Matrics Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="133"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Nathair na Matrics Cothrománach Comhthreomhar</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="134"/>
        <source>Matrix Snake Vertical</source>
        <translation>Nathair na Matrics Ingearach</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="135"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Nathair na Matrics Ingearach Comhthreomhar
&#xa0;</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="136"/>
        <source>Barn V Up</source>
        <translation>Scioból V Suas</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="137"/>
        <source>Iris Circle</source>
        <translation>Ciorcal Iris</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="138"/>
        <source>Double Iris</source>
        <translation>Iris Dúbailte</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="139"/>
        <source>Iris Box</source>
        <translation>Bosca Iris</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="140"/>
        <source>Box Bottom Right</source>
        <translation>Bosca Bun ar dheis</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="141"/>
        <source>Box Bottom Left</source>
        <translation>Bosca Bun ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="142"/>
        <source>Box Right Center</source>
        <translation>Bosca Lár ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="143"/>
        <source>Clock Top</source>
        <translation>Clog Barr</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="147"/>
        <source>Choose a transition effect.</source>
        <translation>Roghnaigh éifeacht trasdula.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="155"/>
        <source>Transition softness</source>
        <translation>Bog an aistrithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="157"/>
        <source>Change the softness of the edge of the wipe.</source>
        <translation>Athraigh an softness an imeall an wipe.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="499"/>
        <source>Preview is not available with GPU Effects</source>
        <translation>Níl réamhamharc ar fáil le Éifeachtaí GPU</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="500"/>
        <source>Generating Preview...</source>
        <translation>Réamhamharc á Giniúint...</translation>
    </message>
</context>
<context>
    <name>SpeedUI</name>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="96"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Coinnigh % 1 chun eochairfhráma a tharraingt ingearach amháin nó % 2 chun cothrománach a tharraingt amháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="108"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="130"/>
        <source>Speed</source>
        <translation>Luas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="134"/>
        <source>Map the specified speed to the current time. Use keyframes to vary the speed mappings over time.</source>
        <translation>Déan an luas sonraithe a mhapáil go dtí an t-am reatha. Úsáid eochairfhrámaí chun na mapálacha luais a athrú thar am.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="158"/>
        <source>Image mode</source>
        <translation>Mód íomhá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="162"/>
        <source>Use the specified image selection mode. Nearest will output the image that is nearest to the mapped time. Blend will blend all images that occur during the mapped time.</source>
        <translation>Úsáid an modh roghnaithe íomhá sonraithe. Aschuirfear an íomhá is gaire don am mapáilte. Déanfaidh Cumasc na híomhánna go léir a tharlaíonn le linn an ama mapáilte a chumasc.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="181"/>
        <source>Nearest</source>
        <translation>Is gaire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="186"/>
        <source>Blend</source>
        <translation>Cumasc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="201"/>
        <source>Enable pitch compensation</source>
        <translation>Cumasaigh cúiteamh páirce</translation>
    </message>
</context>
<context>
    <name>SubtitleBar</name>
    <message>
        <location filename="../src/qml/views/timeline/SubtitleBar.qml" line="73"/>
        <source>Unable to move. Subtitles already exist at this time.</source>
        <translation>Ní féidir bogadh. Tá fotheidil ann cheana féin ag an am seo.</translation>
    </message>
</context>
<context>
    <name>SubtitleTrackDialog</name>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="54"/>
        <source>New Subtitle Track</source>
        <translation>Rian Fotheideal Nua</translation>
    </message>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="58"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="63"/>
        <source>Language</source>
        <translation>Teanga</translation>
    </message>
</context>
<context>
    <name>SubtitlesDock</name>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="131"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="177"/>
        <source>Subtitles</source>
        <translation>Fotheidil</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="147"/>
        <source>Add clips to the Timeline to begin editing subtitles.</source>
        <translation>Cuir gearrthóga leis an Amlíne chun tús a chur le fotheidil a eagarthóireacht.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="178"/>
        <source>Tracks</source>
        <translation>Rianta</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="198"/>
        <source>Columns</source>
        <translation>Colúin</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="199"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="202"/>
        <source>End</source>
        <translation>Críoch</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="205"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="211"/>
        <source>Subtitle Controls</source>
        <translation>Rialuithe Fotheideal</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="217"/>
        <source>Subtitles Menu</source>
        <translation>Roghchlár Fotheidil</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="268"/>
        <source>Previous</source>
        <translation>Roimhe Seo</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="270"/>
        <source>Current</source>
        <translation>Reatha</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="272"/>
        <source>Next</source>
        <translation>Ar aghaidh</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="304"/>
        <source>Add Subtitle Track</source>
        <translation>Cuir Rian Fotheideal leis</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="307"/>
        <source>Add a subtitle track</source>
        <translation>Cuir rian fotheideal leis</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="315"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="545"/>
        <source>Remove Subtitle Track</source>
        <translation>Bain Fotheideal Rian</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="318"/>
        <source>Remove this subtitle track</source>
        <translation>Bain an rian fotheideal seo</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="326"/>
        <source>Edit Subtitle Track</source>
        <translation>Cuir Rian Fotheideal in Eagar</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="329"/>
        <source>Edit this subtitle track</source>
        <translation>Cuir an rian fotheideal seo in eagar</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="337"/>
        <source>Import Subtitles From File</source>
        <translation>Iompórtáil Fotheidil Ó Chomhad</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="340"/>
        <source>Import subtitles from an srt file at the current position</source>
        <translation>Iompórtáil fotheidil ó chomhad srt ag an suíomh reatha</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="348"/>
        <source>Export Subtitles To File</source>
        <translation>Easpórtáil Fotheidil Go Comhad</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="351"/>
        <source>Export the current subtitle track to an SRT file</source>
        <translation>Easpórtáil an rian fotheideal reatha go comhad SRT</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="359"/>
        <source>Create/Edit Subtitle</source>
        <translation>Cruthaigh/Cuir Fotheideal in Eagar</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="363"/>
        <source>Create or Edit a subtitle at the cursor position.</source>
        <translation>Cruthaigh nó Cuir fotheideal in Eagar ag suíomh an chúrsóra.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="367"/>
        <source>Add Subtitle Item</source>
        <translation>Cuir Mír Fotheideal leis</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="371"/>
        <source>Add a subtitle at the cursor position</source>
        <translation>Cuir fotheideal leis ag suíomh an chúrsóra</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="375"/>
        <source>Remove Subtitle Item</source>
        <translation>Bain Mír Fotheideal</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="379"/>
        <source>Remove the selected subtitle item</source>
        <translation>Bain an mhír roghnaithe fotheideal</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="383"/>
        <source>Set Subtitle Start</source>
        <translation>Socraigh Tosaigh Fotheideal</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="388"/>
        <source>Set the selected subtitle to start at the cursor position</source>
        <translation>Socraigh an fotheideal roghnaithe chun tosú ag suíomh an chúrsóra</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="392"/>
        <source>Set Subtitle End</source>
        <translation>Socraigh Deireadh Fotheideal</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="397"/>
        <source>Set the selected subtitle to end at the cursor position</source>
        <translation>Socraigh an fotheideal roghnaithe chun críochnú ag suíomh an chúrsóra</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="401"/>
        <source>Move Subtitles</source>
        <translation>Bog Fotheidil</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="405"/>
        <source>Move the selected subtitles to the cursor position</source>
        <translation>Bog na fotheidil roghnaithe go dtí suíomh an chúrsóra</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="409"/>
        <source>Burn In Subtitles on Output</source>
        <translation>Dóigh Isteach Fotheidil ar Aschur</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="410"/>
        <source>Create or edit a Burn In Subtitles filter on the timeline output.</source>
        <translation>Cruthaigh nó cuir in eagar scagaire Dóigh I bhFotheidil ar an aschur amlíne.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="415"/>
        <source>Generate Text on Timeline</source>
        <translation>Gin Téacs ar Amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="417"/>
        <source>Create a new video track on the timeline with text showing these subtitles.</source>
        <translation>Cruthaigh rian físe nua ar an amlíne le téacs a thaispeánann na fotheidil seo.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="421"/>
        <source>Speech to Text...</source>
        <translation>Óráid go Téacs...</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="422"/>
        <source>Detect speech and transcribe to a new subtitle track.</source>
        <translation>Braith caint agus tras-scríobh chuig rian nua fotheideal.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="428"/>
        <source>Track Timeline Cursor</source>
        <translation>Cúrsóir Amlíne Rian</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="429"/>
        <source>Track the timeline cursor</source>
        <translation>Rianaigh an cúrsóir amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="437"/>
        <source>Show Previous/Next</source>
        <translation>Taispeáin Roimhe/Ar Aghaidh</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="438"/>
        <source>Show the previous and next subtitles</source>
        <translation>Taispeáin na fotheidil roimhe seo agus na chéad fotheidil eile</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="511"/>
        <source>Add a clip to the timeline to create subtitles.</source>
        <translation>Cuir gearrthóg leis an amlíne chun fotheidil a chruthú.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1067"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1069"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1089"/>
        <source>Subtitle Track %1</source>
        <translation>Fotheideal Rian %1</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1131"/>
        <source>Generate subtitle text on timeline</source>
        <translation>Gin téacs fotheideal ar amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1132"/>
        <source>Text style preset</source>
        <translation>Stíl téacs réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1134"/>
        <source>Default subtitle style</source>
        <translation>Stíl fotheideal réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1277"/>
        <source>Extracting Audio</source>
        <translation>Baint Fuaime Amach</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1295"/>
        <source>Speech to Text</source>
        <translation>Óráid go Téacs</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="522"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="575"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1226"/>
        <source>Subtitle track already exists: %1</source>
        <translation>Tá rian fotheideal ann cheana: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="546"/>
        <source>This track is in use by a subtitle filter.
Remove the subtitle filter before removing this track.</source>
        <translation>Tá an rian seo in úsáid ag scagaire fotheideal.
Bain an scagaire fotheideal roimh an rian seo a bhaint.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="592"/>
        <source>Import Subtitle File</source>
        <translation>Iompórtáil Fotheideal Comhad</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="594"/>
        <source>Subtitle Files (*.srt *.SRT *.vtt *.VTT *.ass *.ASS *.ssa *.SSA)</source>
        <translation>Comhaid Fotheideal (*.srt *.SRT *.vtt *.VTT *.ass *.ASS *.ssa *.SSA)</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="602"/>
        <source>Unable to find subtitle file.</source>
        <translation>Ní féidir an comhad fotheideal a aimsiú.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="650"/>
        <source>Export SRT File</source>
        <translation>Easpórtáil Comhad SRT</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="652"/>
        <source>SRT Files (*.srt *.SRT)</source>
        <translation>Comhaid SRT (*.srt *.SRT)</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="717"/>
        <source>A subtitle already exists at this time.</source>
        <translation>Tá fotheideal ann cheana féin ag an am seo.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="727"/>
        <source>Not enough space to add subtitle.</source>
        <translation>Níl go leor spáis chun fotheideal a chur leis.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="764"/>
        <source>Start time can not be after end time.</source>
        <translation>Ní féidir am tosaithe a bheith tar éis am deiridh.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="770"/>
        <source>Start time can not be before previous subtitle.</source>
        <translation>Ní féidir am tosaithe a bheith roimh an bhfotheideal roimhe seo.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="788"/>
        <source>End time can not be before start time.</source>
        <translation>Ní féidir am deiridh a bheith roimh am tosaithe.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="795"/>
        <source>End time can not be after next subtitle.</source>
        <translation>Ní féidir an t-am deiridh a bheith i ndiaidh an chéad fhotheideal eile.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="817"/>
        <source>Unable to move. Subtitles already exist at this time.</source>
        <translation>Ní féidir bogadh. Tá fotheidil ann cheana féin ag an am seo.</translation>
    </message>
</context>
<context>
    <name>SubtitlesModel</name>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="818"/>
        <source>Text</source>
        <translation>Téacs</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="820"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="822"/>
        <source>End</source>
        <translation>Críoch</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="824"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
</context>
<context>
    <name>SystemSyncDialog</name>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="14"/>
        <source>Player Synchronization</source>
        <translation>Sioncrónú Imreoir</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="20"/>
        <source>Adjust your playback audio/video synchronization</source>
        <translation>Coigeartaigh do athsheinm fuaime/físe sioncrónaithe</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="48"/>
        <source>Reset to default value 0</source>
        <translation>Athshocraigh go luach réamhshocraithe 0</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="65"/>
        <source>Video offset</source>
        <translation>Fritháireamh físeáin</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="75"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="82"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
</context>
<context>
    <name>TextEditor</name>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="41"/>
        <source>Decrease Text Size</source>
        <translation>Laghdú ar Méid an Téacs</translation>
    </message>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="44"/>
        <location filename="../src/docks/notesdock.cpp" line="49"/>
        <source>Notes</source>
        <translation>Nótaí</translation>
    </message>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="46"/>
        <source>Increase Text Size</source>
        <translation>Méadú Téacs Méid</translation>
    </message>
</context>
<context>
    <name>TextFilterUi</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="78"/>
        <source>Bold</source>
        <translation>Trom</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="80"/>
        <source>Italic</source>
        <translation>Iodálach</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="208"/>
        <source>Font</source>
        <translation>Cló</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="267"/>
        <source>Use font size</source>
        <translation>Úsáid méid an chló</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="282"/>
        <source>Outline</source>
        <translation>Imlíne</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="303"/>
        <source>Thickness</source>
        <translation>Tiús</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="318"/>
        <source>Background</source>
        <translation>Cúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="339"/>
        <source>Padding</source>
        <translation>Stuáil</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="354"/>
        <source>Opacity</source>
        <translation>Teimhneacht</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="384"/>
        <source>Position</source>
        <translation>Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="461"/>
        <source>Size</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="520"/>
        <source>Horizontal fit</source>
        <translation>Oiriúnach cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="527"/>
        <source>Left</source>
        <translation>Ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="535"/>
        <source>Center</source>
        <translation>Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="543"/>
        <source>Right</source>
        <translation>Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="560"/>
        <source>Vertical fit</source>
        <translation>Oiriúnach ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="567"/>
        <source>Top</source>
        <translation>Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="575"/>
        <source>Middle</source>
        <comment>Text video filter</comment>
        <translation>Lár</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="583"/>
        <source>Bottom</source>
        <translation>Bun</translation>
    </message>
</context>
<context>
    <name>TextFilterVui</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterVui.qml" line="85"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Cliceáil i dronuilleog + coinnigh Shift chun tarraing</translation>
    </message>
</context>
<context>
    <name>TextProducerWidget</name>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="26"/>
        <source>Text</source>
        <translation>Téacs</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="39"/>
        <source>Type or paste the text here</source>
        <translation>Clóscríobh nó greamaigh an téacs anseo</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="48"/>
        <source>Background color...</source>
        <translation>Dath an chúlra...</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="61"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="88"/>
        <source>Simple</source>
        <translation>Simplí</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="98"/>
        <source>Rich</source>
        <translation>Saibhir</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="120"/>
        <source>Text attributes are available in the &lt;b&gt;Filters&lt;/b&gt; panel after clicking &lt;b&gt;OK&lt;/b&gt;.</source>
        <translation>Tá tréithe téacs ar fáil sa phainéal &lt;b&gt;Filters&lt;/b&gt; tar éis &lt;b&gt;OK&lt;/b&gt;a chliceáil.</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="59"/>
        <source>black</source>
        <translation>dubh</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="61"/>
        <source>transparent</source>
        <translation>trédhearcach</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="179"/>
        <location filename="../src/widgets/textproducerwidget.cpp" line="212"/>
        <source>Edit your text using the Filters panel.</source>
        <translation>Cuir do théacs in eagar ag baint úsáide as an bpainéal Scagairí.</translation>
    </message>
</context>
<context>
    <name>TextViewerDialog</name>
    <message>
        <location filename="../src/dialogs/textviewerdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>Dialóg</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="35"/>
        <source>Copy</source>
        <translation>Cóip</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="64"/>
        <source>Save Text</source>
        <translation>Sábháil Téacs</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="65"/>
        <source>Text Documents (*.txt);;All Files (*)</source>
        <translation>Doiciméid Téacs (*.txt);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="67"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;Gach Comhad (*)</translation>
    </message>
</context>
<context>
    <name>TiledItemDelegate</name>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="123"/>
        <source>Duration: %1</source>
        <translation>Fad: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="128"/>
        <source>Date: %1</source>
        <translation>Dáta: %1</translation>
    </message>
</context>
<context>
    <name>TimeSpinner</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="70"/>
        <source>Decrement</source>
        <translation>Laghdú</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="99"/>
        <source>Increment</source>
        <translation>Incrimint</translation>
    </message>
</context>
<context>
    <name>TimelineDock</name>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="83"/>
        <location filename="../src/docks/timelinedock.cpp" line="94"/>
        <source>Timeline</source>
        <translation>Amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1704"/>
        <source>This track is locked</source>
        <translation>Tá an rian seo faoi ghlas</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1709"/>
        <source>You cannot add a non-seekable source.</source>
        <translation>Ní féidir leat foinse nach féidir a lorg a chur leis.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2107"/>
        <location filename="../src/docks/timelinedock.cpp" line="2141"/>
        <source>Track %1 was not moved</source>
        <translation>Níor bogadh rian %1</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2112"/>
        <source>Can not move audio track above video track</source>
        <translation>Ní féidir rian fuaime a bhogadh os cionn rian físeáin</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2128"/>
        <source>Can not move video track below audio track</source>
        <translation>Ní féidir rian físeáin a bhogadh faoi bhun an rian fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1434"/>
        <location filename="../src/docks/timelinedock.cpp" line="2269"/>
        <source>Align To Reference Track</source>
        <translation>Ailínigh leis an Rian Tagartha</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="95"/>
        <source>Track Operations</source>
        <translation>Oibríochtaí Rian</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="107"/>
        <source>Track Height</source>
        <translation>Airde Rian</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="112"/>
        <source>Selection</source>
        <translation>Roghnú</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="125"/>
        <source>Edit</source>
        <translation>Cuir in eagar</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="142"/>
        <source>View</source>
        <translation>Amharc</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="148"/>
        <source>Marker</source>
        <translation>Marcóir</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="158"/>
        <source>Timeline Clip</source>
        <translation>Clip Amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="182"/>
        <source>Timeline Controls</source>
        <translation>Rialuithe Amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="186"/>
        <source>Timeline Menu</source>
        <translation>Roghchlár Amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="377"/>
        <source>Add Audio Track</source>
        <translation>Cuir Rian Fuaime leis</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="386"/>
        <source>Add Video Track</source>
        <translation>Cuir Rian Físeáin leis</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="395"/>
        <source>Insert Track</source>
        <translation>Ionsáigh Rian</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="404"/>
        <source>Remove Track</source>
        <translation>Bain Rian</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="415"/>
        <source>Move Track Up</source>
        <translation>Bog Rian Suas</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="426"/>
        <source>Move Track Down</source>
        <translation>Bog Rian Síos</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="437"/>
        <source>Show/Hide Selected Track</source>
        <translation>Taispeáin/Folaigh an Rian Roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="453"/>
        <source>Lock/Unlock Selected Track</source>
        <translation>Glasáil/Díghlasáil an Rian Roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="472"/>
        <source>Mute/Unmute Selected Track</source>
        <translation>Balbhaigh/Díbhalbhaigh an Rian Roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="488"/>
        <source>Blend/Unblend Selected Track</source>
        <translation>Cumaisc/Díchumasc an Rian Roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="506"/>
        <source>Make Tracks Shorter</source>
        <translation>Déan Rianta Níos Giorra</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="515"/>
        <source>Make Tracks Taller</source>
        <translation>Déan Rianta Níos airde</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="524"/>
        <source>Reset Track Height</source>
        <translation>Athshocraigh Airde an Rian</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="533"/>
        <source>Select All</source>
        <translation>Roghnaigh Uile</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="544"/>
        <source>Select All On Current Track</source>
        <translation>Roghnaigh Gach Ar Rian Reatha</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="555"/>
        <source>Select None</source>
        <translation>Roghnaigh Dada</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="567"/>
        <source>Select Next Clip</source>
        <translation>Roghnaigh An Chéad Ghearrthóg Eile</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="582"/>
        <source>Select Previous Clip</source>
        <translation>Roghnaigh Gearrthóg Roimhe Seo</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="597"/>
        <source>Select Clip Above</source>
        <translation>Roghnaigh Gearrthóg Thuas</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="618"/>
        <source>Select Clip Below</source>
        <translation>Roghnaigh Gearrthóg thíos</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="639"/>
        <source>Set Current Track Above</source>
        <translation>Socraigh Rian Reatha Thuas</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="648"/>
        <source>Set Current Track Below</source>
        <translation>Socraigh Rian Reatha Thíos</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="657"/>
        <source>Select Clip Under Playhead</source>
        <translation>Roghnaigh Gearrthóg Faoi Cheann Súgartha</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="672"/>
        <source>Cu&amp;t</source>
        <translation>Ge&amp;arr</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="693"/>
        <source>&amp;Copy</source>
        <translation>&amp;Cóip</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="722"/>
        <source>&amp;Paste</source>
        <translation>&amp;Greamaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="736"/>
        <source>Nudge Forward</source>
        <translation>Brúigh Chun Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="751"/>
        <source>Nudge Forward is not available</source>
        <translation>Níl Brúigh Chun Tosaigh ar fáil </translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="773"/>
        <source>Nudge Backward</source>
        <translation>Brúigh Siar</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="783"/>
        <source>Nudge Backward is not available</source>
        <translation>Níl Brúigh Siar ar fáil</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="805"/>
        <source>Append</source>
        <translation>Cuir leis</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="816"/>
        <source>Ripple Delete</source>
        <translation>Creathán Scrios</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="833"/>
        <source>Lift</source>
        <translation>Ardaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="851"/>
        <source>Overwrite</source>
        <translation>Forscríobh</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="864"/>
        <source>Split At Playhead</source>
        <translation>Roinn Ag an gCeann Imeartha</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="921"/>
        <source>Split All Tracks At Playhead</source>
        <translation>Roinn Gach Rian Ag an gCeann Imeartha</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="952"/>
        <source>Replace</source>
        <translation>Ionadaigh</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="971"/>
        <source>Create/Edit Marker</source>
        <translation>Cruthaigh/Cuir Marcóir in Eagar</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="984"/>
        <source>Previous Marker</source>
        <translation>Marcóir Roimhe Seo</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="998"/>
        <source>Next Marker</source>
        <translation>Marcóir Eile</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1012"/>
        <source>Delete Marker</source>
        <translation>Scrios Marcálaí</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1023"/>
        <source>Cycle Marker Color</source>
        <translation>Dath Marcóir Rothaíochta</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1039"/>
        <source>Create Marker Around Selected Clip</source>
        <translation>Cruthaigh Marcóir Timpeall Gearrthóg Roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1050"/>
        <source>Rectangle Selection</source>
        <translation>Roghnú Dronuilleog</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1061"/>
        <source>Automatically Add Tracks</source>
        <translation>Cuir Rianta leis go huathoibríoch</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1072"/>
        <source>Snap</source>
        <translation>Snap</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1086"/>
        <source>Scrub While Dragging</source>
        <translation>Scrobarnach Agus Tarraingthe</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1099"/>
        <source>Ripple</source>
        <translation>Creathán</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1113"/>
        <source>Ripple All Tracks</source>
        <translation>Creathán Gach Rian</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1127"/>
        <source>Ripple Markers</source>
        <translation>Creathán Marcóirí</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1142"/>
        <source>Toggle Ripple And All Tracks</source>
        <translation>Scoránaigh Creathán Agus Gach Amhráin</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1150"/>
        <source>Toggle Ripple, All Tracks, And Markers</source>
        <translation>Scoránaigh Creathán, Gach Rianta, Agus Marcóirí</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1159"/>
        <source>Show Audio Waveforms</source>
        <translation>Taispeáin Tonnfhoirmeacha Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1173"/>
        <source>Use Higher Performance Waveforms</source>
        <translation>Úsáid Tonnfhoirmeacha Ardfheidhmíochta</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1189"/>
        <source>Show Video Thumbnails</source>
        <translation>Taispeáin Mionsamhlacha Físeáin</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1200"/>
        <source>No</source>
        <translation>Níl</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1213"/>
        <source>Page</source>
        <translation>Leathanach</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1226"/>
        <source>Smooth</source>
        <translation>Go réidh</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1239"/>
        <source>Center the Playhead</source>
        <translation>Lár an Ceann Súgartha</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1253"/>
        <source>Scroll to Playhead on Zoom</source>
        <translation>Scrollaigh go Playhead ar Zoom</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1265"/>
        <source>Zoom Timeline Out</source>
        <translation>Súmáil Amlíne Amach</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1276"/>
        <source>Zoom Timeline In</source>
        <translation>Súmáil Amlíne Isteach</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1287"/>
        <source>Zoom Timeline To Fit</source>
        <translation>Súmáil Amlíne Le Feistiú</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1299"/>
        <source>New Generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1307"/>
        <source>Color</source>
        <translation>Dath</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1309"/>
        <source>Text</source>
        <translation>Téacs</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1313"/>
        <source>Animation</source>
        <translation>Beochan</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1317"/>
        <source>Noise</source>
        <translation>Torann</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1320"/>
        <source>Color Bars</source>
        <translation>Barraí Dath</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1324"/>
        <source>Audio Tone</source>
        <translation>Ton Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1327"/>
        <source>Count</source>
        <translation>Áireamh</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1330"/>
        <source>Blip Flash</source>
        <translation>Flash blip</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1353"/>
        <source>Properties</source>
        <translation>Airíonna</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1360"/>
        <source>Rejoin With Next Clip</source>
        <translation>Bígí linn arís leis an gCeart Ar Aghaidh</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1376"/>
        <source>Detach Audio</source>
        <translation>Dícheangail Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1404"/>
        <source>Freeze Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1454"/>
        <source>Apply Copied Filters</source>
        <translation>Cuir Scagairí Cóipeála i bhFeidhm</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1478"/>
        <source>Update Thumbnails</source>
        <translation>Nuashonraigh Mionsamhlacha</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1502"/>
        <source>Rebuild Audio Waveform</source>
        <translation>Atógáil Tonnta Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1526"/>
        <source>Ripple Trim Clip In</source>
        <translation>Ripple Bearr Clip Isteach</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1533"/>
        <source>Ripple Trim Clip Out</source>
        <translation>Ripple Bearr Clip Amach</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1540"/>
        <source>Group/Ungroup</source>
        <translation>Ripple Trim Gearrthóg Amach</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2367"/>
        <source>Append multiple to timeline</source>
        <translation>Cuir iolraí leis an amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2427"/>
        <source>Ripple delete transition</source>
        <translation>Scrios Ripple trasdul</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2476"/>
        <source>Lift transition</source>
        <translation>Ardaitheoir trasdul</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2551"/>
        <source>Cut %1 from timeline</source>
        <translation>Gearr %1 ón amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2553"/>
        <source>Remove %1 from timeline</source>
        <translation>Bain %1 den amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2576"/>
        <source>Lift %1 from timeline</source>
        <translation>Ardaigh %1 ón amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2927"/>
        <source>There is nothing in the Source player.</source>
        <translation>Níl aon rud san imreoir Foinse.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2942"/>
        <source>You cannot replace a transition.</source>
        <translation>Ní féidir leat trasdul a athsholáthar.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2972"/>
        <source>Select a clip in the timeline to create a marker around it</source>
        <translation>Roghnaigh gearrthóg san amlíne chun marcóir a chruthú timpeall air</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2993"/>
        <source>Added marker: &quot;%1&quot;.</source>
        <translation>Cuireadh marcóir leis: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3013"/>
        <source>Added marker: &quot;%1&quot;. Hold %2 and drag to create a range</source>
        <translation>Cuireadh marcóir leis: &quot;%1&quot;. Coinnigh %2 agus tarraing chun raon a chruthú</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3129"/>
        <source>Failed to open </source>
        <translation>Theip ar oscailt</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3162"/>
        <source>Dropped Files</source>
        <translation>Comhaid Tite</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3207"/>
        <source>You cannot freeze a frame of a transition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3226"/>
        <source>Freeze Frame is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3260"/>
        <source>Insert Freeze Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3264"/>
        <source>The play head is not over the selected clip.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3616"/>
        <source>Insert multiple into timeline</source>
        <translation>Cuir iolrach isteach san amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3755"/>
        <source>Overwrite multiple onto timeline</source>
        <translation>Forscríobh iolraí ar amlíne</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="904"/>
        <location filename="../src/docks/timelinedock.cpp" line="936"/>
        <source>You cannot split a transition.</source>
        <translation>Ní féidir leat trasdul a roinnt.</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/timelinedock.cpp" line="4171"/>
        <source>Replace %n timeline clips</source>
        <translation>
            <numerusform>Ionadaigh %n gearrthóg amlíne</numerusform>
            <numerusform>Ionadaigh %n gearrthóg amlíne</numerusform>
            <numerusform>Ionadaigh %n gearrthóg amlíne</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4224"/>
        <source>voiceover</source>
        <translation>guthú</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4225"/>
        <source>Opus (*.opus);;All Files (*)</source>
        <translation>Opus (*.opus);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1336"/>
        <location filename="../src/docks/timelinedock.cpp" line="4227"/>
        <location filename="../src/docks/timelinedock.cpp" line="4343"/>
        <source>Record Audio</source>
        <translation>Taifead Fuaime</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4241"/>
        <source>Record Audio: %1</source>
        <translation>Taifead Fuaime: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4308"/>
        <source>Audio Recording In Progress</source>
        <translation>Taifeadadh Fuaime ar Siúl</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4318"/>
        <source>Record Audio error: check PulseAudio settings</source>
        <translation>Earráid Taifeadta Fuaime: seiceáil socruithe PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4322"/>
        <source>Record Audio error: choose File &gt; Open Other &gt; Audio/Video Device</source>
        <translation>Taifead Earráid Fuaime: roghnaigh Comhad &gt; Oscail Eile &gt; Gléas Fuaime/Físe</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4349"/>
        <source>Saving audio recording...</source>
        <translation>Taifead Earráid Fuaime: roghnaigh Comhad &gt; Oscail Eile &gt; Gléas Fuaime/Físe</translation>
    </message>
</context>
<context>
    <name>TimelinePropertiesWidget</name>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="26"/>
        <source>Timeline</source>
        <translation>Amlíne</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="104"/>
        <source>Frame rate</source>
        <translation>Ráta fráma</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="246"/>
        <source>Edit...</source>
        <translation>Cuir in eagar...</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="73"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="114"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="179"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="186"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="237"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="39"/>
        <source>Resolution</source>
        <translation>Rún</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="227"/>
        <source>Scan mode</source>
        <translation>Modh scanadh</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="169"/>
        <source>Aspect ratio</source>
        <translation>Cóimheas gné</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="193"/>
        <source>Colorspace</source>
        <translation>Spás datha</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="39"/>
        <source>%L1 fps</source>
        <translation>%L1 fps</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="41"/>
        <source>Progressive</source>
        <translation>Forásach</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="43"/>
        <source>Interlaced</source>
        <translation>Idirfhighte</translation>
    </message>
</context>
<context>
    <name>ToneProducerWidget</name>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="26"/>
        <source>Audio Tone</source>
        <translation>Ton Fuaime</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>Minicíocht</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="51"/>
        <source> Hz</source>
        <translation> Hz</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="80"/>
        <source>Level</source>
        <translation>Leibhéal</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="90"/>
        <source> dB</source>
        <translation> dB</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.cpp" line="98"/>
        <source>Tone: %1Hz %2dB</source>
        <translation>Ton: %1Hz %2dB</translation>
    </message>
</context>
<context>
    <name>TrackHead</name>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="219"/>
        <source>Unmute</source>
        <translation>Díbhalbhaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="219"/>
        <source>Mute</source>
        <translation>Balbhaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="236"/>
        <source>Show</source>
        <translation>Taispeáin</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="236"/>
        <source>Hide</source>
        <translation>Folaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="183"/>
        <source>Unlock track</source>
        <translation>Díghlasáil rian</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="183"/>
        <source>Lock track</source>
        <translation>Glasáil rian</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="255"/>
        <source>Filters</source>
        <translation>Scagairí</translation>
    </message>
</context>
<context>
    <name>TrackPropertiesWidget</name>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="38"/>
        <source>Blend mode</source>
        <translation>Modh chumasc</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="38"/>
        <source>Track: %1</source>
        <translation>Rian: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="45"/>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="77"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="46"/>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="78"/>
        <source>Over</source>
        <translation>Thar</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="47"/>
        <source>Add</source>
        <translation>Cuir</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="48"/>
        <source>Saturate</source>
        <translation>Sáithithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="49"/>
        <source>Multiply</source>
        <translation>Méadaigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="50"/>
        <source>Screen</source>
        <translation>Scáileán</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="51"/>
        <source>Overlay</source>
        <translation>Forleagan</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="52"/>
        <source>Darken</source>
        <translation>Dorchaigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="53"/>
        <source>Dodge</source>
        <translation>Seachain</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="54"/>
        <source>Burn</source>
        <translation>Dóigh</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="55"/>
        <source>Hard Light</source>
        <translation>Solas Crua</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="56"/>
        <source>Soft Light</source>
        <translation>Solas Bog</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="57"/>
        <source>Difference</source>
        <translation>Difríocht</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="58"/>
        <source>Exclusion</source>
        <translation>Eisiamh</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="59"/>
        <source>HSL Hue</source>
        <translation>Dath Hue HSL</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="60"/>
        <source>HSL Saturation</source>
        <translation>HSL Sáithiú</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="61"/>
        <source>HSL Color</source>
        <translation>HSL Dath</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="62"/>
        <source>HSL Luminosity</source>
        <translation>HSL Loinnir</translation>
    </message>
</context>
<context>
    <name>TranscodeDialog</name>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="38"/>
        <source>good</source>
        <translation>maith</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="48"/>
        <source>better</source>
        <translation>níos fearr</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="58"/>
        <source>best</source>
        <translation>is fearr</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="94"/>
        <source>medium</source>
        <translation>meánach</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="136"/>
        <source>Do not show this anymore.</source>
        <comment>Convert to edit-friendly format dialog</comment>
        <translation>Ná taispeáin é seo a thuilleadh.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="206"/>
        <source>Change the frame rate from its source.</source>
        <translation>Athraigh an ráta fráma óna fhoinse.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="262"/>
        <location filename="../src/dialogs/transcodedialog.ui" line="266"/>
        <source>Same as original</source>
        <translation>Mar an gcéanna leis an mbunaidh</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="271"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="276"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="155"/>
        <source>This is useful when the source video is HDR (High Dynamic Range), which requires tone-mapping to the old, standard range.</source>
        <translation>Tá sé seo úsáideach nuair is HDR (Raon Ard Dinimiciúla) an físeán foinse, a éilíonn mapáil ton chuig an sean-raon caighdeánach.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="249"/>
        <source>Frame rate conversion</source>
        <translation>Comhshó ráta fráma</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="165"/>
        <source>This option converts only the trimmed portion of the source
clip plus a little instead of the entire clip. When this option is
used not all of the matching source clips are replaced, instead
only the currently selected one.</source>
        <translation>Ní athraíonn an rogha seo ach an chuid bearrtha den fhoinse
gearrthóg móide beagán in ionad an gearrthóg ar fad. Nuair a bhíonn an rogha seo
ní úsáidtear gach ceann de na gearrthóga foinse meaitseála ina ionad sin
ach an ceann atá roghnaithe faoi láthair.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="104"/>
        <source>BIG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="114"/>
        <source>&lt;span style=&quot; font-weight:700; color:#ff0000;&quot;&gt;HUGE&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="171"/>
        <source>Use sub-clip</source>
        <translation>Úsáid fo-chlip</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="219"/>
        <source>Sample rate</source>
        <translation>Ráta samplach</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="239"/>
        <source>If the source is interlaced, each interlaced field will be converted to a progressive frame resulting in double frame rate.</source>
        <translation>Má tá an fhoinse fite fuaite, déanfar gach réimse interlaced a thiontú go fráma forásach a mbeidh ráta fráma dúbailte mar thoradh air.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="242"/>
        <source>Deinterlace</source>
        <translation>Dé-inléascáil</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="178"/>
        <source>Enable this to keep the Advanced section open for the next time this dialog appears.</source>
        <translation>Cumasaigh é seo chun an rannóg Casta a choinneáil ar oscailt an chéad uair eile a thaispeánfar an dialóg seo.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="181"/>
        <source>Keep Advanced open</source>
        <translation>Coinnigh Casta ar oscailt</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="148"/>
        <source>Override the frame rate to a specific value.</source>
        <translation>Sáraigh an ráta fráma go luach sonrach.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="188"/>
        <source>Frame rate conversion method

Duplicate: Duplicate frames.
Blend: Blend frames.
Motion Compensation: Interpolate new frames using motion compensation. This method is very slow and may result in artifacts.</source>
        <translation>Modh comhshó ráta fráma

Dúblach: Frámaí dúblach.
Cumasc: Cumaisc frámaí.
Cúiteamh Tairisceana: Idirshuíomh frámaí nua ag baint úsáide as cúiteamh gluaisne. Tá an modh seo an-mhall agus d&apos;fhéadfadh artifacts a bheith mar thoradh air.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="209"/>
        <source>Override frame rate</source>
        <translation>Sáraigh ráta fráma</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="229"/>
        <source>Frames/sec</source>
        <translation>Frámaí/soic</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="158"/>
        <source>Convert to BT.709 colorspace</source>
        <translation>Tiontaigh go spás datha BT.709</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="34"/>
        <source>Convert to Edit-friendly...</source>
        <translation>Tiontaigh go Éasca le hEagar...</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="51"/>
        <source>Duplicate (fast)</source>
        <translation>Dúblach (tapa)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="52"/>
        <source>Blend</source>
        <translation>Cumasc</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="53"/>
        <source>Motion Compensation (slow)</source>
        <translation>Cúiteamh Tairisceana (mall)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="56"/>
        <source>Advanced</source>
        <translation>Ard</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="146"/>
        <source>Lossy: I-frame–only %1</source>
        <translation>Caillteanais: I-frame–amháin %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="150"/>
        <source>Intermediate: %1</source>
        <translation>Idirmheánach: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="153"/>
        <source>Lossless: %1</source>
        <translation>Gan chailliúint: %1</translation>
    </message>
</context>
<context>
    <name>Transcoder</name>
    <message>
        <location filename="../src/transcoder.cpp" line="58"/>
        <source>Sub-clip</source>
        <translation>Fo-chlip</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="58"/>
        <source>Converted</source>
        <translation>Tiontaithe</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="66"/>
        <source>MP4 (*.mp4);;All Files (*)</source>
        <translation>MP4 (*.mp4);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="70"/>
        <source>MOV (*.mov);;All Files (*)</source>
        <translation>MOV (*.mov);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="74"/>
        <source>MKV (*.mkv);;All Files (*)</source>
        <translation>MKV (*.mkv);;Gach Comhad (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="102"/>
        <location filename="../src/transcoder.cpp" line="138"/>
        <source>A job already exists for %1</source>
        <translation>Tá post le haghaidh %1 cheana féin</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="109"/>
        <location filename="../src/transcoder.cpp" line="120"/>
        <location filename="../src/transcoder.cpp" line="127"/>
        <source>Convert canceled</source>
        <translation>Tiontaigh ar ceal</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="349"/>
        <source>Convert %1</source>
        <translation>Tiontaigh % 1</translation>
    </message>
</context>
<context>
    <name>TranscribeAudioDialog</name>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="73"/>
        <source>Speech to Text</source>
        <translation>Óráid go Téacs</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="85"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="90"/>
        <source>Language</source>
        <translation>Teanga</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="116"/>
        <source>Translate to English</source>
        <translation>Aistrigh go Béarla</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="118"/>
        <source>Maximum line length</source>
        <translation>Fad líne uasta</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="128"/>
        <source>Include non-spoken sounds</source>
        <translation>Cuir fuaimeanna neamhlabhartha san áireamh</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="130"/>
        <source>Tracks with speech</source>
        <translation>Rianta le cainte</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="131"/>
        <source>Select tracks that contain speech to be transcribed.</source>
        <translation>Roghnaigh rianta a bhfuil urlabhra iontu le tras-scríobh.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="180"/>
        <source>Whisper.cpp executable</source>
        <translation>Whisper.cpp inrite</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="190"/>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="213"/>
        <source>Find Whisper.cpp</source>
        <translation>Faigh Whisper.cpp</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="203"/>
        <source>GGML Model</source>
        <translation>Múnla GGML</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="232"/>
        <source>Configuration</source>
        <translation>Cumraíocht</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="326"/>
        <source>Path to Whisper.cpp executable</source>
        <translation>Cosán go Whisper.cpp inrite</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="331"/>
        <source>Whisper.cpp executable not found</source>
        <translation>Níor aimsíodh inrite Whisper.cpp</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="337"/>
        <source>Path to GGML model</source>
        <translation>Cosán chuig samhail GGML</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="342"/>
        <source>GGML model not found</source>
        <translation>Níor aimsíodh múnla GGML</translation>
    </message>
</context>
<context>
    <name>UndoButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/UndoButton.qml" line="28"/>
        <source>Reset to default</source>
        <translation>Athshocraigh go réamhshocrú</translation>
    </message>
</context>
<context>
    <name>UnlinkedFilesDialog</name>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="14"/>
        <source>Missing Files</source>
        <translation>Comhaid ar Iarraidh</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="26"/>
        <source>There are missing files in your project. Double-click each row to locate a file.</source>
        <translation>Tá comhaid ar iarraidh i do thionscadal. Cliceáil faoi dhó ar gach sraith chun comhad a aimsiú.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="78"/>
        <source>This looks at every file in a folder to see if it matches any of the missing files.</source>
        <translation>Féachann sé seo ar gach comhad i bhfillteán féachaint an dtagann sé le haon cheann de na comhaid atá ar iarraidh.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="81"/>
        <source>Search in Folder...</source>
        <translation>Cuardaigh i bhFillteán...</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="43"/>
        <source>Missing</source>
        <translation>Ar iarraidh</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="44"/>
        <source>Replacement</source>
        <translation>Athsholáthar</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="58"/>
        <source>Open File</source>
        <translation>Oscail Comhad</translation>
    </message>
</context>
<context>
    <name>Video4LinuxWidget</name>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Foirm</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="36"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="43"/>
        <source>Set the path to the video device file</source>
        <translation>Socraigh an cosán go dtí an comhad gléas físeáin</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="46"/>
        <source>/dev/video0</source>
        <translation>/dev/video0</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="72"/>
        <source>Video4Linux</source>
        <translation>Físeán4linux</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="82"/>
        <source>fps</source>
        <translation>fps</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="102"/>
        <source>Height</source>
        <translation>Airde</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="115"/>
        <source>Frame rate</source>
        <translation>Ráta fráma</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="125"/>
        <source>Resolution</source>
        <translation>Rún</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="135"/>
        <source>Device</source>
        <translation>Gléas</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="145"/>
        <source>TV Tuner</source>
        <translation>Tiontaire Teilifíse</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="157"/>
        <source>Standard</source>
        <translation>Caighdeán</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="167"/>
        <source>Set the television standard</source>
        <translation>Socraigh an caighdeán teilifíse</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="171"/>
        <source>Automatic</source>
        <translation>Uathoibríoch</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="176"/>
        <source>NTSC</source>
        <translation>NTSC</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="181"/>
        <source>PAL</source>
        <translation>PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="186"/>
        <source>SECAM</source>
        <translation>SECAM</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="194"/>
        <source>Channel</source>
        <translation>Cainéal</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="213"/>
        <source>Audio Input</source>
        <translation>Ionchur Fuaime</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="223"/>
        <source>Width</source>
        <translation>Leithead</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="236"/>
        <source>pixels</source>
        <translation>picteilíní</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="249"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="257"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="262"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="267"/>
        <source>ALSA</source>
        <translation>ALSA</translation>
    </message>
</context>
<context>
    <name>VideoHistogramScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="103"/>
        <source>Luma</source>
        <translation>Lúma</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="108"/>
        <source>Red</source>
        <translation>Dearg</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="113"/>
        <source>Green</source>
        <translation>Glas</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="118"/>
        <source>Blue</source>
        <translation>Gorm</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="205"/>
        <source>Value: %1
IRE: %2</source>
        <translation>Luach: %1
IRE: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="207"/>
        <source>Value: %1</source>
        <translation>Luach: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="215"/>
        <source>Video Histogram</source>
        <translation>Histeagram físeán</translation>
    </message>
</context>
<context>
    <name>VideoQualityJob</name>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="39"/>
        <source>Open</source>
        <translation>Oscail</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="41"/>
        <source>Open original and encoded side-by-side in the Shotcut player</source>
        <translation>Oscail bunchóip agus ionchódaithe taobh le taobh san imreoir Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="45"/>
        <source>View Report</source>
        <translation>Féach ar an Tuarascáil</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="49"/>
        <source>Show In Files</source>
        <translation>Taispeáin I gComhaid</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="53"/>
        <source>Show In Folder</source>
        <translation>Taispeáin I bhFillteán</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="57"/>
        <source>Measure %1</source>
        <translation>Tomhais % 1</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="96"/>
        <source>Video Quality Measurement</source>
        <translation>Tomhas Cáilíochta Físeáin</translation>
    </message>
</context>
<context>
    <name>VideoRgbParadeScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="132"/>
        <source>255</source>
        <translation>255</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="136"/>
        <source>191</source>
        <translation>191</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="140"/>
        <source>127</source>
        <translation>127</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="144"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="148"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="158"/>
        <source>Red</source>
        <translation>Dearg</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="160"/>
        <source>Green</source>
        <translation>Glas</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="162"/>
        <source>Blue</source>
        <translation>Gorm</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="173"/>
        <source>Channel: %1
Pixel: %2
Value: %3</source>
        <translation>Cainéal: %1
picteilíní: %2
Luach: %3</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="175"/>
        <source>Channel: %1
Value: %2</source>
        <translation>Cainéal: %1
Luach: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="182"/>
        <source>Video RGB Parade</source>
        <translation>Físeán RGB Paráid</translation>
    </message>
</context>
<context>
    <name>VideoRgbWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="128"/>
        <source>255</source>
        <translation>255</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="132"/>
        <source>191</source>
        <translation>191</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="136"/>
        <source>127</source>
        <translation>127</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="140"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="144"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="159"/>
        <source>Pixel: %1
Value: %2</source>
        <translation>picteilíní: %1
Luach: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="161"/>
        <source>Value: %1</source>
        <translation>Luach: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="168"/>
        <source>Video RGB Waveform</source>
        <translation>Físeán RGB Tonnform</translation>
    </message>
</context>
<context>
    <name>VideoVectorScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videovectorscopewidget.cpp" line="53"/>
        <source>Video Vector</source>
        <translation>Físeán veicteoir</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videovectorscopewidget.cpp" line="243"/>
        <source>U: %1
V: %2</source>
        <translation>U: %1
V: %2</translation>
    </message>
</context>
<context>
    <name>VideoWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="120"/>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="124"/>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="125"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="144"/>
        <source>Pixel: %1
IRE: %2</source>
        <translation>Picteilíní: %1
IRE: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="146"/>
        <source>IRE: %1</source>
        <translation>IRE: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="153"/>
        <source>Video Waveform</source>
        <translation>Cruth Tonn Físeáin</translation>
    </message>
</context>
<context>
    <name>VideoZoomScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="123"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="125"/>
        <source>y</source>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="128"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="130"/>
        <source>G</source>
        <translation>G</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="132"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="135"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="137"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="139"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="157"/>
        <source>Pick a pixel from the source player</source>
        <translation>Roghnaigh picteilín ón imreoir foinse</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="164"/>
        <source>Lock/Unlock the selected pixel</source>
        <translation>Glasáil/Díghlasáil an picteilín roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="273"/>
        <source>%1x</source>
        <translation>%1x</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="321"/>
        <source>Video Zoom</source>
        <translation>Súmáil Físeáin</translation>
    </message>
</context>
<context>
    <name>WhisperJob</name>
    <message>
        <location filename="../src/jobs/whisperjob.cpp" line="94"/>
        <source>SRT</source>
        <translation>SRT</translation>
    </message>
</context>
<context>
    <name>audioloudnessscope</name>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="186"/>
        <source>Momentary Loudness.</source>
        <translation>Aoibhinnacht sealadach.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="229"/>
        <source>Short-term Loudness.</source>
        <translation>Aoibhinnacht gearrthéarmach.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="272"/>
        <source>Integrated Loudness.</source>
        <translation>Aoibhinnacht chomhtháite.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="315"/>
        <source>Loudness Range.</source>
        <translation>Raon Aoibhinnachta.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="358"/>
        <source>Peak.</source>
        <translation>Buaic.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="401"/>
        <source>True Peak.</source>
        <translation>Fíor Bhuaic.</translation>
    </message>
</context>
<context>
    <name>filterview</name>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="173"/>
        <source>Select a clip</source>
        <translation>Roghnaigh gearrthóg</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="193"/>
        <source>Add a filter</source>
        <translation>Cuir scagaire leis</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="210"/>
        <source>Remove selected filter</source>
        <translation>Bain an scagaire roghnaithe</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="232"/>
        <source>Copy filters</source>
        <translation>Cóipeáil na scagairí</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="247"/>
        <source>Paste filters</source>
        <translation>Greamaigh scagairí</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="262"/>
        <source>Save a filter set</source>
        <translation>Sábháil sraith scagaire</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="284"/>
        <source>Move filter up</source>
        <translation>Bog an scagaire suas</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="299"/>
        <source>Move filter down</source>
        <translation>Bog an scagaire síos</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="326"/>
        <source>Deselect the filter</source>
        <translation>Díroghnaigh an scagaire</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Fill the screen with the Shotcut window.</source>
        <translation>Líon an scáileán leis an fhuinneog Shotcut.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="158"/>
        <source>Hide upgrade prompt and menu item.</source>
        <translation>Folaigh leid uasghrádaithe agus mír roghchláir.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="162"/>
        <source>Run Glaxnimate instead of Shotcut.</source>
        <translation>Rith Glaxnimate in ionad Shotcut.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <source>Use GPU processing.</source>
        <translation>Úsáid GPU a phróiseáil.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="169"/>
        <source>Clear Recent on Exit</source>
        <translation>Glan Le Déanaí ar Scoir</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="174"/>
        <source>The directory for app configuration and data.</source>
        <translation>An t-eolaire do chumraíocht agus sonraí aip.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="175"/>
        <source>directory</source>
        <translation>eolaire</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="179"/>
        <source>The scale factor for a high-DPI screen</source>
        <translation>An fachtóir scála le haghaidh scáileán ard-DPI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="181"/>
        <source>number</source>
        <translation>uimhir</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="185"/>
        <source>A semicolon-separated list of scale factors for each screen</source>
        <translation>Tá liosta leathstad-scartha fachtóirí scála do gach scáileán....</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="188"/>
        <source>list</source>
        <translation>liosta</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="192"/>
        <source>How to handle a fractional display scale: %1</source>
        <translation>Conas scála taispeána codánach a láimhseáil: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="194"/>
        <location filename="../src/main.cpp" line="202"/>
        <location filename="../src/main.cpp" line="210"/>
        <source>string</source>
        <translation>teaghrán</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="200"/>
        <location filename="../src/main.cpp" line="208"/>
        <source>Which operating system audio API to use: %1</source>
        <translation>Cé acu API fuaime an chórais oibriúcháin a úsáidfear: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="216"/>
        <source>Zero or more files or folders to open</source>
        <translation>Comhaid nó fillteáin nialais nó níos mó le hoscailt</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="460"/>
        <source>Loading plugins...</source>
        <translation>Breiseáin á lódáil...</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="437"/>
        <source>Expiring cache...</source>
        <translation>Taisce ag dul in éag...</translation>
    </message>
</context>
<context>
    <name>meta</name>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="22"/>
        <source>Alpha Channel: Adjust</source>
        <translation>Cainéal Alfa: Coigeartaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="23"/>
        <source>transparency shave shrink grow soft feather</source>
        <comment>search keywords for the Alpha Channel: Adjust video filter</comment>
        <translation>trédhearcacht shave Laghdaigh fás cleite bog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="22"/>
        <source>Alpha Channel: View</source>
        <translation>Cainéal Alfa: Amharc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="23"/>
        <source>transparency</source>
        <comment>search keywords for the Alpha Channel: View video filter</comment>
        <translation>trédhearcacht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="7"/>
        <source>Balance</source>
        <translation>Comhionannas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="8"/>
        <source>pan channel mixer</source>
        <comment>search keywords for the Balance audio filter</comment>
        <translation>meascóir cainéal pan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="19"/>
        <location filename="../src/qml/filters/reframe/meta.qml" line="22"/>
        <source>Position</source>
        <translation>Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="7"/>
        <source>Band Pass</source>
        <translation>Pas Banna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the Band Pass audio filter</comment>
        <translation>minicíocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="18"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="18"/>
        <source>Center Frequency</source>
        <translation>Minicíocht Lár</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="26"/>
        <source>Bandwidth</source>
        <translation>bandaleithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/meta.qml" line="8"/>
        <source>Bass &amp; Treble</source>
        <translation>Dord &amp; Treble</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="7"/>
        <source>Copy Channel</source>
        <translation>Cóipeáil Cainéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="8"/>
        <source>duplicate</source>
        <comment>search keywords for the Copy Channel audio filter</comment>
        <translation>dúbailt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="7"/>
        <source>Compressor</source>
        <translation>Comhbhrúiteoir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="8"/>
        <source>loudness dynamics range</source>
        <comment>search keywords for the Compressor audio filter</comment>
        <translation>raon dinimic treise</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="7"/>
        <source>Delay</source>
        <translation>Moill</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="8"/>
        <source>time echo</source>
        <comment>search keywords for the Delay audio filter</comment>
        <translation>eachtra ama</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="7"/>
        <source>Expander</source>
        <translation>Leathnaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="8"/>
        <source>dynamics range</source>
        <comment>search keywords for the Expander audio filter</comment>
        <translation>raon dinimic</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="8"/>
        <source>Fade In Audio</source>
        <translation>Fuaim ag dul i léig isteach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Fade In audio filter</comment>
        <translation>Airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="8"/>
        <source>Fade Out Audio</source>
        <translation>Fuaim ag dul i léig amach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Fade Out audio filter</comment>
        <translation>Airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="7"/>
        <source>Gain / Volume</source>
        <translation>Gnóthachan / Toirt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Gain/Volume audio filter</comment>
        <translation>Airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="20"/>
        <location filename="../src/qml/filters/brightness/meta.qml" line="20"/>
        <location filename="../src/qml/filters/contrast/meta.qml" line="21"/>
        <location filename="../src/qml/filters/dither/meta.qml" line="19"/>
        <location filename="../src/qml/filters/opacity/meta.qml" line="20"/>
        <location filename="../src/qml/filters/threshold/meta.qml" line="18"/>
        <source>Level</source>
        <translation>Leibhéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="7"/>
        <source>High Pass</source>
        <translation>Pas Ard</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the High Pass audio filter</comment>
        <translation>minicíocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="18"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="18"/>
        <source>Cutoff</source>
        <translation>Gearradh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="34"/>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="34"/>
        <source>Rolloff rate</source>
        <translation>Ráta rolladh as</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="41"/>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="33"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="33"/>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="25"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="41"/>
        <source>Wetness</source>
        <translation>Fliuchas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="7"/>
        <source>Limiter</source>
        <translation>Teorantóir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="8"/>
        <source>dynamics range loudness</source>
        <comment>search keywords for the Limiter audio filter</comment>
        <translation>Raon dinimice na tonnchumhachta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="7"/>
        <source>Low Pass</source>
        <translation>Pas Íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the Low Pass audio filter</comment>
        <translation>minicíocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="7"/>
        <source>Downmix</source>
        <translation>Meascán síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="8"/>
        <source>stereo mixdown channel</source>
        <comment>search keywords for the Downmix audio filter</comment>
        <translation>cainéal meascáin steirió</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="8"/>
        <source>Mute</source>
        <translation>Balbhaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="9"/>
        <source>silent silence volume</source>
        <comment>search keywords for the Mute audio filter</comment>
        <translation>Toirmeasc ciúin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="7"/>
        <source>Normalize: One Pass</source>
        <translation>Normalaigh: Pas amháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="8"/>
        <source>volume loudness gain dynamics</source>
        <comment>search keywords for the Normalize: One Pass audio filter</comment>
        <translation>dinimic gnóthachain treise toirte</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="7"/>
        <source>Normalize: Two Pass</source>
        <translation>Normalaigh: Dhá Phas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="9"/>
        <source>volume loudness gain dynamics</source>
        <comment>search keywords for the Normalize: Two Pass audio filter</comment>
        <translation>dinimic gnóthachain treise toirte</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="7"/>
        <source>Notch</source>
        <translation>eang</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="8"/>
        <source>frequency pass</source>
        <comment>search keywords for the Notch audio filter</comment>
        <translation>pas minicíochta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="7"/>
        <source>Pan</source>
        <translation>Pan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="8"/>
        <source>stereo balance channel mixer</source>
        <comment>search keywords for the Pan audio filter</comment>
        <translation>meascthóir cainéal cothromaíocht steirió</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="7"/>
        <source>Reverb</source>
        <translation>Aisfhuaimniú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="9"/>
        <source>delay time echo</source>
        <comment>search keywords for the Reverb audio filter</comment>
        <translation>macalla am moille</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="18"/>
        <source>Room size</source>
        <translation>Méid an tseomra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="26"/>
        <source>Reverb time</source>
        <translation>Am Aisfhuaimniú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="34"/>
        <source>Damping</source>
        <translation>Laghdú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="42"/>
        <source>Input bandwidth</source>
        <translation>Bandaleithead ionchuir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="50"/>
        <source>Dry signal level</source>
        <translation>Leibhéal comhartha tirim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="58"/>
        <source>Early reflection level</source>
        <translation>Leibhéal machnaimh go luath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="66"/>
        <source>Tail level</source>
        <translation>Leibhéal eireaball</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="7"/>
        <source>Swap Channels</source>
        <translation>Cainéil Babhtáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="9"/>
        <source>switch stereo</source>
        <comment>search keywords for the Swap Channels audio filter</comment>
        <translation>Lasc steirió</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="23"/>
        <source>Chroma Key: Simple</source>
        <translation>Eochair Chrómata: Simplí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="24"/>
        <source>green blue screen</source>
        <comment>search keywords for the Chroma Key: Simple video filter</comment>
        <translation>scáileán gorm glas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="6"/>
        <source>Brightness</source>
        <translation>Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="8"/>
        <source>lightness value exposure</source>
        <comment>search keywords for the Brightness video filter</comment>
        <translation>nochtadh luach Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="6"/>
        <source>Color Grading</source>
        <translation>Grádú Datha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="7"/>
        <source>correct shadows lift midtones gamma highlights gain hue lightness brightness value</source>
        <comment>search keywords for the Color Grading video filter</comment>
        <translation>scáileanna cearta ardaitheoir midtones gáma buaicphointí fháil luach gile lí Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="17"/>
        <source>Shadows (Lift)</source>
        <translation>Scáthanna (Ardaitheoir)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="22"/>
        <source>Midtones (Gamma)</source>
        <translation>Toin Mheáin (Gáma)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="27"/>
        <source>Highlights (Gain)</source>
        <translation>Buaicphointí (Gain)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="6"/>
        <source>Contrast</source>
        <translation>Codarsnacht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="7"/>
        <source>variation value</source>
        <comment>search keywords for the Contrast video filter</comment>
        <translation>luach éagsúlachta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="6"/>
        <source>Old Film: Dust</source>
        <translation>Seanscannán: Dusta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="7"/>
        <source>noise dirt hair fiber</source>
        <comment>search keywords for the Old Film: Dust video filter</comment>
        <translation>snáithín gruaige salachar torainn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="7"/>
        <source>Text: Simple</source>
        <translation>Téacs: Simplí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="8"/>
        <source>type font timecode timestamp date filename</source>
        <comment>search keywords for the Text: Simple video filter</comment>
        <translation>clóscríobh cód ama an stampa ama ainm comhaid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="25"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="40"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="26"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="25"/>
        <source>Font color</source>
        <translation>Dath cló</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="31"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="46"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="32"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="31"/>
        <source>Outline</source>
        <translation>Imlíne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="37"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="52"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="38"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="37"/>
        <source>Background</source>
        <translation>Cúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="20"/>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="20"/>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="36"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="35"/>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="20"/>
        <location filename="../src/qml/filters/richtext/meta.qml" line="21"/>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="20"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="21"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="20"/>
        <source>Position / Size</source>
        <translation>Seasamh / Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="7"/>
        <source>Fade In Video</source>
        <translation>Físeán ag dul i léig isteach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="8"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="8"/>
        <source>brightness lightness opacity alpha</source>
        <comment>search keywords for the Fade In video filter</comment>
        <translation>gile solas teimhneacht alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="7"/>
        <source>Fade Out Video</source>
        <translation>Físeán ag dul i léig amach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="8"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="8"/>
        <source>brightness lightness opacity alpha</source>
        <comment>search keywords for the Fade Out video filter</comment>
        <translation>gile solas teimhneacht alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="6"/>
        <source>Old Film: Grain</source>
        <translation>Seanscannán: Gráinne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="7"/>
        <source>dots particles noise dirt</source>
        <comment>search keywords for the Old Film: Grain video filter</comment>
        <translation>poncanna cáithníní torann salachar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="22"/>
        <source>Hue/Lightness/Saturation</source>
        <translation>Lí/Gile/Sáithiú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="23"/>
        <source>color value desaturate grayscale</source>
        <comment>search keywords for the Hue/Lightness/Saturation video filter</comment>
        <translation>luach datha liathscála neamhsháithithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="34"/>
        <source>Hue</source>
        <translation>Lí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="41"/>
        <source>Lightness</source>
        <translation>Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="48"/>
        <source>Saturation</source>
        <translation>Sáithiú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="6"/>
        <source>Invert Colors</source>
        <translation>Inbhéartaigh Dathanna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="7"/>
        <source>reverse opposite negative</source>
        <comment>search keywords for the Invert Colors video filter</comment>
        <translation>droim ar ais os coinne diúltach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="22"/>
        <source>Key Spill: Advanced</source>
        <translation>Doirteadh Eochair: Casta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="23"/>
        <source>chroma alpha clean suppress</source>
        <comment>search keywords for the Key Spill: Advanced video filter</comment>
        <translation>chroma alfa glan faoi chois</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="22"/>
        <source>Lens Correction</source>
        <translation>Ceartú Lionsa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="23"/>
        <source>deform lens distort wide angle panoramic hemispherical fisheye</source>
        <comment>search keywords for the Lens Correction video filter</comment>
        <translation>lionsa deformáil a shaobhadh uillinn leathan lánléargais leathsféarúil fisheye</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="34"/>
        <source>X Center</source>
        <translation>X Lárionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="41"/>
        <source>Y Center</source>
        <translation>Y Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="48"/>
        <source>Correction at Center</source>
        <translation>Ceartú san Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="55"/>
        <source>Correction at Edges</source>
        <translation>Ceartúchán ag Imeall</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="6"/>
        <source>Old Film: Scratches</source>
        <translation>Ceartúchán ag Imeall</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="7"/>
        <source>noise projector lines defect</source>
        <comment>search keywords for the Old Film: Scratches video filter</comment>
        <translation>locht línte teilgeoir torainn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/meta.qml" line="22"/>
        <source>LUT (3D)</source>
        <translation>LUT (3D)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/meta.qml" line="23"/>
        <source>lookup table color</source>
        <comment>search keywords for the LUT (3D) video filter</comment>
        <translation>tábla dathanna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/meta.qml" line="6"/>
        <source>Mask</source>
        <translation>Masc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="7"/>
        <source>360: Rectilinear to Equirectangular</source>
        <translation>360: Dronuilleogach go Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="8"/>
        <source>spherical projection</source>
        <comment>search keywords for the 360: Rectilinear to Equirectangular video filter</comment>
        <translation>teilgean sféarúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="20"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="17"/>
        <location filename="../src/qml/filters/nosync/meta.qml" line="26"/>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="41"/>
        <source>Horizontal</source>
        <translation>Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="27"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="24"/>
        <location filename="../src/qml/filters/nosync/meta.qml" line="19"/>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="34"/>
        <source>Vertical</source>
        <translation>Ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="7"/>
        <source>Mid-Side Matrix</source>
        <translation>Maitrís Lár-Taobh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="8"/>
        <source>middle stereo microphone</source>
        <comment>search keywords for the Mid-Side Matrix audio filter</comment>
        <translation>micreafón steirió lár</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="18"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="31"/>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="34"/>
        <source>Width</source>
        <translation>Leithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/meta.qml" line="38"/>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="41"/>
        <source>Height</source>
        <translation>Airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="6"/>
        <source>Mirror</source>
        <translation>Scáthán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="7"/>
        <source>horizontal flip transpose flop</source>
        <comment>search keywords for the Mirror video filter</comment>
        <translation>flop cothrománach trasuí smeach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="22"/>
        <source>Mosaic</source>
        <translation>Mósáic</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="23"/>
        <source>pixelize pixelate</source>
        <comment>search keywords for the Mosaic video filter</comment>
        <translation>picteilíni picteilíni</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="6"/>
        <source>Diffusion</source>
        <translation>Idirleathadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="7"/>
        <source>blur smooth clean beauty</source>
        <comment>search keywords for the Diffusion video filter</comment>
        <translation>doiléir réidh ghlan áilleacht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="6"/>
        <source>Old Film: Projector</source>
        <translation>Seanscannán: Teilgeoir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="7"/>
        <source>glitch flashing brightness vertical slip</source>
        <comment>search keywords for the Old Film: Projector video filter</comment>
        <translation>fadhb fleascadh gile sleamhnán ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="43"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="58"/>
        <location filename="../src/qml/filters/opacity/meta.qml" line="7"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="44"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="43"/>
        <source>Opacity</source>
        <translation>Teimhneacht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta.qml" line="8"/>
        <source>alpha transparent translucent</source>
        <comment>search keywords for the Opacity video filter</comment>
        <translation>alfa trédhearcach tréshoilseach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="7"/>
        <source>Rotate and Scale</source>
        <translation>Rothlaigh agus Scála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="7"/>
        <source>matte stencil alpha rectangle ellipse circle triangle diamond</source>
        <comment>search keywords for the Mask: Simple Shape video filter</comment>
        <translation>Neamhlonrach stionsal alfa dronuilleog éilips ciorcal triantán Diamond</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="20"/>
        <source>Size &amp; Position</source>
        <translation>Méid &amp; Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="26"/>
        <location filename="../src/qml/filters/rotate/meta.qml" line="18"/>
        <source>Rotation</source>
        <translation>Rothlú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="25"/>
        <source>Scale</source>
        <translation>Scála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="33"/>
        <source>X offset</source>
        <translation>X fhritháireamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="37"/>
        <source>Y offset</source>
        <translation>Y fritháireamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="22"/>
        <source>Chroma Key: Advanced</source>
        <translation>Chroma Key: Casta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="23"/>
        <source>green blue screen</source>
        <comment>search keywords for the Chroma Key: Advanced video filter</comment>
        <translation>scáileán gorm glas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="6"/>
        <source>Sepia Tone</source>
        <translation>Ton Sepia</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="7"/>
        <source>color old photograph print</source>
        <comment>search keywords for the Sepia Tone video filter</comment>
        <translation>dath sean grianghraf priontáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/meta.qml" line="6"/>
        <source>Sketch</source>
        <translation>Sceitse</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/meta.qml" line="7"/>
        <source>drawing painting cartoon</source>
        <comment>search keywords for the Sketch video filter</comment>
        <translation>líníocht péintéireacht cartún</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="23"/>
        <source>Key Spill: Simple</source>
        <translation>Doirteadh Eochair: Simplí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="24"/>
        <source>chroma alpha clean suppress</source>
        <comment>search keywords for the Key Spill: Simple video filter</comment>
        <translation>chroma alfa glan faoi chois</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="6"/>
        <source>Stabilize</source>
        <translation>Cobhsaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="7"/>
        <source>smooth deshake</source>
        <comment>search keywords for the Stabilize video filter</comment>
        <translation>mín de-chroith</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="6"/>
        <source>Old Film: %1</source>
        <translation>Sean Scannán: %1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="7"/>
        <source>projector movie</source>
        <comment>search keywords for the Old Film: Technocolor video filter</comment>
        <translation>scannán teilgeoir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/unpremultiply/meta.qml" line="22"/>
        <source>Unpremultiply Alpha</source>
        <translation>Alfa a dhíghníomhachtú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/unpremultiply/meta.qml" line="23"/>
        <source>disassociate associated straight</source>
        <comment>search keywords for the Unpremultiply Alpha video filter</comment>
        <translation>díghníomhachtú comhoiriúnaithe díreach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="6"/>
        <source>Wave</source>
        <translation>Tonn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="7"/>
        <source>distort deform frequency water warp bend</source>
        <comment>search keywords for the Wave video filter</comment>
        <translation>cuir as a chúrsa a shaobhadh minicíocht uisce stuaigh lúb</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="7"/>
        <source>Crop: Circle</source>
        <translation>Gearradh: Ciorcal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="8"/>
        <source>trim remove oval ellipse</source>
        <comment>search keywords for the Crop: Circle video filter</comment>
        <translation>bearr bain ubhchruth éilips</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="26"/>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="18"/>
        <source>Color</source>
        <translation>Dath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="6"/>
        <source>Halftone</source>
        <translation>Leath-thonach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="7"/>
        <source>360: Hemispherical to Equirectangular</source>
        <translation>360: Leathsféarúil go Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="9"/>
        <source>spherical projection dual fisheye</source>
        <comment>search keywords for the 360: Hemispherical to Equirectangular video filter</comment>
        <translation>sféarúil teilgean déach súil iasc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="48"/>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="19"/>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="24"/>
        <location filename="../src/qml/filters/halftone/meta.qml" line="19"/>
        <source>Radius</source>
        <translation>Raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="55"/>
        <source>Front X</source>
        <translation>X tosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="62"/>
        <source>Front Y</source>
        <translation>Y tosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="69"/>
        <source>Front Up</source>
        <translation>Tosaigh Suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="76"/>
        <source>Back X</source>
        <translation>Ar ais X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="83"/>
        <source>Back Y</source>
        <translation>Ar ais Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="90"/>
        <source>Back Up</source>
        <translation>Ar Ais Suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="97"/>
        <source>Nadir Radius</source>
        <translation>Raon Nadir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="104"/>
        <source>Nadir Start</source>
        <translation>Tosaigh Nadir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="7"/>
        <source>noise dots newsprint</source>
        <comment>search keywords for the Halftone video filter</comment>
        <translation>torainn poncanna nuachtpháipéar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="26"/>
        <source>Cyan</source>
        <translation>Cian</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="33"/>
        <source>Magenta</source>
        <translation>Maigeanta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="40"/>
        <source>Yellow</source>
        <translation>Buí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="7"/>
        <source>Spot Remover</source>
        <translation>Spota Glantóir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="8"/>
        <source>delogo dirt clean watermark</source>
        <comment>search keywords for the Spot Remover video filter</comment>
        <translation>delógó salachar glan comhartha uisce</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/meta.qml" line="7"/>
        <source>Timer</source>
        <translation>Amadóir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/meta.qml" line="8"/>
        <source>text seconds timestamp</source>
        <comment>search keywords for the Timer video filter</comment>
        <translation>téacs soicindí stampa ama</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="6"/>
        <source>Levels</source>
        <comment>Levels video filter</comment>
        <translation>Leibhéil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="7"/>
        <source>gamma value black white color</source>
        <comment>search keywords for the Levels video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="18"/>
        <source>Input Black</source>
        <translation>Ionchur Dubh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="25"/>
        <source>Input White</source>
        <translation>Ionchur Bán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="32"/>
        <source>Gamma</source>
        <translation>Gáma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="6"/>
        <source>Mask: Simple Shape</source>
        <translation>Masc: Cruth Simplí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_apply/meta.qml" line="6"/>
        <source>Mask: Apply</source>
        <translation>Masc: Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_apply/meta.qml" line="7"/>
        <source>matte stencil alpha confine composite bounce</source>
        <comment>search keywords for the Mask: Apply video filter</comment>
        <translation>neamhlonrach stionsal alfa coinnigh ilchodach preab</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="6"/>
        <source>Mask: From File</source>
        <translation>Masc: Ó Comhad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="7"/>
        <source>matte stencil alpha luma wipe custom</source>
        <comment>search keywords for the Mask: From File video filter</comment>
        <translation>neamhlonrach stionsal alfa luma glan saincheaptha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="7"/>
        <source>Noise Gate</source>
        <translation>Geata Torainn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="8"/>
        <source>hum hiss distortion clean</source>
        <comment>search keywords for the Noise Gate audio filter</comment>
        <translation>hum hiss saobhadh glan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="18"/>
        <source>Key Filter: Low Frequency</source>
        <translation>Eochair Scagaire: Minicíocht Íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="25"/>
        <source>Key Filter: High Frequency</source>
        <translation>Eochair Scagaire: Minicíocht Ard</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="32"/>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="20"/>
        <location filename="../src/qml/filters/threshold/meta.qml" line="6"/>
        <source>Threshold</source>
        <translation>Táirseach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="39"/>
        <source>Attack</source>
        <translation>Ionsaí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="46"/>
        <source>Hold</source>
        <translation>Coinnigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="53"/>
        <source>Decay</source>
        <translation>Lobhadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="60"/>
        <source>Range</source>
        <translation>Raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/meta.qml" line="7"/>
        <source>Audio Waveform Visualization</source>
        <translation>Amhairc Fuaimthonnta Fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/meta.qml" line="8"/>
        <source>music visualizer reactive</source>
        <comment>search keywords for the Audio Waveform Visualization video filter</comment>
        <translation>Amhairc Cheoil Imoibríocha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="22"/>
        <source>Chroma Hold</source>
        <translation>Chroma Coinnigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="23"/>
        <source>color hue select choose pick</source>
        <comment>search keywords for the Chroma Hold video filter</comment>
        <translation>dath hue roghnaigh roghnú pioc </translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="34"/>
        <source>Distance</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="6"/>
        <source>Grid</source>
        <translation>Greille</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="7"/>
        <source>repeat</source>
        <comment>search keywords for the Grid video filter</comment>
        <translation>déan arís</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="18"/>
        <source>Rows</source>
        <translation>sraitheanna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="25"/>
        <source>Columns</source>
        <translation>Colúin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="22"/>
        <source>Distort</source>
        <translation>Saobhadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="23"/>
        <source>deform wiggle wave</source>
        <comment>search keywords for the Distort video filter</comment>
        <translation>bréimhse luaisc tonn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="34"/>
        <source>Amplitude</source>
        <translation>Aimplitiúid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="41"/>
        <location filename="../src/qml/filters/glitch/meta.qml" line="34"/>
        <source>Frequency</source>
        <translation>Minicíocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="48"/>
        <source>Velocity</source>
        <translation>Treoluas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="22"/>
        <source>Glitch</source>
        <translation>Fabht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="23"/>
        <source>defect broken distort</source>
        <comment>search keywords for the Glitch video filter</comment>
        <translation>saobhadh briste locht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="41"/>
        <source>Block height</source>
        <translation>Bloc airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="48"/>
        <source>Shift intensity</source>
        <translation>Déine gluais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="55"/>
        <source>Color intensity</source>
        <translation>Dath déine</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="22"/>
        <source>RGB Shift</source>
        <translation>RGB Gluais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="23"/>
        <source>glitch chroma analog split</source>
        <comment>search keywords for the RGB Shift video filter</comment>
        <translation>fabht cróma analóg scoilt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="22"/>
        <source>Blur: Exponential</source>
        <translation>Doiléirigh: Easpónantúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Exponential video filter</comment>
        <translation>déan bog doiléir folaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="7"/>
        <source>360: Equirectangular to Stereographic</source>
        <translation>360: Comhionann go Steiréagrafach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="8"/>
        <source>spherical projection tiny small planet</source>
        <comment>search keywords for the 360: Equirectangular to Stereographic video filter</comment>
        <translation>teilgean sféarúil pláinéad beag bídeach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="49"/>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="35"/>
        <location filename="../src/qml/filters/blur_gaussian/meta.qml" line="34"/>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="35"/>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="35"/>
        <source>Amount</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta.qml" line="22"/>
        <source>Blur: Gaussian</source>
        <translation>Doiléirigh: Gaussach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="22"/>
        <source>Blur: Low Pass</source>
        <translation>Doiléirigh: Pas Íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Low Pass video filter</comment>
        <translation>déan bog doiléir folaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="6"/>
        <source>Crop: Source</source>
        <translation>Gearradh: Foinse</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="7"/>
        <source>trim remove edges</source>
        <comment>search keywords for the Crop: Source video filter</comment>
        <translation>bearr bain imill</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta.qml" line="6"/>
        <source>Flip</source>
        <translation>Smeach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta.qml" line="7"/>
        <source>vertical flop transpose rotate</source>
        <comment>search keywords for the Flip video filter</comment>
        <translation>ingearach claon trasuí rothlaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="22"/>
        <source>Reduce Noise: HQDN3D</source>
        <translation>Laghdú Torainn: HQDN3D</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="23"/>
        <source>denoise artifact dirt smooth</source>
        <comment>search keywords for the Reduce Noise: HQDN3D video filter</comment>
        <translation>díthorann déantán salachar mín</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="34"/>
        <source>Spatial</source>
        <translation>Spásúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="41"/>
        <source>Temporal</source>
        <translation>Teamparálta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_fast/meta.qml" line="22"/>
        <source>Noise: Fast</source>
        <translation>Torann: Go tapa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_fast/meta.qml" line="23"/>
        <source>dirt grunge</source>
        <comment>search keywords for the Noise: Fast video filter</comment>
        <translation>grunge salachar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="22"/>
        <source>Noise: Keyframes</source>
        <translation>Torann: Keyframes</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="23"/>
        <source>dirt grunge</source>
        <comment>search keywords for the Noise: Keyframes video filter</comment>
        <translation>grunge salachar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="22"/>
        <source>Reduce Noise: Smart Blur</source>
        <translation>Laghdaigh Torann: Doiléirigh Chliste</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="23"/>
        <source>denoise artifact clean</source>
        <comment>search keywords for the Reduce Noise: Smart Blur video filter</comment>
        <translation>de-torann déantán glan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="7"/>
        <source>Crop: Rectangle</source>
        <translation>Gearradh: Dronuilleog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="8"/>
        <source>trim remove square</source>
        <comment>search keywords for the Crop: Rectangle video filter</comment>
        <translation>bearr cearnóg a bhaint</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="25"/>
        <source>Corner radius</source>
        <translation>Cúinne raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="32"/>
        <source>Padding color</source>
        <translation>Dath stuála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/meta.qml" line="6"/>
        <source>Blend Mode</source>
        <translation>Mód Cumaisc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/meta.qml" line="7"/>
        <source>blending composite porter duff</source>
        <comment>search keywords for the Blend Mode video filter</comment>
        <translation>cumasc ilchodach póirtéir duff</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/meta.qml" line="6"/>
        <source>Dither</source>
        <translation>Díodánaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/meta.qml" line="7"/>
        <source>noise dots</source>
        <comment>search keywords for the Dither video filter</comment>
        <translation>poncanna torainn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="22"/>
        <source>Elastic Scale</source>
        <translation>Scála Leaisteacha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="23"/>
        <source>stretch nonlinear</source>
        <comment>search keywords for the Elastic Scale video filter</comment>
        <translation>stráice neamhlíne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="35"/>
        <source>Center</source>
        <translation>Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="42"/>
        <source>Linear width</source>
        <translation>Leithead líneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="49"/>
        <source>Linear scale factor</source>
        <translation>Fachtóir scála líneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="56"/>
        <source>Non-Linear scale factor</source>
        <translation>Fachtóir scála neamh-líneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="6"/>
        <source>Posterize</source>
        <translation>Postearú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="7"/>
        <source>reduce colors banding cartoon</source>
        <comment>search keywords for the Posterize video filter</comment>
        <translation>laghdaigh na dathanna bandáil cartún</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="19"/>
        <source>Levels</source>
        <comment>Posterize filter</comment>
        <translation>Leibhéil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nervous/meta.qml" line="6"/>
        <source>Nervous</source>
        <translation>Neirbhíseach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nervous/meta.qml" line="7"/>
        <source>random shake twitch glitch</source>
        <comment>search keywords for the Nervous video filter</comment>
        <translation>Randamach Crith Púc Fabht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nosync/meta.qml" line="6"/>
        <source>No Sync</source>
        <translation>Gan Sioncronú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nosync/meta.qml" line="7"/>
        <source>horizontal vertical synchronization slip analog</source>
        <comment>search keywords for the No Sync video filter</comment>
        <translation>analóg duillín sioncrónaithe ingearach cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/trails/meta.qml" line="6"/>
        <source>Trails</source>
        <translation>Rianta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/trails/meta.qml" line="7"/>
        <source>temporal mix psychedelic motion blur</source>
        <comment>search keywords for the Trails video filter</comment>
        <translation>meascán ama doiléirigh tairiscint sícideileach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="22"/>
        <source>Vertigo</source>
        <translation>Veirtige </translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="23"/>
        <source>temporal mix dizzy psychedelic</source>
        <comment>search keywords for the Vertigo video filter</comment>
        <translation>meascán ama dizzy sícideileach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="35"/>
        <source>Speed</source>
        <translation>Luas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="41"/>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="42"/>
        <source>Zoom</source>
        <translation>Súmáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="6"/>
        <source>Choppy</source>
        <translation>Snagach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="7"/>
        <source>fps framerate</source>
        <comment>search keywords for the Choppy video filter</comment>
        <translation>Fráma fps</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="19"/>
        <source>Repeat</source>
        <translation>Déan arís</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/meta.qml" line="7"/>
        <source>Gradient</source>
        <translation>Grádán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/meta.qml" line="8"/>
        <source>graduated color spectrum</source>
        <comment>search keywords for the Gradient video filter</comment>
        <translation>speictream datha céimnithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/scanlines/meta.qml" line="6"/>
        <source>Scan Lines</source>
        <translation>Scanadh Línte</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/scanlines/meta.qml" line="7"/>
        <source>analog horizontal television</source>
        <comment>search keywords for the Scan Lines video filter</comment>
        <translation>teilifís cothrománach analógach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="7"/>
        <source>360: Equirectangular Mask</source>
        <translation>360: Maisc Eicireictangúlach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="9"/>
        <source>spherical matte stencil</source>
        <comment>search keywords for the 360: Equirectangular Mask video filter</comment>
        <translation>stionsal Neamhlonrach sféarúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="20"/>
        <source>Horizontal Start</source>
        <translation>Tús Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="27"/>
        <source>Horizontal End</source>
        <translation>Deireadh Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="34"/>
        <source>Vertical Start</source>
        <translation>Ingearach Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="41"/>
        <source>Vertical End</source>
        <translation>Ingearach Críoch</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="7"/>
        <source>360: Equirectangular to Rectilinear</source>
        <translation>360: Eicireictangúlach go Rectilineach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="9"/>
        <source>spherical projection</source>
        <comment>search keywords for the 360: Equirectangular to Rectilinear video filter</comment>
        <translation>teilgean sféarúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="7"/>
        <source>Ambisonic Decoder</source>
        <translation>Díchódóir Ambisonic</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="9"/>
        <source>spatial surround binaural</source>
        <comment>search keywords for the Ambisonic Decoder audio filter</comment>
        <translation>spásúil timpeall binaural</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="20"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="21"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="21"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="20"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="21"/>
        <source>Yaw</source>
        <translation>Luascáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="27"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="28"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="28"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="27"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="28"/>
        <source>Pitch</source>
        <comment>rotation around the side-to-side axis (roll, pitch, yaw)</comment>
        <translation>Claonadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="34"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="35"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="35"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="34"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="35"/>
        <source>Roll</source>
        <translation>Rolla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="42"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="42"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="41"/>
        <source>FOV</source>
        <comment>field of view</comment>
        <translation>FOV</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="49"/>
        <location filename="../src/qml/filters/fisheye/meta.qml" line="22"/>
        <source>Fisheye</source>
        <translation>Súil Iasc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="22"/>
        <source>Corner Pin</source>
        <translation>Biorán Cúinne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="23"/>
        <source>stretch distort pinch twist deform</source>
        <comment>search keywords for the Corner Pin video filter</comment>
        <translation>stráice saobhadh pinse cas míchum</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="35"/>
        <source>Corners</source>
        <translation>Cúinní</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="40"/>
        <source>Stretch X</source>
        <translation>Sín X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="47"/>
        <source>Stretch Y</source>
        <translation>Sín Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="54"/>
        <source>Feathering</source>
        <translation>Cleitíú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/meta.qml" line="7"/>
        <source>360: Stabilize</source>
        <translation>360: Cobhsaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/meta.qml" line="8"/>
        <source>spherical smooth deshake</source>
        <comment>search keywords for the 360: Stabilize video filter</comment>
        <translation>sféarúil mín díchroitheadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="7"/>
        <source>360: Transform</source>
        <translation>360: Trasfhoirmigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="9"/>
        <source>spherical yaw pitch roll</source>
        <comment>search keywords for the 360: Transform video filter</comment>
        <translation>sféarúil luascáil claonadh rolla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/meta.qml" line="23"/>
        <source>Reduce Noise: Wavelet</source>
        <translation>Laghdú Torainn: Tonnán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/meta.qml" line="24"/>
        <source>vague denoise artifact dirt</source>
        <comment>search keywords for the Reduce Noise: Wavelet video filter</comment>
        <translation> doiléir de-torann déantán salachar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="7"/>
        <source>Text: Rich</source>
        <translation>Téacs: Saibhir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="8"/>
        <source>type font format overlay</source>
        <comment>search keywords for the Text: Rich video filter</comment>
        <translation>cineál cló formáid forleagan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="26"/>
        <source>Background color</source>
        <translation>Dath an chúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="7"/>
        <source>Blur: Pad</source>
        <translation>Doiléirigh: Pad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="8"/>
        <source>pillar echo fill</source>
        <comment>search keywords for the Blur: Pad video filter</comment>
        <translation>piléar macalla líonadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_invert/meta.qml" line="7"/>
        <source>Invert</source>
        <translation>Inbhéartaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_invert/meta.qml" line="8"/>
        <source>phase</source>
        <comment>search keywords for the Invert audio filter</comment>
        <translation>céim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/meta.qml" line="22"/>
        <source>Reduce Noise: Quantization</source>
        <translation>Laghdaigh Torann: Cainníochtú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/meta.qml" line="23"/>
        <source>denoise artifact postprocess compress</source>
        <comment>search keywords for the Reduce Noise: Quantization video filter</comment>
        <translation>de-torann déantán iarphróiseas comhbhrú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="7"/>
        <source>Time Remap</source>
        <translation>Athléarscáil Ama</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="8"/>
        <source>temporal speed ramp reverse fast slow motion</source>
        <comment>search keywords for the Time: Remap filter</comment>
        <translation>sealadach rampa droim ar ais tapa mall ghluaisne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="21"/>
        <source>Time</source>
        <translation>Am</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/meta.qml" line="23"/>
        <source>Deband</source>
        <translation>Díbhandaáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/meta.qml" line="24"/>
        <source>mean average median contour</source>
        <comment>search keywords for the Deband video filter</comment>
        <translation>meán meánach airmheánach cruth imlíne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="22"/>
        <source>GPS Text</source>
        <translation>Téacs GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="23"/>
        <source>gpx</source>
        <comment>search keywords for the GPS Text video filter</comment>
        <translation>gpx</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reflect/meta.qml" line="6"/>
        <source>Reflect</source>
        <translation>Machnamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reflect/meta.qml" line="7"/>
        <source>mirror repeat</source>
        <comment>search keywords for the Reflect video filter</comment>
        <translation>scáthán athrá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_chromakey/meta.qml" line="22"/>
        <source>Mask: Chroma Key</source>
        <translation>Masc: Eochair Chroma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_chromakey/meta.qml" line="23"/>
        <source>matte stencil alpha color</source>
        <comment>search keywords for the Mask: Chroma Key video filter</comment>
        <translation>neamhlonrach stionsal alfa dath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="7"/>
        <source>Equalizer: 15-Band</source>
        <translation>Cothromóir: 15-Banna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: 15-Band audio filter</comment>
        <translation>minicíocht ton</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="19"/>
        <source>Equalizer</source>
        <translation>Cothromóir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="7"/>
        <source>Equalizer: Parametric</source>
        <translation>Cothromóir: Paraiméadrach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: Parametric audio filter</comment>
        <translation>minicíocht ton</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/meta.qml" line="7"/>
        <source>Audio Level Visualization</source>
        <translation>Amharcléiriú Leibhéal Fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/meta.qml" line="8"/>
        <source>music visualizer reactive</source>
        <comment>search keywords for the Audio Level Visualization video filter</comment>
        <translation>Amhairc Cheoil Imoibríocha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="7"/>
        <source>Equalizer: 3-Band (Bass &amp; Treble)</source>
        <translation>Cothromóir: 3-bhanna (Dord &amp; Treble)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: 3-Band audio filter</comment>
        <translation>minicíocht ton</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="7"/>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="19"/>
        <source>Pitch</source>
        <comment>audio pitch or tone</comment>
        <translation>Claonadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="9"/>
        <source>frequency tone</source>
        <comment>search keywords for the Pitch audio filter</comment>
        <translation>ton minicíochta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/meta.qml" line="7"/>
        <source>Stereo Enhancer</source>
        <translation>Feabhsaitheoir Steirió</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/meta.qml" line="9"/>
        <source>channel spatial delay</source>
        <comment>search keywords for the Stereo Enhancer audio filter</comment>
        <translation>moill spásúil cainéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/meta.qml" line="6"/>
        <source>Mask: Draw</source>
        <translation>Masc: Tarraing</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/meta.qml" line="7"/>
        <source>rotoscope matte stencil alpha</source>
        <comment>search keywords for the Mask: Draw video filter</comment>
        <translation>rotoscope neamhlonrach stionsal alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/meta.qml" line="23"/>
        <source>deform lens distort wide angle panoramic hemispherical</source>
        <comment>search keywords for the Fisheye video filter</comment>
        <translation>claon lionsa saobh uillinn leathan panaiméarach leathsféarúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="22"/>
        <source>GPS Graphic</source>
        <translation>Grafaicí GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="23"/>
        <source>gpx sticker decal gauge map graph speedometer</source>
        <comment>search keywords for the GPS Graphic video filter</comment>
        <translation>gpx greamán greamán maisiúil tomhas léarscáil graf luasmhéadar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/threshold/meta.qml" line="7"/>
        <source>black white luma</source>
        <comment>search keywords for the Threshold video filter</comment>
        <translation>luma dubh bán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/meta.qml" line="6"/>
        <source>Motion Tracker</source>
        <translation>Lorgaire Gluaisne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/meta.qml" line="8"/>
        <source>tracking</source>
        <comment>search keywords for the Motion Tracker video filter</comment>
        <translation>rianú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/meta.qml" line="7"/>
        <source>Track Auto Fade Audio</source>
        <translation>Rian Uath Céimnigh Fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/meta.qml" line="8"/>
        <source>click splice fade</source>
        <comment>search keywords for the Auto Fade audio filter</comment>
        <translation>cliceáil spladhsáil céimnigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/meta.qml" line="7"/>
        <source>Track Seam</source>
        <translation>Séama Rian</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/meta.qml" line="8"/>
        <source>click splice seam</source>
        <comment>search keywords for the Seam audio filter</comment>
        <translation>cliceáil spladhsáil séama</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/meta.qml" line="6"/>
        <source>Declick Audio</source>
        <translation>Decliceáil Fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/meta.qml" line="8"/>
        <source>declick crackle pop</source>
        <comment>search keywords for the Declick audio filter</comment>
        <translation>decliceáil cnagarnach pop</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/meta.qml" line="7"/>
        <source>Track Auto Fade Video</source>
        <translation>Rian Uath Céimnithe Físeán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/meta.qml" line="8"/>
        <source>splice fade dip</source>
        <comment>search keywords for the Track Auto Fade Video filter</comment>
        <translation>spladhsáil céimniú tum</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="7"/>
        <source>Ambisonic Encoder</source>
        <translation>Ionchódóra Ambisonic</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="9"/>
        <source>spatial surround panner</source>
        <comment>search keywords for the Ambisonic Encoder audio filter</comment>
        <translation>pannéar timpeallacht spáisúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="20"/>
        <source>Azimuth</source>
        <translation>Asamat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="27"/>
        <source>Elevation</source>
        <translation>Ingearchló</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="6"/>
        <source>Drop Shadow</source>
        <translation>Buail Scáth</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="7"/>
        <source></source>
        <comment>search keywords for the Drop Shadow video filter</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="31"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="38"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="22"/>
        <source>Vibrance</source>
        <translation>Beocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="23"/>
        <source>color intensity saturation vibe</source>
        <comment>search keywords for the Vibrance video filter</comment>
        <translation>dath déine sáithiú mothú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="34"/>
        <source>Intensity</source>
        <translation>Déine</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="41"/>
        <source>Red</source>
        <translation>Dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="48"/>
        <source>Green</source>
        <translation>Glas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="55"/>
        <source>Blue</source>
        <translation>Gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="7"/>
        <source>Subtitle Burn In</source>
        <translation>Fotheideal Dóigh Isteach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="8"/>
        <source>subtitle overlay burn</source>
        <comment>search keywords for the Subtitle Burn In video filter</comment>
        <translation>fotheideal forleagan dóigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/meta.qml" line="7"/>
        <source>Reframe</source>
        <translation>Athfhráma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/meta.qml" line="8"/>
        <source>crop trim remove square vertical portrait</source>
        <comment>search keywords for the Reframe video filter</comment>
        <translation>gearrtha bearr bain cearnóg ingearach portráid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/meta.qml" line="7"/>
        <source>Gradient Map</source>
        <translation>Léarscáil grádán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/meta.qml" line="8"/>
        <source>color mapping intensity</source>
        <comment>search keywords for the Gradient Map video filter</comment>
        <translation>dath mapáil déine</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="6"/>
        <source>HSL Primaries</source>
        <translation>Príomhthóil HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="8"/>
        <source>hue saturation lightness color</source>
        <comment>search keywords for the HSL Primaries video filter</comment>
        <translation>dath tón sáithiú soiléiriú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="18"/>
        <source>Overlap</source>
        <translation>Forluí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="25"/>
        <source>Red Hue</source>
        <translation>Lí Dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="32"/>
        <source>Red Saturation</source>
        <translation>Sáithiú Dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="39"/>
        <source>Red Lightness</source>
        <translation>Gile Dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="46"/>
        <source>Yellow Hue</source>
        <translation>Lí Buí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="53"/>
        <source>Yellow Saturation</source>
        <translation>Sáithiú Buí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="60"/>
        <source>Yellow Lightness</source>
        <translation>Gile Buí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="67"/>
        <source>Green Hue</source>
        <translation>Lí Glas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="74"/>
        <source>Green Saturation</source>
        <translation>Sáithiú Glas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="81"/>
        <source>Green Lightness</source>
        <translation>Gile Glas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="88"/>
        <source>Cyan Hue</source>
        <translation>Cian Lí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="95"/>
        <source>Cyan Saturation</source>
        <translation>Sáithiú Cian</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="102"/>
        <source>Cyan Lightness</source>
        <translation>Gile Cian</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="109"/>
        <source>Blue Hue</source>
        <translation>Lí Gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="116"/>
        <source>Blue Saturation</source>
        <translation>Sáithiú Gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="123"/>
        <source>Blue Lightness</source>
        <translation>Gile Gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="130"/>
        <source>Magenta Hue</source>
        <translation>Magenta Hue</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="137"/>
        <source>Magenta Saturation</source>
        <translation>Sáithiú Mageanta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="144"/>
        <source>Magenta Lightness</source>
        <translation>Gile Mageanta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="6"/>
        <source>HSL Range</source>
        <translation>Raon HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="8"/>
        <source>hue saturation lightness color primaries</source>
        <comment>search keywords for the HSL Range video filter</comment>
        <translation>dath tón sáithiú soiléiriú príomhthóil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="18"/>
        <source>Blend</source>
        <translation>Cumasc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="25"/>
        <source>Hue Shift</source>
        <translation>Lí Athrú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="32"/>
        <source>Saturation Scale</source>
        <translation>Scála Sáithiúcháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="39"/>
        <source>Lightness Scale</source>
        <translation>Scála Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="46"/>
        <source>Hue Center</source>
        <translation>Lárionad Lí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="53"/>
        <source>Hue Range</source>
        <translation>Raon Lí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="7"/>
        <source>360: Cap Top &amp; Bottom</source>
        <translation>360: Cap Barr &amp; Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="9"/>
        <source>spherical fill blur zenith nadir</source>
        <comment>search keywords for the 360: Cap Top &amp; Bottom video filter</comment>
        <translation>líonadh sféarúil doiléirigh buaic nadir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="38"/>
        <source>topStart</source>
        <translation>barrTosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="45"/>
        <source>topEnd</source>
        <translation>barrDeireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="52"/>
        <source>topBlendIn</source>
        <translation>barrCumaiscI</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="59"/>
        <source>topBlendOut</source>
        <translation>barrCumaiscAmach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="66"/>
        <source>topFadeIn</source>
        <translation>barrCéimnitheI</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="73"/>
        <source>topBlurWidthStart</source>
        <translation>barrDoiléirighLeitheadTosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="80"/>
        <source>topBlurWidthEnd</source>
        <translation>barrDoiléirighLeitheadDeireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="87"/>
        <source>topBlurHeightStart</source>
        <translation>barrDoiléirighAirdeTosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="94"/>
        <source>topBlurHeightEnd</source>
        <translation>barrDoiléirighAirdeDeireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="102"/>
        <source>bottomStart</source>
        <translation>bunTosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="109"/>
        <source>bottomEnd</source>
        <translation>bunDeireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="116"/>
        <source>bottomBlendIn</source>
        <translation>bunCumascI</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="123"/>
        <source>bottomBlendOut</source>
        <translation>bunCumascAmach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="130"/>
        <source>bottomFadeIn</source>
        <translation>bunCéimnitheI</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="137"/>
        <source>bottomBlurWidthStart</source>
        <translation>bunDoiléirighLeitheadTosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="144"/>
        <source>bottomBlurWidthEnd</source>
        <translation>bunDoiléirighLeitheadDeireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="151"/>
        <source>bottomBlurHeightStart</source>
        <translation>bunDoiléirighAirdeTosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="158"/>
        <source>bottomBlurHeightEnd</source>
        <translation>bunDoiléirighAirdeDeireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="7"/>
        <source>360: Equirectangular Wrap</source>
        <translation>360: Timfhilleadh Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="9"/>
        <source>spherical stretch</source>
        <comment>search keywords for the 360: Equirectangular Wrap video filter</comment>
        <translation>stráice sféarúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="18"/>
        <source>hfov0</source>
        <translation>hfov0</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="25"/>
        <source>hfov1</source>
        <translation>hfov1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="32"/>
        <source>vfov0</source>
        <translation>vfov0</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="39"/>
        <source>vfov1</source>
        <translation>vfov1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="46"/>
        <source>blurStart</source>
        <translation>doiléirighTosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="53"/>
        <source>blurEnd</source>
        <translation>doiléirighDeireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/meta.qml" line="7"/>
        <source>360: Zenith Correction</source>
        <translation>360: Ceartú Zenith</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/meta.qml" line="8"/>
        <source>spherical level</source>
        <comment>search keywords for the 360: Zenith correction filter</comment>
        <translation>leibhéal sféarúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/meta.qml" line="6"/>
        <source>Clarity</source>
        <translation>Soiléire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/meta.qml" line="7"/>
        <source>histogram equalization constrast detail color distribution</source>
        <comment>search keywords for the Clarity video filter</comment>
        <translation>histeagram cothromú codarsnacht sonraí dáileadh dath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="6"/>
        <source>Alpha Strobe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="7"/>
        <source>strobe alpha</source>
        <comment>search keywords for the Strobe video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="17"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_affine</name>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="7"/>
        <source>Size, Position &amp; Rotate</source>
        <translation>Méid, Seasamh agus Rothlaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="8"/>
        <source>transform zoom rotation distort fill move</source>
        <comment>search keywords for the Size, Position &amp; Rotate video filter</comment>
        <translation>athrú súmáil rothlú saobhadh líonadh bogadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="21"/>
        <source>Size &amp; Position</source>
        <translation>Méid &amp; Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="26"/>
        <source>Rotation</source>
        <translation>Rothlú</translation>
    </message>
</context>
<context>
    <name>meta_av</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="22"/>
        <source>Blur: Gaussian</source>
        <translation>Doiléirigh: Gaussach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Box video filter</comment>
        <translation>déan bog doiléir folaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="35"/>
        <source>Amount</source>
        <translation>Méid</translation>
    </message>
</context>
<context>
    <name>meta_box_blur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="6"/>
        <source>Blur: Box</source>
        <translation>Doiléirigh: Bosca</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="7"/>
        <source>soften obscure hide directional</source>
        <comment>search keywords for the Blur: Box video filter</comment>
        <translation>bogann doiléir folaigh treo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="18"/>
        <source>Width</source>
        <translation>Leithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="25"/>
        <source>Height</source>
        <translation>Airde</translation>
    </message>
</context>
<context>
    <name>meta_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="6"/>
        <source>Blur: Box</source>
        <translation>Doiléirigh: Bosca</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="17"/>
        <source>Width</source>
        <translation>Leithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="24"/>
        <source>Height</source>
        <translation>Airde</translation>
    </message>
</context>
<context>
    <name>meta_dance</name>
    <message>
        <location filename="../src/qml/filters/dance/meta_dance.qml" line="7"/>
        <source>Audio Dance Visualization</source>
        <translation>Fuaime Rince Amharcléiriú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/meta_dance.qml" line="8"/>
        <source>music visualizer reactive transform move size position rotate rotation</source>
        <comment>search keywords for the Audio Dance Visualization video filter</comment>
        <translation>ceol amharcléirigh imoibríoch athrú bogadh méid suíomh rothlú uainíocht</translation>
    </message>
</context>
<context>
    <name>meta_forward</name>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="8"/>
        <source>Speed: Forward Only</source>
        <translation>Luas: Ar Aghaidh Amháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="9"/>
        <source>temporal speed ramp fast slow motion</source>
        <comment>search keywords for the Speed filter</comment>
        <translation>rampa luas ama mall tapa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="23"/>
        <source>Speed</source>
        <translation>Luas</translation>
    </message>
</context>
<context>
    <name>meta_forward_reverse</name>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="8"/>
        <source>Speed: Forward &amp; Reverse</source>
        <translation>Luas: Ar Aghaidh &amp; Droim ar ais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="9"/>
        <source>temporal speed ramp fast slow motion reverse</source>
        <comment>search keywords for the Speed filter</comment>
        <translation>rampa luas ama mall tapa droim ar ais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="24"/>
        <source>Speed</source>
        <translation>Luas</translation>
    </message>
</context>
<context>
    <name>meta_frei0r</name>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="6"/>
        <source>Glow</source>
        <translation>Lonradh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="7"/>
        <source>shine blur</source>
        <comment>search keywords for the Glow video filter</comment>
        <translation>soilsigh doiléir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="19"/>
        <source>Blur</source>
        <translation>Doiléirigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="6"/>
        <source>Saturation</source>
        <translation>Sáithiú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="7"/>
        <source>color desaturate grayscale chroma</source>
        <comment>search keywords for the Saturation video filter</comment>
        <translation>dath neamhsháithithe liathscála cromach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="19"/>
        <source>Level</source>
        <translation>Leibhéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="6"/>
        <source>Sharpen</source>
        <translation>Géaraigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="7"/>
        <source>sharpness focus clear crisp</source>
        <comment>search keywords for the Sharpen video filter</comment>
        <translation>géire fócas soiléir géar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="19"/>
        <source>Amount</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="26"/>
        <source>Size</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="6"/>
        <source>White Balance</source>
        <translation>Iarmhéid Bán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="7"/>
        <source>color correct light temperature neutral</source>
        <comment>search keywords for the White Balance video filter</comment>
        <translation>dath ceart teocht solais neodrach</translation>
    </message>
</context>
<context>
    <name>meta_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/meta_frei0r_coloradj.qml" line="7"/>
        <source>Color Grading</source>
        <translation>Grádú Datha</translation>
    </message>
</context>
<context>
    <name>meta_lightshow</name>
    <message>
        <location filename="../src/qml/filters/lightshow/meta_lightshow.qml" line="7"/>
        <source>Audio Light Visualization</source>
        <translation>Amharcléiriú Solas Fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/meta_lightshow.qml" line="8"/>
        <source>music visualizer reactive color</source>
        <comment>search keywords for the Audio Light Visualization video filter</comment>
        <translation>amhairc cheoil dath imoibríoch</translation>
    </message>
</context>
<context>
    <name>meta_movit</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="6"/>
        <source>Blur</source>
        <translation>Doiléirigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="7"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur video filter</comment>
        <translation>déan bog doiléir folaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="19"/>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="19"/>
        <source>Radius</source>
        <translation>Raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="6"/>
        <source>Brightness</source>
        <translation>Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="7"/>
        <source>lightness value</source>
        <comment>search keywords for the Brightness video filter</comment>
        <translation>luach Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="21"/>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="21"/>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="20"/>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="19"/>
        <source>Level</source>
        <translation>Leibhéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="6"/>
        <source>Color Grading</source>
        <translation>Grádú Datha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="7"/>
        <source>correct shadows lift midtones gamma highlights gain hue lightness brightness value</source>
        <comment>search keywords for the Color Grading video filter</comment>
        <translation>scáileanna cearta ardaitheoir midtones gáma buaicphointí fháil luach gile lí Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="17"/>
        <source>Shadows (Lift)</source>
        <translation>Scáthanna (Ardaitheoir)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="22"/>
        <source>Midtones (Gamma)</source>
        <translation>Toin Mheáin (Gáma)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="27"/>
        <source>Highlights (Gain)</source>
        <translation>Buaicphointí (Gain)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="6"/>
        <source>Contrast</source>
        <translation>Codarsnacht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="7"/>
        <source>variation value</source>
        <comment>search keywords for the Contrast video filter</comment>
        <translation>luach éagsúlachta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="6"/>
        <source>Glow</source>
        <translation>Lonradh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="7"/>
        <source>shine blur</source>
        <comment>search keywords for the Glow video filter</comment>
        <translation>soilsigh doiléir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="26"/>
        <source>Highlight blurriness</source>
        <translation>Aibhsigh doiléire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="33"/>
        <source>Highlight cutoff</source>
        <translation>Aibhsigh gearrtha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="6"/>
        <source>Mirror</source>
        <translation>Scáthán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="7"/>
        <source>horizontal flip transpose flop</source>
        <comment>search keywords for the Mirror video filter</comment>
        <translation>flop cothrománach trasuí smeach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="7"/>
        <source>Opacity</source>
        <translation>Teimhneacht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="8"/>
        <source>alpha transparent translucent</source>
        <comment>search keywords for the Opacity video filter</comment>
        <translation>alfa trédhearcach tréshoilseach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="6"/>
        <source>Saturation</source>
        <translation>Sáithiú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="7"/>
        <source>color desaturate grayscale chroma</source>
        <comment>search keywords for the Saturation video filter</comment>
        <translation>dath neamhsháithithe liathscála cromach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="6"/>
        <source>Sharpen</source>
        <translation>Géaraigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="7"/>
        <source>sharpness focus clear crisp</source>
        <comment>search keywords for the Sharpen video filter</comment>
        <translation>géire fócas soiléir géar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="19"/>
        <source>Circle radius</source>
        <translation>Ga ciorcail</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="26"/>
        <source>Gaussian radius</source>
        <translation>Raon Gaóisianach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="33"/>
        <source>Correlation</source>
        <translation>Comhchoibhneas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="40"/>
        <source>Noise</source>
        <translation>Torann</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="6"/>
        <source>Vignette</source>
        <translation>Fínéad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="7"/>
        <source>dark edges fade</source>
        <comment>search keywords for the Vignette video filter</comment>
        <translation>imill dorcha céimnithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="19"/>
        <source>Outer radius</source>
        <translation>Ga seachtrach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="26"/>
        <source>Inner radius</source>
        <translation>Ga istigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="6"/>
        <source>White Balance</source>
        <translation>Iarmhéid Bán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="7"/>
        <source>color correct light temperature neutral</source>
        <comment>search keywords for the White Balance video filter</comment>
        <translation>dath ceart teocht solais neodrach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta_movit.qml" line="6"/>
        <source>Flip</source>
        <translation>Smeach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta_movit.qml" line="7"/>
        <source>vertical flop transpose rotate</source>
        <comment>search keywords for the Flip video filter</comment>
        <translation>Ingearach Claon Trasuí Rothlaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="6"/>
        <source>Crop: Source</source>
        <translation>Gearradh: Foinse</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="7"/>
        <source>trim remove edges</source>
        <comment>search keywords for the Crop: Source video filter</comment>
        <translation>bearr bain imill</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="7"/>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="24"/>
        <source>Size &amp; Position</source>
        <translation>Méid &amp; Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="8"/>
        <source>transform zoom distort fill move</source>
        <comment>search keywords for the Size and Position filter</comment>
        <translation>athrú súmáil shaobhadh líonadh bogadh</translation>
    </message>
</context>
<context>
    <name>meta_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="6"/>
        <source>Vignette</source>
        <translation>Fínéad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="7"/>
        <source>dark edges fade</source>
        <comment>search keywords for the Vignette video filter</comment>
        <translation>imill dorcha céimnithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="18"/>
        <source>Radius</source>
        <translation>Raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="25"/>
        <source>Feathering</source>
        <translation>Cleitíú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="32"/>
        <source>Opacity</source>
        <translation>Teimhneacht</translation>
    </message>
</context>
<context>
    <name>meta_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/meta_spectrum.qml" line="7"/>
        <source>Audio Spectrum Visualization</source>
        <translation>Amharcléiriú Speictrim Fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/meta_spectrum.qml" line="8"/>
        <source>music visualizer reactive frequency</source>
        <comment>search keywords for the Audio Spectrum Visualization video filter</comment>
        <translation>amhairc cheoil imoibríoch minicíocht</translation>
    </message>
</context>
<context>
    <name>timeline</name>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="178"/>
        <source>Output</source>
        <translation>Aschur</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="208"/>
        <source>Filters</source>
        <translation>Scagairí</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="313"/>
        <source>Move %1</source>
        <translation>Bog %1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="355"/>
        <source>Can not move audio track above video track</source>
        <translation>Ní féidir rian fuaime a bhogadh os cionn rian físeáin</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="357"/>
        <source>Can not move video track below audio track</source>
        <translation>Ní féidir rian físeáin a bhogadh faoi bhun an rian fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="359"/>
        <source>Track %1 was not moved</source>
        <translation>Níor bogadh rian %1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="706"/>
        <source>Insert</source>
        <translation>Ionsáigh</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="706"/>
        <source>Overwrite</source>
        <translation>Forscríobh</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1028"/>
        <source>Do you want to insert an audio or video track?</source>
        <translation>Ar mhaith leat rian fuaime nó físe a chur isteach?</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1038"/>
        <source>Audio</source>
        <translation>Fuaime</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1046"/>
        <source>Video</source>
        <translation>Físeán</translation>
    </message>
</context>
<context>
    <name>ui</name>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="58"/>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="296"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="353"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="46"/>
        <source>Mode</source>
        <translation>Mód</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="82"/>
        <source>No Change</source>
        <translation>No Change</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="87"/>
        <source>Shave</source>
        <translation>Bearr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="92"/>
        <source>Shrink Hard</source>
        <translation>Laghdaigh go crua</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="97"/>
        <source>Shrink Soft</source>
        <translation>Laghdaigh go bog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="102"/>
        <source>Grow Hard</source>
        <translation>Fás go crua</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="107"/>
        <source>Grow Soft</source>
        <translation>Fás go bog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="112"/>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="98"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="150"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="138"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="189"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="570"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="118"/>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="158"/>
        <source>Threshold</source>
        <translation>Táirseach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="117"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="653"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="916"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="129"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="287"/>
        <source>Blur</source>
        <translation>Doiléirigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="136"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="547"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="543"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="618"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="693"/>
        <location filename="../src/qml/filters/blur_exponential/ui.qml" line="84"/>
        <location filename="../src/qml/filters/blur_lowpass/ui.qml" line="84"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="79"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="82"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="55"/>
        <location filename="../src/qml/filters/noise_fast/ui.qml" line="60"/>
        <location filename="../src/qml/filters/noise_keyframes/ui.qml" line="84"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="63"/>
        <source>Amount</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="164"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="171"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="445"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="405"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="124"/>
        <source>Invert</source>
        <translation>Inbhéartaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="50"/>
        <source>Display</source>
        <translation>Taispeáin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="66"/>
        <source>Gray Alpha</source>
        <translation>Alfa liath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="71"/>
        <source>Red &amp; Gray Alpha</source>
        <translation>Alfa Dearg &amp; Liath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="76"/>
        <source>Checkered Background</source>
        <translation>Cúlra Seiceáilte</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="81"/>
        <source>Black Background</source>
        <translation>Cúlra Dubh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="86"/>
        <source>Gray Background</source>
        <translation>Cúlra Liath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="91"/>
        <source>White Background</source>
        <translation>Cúlra Bán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="122"/>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="134"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="139"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="61"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="200"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="68"/>
        <source>Left</source>
        <translation>Ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="132"/>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="134"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="148"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="61"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="220"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="63"/>
        <source>Right</source>
        <translation>Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="254"/>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="152"/>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="54"/>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="80"/>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="99"/>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="79"/>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="174"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="68"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="49"/>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="109"/>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="111"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="109"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="56"/>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="142"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="74"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="74"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="68"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="87"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="78"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="138"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="137"/>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="75"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="72"/>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="92"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="451"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="232"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="294"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="295"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="314"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="692"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="150"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="308"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="211"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="125"/>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="50"/>
        <location filename="../src/qml/filters/blur_exponential/ui.qml" line="65"/>
        <location filename="../src/qml/filters/blur_lowpass/ui.qml" line="65"/>
        <location filename="../src/qml/filters/brightness/ui.qml" line="138"/>
        <location filename="../src/qml/filters/choppy/ui.qml" line="62"/>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="69"/>
        <location filename="../src/qml/filters/color/ui.qml" line="177"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="144"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="304"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="99"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="185"/>
        <location filename="../src/qml/filters/deband/ui.qml" line="197"/>
        <location filename="../src/qml/filters/distort/ui.qml" line="77"/>
        <location filename="../src/qml/filters/dither/ui.qml" line="67"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="81"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="47"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="157"/>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="83"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="432"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="720"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="900"/>
        <location filename="../src/qml/filters/fspp/ui.qml" line="52"/>
        <location filename="../src/qml/filters/glitch/ui.qml" line="82"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="482"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="679"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="196"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="246"/>
        <location filename="../src/qml/filters/grain/ui.qml" line="48"/>
        <location filename="../src/qml/filters/grid/ui.qml" line="137"/>
        <location filename="../src/qml/filters/halftone/ui.qml" line="82"/>
        <location filename="../src/qml/filters/histeq/ui.qml" line="50"/>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="70"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="140"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="109"/>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="75"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="96"/>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="82"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="154"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="51"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="153"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="326"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="52"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="204"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="71"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="42"/>
        <location filename="../src/qml/filters/noise_fast/ui.qml" line="47"/>
        <location filename="../src/qml/filters/noise_keyframes/ui.qml" line="65"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="71"/>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="59"/>
        <location filename="../src/qml/filters/opacity/ui.qml" line="106"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="129"/>
        <location filename="../src/qml/filters/posterize/ui.qml" line="65"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="192"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="70"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="271"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="136"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="105"/>
        <location filename="../src/qml/filters/sepia/ui.qml" line="37"/>
        <location filename="../src/qml/filters/sketch/ui.qml" line="52"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="55"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="161"/>
        <location filename="../src/qml/filters/strobe/ui.qml" line="97"/>
        <location filename="../src/qml/filters/subtitle/ui.qml" line="83"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="47"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="70"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="290"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="117"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="109"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="50"/>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="108"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="70"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="81"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="85"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="42"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="79"/>
        <location filename="../src/qml/filters/white/ui.qml" line="64"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="72"/>
        <source>The size of the window, in milliseconds, which will be processed at once.</source>
        <translation>Méid na fuinneoige, i milleasoicindí, a phróiseálfar ag an am céanna.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="101"/>
        <source>The strength of impulsive noise which is going to be removed. The lower value, the more samples will be detected as impulsive noise.</source>
        <translation>Neart an torainn ríogach atá le baint. An luach níos ísle, beidh na samplaí níos mó a bhrath mar torann ríogach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="126"/>
        <source>Burst Fusion</source>
        <translation>Comhleá pléasctha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="129"/>
        <source>Treat small bursts that are close together as one large burst. Units are percent of the window size. A higher percent will combine bursts that are farther apart.</source>
        <translation>Déan pléascanna beaga atá gar dá chéile a chóireáil mar aon pléasctha mór amháin. Tá aonaid faoin gcéad de mhéid na fuinneoige. Cuirfidh faoin gcéad níos airde le chéile pléasctha atá níos faide óna chéile.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="32"/>
        <source>Fast Fade</source>
        <translation>Céimniú tapa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="93"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="98"/>
        <source>Fade duration</source>
        <translation>Céimniú ré</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="97"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="102"/>
        <source>The duration of fade to apply at the begining and end of each clip</source>
        <translation>An fad céimnithe le cur i bhfeidhm ag tús agus deireadh gach gearrthóg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="133"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="168"/>
        <source>Fade in</source>
        <translation>Céimniú isteach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="137"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="172"/>
        <source>Status indicator showing when a fade in has occured.</source>
        <translation>Táscaire stádais a thaispeánann cathain a tháinig maolú isteach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="163"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="198"/>
        <source>Fade out</source>
        <translation>Céimniú amach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="167"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="202"/>
        <source>Status indicator showing when a fade out has occured.</source>
        <translation>Táscaire stádais a thaispeánann cathain a thit amach céimnithe.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="98"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="97"/>
        <source>Center frequency</source>
        <translation>Minicíocht ionaid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="125"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="124"/>
        <source>Bandwidth</source>
        <translation>bandaleithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="152"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="151"/>
        <source>Rolloff rate</source>
        <translation>Ráta rolladh as</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="178"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="110"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="146"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="146"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="114"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="177"/>
        <source>Dry</source>
        <translation>Tirim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="188"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="156"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="156"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="124"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="187"/>
        <source>Wet</source>
        <translation>Fliuch</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="215"/>
        <source>Bass</source>
        <translation>Dord</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="245"/>
        <source>Middle</source>
        <comment>Bass &amp; Treble audio filter</comment>
        <translation>Lár</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="275"/>
        <source>Treble</source>
        <translation>Tríble</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Front left</source>
        <translation>Tosaigh ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Front right</source>
        <translation>Tosaigh ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="117"/>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="102"/>
        <source>Center</source>
        <translation>Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Low frequency</source>
        <translation>Minicíocht íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Left surround</source>
        <translation>Timpeall ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Right surround</source>
        <translation>Timpeall ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="54"/>
        <source>Copy from</source>
        <translation>Cóipeáil ó</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="65"/>
        <source>to</source>
        <translation>chuig</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="81"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="69"/>
        <source>RMS</source>
        <translation>RMS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="85"/>
        <source>The balance between the RMS and peak envelope followers. RMS is generally better for subtle, musical compression and peak is better for heavier, fast compression and percussion.</source>
        <translation>An chothromaíocht idir an RMS agus leantóirí buaic-chlúdaigh. Tá RMS níos fearr go ginearálta le haghaidh comhbhrú subtle, ceoil agus tá buaic níos fearr le haghaidh comhbhrú níos troime, tapa agus cnaguirlisí.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="95"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="83"/>
        <source>Peak</source>
        <translation>Buaic</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="96"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="218"/>
        <source>Attack</source>
        <translation>Ionsaí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="129"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="117"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="125"/>
        <source>Release</source>
        <translation>Scaoileadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="154"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="142"/>
        <source>The point at which the compressor will start to kick in.</source>
        <translation>An pointe ag a dtosóidh an comhbhrúiteoir ag ciceáil isteach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="176"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="164"/>
        <source>Ratio</source>
        <translation>Cóimheas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="180"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="168"/>
        <source>The gain reduction ratio used when the signal level exceeds the threshold.</source>
        <translation>An cóimheas laghdaithe gnóthachain a úsáidtear nuair a sháraíonn an leibhéal comhartha an tairseach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="201"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="189"/>
        <source>Knee radius</source>
        <translation>Ga glúine</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="205"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="193"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="315"/>
        <source>The distance from the threshold where the knee curve starts.</source>
        <translation>An fad ón tairseach ina dtosaíonn an cuar glúine.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="227"/>
        <source>Makeup gain</source>
        <translation>Cúiteamh Gnóthachan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="231"/>
        <source>The gain of the makeup input signal.</source>
        <translation>An gnóthachan ar an comhartha ionchur makeup.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="270"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="166"/>
        <source>Gain Reduction</source>
        <translation>Laghdú Gnóthachan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="274"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="170"/>
        <source>Status indicator showing the gain reduction applied by the compressor.</source>
        <translation>Táscaire stádais a thaispeánann an laghdú gnóthachain a chuir an comhbhrúiteoir i bhfeidhm.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="294"/>
        <source>About dynamic range compression</source>
        <translation>Maidir le comhbhrú raon dinimiciúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="62"/>
        <source>Delay</source>
        <translation>Moill</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="66"/>
        <source>The neutral delay time is 2 seconds.
Times above 2 seconds will have reduced quality.
Times below will have increased CPU usage.</source>
        <translation>Is é an t-am moille neodrach ná 2 soicind.
Beidh cáilíocht laghdaithe ag amanna os cionn 2 shoicind.
Beidh méadú ar úsáid LAP ag na hamanna thíos.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="88"/>
        <source>Feedback</source>
        <translation>Aiseolas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="73"/>
        <source>The balance between the RMS and peak envelope followers.
RMS is generally better for subtle, musical compression.
Peak is better for heavier, fast compression and percussion.</source>
        <translation>An chothromaíocht idir an RMS agus leantóirí buaic-chlúdaigh.
Tá RMS níos fearr go ginearálta le haghaidh comhbhrú subtle, ceoil.
Tá buaic níos fearr le haghaidh comhbhrú níos troime, tapa agus cnaguirlisí.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="215"/>
        <source>Attenuation</source>
        <translation>Tanúchán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="219"/>
        <source>The gain of the output signal.
Used to correct for excessive amplitude caused by the extra dynamic range.</source>
        <translation>Gnóthachan an chomhartha aschuir.
A úsáidtear chun aimplitiúid iomarcach a cheartú de bharr an raon dinimiciúil breise.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="67"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="72"/>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="62"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="67"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="271"/>
        <source>Duration</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="166"/>
        <location filename="../src/qml/filters/brightness/ui.qml" line="162"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="167"/>
        <location filename="../src/qml/filters/opacity/ui.qml" line="131"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="89"/>
        <source>Level</source>
        <translation>Leibhéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="93"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="93"/>
        <source>Cutoff frequency</source>
        <translation>Minicíocht gearrtha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="73"/>
        <source>Input gain</source>
        <translation>Gnóthachan ionchuir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="77"/>
        <source>Gain that is applied to the input stage. Can be used to trim gain to bring it roughly under the limit or to push the signal against the limit.</source>
        <translation>Gnóthachan a chuirtear i bhfeidhm ar an gcéim ionchuir. Is féidir é a úsáid chun gnóthachan a bhearradh chun é a thabhairt thart faoin teorainn nó chun an comhartha a bhrú in aghaidh na teorann.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="99"/>
        <source>Limit</source>
        <translation>Teorainn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="103"/>
        <source>The maximum output amplitude. Peaks over this level will be attenuated as smoothly as possible to bring them as close as possible to this level.</source>
        <translation>An aimplitiúid aschuir uasta. Déanfar beanna os cionn an leibhéil seo a mhaolú chomh réidh agus is féidir chun iad a thabhairt chomh gar agus is féidir don leibhéal seo.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="129"/>
        <source>The time taken for the limiter&apos;s attenuation to return to 0 dB&apos;s.</source>
        <translation>An t-am a thógann sé ar mhaolú an tsriantóra filleadh ar 0 dB.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="100"/>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="67"/>
        <source>Target Loudness</source>
        <translation>Gile Sprioc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="104"/>
        <source>The target loudness of the output in LUFS.</source>
        <translation>Treise sprice an aschuir in LUFS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="125"/>
        <source>Analysis Window</source>
        <translation>Fuinneog Anailíse</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="129"/>
        <source>The amount of history to use to calculate the input loudness.</source>
        <translation>Méid na staire le húsáid chun treise an ionchuir a ríomh.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="150"/>
        <source>Maximum Gain</source>
        <translation>Gnóthachan Uasta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="154"/>
        <source>The maximum that the gain can be increased.</source>
        <translation>An t-uasmhéid gur féidir an gnóthachan a mhéadú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="175"/>
        <source>Minimum Gain</source>
        <translation>Gnóthachan Íosta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="179"/>
        <source>The maximum that the gain can be decreased.</source>
        <translation>An t-uasmhéid gur féidir an gnóthachan a laghdú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="200"/>
        <source>Maximum Rate</source>
        <translation>Uasráta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="204"/>
        <source>The maximum rate that the gain can be changed.</source>
        <translation>An ráta uasta ar féidir an gnóthachan a athrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="230"/>
        <source>Reset on discontinuity</source>
        <translation>Athshocrú ar neamhleanúnachas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="234"/>
        <source>Reset the measurement if a discontinuity is detected - such as seeking or clip change.</source>
        <translation>Athshocraigh an tomhas má aimsítear neamhleanúnachas - amhail athrú a lorg nó gearrthóg.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="260"/>
        <source>Input Loudness</source>
        <translation>Gnóthachan Ionchuir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="264"/>
        <source>Status indicator showing the loudness measured on the input.</source>
        <translation>Táscaire stádais a thaispeánann an treise arna thomhas ar an ionchur.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="283"/>
        <source>Output Gain</source>
        <translation>Gnóthachan Aschuir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="287"/>
        <source>Status indicator showing the gain being applied.</source>
        <translation>Táscaire stádais a thaispeánann an gnóthachan atá á chur i bhfeidhm.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="122"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="304"/>
        <source>Reset</source>
        <translation>Athshocraigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="308"/>
        <source>Status indicator showing when the loudness measurement is reset.</source>
        <translation>Táscaire stádais a thaispeánann cathain a athshocraítear an tomhas treise.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="26"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="35"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="30"/>
        <source>Analyzing...</source>
        <translation>Ag anailísiú…</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="30"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="38"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="32"/>
        <source>Analysis complete.</source>
        <translation>Anailís críochnaithe.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="33"/>
        <source>%1 LUFS</source>
        <translation>%1 LUFS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="36"/>
        <source>%1 dB</source>
        <translation>%1 dB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="38"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="34"/>
        <source>Click &quot;Analyze&quot; to use this filter.</source>
        <translation>Cliceáil &quot;Anailísigh&quot; chun an scagaire seo a úsáid.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="97"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="360"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="165"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="376"/>
        <source>Analyze</source>
        <translation>Anailísigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="128"/>
        <source>Detected Loudness:</source>
        <translation>Gile Braite:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="132"/>
        <source>The loudness calculated by the analysis.</source>
        <translation>An treise arna ríomh ag an anailís.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="143"/>
        <source>Normalization Gain:</source>
        <translation>Gnóthachan Normalaithe:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="147"/>
        <source>The gain applied to normalize to the Target Loudness.</source>
        <translation>Cuireadh an gnóthachan i bhfeidhm chun an Sprioc-Gairdeachas a normalú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="126"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="175"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="491"/>
        <source>Channel</source>
        <translation>Cainéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="83"/>
        <source>Quick fix</source>
        <translation>Ceartúchán tapa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="91"/>
        <source>Small hall</source>
        <translation>Halla beag</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="99"/>
        <source>Large hall</source>
        <translation>Halla mór</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="107"/>
        <source>Sewer</source>
        <translation>Séarach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="115"/>
        <source>Church</source>
        <translation>Eaglais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="156"/>
        <source>Room size</source>
        <translation>Méid an tseomra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="160"/>
        <source>The size of the room, in meters. Excessively large, and excessively small values will make it sound a bit unrealistic. Values of around 30 sound good.</source>
        <translation>Méid an tseomra, i méadair. Déanfaidh luachanna ró-mhóra agus róbheaga é a bheith beagán neamhréadúil. Fuaimeann luachanna thart ar 30 go maith.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="187"/>
        <source>Reverb time</source>
        <translation>Am Aisfhuaimniú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="215"/>
        <source>Damping</source>
        <translation>Laghdú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="219"/>
        <source>This controls the high frequency damping (a lowpass filter), values near 1 will make it sound very bright, values near 0 will make it sound very dark.</source>
        <translation>Rialaíonn sé seo an taiseadh ardmhinicíochta (scagaire pas íseal), fágfaidh luachanna in aice le 1 go mbeidh an fhuaim an-gheal, agus de réir luachanna gar do 0, beidh an fhuaim an-dorcha.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="247"/>
        <source>Input bandwidth</source>
        <translation>Bandaleithead ionchuir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="251"/>
        <source>This is like a damping control for the input, it has a similar effect to the damping control, but is subtly different.</source>
        <translation>Tá sé seo cosúil le rialú damping don ionchur, tá éifeacht cosúil leis an rialú taise, ach subtly difriúil.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="279"/>
        <source>Dry signal level</source>
        <translation>Leibhéal comhartha tirim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="283"/>
        <source>The amount of dry signal to be mixed with the reverberated signal.</source>
        <translation>An méid comhartha tirim a mheascadh leis an comhartha reverberated.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="311"/>
        <source>Early reflection level</source>
        <translation>Leibhéal machnaimh go luath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="342"/>
        <source>Tail level</source>
        <translation>Leibhéal eireaball</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="346"/>
        <source>The quantity of early reflections (scatter reflections directly from the source).</source>
        <translation>Cainníocht na n-athmhachnamh luath (scaip na machnaimh go díreach ón bhfoinse).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="375"/>
        <source>About reverb</source>
        <translation>Maidir Aisfhuaimniú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="55"/>
        <source>Swap</source>
        <translation>Babhtáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="66"/>
        <source>with</source>
        <translation>le</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="66"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="109"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="68"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="118"/>
        <source>Key color</source>
        <translation>Dath eochair</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="86"/>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="110"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="88"/>
        <source>Distance</source>
        <translation>Fad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="203"/>
        <source>Shadows (Lift)</source>
        <translation>Scáthanna (Ardaitheoir)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="241"/>
        <source>Midtones (Gamma)</source>
        <translation>Toin Mheáin (Gáma)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="279"/>
        <source>Highlights (Gain)</source>
        <translation>Buaicphointí (Gain)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/ui.qml" line="140"/>
        <source>Center bias</source>
        <translation>Laofacht ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="503"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="160"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="78"/>
        <source>Top</source>
        <translation>Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="566"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="829"/>
        <source>Fade</source>
        <translation>Céimnithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="601"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="864"/>
        <source>In</source>
        <translation>I</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="627"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="890"/>
        <source>Out</source>
        <translation>Amach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="662"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="925"/>
        <source>Width at start</source>
        <translation>Leithead ag tús</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="688"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="951"/>
        <source>Height at start</source>
        <translation>Airde ag tús</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="714"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="977"/>
        <source>Width at end</source>
        <translation>Leithead ag deireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="740"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="1003"/>
        <source>Height at end</source>
        <translation>Airde sa deireadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="766"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="180"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="73"/>
        <source>Bottom</source>
        <translation>Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="239"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="291"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="60"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1584"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="370"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="471"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="231"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="301"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="265"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="204"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="187"/>
        <source>Size</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="61"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="87"/>
        <source>Bottom Left</source>
        <translation>Bun ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="65"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="91"/>
        <source>Bottom Right</source>
        <translation>Bun ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="69"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>Top Left</source>
        <translation>Barr ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="73"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>Top Right</source>
        <translation>Barr Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="77"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="206"/>
        <source>Lower Third</source>
        <translation>An Tríú Íochtarach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="81"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="222"/>
        <source>Slide In From Left</source>
        <translation>Sleamhnán Isteach Ó Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="83"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="224"/>
        <source>Slide In From Right</source>
        <translation>Sleamhnán Isteach Ó Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="85"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="226"/>
        <source>Slide In From Top</source>
        <translation>Sleamhnán Isteach Ó Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="87"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="228"/>
        <source>Slide In From Bottom</source>
        <translation>Sleamhnán Isteach Ó Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="91"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="232"/>
        <source>Slide Out Left</source>
        <translation>Sleamhnán Amach ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="93"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="234"/>
        <source>Slide Out Right</source>
        <translation>Sleamhnán Amach Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="95"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="236"/>
        <source>Slide Out Top</source>
        <translation>Sleamhnán Amach Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="97"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="238"/>
        <source>Slide Out Bottom</source>
        <translation>Sleamhnán Amach Bun</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="101"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="242"/>
        <source>Slow Zoom In</source>
        <translation>Súmáil Mhall Isteach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="103"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="244"/>
        <source>Slow Zoom Out</source>
        <translation>Súmáil Mall Amach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="105"/>
        <source>Slow Pan Left</source>
        <translation>Pan Mall ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="106"/>
        <source>Slow Move Left</source>
        <translation>Bog Mall Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="108"/>
        <source>Slow Pan Right</source>
        <translation>Pan Mall Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="109"/>
        <source>Slow Move Right</source>
        <translation>Bog Mall Ar Dheas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="111"/>
        <source>Slow Pan Up</source>
        <translation>Pan Mall Suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="112"/>
        <source>Slow Move Up</source>
        <translation>Bog Suas Mall</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="114"/>
        <source>Slow Pan Down</source>
        <translation>Pan Mall síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="115"/>
        <source>Slow Move Down</source>
        <translation>Bog mall síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="117"/>
        <source>Slow Zoom In, Pan Up Left</source>
        <translation>Súmáil Mall Isteach, Pan Suas Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="118"/>
        <source>Slow Zoom In, Move Up Left</source>
        <translation>Súmáil Mall Isteach, Bog Suas ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="120"/>
        <source>Slow Zoom In, Pan Down Right</source>
        <translation>Súmáil Mall Isteach, Pan Síos Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="121"/>
        <source>Slow Zoom In, Move Down Right</source>
        <translation>Súmáil Mall Isteach, Bog Síos Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="123"/>
        <source>Slow Zoom Out, Pan Up Right</source>
        <translation>Súmáil Mall Amach, Pan Suas Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="124"/>
        <source>Slow Zoom Out, Move Up Right</source>
        <translation>Súmáil Mall Amach, Bog Suas Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="126"/>
        <source>Slow Zoom Out, Pan Down Left</source>
        <translation>Súmáil Mall Amach, Pan Síos Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="127"/>
        <source>Slow Zoom Out, Move Down Left</source>
        <translation>Súmáil Mall Amach, Bog Síos Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="187"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="709"/>
        <source>Text</source>
        <translation>Téacs</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="277"/>
        <source>Insert field</source>
        <translation>Cuir isteach réimse</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="299"/>
        <source># (Hash sign)</source>
        <translation># (Comhartha hais)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="304"/>
        <source>Timecode (drop frame)</source>
        <translation>Cód ama (fráma titim)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="309"/>
        <source>Timecode (non-drop frame)</source>
        <translation>Cód ama (fráma neamh-titim)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="339"/>
        <source>File base name</source>
        <translation>Bunainm comhaid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="314"/>
        <source>Frame #</source>
        <comment>Frame number</comment>
        <translation>Fráma #</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="319"/>
        <source>File date</source>
        <translation>Dáta an chomhaid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="324"/>
        <source>Creation date</source>
        <translation>Dáta cruthaithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="329"/>
        <source>File name and path</source>
        <translation>Ainm comhaid agus cosán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="334"/>
        <source>File name</source>
        <translation>Ainm comhaid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="130"/>
        <source>Bar</source>
        <translation>Barra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="130"/>
        <source>Segment</source>
        <translation>Deighleog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="138"/>
        <source>Graph Colors</source>
        <translation>Dathanna Graf</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="168"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1447"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="126"/>
        <source>Thickness</source>
        <translation>Tiús</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="192"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="216"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1529"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="313"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="367"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="390"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="156"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="222"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="310"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="188"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="144"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="146"/>
        <source>Position</source>
        <translation>Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="293"/>
        <source>Mirror the levels.</source>
        <translation>Scáthán na leibhéil.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="305"/>
        <source>Reverse the levels.</source>
        <translation>Athraigh na leibhéil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="314"/>
        <source>Channels</source>
        <translation>Cainéil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="337"/>
        <source>Segments</source>
        <translation>Deighleoga</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="360"/>
        <source>Segment Gap</source>
        <translation>Bearna Deighleog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="98"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="92"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="98"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="95"/>
        <source>Adjust opacity instead of fade with black</source>
        <translation>Coigeartaigh teimhneacht in ionad céimnithe le dubh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="61"/>
        <source>Noise</source>
        <translation>Torann</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="80"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="503"/>
        <source>Brightness</source>
        <translation>Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="92"/>
        <source>Hue</source>
        <translation>Lí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1428"/>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="101"/>
        <source> °</source>
        <comment>degrees</comment>
        <translation> °</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="119"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="118"/>
        <source>Lightness</source>
        <translation>Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="146"/>
        <source>Saturation</source>
        <translation>Sáithiú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="135"/>
        <source>Target color</source>
        <translation>Dath sprioc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="162"/>
        <source>Mask type</source>
        <translation>Cineál masc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Color Distance</source>
        <translation>Fad Dath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Transparency</source>
        <translation>Trédhearcacht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Edge Inwards</source>
        <translation>Imeall Isteach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Edge Outwards</source>
        <translation>Imeall Amach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="182"/>
        <source>Tolerance</source>
        <translation>Caoinfhulaingt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="128"/>
        <source>&lt;b&gt;Low Shelf&lt;/b&gt;</source>
        <translation>&lt;b&gt;Seilf Íseal&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="204"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="281"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="359"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="437"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="515"/>
        <source>Gain</source>
        <translation>Gnóthachan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="228"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="539"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="202"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="315"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="329"/>
        <source>Slope</source>
        <translation>Fána</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="251"/>
        <source>&lt;b&gt;Band 1&lt;/b&gt;</source>
        <translation>&lt;b&gt;Banna 1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="305"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="383"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="461"/>
        <source>Bandwidth</source>
        <comment>Parametric equalizer bandwidth</comment>
        <translation>bandaleithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="316"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="394"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="472"/>
        <source> octaves</source>
        <translation>ochtacha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="329"/>
        <source>&lt;b&gt;Band 2&lt;/b&gt;</source>
        <translation>&lt;b&gt;Banna 2&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="407"/>
        <source>&lt;b&gt;Band 3&lt;/b&gt;</source>
        <translation>&lt;b&gt;Banna 3&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="485"/>
        <source>&lt;b&gt;High Shelf&lt;/b&gt;</source>
        <translation>&lt;b&gt;Seilf Ard&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="222"/>
        <source>Hue gate</source>
        <translation>Geata lí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="242"/>
        <source>Saturation threshold</source>
        <translation>Tairseach sáithiúcháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="262"/>
        <source>Operation 1</source>
        <translation>Oibríocht 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="50"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="427"/>
        <source>Blend mode</source>
        <translation>Modh chumasc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="65"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="442"/>
        <source>Over</source>
        <translation>Thar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="70"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="447"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>None</source>
        <translation>Dada</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="80"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="457"/>
        <source>Saturate</source>
        <translation>Sáithithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="85"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="462"/>
        <source>Multiply</source>
        <translation>Méadaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="90"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="467"/>
        <source>Screen</source>
        <translation>Scáileán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="95"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="472"/>
        <source>Overlay</source>
        <translation>Forleagan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="100"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="477"/>
        <source>Darken</source>
        <translation>Dorchaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="105"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="482"/>
        <source>Dodge</source>
        <translation>Seachain</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="110"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="487"/>
        <source>Burn</source>
        <translation>Dóigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="115"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="492"/>
        <source>Hard Light</source>
        <translation>Solas Crua</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="120"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="497"/>
        <source>Soft Light</source>
        <translation>Solas Bog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="125"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="502"/>
        <source>Difference</source>
        <translation>Difríocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="130"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="507"/>
        <source>Exclusion</source>
        <translation>Eisiamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="135"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="512"/>
        <source>HSL Hue</source>
        <translation>Dath Hue HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="140"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="517"/>
        <source>HSL Saturation</source>
        <translation>HSL Sáithiú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="145"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="522"/>
        <source>HSL Color</source>
        <translation>HSL Dath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="150"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="527"/>
        <source>HSL Luminosity</source>
        <translation>HSL Loinnir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>De-Key</source>
        <translation>Dí-eochair</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>Desaturate</source>
        <translation>Dísháithithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>Adjust Luma</source>
        <translation>Coigeartaigh Luma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="282"/>
        <source>Amount 1</source>
        <translation>Méid 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="302"/>
        <source>Operation 2</source>
        <translation>Oibríocht 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="322"/>
        <source>Amount 2</source>
        <translation>Méid 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="346"/>
        <source>Show mask</source>
        <translation>Taispeáin masc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="359"/>
        <source>Send mask to alpha channel</source>
        <translation>Seol masc chuig cainéal alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="101"/>
        <source>X Center</source>
        <translation>X Lárionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="130"/>
        <source>Y Center</source>
        <translation>Y Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="159"/>
        <source>Correction at Center</source>
        <translation>Ceartú san Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="188"/>
        <source>Correction at Edges</source>
        <translation>Ceartúchán ag Imeall</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="87"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="64"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="265"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="90"/>
        <source>Width</source>
        <translation>Leithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/ui.qml" line="100"/>
        <source>Darkness</source>
        <translation>Dorchadas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="43"/>
        <source>No File Loaded</source>
        <translation>Níor Luchtaíodh aon Chomhad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="45"/>
        <source>No 3D LUT file loaded.
Click &quot;Open&quot; to load a file.</source>
        <translation>Níor luchtaíodh aon chomhad 3D LUT.
Cliceáil &quot;Oscail&quot; chun comhad a luchtú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="81"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="121"/>
        <source>Open...</source>
        <translation>Oscail...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="84"/>
        <source>Open 3D LUT File</source>
        <translation>Oscail Comhad LUT 3D</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="488"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="343"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="344"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="791"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="181"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="418"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="248"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="189"/>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="101"/>
        <source>Interpolation</source>
        <translation>Idirshuíomh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="305"/>
        <source>Stereo</source>
        <translation>Steirió</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="314"/>
        <source>Binaural</source>
        <translation>Binaural</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="323"/>
        <source>Quad</source>
        <translation>Ceathrairín</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="354"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="366"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="368"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="820"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="537"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="271"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="204"/>
        <source>Yaw</source>
        <translation>luascáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="400"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="410"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="412"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="864"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="612"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="315"/>
        <source>Pitch</source>
        <comment>rotation around the side-to-side axis (roll, pitch, yaw)</comment>
        <translation>Claonadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="446"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="454"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="456"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="909"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="687"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="359"/>
        <source>Roll</source>
        <translation>Rolla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="541"/>
        <source>Paste Parameters</source>
        <translation>Paraiméadair Greamaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="498"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="500"/>
        <source>FOV</source>
        <comment>field of view</comment>
        <translation>FOV</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="501"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="503"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="985"/>
        <source>Field of view</source>
        <translation>Réimse radhairc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="590"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="592"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="414"/>
        <source>Copy Parameters</source>
        <translation>Cóipeáil Paraiméadair</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="982"/>
        <source>FOV</source>
        <translation>FOV</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="545"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="450"/>
        <source>Fisheye</source>
        <translation>Súil Iasc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="403"/>
        <source>Nearest</source>
        <translation>Is gaire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <source>Trilinear</source>
        <translation>Trílíneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <source>Tetrahedral</source>
        <translation>Téadaréagánach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="173"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="348"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="202"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="349"/>
        <source>Operation</source>
        <translation>Oibríocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="336"/>
        <source>Corner 1 X</source>
        <translation>Cúinne 1 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="431"/>
        <source>Corner 2 X</source>
        <translation>Cúinne 2 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="483"/>
        <source>Corner 3 X</source>
        <translation>Cúinne 3 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="535"/>
        <source>Corner 4 X</source>
        <translation>Cúinne 4 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="587"/>
        <source>Stretch X</source>
        <translation>Sín X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="645"/>
        <source>Interpolator</source>
        <translation>Idirshuiteálaí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Nearest Neighbor</source>
        <translation>Comharsa is gaire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="557"/>
        <source>Bilinear</source>
        <translation>Délíneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Bicubic Smooth</source>
        <translation>Bicúbach Réidh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Bicubic Sharp</source>
        <translation>Bicúbach Géar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="572"/>
        <source>Spline 4x4</source>
        <translation>Splíona 4x4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="577"/>
        <source>Spline 6x6</source>
        <translation>Splíona 6x6</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="667"/>
        <source>Alpha Operation</source>
        <translation>Oibríocht Alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="226"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="533"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="369"/>
        <source>Maximum</source>
        <translation>Uasmhéid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="231"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="538"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="374"/>
        <source>Minimum</source>
        <translation>Íosmhéid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <source>Opaque</source>
        <translation>Teimhneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="221"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="528"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="364"/>
        <source>Overwrite</source>
        <translation>Forscríobh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="694"/>
        <source>Feathering</source>
        <translation>Cleitíú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="75"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="480"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="452"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="236"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="543"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="379"/>
        <source>Add</source>
        <translation>Cuir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="241"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="548"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="384"/>
        <source>Subtract</source>
        <translation>Dealaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="194"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="369"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="241"/>
        <source>Shape</source>
        <translation>Cruth</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Rectangle</source>
        <translation>Dronuilleog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Ellipse</source>
        <translation>Éilips</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Triangle</source>
        <translation>Triantán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="266"/>
        <source>Diamond</source>
        <translation>Diamant</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="273"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="362"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="204"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="164"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="215"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="120"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="116"/>
        <source>Horizontal</source>
        <translation>Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="514"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="777"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="279"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="373"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="446"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1395"/>
        <source>Start</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="540"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="803"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="323"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="417"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="404"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="483"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="557"/>
        <source>End</source>
        <translation>Críoch</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="105"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="109"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="222"/>
        <source>Type</source>
        <translation>Cineál</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="230"/>
        <source>Linear</source>
        <translation>Líneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="241"/>
        <source>Radial</source>
        <translation>Gathach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="277"/>
        <source>Colors</source>
        <translation>Dathanna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="441"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="248"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="240"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="91"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="87"/>
        <source>Vertical</source>
        <translation>Ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="290"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="119"/>
        <source>Height</source>
        <translation>Airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1413"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="315"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="530"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="158"/>
        <source>Rotation</source>
        <translation>Rothlú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="336"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="566"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="596"/>
        <source>Softness</source>
        <translation>Bog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="814"/>
        <source>Alignment</source>
        <translation>Ailíniú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="953"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="597"/>
        <source>Lens</source>
        <translation>Lionsa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="959"/>
        <source>Projection</source>
        <translation>Teilgean</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1029"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1352"/>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="63"/>
        <location filename="../src/qml/filters/halftone/ui.qml" line="104"/>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="33"/>
        <source>Radius</source>
        <translation>Raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1072"/>
        <source>Front</source>
        <translation>Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1078"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1215"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="157"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1121"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1258"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="405"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="457"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="509"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="561"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="616"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="185"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="768"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1209"/>
        <source>Back</source>
        <translation>Ar ais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1346"/>
        <source>Nadir</source>
        <translation>Nadir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="133"/>
        <source>Cyan</source>
        <translation>Cian</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="162"/>
        <source>Magenta</source>
        <translation>Maigeanta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="54"/>
        <source>Blurriness</source>
        <translation>Doiléire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="72"/>
        <source>Vertical amount</source>
        <translation>Méid ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="90"/>
        <source>Vertical frequency</source>
        <translation>Minicíocht ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="109"/>
        <source>Brightness up</source>
        <translation>Gile suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="127"/>
        <source>Brightness down</source>
        <translation>Gile síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="145"/>
        <source>Brightness frequency</source>
        <translation>Minicíocht gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="164"/>
        <source>Uneven develop up</source>
        <translation>Forbairt mhíchothrom suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="182"/>
        <source>Uneven develop down</source>
        <translation>Forbairt mhíchothrom síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="200"/>
        <source>Uneven develop duration</source>
        <translation>Míchothrom forbair fad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="326"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="549"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="169"/>
        <source> deg</source>
        <comment>degrees</comment>
        <translation>céime</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="454"/>
        <source>Add or remove fisheye effect</source>
        <translation>Cuir leis nó bain éifeacht súil iasc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="466"/>
        <source>Remove</source>
        <translation>Bain</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="501"/>
        <source>Focal ratio</source>
        <translation>Cóimheas fócasach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="506"/>
        <source>The amount of lens distortion</source>
        <translation>An méid saobhadh lionsa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="531"/>
        <source>Quality</source>
        <translation>Cáilíocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="535"/>
        <source>Resample quality</source>
        <translation>Cáilíocht athshampla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="552"/>
        <source>Nearest neighbor</source>
        <translation>Comharsa is gaire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="562"/>
        <source>Bicubic smooth</source>
        <translation>Bicúbach réidh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="567"/>
        <source>Bicubic sharp</source>
        <translation>Bicúbach géar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="582"/>
        <source>Lanczos 16x16</source>
        <translation>Lanczos 16x16</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="601"/>
        <source>Select a lens distortion pattern that best matches your camera</source>
        <translation>Roghnaigh patrún saobhadh lionsa a oireann is fearr do do cheamara</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="619"/>
        <source>Equidistant</source>
        <translation>Comhfhad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="624"/>
        <source>Orthographic</source>
        <translation>Ortagrafach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="629"/>
        <source>Equiarea</source>
        <translation>Réimse Comhionann</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="634"/>
        <source>Stereographic</source>
        <translation>Steiréagrafach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="643"/>
        <source>Non-Linear scale</source>
        <translation>Scála neamhlíneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="657"/>
        <source>The image will be stretched/squished to fix camera scaling between 4:3 and 16:9
Like used in GoPro&apos;s superview</source>
        <translation>Déanfar an íomhá a shíneadh/squiseáil chun scálú ceamara a shocrú idir 4:3 agus 16:9
Mar a úsáidtear i bhforbhreathnú GoPro</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="673"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="707"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1723"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="187"/>
        <source>Scale</source>
        <translation>Scála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="677"/>
        <source>Use negative values for up-scaled videos
Use positive values for down-scaled videos</source>
        <translation>Úsáid luachanna diúltacha le haghaidh físeáin uasscála
Úsáid luachanna dearfacha le haghaidh físeáin íosscála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="724"/>
        <source>Preset scale methods
Lock pixels at specific locations</source>
        <translation>Modhanna scála réamhshocraithe
Glasáil picteilíní ag láithreacha ar leith</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="744"/>
        <source>Scale to Fill</source>
        <translation>Scála le Líonadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="749"/>
        <source>Keep Center Scale</source>
        <translation>Coinnigh Scála Lárionaid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="754"/>
        <source>Scale to Fit</source>
        <translation>Scála le Feistiú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="759"/>
        <source>Manual Scale</source>
        <translation>Scála Lámhleabhar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="782"/>
        <source>Scale Y separately
This changes video aspect ratio</source>
        <translation>Scála Y ar leithligh
Athraíonn sé seo an cóimheas gné físeáin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="789"/>
        <source>Crop</source>
        <translation>Gearradh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="801"/>
        <source>Remove distorted edges</source>
        <translation>Bain imill shaobhtha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="820"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="962"/>
        <source>Manual</source>
        <translation>Lámhleabhar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="825"/>
        <source>User set zoom/scale
Sides of image are not fixed</source>
        <translation>Shocraigh an t-úsáideoir súmáil/scála
Níl taobhanna na híomhá socraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="852"/>
        <source>Y ratio</source>
        <translation>Cóimheas Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="857"/>
        <source>Separate Y scale</source>
        <translation>Ar leithligh Y scála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="887"/>
        <source>Aspect</source>
        <translation>Gné</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="904"/>
        <source>Preset pixel aspect ratio</source>
        <translation>Cóimheas gné picteilín réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="944"/>
        <source>Manual Aspect</source>
        <translation>Gné láimhe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="967"/>
        <source>User set pixel aspect ratios
Change top/side distortion bias</source>
        <translation>Shocraigh úsáideoirí cóimheasa gné picteilín
Athraigh an claonadh saobhadh barr/taobh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="998"/>
        <source>Cameras</source>
        <translation>Ceamaraí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1012"/>
        <source>Camera</source>
        <translation>Ceamara</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1032"/>
        <source>Record mode</source>
        <translation>Mód taifead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1053"/>
        <source>Result</source>
        <translation>Toradh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1073"/>
        <source>Apply</source>
        <translation>Cuir i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="234"/>
        <source>X offset</source>
        <translation>X fhritháireamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="272"/>
        <source>Y offset</source>
        <translation>Y fritháireamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="208"/>
        <source>Full Screen</source>
        <translation>Scáileán Iomlán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="212"/>
        <source>Scroll Down</source>
        <translation>Scrollaigh Síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="214"/>
        <source>Scroll Up</source>
        <translation>Scrollaigh Suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="216"/>
        <source>Scroll Right</source>
        <translation>Scrollaigh ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="218"/>
        <source>Scroll Left</source>
        <translation>Scrollaigh ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="305"/>
        <source>Click in the rectangle atop the video to edit the text.</source>
        <translation>Cliceáil ar an dronuilleog ar bharr an fhíse chun an téacs a chur in eagar.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="396"/>
        <source>Background size</source>
        <translation>Méid an chúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="459"/>
        <source>Text size</source>
        <translation>Méid an téacs</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="524"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="310"/>
        <source>Background color</source>
        <translation>Dath an chúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="556"/>
        <source>Overflow</source>
        <translation>Cur thar maoil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="570"/>
        <source>Automatic</source>
        <translation>Uathoibríoch</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="583"/>
        <source>Visible</source>
        <translation>Infheicthe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="595"/>
        <source>Hidden</source>
        <translation>I bhfolach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="144"/>
        <source>Color space</source>
        <translation>Dath spás</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="156"/>
        <source>Red-Green-Blue</source>
        <translation>Dearg-Glas-Gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="167"/>
        <source>Hue-Chroma-Intensity</source>
        <translation>Lí-Chroma-Déine</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="181"/>
        <source>Red delta</source>
        <translation>Deilt dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="181"/>
        <source>Hue delta</source>
        <translation>Lí deilt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Green delta</source>
        <translation>Delta glas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Chroma delta</source>
        <translation>Chroma deilt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="221"/>
        <source>Blue delta</source>
        <translation>Delta gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="221"/>
        <source>Intensity delta</source>
        <translation>Deilt déine</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="256"/>
        <source>Box</source>
        <translation>Bosca</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="261"/>
        <source>Ellipsoid</source>
        <translation>Éilipsoid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="280"/>
        <source>Edge</source>
        <translation>Imeall</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="295"/>
        <source>Hard</source>
        <comment>Chroma Key Advanced filter</comment>
        <translation>Crua</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="300"/>
        <source>Fat</source>
        <translation>Toirtiúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="305"/>
        <source>Normal</source>
        <translation>Gnáth</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="310"/>
        <source>Thin</source>
        <translation>Tanaí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="53"/>
        <source>Yellow-Blue</source>
        <translation>Buí-Gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="71"/>
        <source>Cyan-Red</source>
        <translation>Cian-dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="65"/>
        <source>Line Width</source>
        <translation>Leithead Líne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="85"/>
        <source>Line Height</source>
        <translation>Airde Líne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="105"/>
        <source>Contrast</source>
        <translation>Codarsnacht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="86"/>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="91"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="98"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1302"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1366"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="383"/>
        <location filename="../src/qml/filters/sketch/ui.qml" line="126"/>
        <source>Color</source>
        <translation>Dath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="68"/>
        <source>Blur Radius</source>
        <translation>Ga Doiléirigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="72"/>
        <source>The radius of the gaussian blur.</source>
        <translation>Ga raon an doiléire Gaussaigh.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="93"/>
        <source>Blur Strength</source>
        <translation>Doiléirigh Neart</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="97"/>
        <source>The strength of the gaussian blur.</source>
        <translation>Neart doiléire Gaussaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="122"/>
        <source>If the difference between the original pixel and the blurred pixel is less than threshold, the pixel will be replaced with the blurred pixel.</source>
        <translation>Má tá an difríocht idir an picteilín bunaidh agus an picteilín doiléir níos lú ná an tairseach, cuirfear na picteilíní doiléir in ionad na picteilíní.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="50"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="60"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="152"/>
        <source>Green</source>
        <translation>Glas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="58"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="89"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="179"/>
        <source>Blue</source>
        <translation>Gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="125"/>
        <source>Red</source>
        <translation>Dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <source>Value</source>
        <translation>Luach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="198"/>
        <source>Histogram</source>
        <translation>Histeagram</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="227"/>
        <source>Input Black</source>
        <translation>Ionchur Dubh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="251"/>
        <source>Input White</source>
        <translation>Ionchur Bán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="275"/>
        <source>Gamma</source>
        <translation>Gáma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="299"/>
        <source>Output Black</source>
        <translation>Aschur Dubh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="320"/>
        <source>Output White</source>
        <translation>Aschur Bán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="27"/>
        <source>Click Analyze to use this filter.</source>
        <translation>Cliceáil ar Anailís a dhéanamh chun an scagaire seo a úsáid.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="90"/>
        <source>Select a file to store analysis results.</source>
        <translation>Roghnaigh comhad chun torthaí anailíse a stóráil.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="116"/>
        <source>&lt;b&gt;Analyze Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Roghanna Anailís&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="121"/>
        <source>Shakiness</source>
        <translation>Crith</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="142"/>
        <source>Accuracy</source>
        <translation>Cruinneas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="184"/>
        <source>&lt;b&gt;Filter Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Roghanna Scagaire&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="492"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="189"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="118"/>
        <source>Zoom</source>
        <translation>Súmáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="248"/>
        <source>Stabilization file:</source>
        <translation>Comhad cobhsaithe:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="252"/>
        <source>The stabilization file generated by the analysis.</source>
        <translation>An comhad cobhsaíochta ginte ag an anailís.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="189"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="291"/>
        <source>File for motion analysis</source>
        <translation>Comhad le haghaidh anailíse tairiscint</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="390"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="168"/>
        <source>Browse...</source>
        <translation>Brabhsáil...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="395"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="172"/>
        <source>Start Offset</source>
        <translation>Tosaigh Fritháireamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="407"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="181"/>
        <source>seconds</source>
        <translation>soicindí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="438"/>
        <source>Analysis</source>
        <translation>Anailís</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="448"/>
        <source>Apply transform</source>
        <translation>Cuir claochlú i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="454"/>
        <source>Sample Radius</source>
        <translation>Ga Samplach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="477"/>
        <source>Search Radius</source>
        <translation>Ga Cuardaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="523"/>
        <source>Track Points</source>
        <translation>Pointí Rian</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="530"/>
        <source>Use backwards-facing track points</source>
        <translation>Úsáid rianphointí a fhéachann ar gcúl</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="566"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="641"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="716"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="215"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="212"/>
        <source>Smoothing</source>
        <translation>Sleamhnú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="589"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="664"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="739"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="233"/>
        <source>Time Bias</source>
        <translation>Claonadh Ama</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="70"/>
        <source> Red</source>
        <translation>Dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="191"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="79"/>
        <source>Yellow</source>
        <translation>Buí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/ui.qml" line="96"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="60"/>
        <source>Amplitude</source>
        <translation>Aimplitiúid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="180"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="257"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="335"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="413"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="491"/>
        <location filename="../src/qml/filters/distort/ui.qml" line="125"/>
        <location filename="../src/qml/filters/glitch/ui.qml" line="101"/>
        <source>Frequency</source>
        <translation>Minicíocht</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/ui.qml" line="154"/>
        <source>Velocity</source>
        <translation>Treoluas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="68"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Coinnigh % 1 chun eochairfhráma a tharraingt ingearach amháin nó % 2 chun cothrománach a tharraingt amháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="50"/>
        <source>Forward</source>
        <translation>Ar aghaidh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="52"/>
        <source>Freeze</source>
        <translation>Reo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="53"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="54"/>
        <source>%L1s</source>
        <translation>%L1s</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="205"/>
        <source>Set Speed After</source>
        <translation>Socraigh Luas Tar éis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="205"/>
        <source>Set Speed Before</source>
        <translation>Socraigh Luas Roimh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="242"/>
        <source>Modify current mapping</source>
        <translation>Mionathraigh an léarscáiliú reatha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="247"/>
        <source>Lock current mapping</source>
        <translation>Glasáil an mhapáil reatha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="257"/>
        <source>&quot;Modify current mapping&quot; will modify the input time at the current position.
&quot;Lock current mapping&quot; will lock the input time at the current position and modify the value of an adjacent keyframe</source>
        <translation>Déanfaidh &quot;Mionathraigh an léarscáiliú reatha&quot; an t-am ionchuir ag an suíomh reatha a mhodhnú.
Déanfaidh &quot;Cuir glas ar an léarscáiliú reatha&quot; an t-am ionchuir a ghlasáil ag an suíomh reatha agus modhnóidh sé luach eochairfhráma in aice láimhe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="265"/>
        <source>OK</source>
        <translation>Ceart go leor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="273"/>
        <source>Cancel</source>
        <translation>Cealaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="309"/>
        <source>Time</source>
        <translation>Am</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="313"/>
        <source>Map the specified input time to the current time. Use keyframes to vary the time mappings over time.</source>
        <translation>Déan an t-am ionchuir sonraithe a mhapáil go dtí an t-am reatha. Úsáid eochairfhrámaí chun na mapálacha ama a athrú de réir a chéile.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="345"/>
        <source>Set the input time to achieve a desired speed before the current frame.</source>
        <translation>Socraigh an t-am ionchuir chun luas inmhianaithe a bhaint amach roimh an bhfráma reatha.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="361"/>
        <source>Set the input time to achieve a desired speed after the current frame.</source>
        <translation>Socraigh an t-am ionchuir chun luas inmhianaithe a bhaint amach tar éis an fhráma reatha.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="379"/>
        <source>Image mode</source>
        <translation>Mód íomhá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="383"/>
        <source>Use the specified image selection mode. Nearest will output the image that is nearest to the mapped time. Blend will blend all images that occur during the mapped time.</source>
        <translation>Úsáid an modh roghnaithe íomhá sonraithe. Aschuirfear an íomhá is gaire don am mapáilte. Déanfaidh Cumasc na híomhánna go léir a tharlaíonn le linn an ama mapáilte a chumasc.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="128"/>
        <source>Hue Center</source>
        <translation>Lárionad Lí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="131"/>
        <source>The center of the color range to be changed.</source>
        <translation>Lár an raon dath atá le hathrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="157"/>
        <source>Hue Range</source>
        <translation>Raon Lí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="160"/>
        <source>The width of the color range to be changed.</source>
        <translation>Leithead an raon dath atá le hathrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="260"/>
        <source>Pick the center hue from a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation>Roghnaigh an lí lár ó dhath ar an scáileán. Trí chnaipe na luiche a bhrú agus ansin do luch a bhogadh is féidir leat cuid den scáileán a roghnú as a bhfaighidh tú dath meánach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="592"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="855"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="265"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="408"/>
        <source>Blend</source>
        <translation>Cumasc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="268"/>
        <source>The amount of blending to apply to the edges of the color range.</source>
        <translation>An méid chumasc a chur i bhfeidhm ar an imill an raon dath.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="297"/>
        <source>The amount to shift the Hue of the color range.</source>
        <translation>An méid a athrú ar an Lí an raon dath.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="326"/>
        <source>The amount to scale the saturation of the color range.</source>
        <translation>An méid chun sáithiúchán an raoin datha a scála.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="355"/>
        <source>The amount to scale the lightness of the color range.</source>
        <translation>An méid le scála a dhéanamh ar ghile an raoin datha.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="424"/>
        <source>Enable pitch compensation</source>
        <translation>Cumasaigh cúiteamh páirce</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="452"/>
        <source>Speed:</source>
        <translation>Luas:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="482"/>
        <source>Input Time:</source>
        <translation>Am Ionchuir:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="497"/>
        <source>Output Time:</source>
        <translation>Am Aschuir:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="338"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="89"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="78"/>
        <source>Speed</source>
        <translation>Luas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="456"/>
        <source>The instantaneous speed of the last frame that was processed.</source>
        <translation>Luas meandarach an fhráma dheireanach a próiseáladh.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="467"/>
        <source>Direction:</source>
        <translation>Treo:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="471"/>
        <source>The instantaneous direction of the last frame that was processed.</source>
        <translation>Treo meandarach an fhráma deiridh a próiseáladh.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="486"/>
        <source>The original clip time of the frame.</source>
        <translation>Am gearrthóg bunaidh an fhráma.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="501"/>
        <source>The mapped output time for the input frame.</source>
        <translation>An t-am aschuir léarscáilithe don fhráma ionchuir.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="102"/>
        <source>Deform horizontally?</source>
        <translation>Dífhoirmigh go cothrománach?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="119"/>
        <source>Deform vertically?</source>
        <translation>Dífhoirmigh go hingearach?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="81"/>
        <source>Neutral color</source>
        <translation>Dath neodrach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="111"/>
        <source>Color temperature</source>
        <translation>Teocht datha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="183"/>
        <source>degrees</source>
        <translation>céimeanna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="147"/>
        <source>Format</source>
        <translation>Formáid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="161"/>
        <source>HH:MM:SS</source>
        <translation>UU:NN:SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="166"/>
        <source>HH:MM:SS.S</source>
        <translation>UU:NN:SS.S</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="171"/>
        <source>MM:SS</source>
        <translation>NN:SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="176"/>
        <source>MM:SS.SS</source>
        <translation>NN:SS:SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="181"/>
        <source>MM:SS.SSS</source>
        <translation>NN:SS:SSS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="186"/>
        <source>SS</source>
        <translation>SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="191"/>
        <source>SS.S</source>
        <translation>SS.S</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="196"/>
        <source>SS.SS</source>
        <translation>SS.SS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="201"/>
        <source>SS.SSS</source>
        <translation>SS.SSS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="290"/>
        <source>A value of 0 will run the timer to the end of the filter</source>
        <translation>Rithfidh luach 0 an t-amadóir go dtí deireadh an scagaire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="332"/>
        <source>When the direction is Down, the timer will count down to Offset.
When the direction is Up, the timer will count up starting from Offset.</source>
        <translation>Nuair a bhíonn an treo Síos, comhairfidh an t-amadóir síos go dtí Fritháireamh.
Nuair a bhíonn an treo Suas, comhairfidh an t-amadóir suas ag tosú ó Fritháireamh.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="359"/>
        <source>Timer seconds per playback second. Scales Duration but does not affect Start Delay or Offset.</source>
        <translation>Soicind lasc ama in aghaidh an tsoicind athsheinm. Scálaí Fad ach ní chuireann sé isteach ar Moill Tosaigh nó Fritháireamh.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="122"/>
        <source>Minimal strength</source>
        <translation>Neart íosta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="133"/>
        <source>Average strength</source>
        <translation>Meán neart</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="144"/>
        <source>Blue sky</source>
        <translation>Spéir gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="155"/>
        <source>Red sky</source>
        <translation>Spéir dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="166"/>
        <source>Full range to limited range</source>
        <translation>Raon iomlán go raon teoranta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="210"/>
        <source>Contrast threshold</source>
        <translation>Tairseach codarsnachta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="214"/>
        <source>Banding similarity within first component
Y (luma) in YCbCr mode
Red in RGB mode</source>
        <translation>Cosúlacht bandála laistigh den chéad chomhpháirt
Y (luma) i mód YCbCr
Dearg i mód RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="233"/>
        <source>Blue threshold</source>
        <translation>Tairseach gorm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="237"/>
        <source>Banding similarity within second component
Cb (blue) in YCbCr mode
Green in RGB mode</source>
        <translation>Cosúlacht bandála laistigh den dara comhpháirt
Cb (gorm) i mód YCbCr
Glas i mód RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="256"/>
        <source>Red threshold</source>
        <translation>Tairseach dearg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="260"/>
        <source>Banding similarity within third component
Cr (red) in YCbCr mode
Blue in RGB mode</source>
        <translation>Cosúlacht bandála laistigh den tríú comhpháirt
Cr (dearg) i mód YCbCr
Gorm i mód RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="279"/>
        <source>Alpha threshold</source>
        <translation>Tairseach alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="283"/>
        <source>Banding similarity within fourth component</source>
        <translation>Cosúlacht bandála laistigh den cheathrú comhpháirt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="308"/>
        <source>Link thresholds</source>
        <translation>Tairseacha naisc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="317"/>
        <source>Pixel range</source>
        <translation>Raon picteilíní</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="321"/>
        <source>The size of bands being targeted</source>
        <translation>Méid na mbandaí atá á ndíriú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="348"/>
        <source>Randomize pixel range between zero and value</source>
        <translation>Randomize raon picteilín idir nialas agus luach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="357"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="208"/>
        <source>Direction</source>
        <translation>Treo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="361"/>
        <source>Up = 270°
Down = 90°
Left = 180°
Right = 0° or 360°
All = 360° + Randomize</source>
        <translation>Suas = 270°
Síos = 90°
Ar chlé = 180°
Ar dheis = 0° nó 360°
Gach = 360° + Randamaíodh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="388"/>
        <source>Randomize direction between zero degrees and value</source>
        <translation>Randamaíodh treo idir nialas céimeanna agus luach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="403"/>
        <source>Measure similarity using average of neighbors</source>
        <translation>Cosúlacht a thomhas ag baint úsáide as meán na gcomharsana</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="407"/>
        <source>Compare to thresholds using average versus exact neighbor values</source>
        <translation>Cuir meánluachanna in aghaidh beachta comharsan i gcomparáid le tairseacha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="425"/>
        <source>All components required to trigger deband</source>
        <translation>Na comhpháirteanna go léir a theastaíonn chun díbhanda a spreagadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="429"/>
        <source>Deband only if all pixel components (including alpha) are within thresholds</source>
        <translation>Deband ach amháin má tá gach comhpháirt picteilín (alfa san áireamh) laistigh de na tairseacha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1164"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1301"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="222"/>
        <source>Up</source>
        <translation>Suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="227"/>
        <source>Down</source>
        <translation>Síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="234"/>
        <source>Start Delay</source>
        <translation>Moill Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="253"/>
        <source>The timer will be frozen from the beginning of the filter until the Start Delay time has elapsed.</source>
        <translation>Beidh an t-amadóir reoite ó thús an scagaire go dtí go mbeidh an t-am Moill Tosaigh caite.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="265"/>
        <source>Set start to begin at the current position</source>
        <translation>Cuir tús le tosú ag an staid reatha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="290"/>
        <source>The timer will be frozen after the Duration has elapsed.</source>
        <translation>Beidh an t-amadóir reoite tar éis don Ré a bheith caite.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="307"/>
        <source>Set duration to end at the current position</source>
        <translation>Socraigh ré chun críochnú ag an staid reatha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="500"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="258"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="313"/>
        <source>Offset</source>
        <translation>Fritháireamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="149"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="223"/>
        <source>File</source>
        <translation>Comhad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="285"/>
        <source>Custom...</source>
        <translation>Saincheaptha...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="280"/>
        <source>Bar Horizontal</source>
        <translation>Barra Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="290"/>
        <source>Bar Vertical</source>
        <translation>Barra Ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="295"/>
        <source>Barn Door Horizontal</source>
        <translation>Doras Barn Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="300"/>
        <source>Barn Door Vertical</source>
        <translation>Doras Barn Ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="305"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Doras na Seanchreime Diagánach SW-NE</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="310"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Doras na Seanchreime Diagánach NW-SE</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="315"/>
        <source>Diagonal Top Left</source>
        <translation>Diagánach Barr Ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="320"/>
        <source>Diagonal Top Right</source>
        <translation>Diagánach Barr Ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="325"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Maitrís Eas Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="330"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Maitrís Eas Ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="335"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Nathair na Matrics Cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="340"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Nathair na Matrics Cothrománach Comhthreomhar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="345"/>
        <source>Matrix Snake Vertical</source>
        <translation>Nathair na Matrics Ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="350"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Nathair na Matrics Ingearach Comhthreomhar
&#xa0;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="355"/>
        <source>Barn V Up</source>
        <translation>Scioból V Suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="360"/>
        <source>Iris Circle</source>
        <translation>Ciorcal Iris</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="365"/>
        <source>Double Iris</source>
        <translation>Iris Dúbailte</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="370"/>
        <source>Iris Box</source>
        <translation>Bosca Iris</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="375"/>
        <source>Box Bottom Right</source>
        <translation>Bosca Bun ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="380"/>
        <source>Box Bottom Left</source>
        <translation>Bosca Bun ar Chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="385"/>
        <source>Box Right Center</source>
        <translation>Bosca Lár ar Dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="390"/>
        <source>Clock Top</source>
        <translation>Clog Barr</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="262"/>
        <source>Set a mask from another file&apos;s brightness or alpha.</source>
        <translation>Socraigh masc ó chomhad eile gile nó alfa.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="238"/>
        <source>Open Mask File</source>
        <translation>Oscail Comhad Masc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="189"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="464"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="48"/>
        <source>Reverse</source>
        <translation>Tiontaigh thart</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="511"/>
        <source>Alpha</source>
        <translation>Alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="96"/>
        <source>Waveform Color</source>
        <translation>Dath Cruth Tonn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="154"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="112"/>
        <source>Background Color</source>
        <translation>Dath Cúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="235"/>
        <source>Fill the area under the waveform.</source>
        <translation>Líon isteach an limistéar faoin bhfoirm tonn.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="247"/>
        <source>Combine all channels into one waveform.</source>
        <translation>Comhcheangail gach cainéal in aon tonnchruth amháin.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="69"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="252"/>
        <source>Window</source>
        <translation>Fuinneog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/ui.qml" line="166"/>
        <source>Rows</source>
        <translation>sraitheanna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/ui.qml" line="206"/>
        <source>Columns</source>
        <translation>Colúin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="130"/>
        <source>Block height</source>
        <translation>Bloc airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="159"/>
        <source>Shift intensity</source>
        <translation>Déine Shift</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="188"/>
        <source>Color intensity</source>
        <translation>Dath déine</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="89"/>
        <source>Spatial</source>
        <translation>Spásúil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="118"/>
        <source>Temporal</source>
        <translation>Teamparálta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="353"/>
        <source>Apply to Source</source>
        <translation>Cuir i bhfeidhm ar an Fhoinse</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="379"/>
        <source>Corner radius</source>
        <translation>Cúinne raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="407"/>
        <source>Padding color</source>
        <translation>Dath stuála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="86"/>
        <source>Levels</source>
        <comment>Dither video filter</comment>
        <translation>Leibhéil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="115"/>
        <source>Matrix</source>
        <translation>Maitrís</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>2x2 Magic Square</source>
        <translation>Cearnóg Draíocht 2x2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Magic Square</source>
        <translation>Cearnóg Draíocht 4x4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Ordered</source>
        <translation>4x4 Ordaithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Lines</source>
        <translation>Línte 4x4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>6x6 90 Degree Halftone</source>
        <translation>Leath Ton 6x6 90 Céim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>6x6 Ordered</source>
        <translation>6x6 Ordaithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>8x8 Ordered</source>
        <translation>8x8 Ordaithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-3 Clustered</source>
        <translation>Ordú-3 Cnuasaithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-4 Ordered</source>
        <translation>Ordú-4 Orduithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-8 Ordered</source>
        <translation>Ordú-8 Orduithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="106"/>
        <source>Horizontal center position of the linear area.</source>
        <translation>Seasamh lárionad cothrománach an limistéir líneach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="135"/>
        <source>Linear width</source>
        <translation>Leithead líneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="139"/>
        <source>Width of the linear area.</source>
        <translation>Leithead an limistéir líneach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="168"/>
        <source>Linear scale factor</source>
        <translation>Fachtóir scála líneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="172"/>
        <source>Amount the linear area is scaled.</source>
        <translation>An méid a bhfuil an limistéar líneach scálaithe.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="201"/>
        <source>Non-Linear scale factor</source>
        <translation>Fachtóir scála neamh-líneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="205"/>
        <source>Amount the outer left and outer right areas are scaled non linearly.</source>
        <translation>Méid na limistéir ar chlé seachtrach agus ar dheis seachtrach de réir scála neamhlíneach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/threshold/ui.qml" line="141"/>
        <source>Compare with alpha channel</source>
        <translation>Déan comparáid idir le cainéal alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/ui.qml" line="91"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="65"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="73"/>
        <source> frames</source>
        <translation>frámaí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/ui.qml" line="81"/>
        <source>Repeat</source>
        <translation>Déan arís</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="121"/>
        <source>Key Filter: Low Frequency</source>
        <translation>Eochair Scagaire: Minicíocht Íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="150"/>
        <source>Key Filter: High Frequency</source>
        <translation>Eochair Scagaire: Minicíocht Ard</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="184"/>
        <source>Output key only</source>
        <translation>Eochair aschuir amháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="246"/>
        <source>Hold</source>
        <translation>Coinnigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="274"/>
        <source>Decay</source>
        <translation>Lobhadh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="302"/>
        <source>Range</source>
        <translation>Raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="161"/>
        <source>Octave Shift</source>
        <translation>Aistriú Ochtach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="165"/>
        <source>Specify the pitch shift in octaves.
-1 shifts down an octave.
+1 shifts up an octave.
0 is unchanged.</source>
        <translation>Sonraigh an t-athrú tuinairde i ochtáin.
-1 aistríonn síos ochtáve.
Aistríonn +1 suas ochtáibh.
0 gan athrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="205"/>
        <source>Specify the speed change that should be compensated for.
2x will halve the pitch to compensate for the speed being doubled.</source>
        <translation>Sonraigh an t-athrú luais ar cheart a chúiteamh.
Déanfaidh 2x an pháirc a ghearradh ina leath chun an luas a dhúbailt.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="201"/>
        <source>Speed Compensation</source>
        <translation>Cúiteamh Luas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="69"/>
        <source>Light</source>
        <translation>Solas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="75"/>
        <source>Medium</source>
        <translation>Meánach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="81"/>
        <source>Heavy</source>
        <translation>Trom</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="121"/>
        <source>Method</source>
        <translation>Modh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Soft</source>
        <translation>Bog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Garrote</source>
        <translation>Garrote</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Hard</source>
        <comment>Remove Noise Wavelet filter</comment>
        <translation>Crua</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="141"/>
        <source>Decompose</source>
        <translation>Lobh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="175"/>
        <source>Percent</source>
        <translation>Faoin gcéad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="193"/>
        <source>Max decompositions for the current video mode</source>
        <translation>An uasmhéid dianscaoilte do mhodh físe reatha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="199"/>
        <source>More information</source>
        <translation>Tuilleadh eolais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/ui.qml" line="84"/>
        <source>Levels</source>
        <comment>Posterize filter</comment>
        <translation>Leibhéil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="113"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="430"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="143"/>
        <source>Transparent</source>
        <translation>Trédhearcach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="408"/>
        <source>Show grid</source>
        <translation>Taispeáin greille</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/ui.qml" line="65"/>
        <source>Quantization</source>
        <translation>Cuantú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/ui.qml" line="83"/>
        <location filename="../src/qml/filters/histeq/ui.qml" line="63"/>
        <source>Strength</source>
        <translation>Neart</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="105"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="40"/>
        <source>No File Loaded.</source>
        <translation>Níor Luchtaíodh aon Chomhad.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="107"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="42"/>
        <source>No GPS file loaded.
Click &quot;Open&quot; to load a file.</source>
        <translation>Níor lódaíodh aon chomhad GPS.
Cliceáil &quot;Oscail&quot; chun comhad a luchtú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="401"/>
        <source>Select GPS File</source>
        <translation>Roghnaigh Comhad GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="443"/>
        <source>Select Background Image</source>
        <translation>Roghnaigh Íomhá Chúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="463"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="218"/>
        <source>Open file</source>
        <translation>Comhad a oscailt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="221"/>
        <source>Open GPS File</source>
        <translation>Oscail Comhad GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="503"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="238"/>
        <source>&lt;b&gt;GPS options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Roghanna GPS&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="510"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="245"/>
        <source>GPS offset</source>
        <translation>Fritháireamh GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="514"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="249"/>
        <source>This is added to video time to sync with gps time.</source>
        <translation>Cuirtear é seo leis an am físeáin chun sioncronú le ham GPS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="533"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="266"/>
        <source>+ : Adds time to video (use if GPS is ahead).
 - : Subtracts time from video (use if video is ahead).</source>
        <translation>+ : Cuireann sé am le físeáin (úsáid má tá GPS chun tosaigh).
- : Dealaigh am ón bhfíseán (úsáid má tá físeán chun tosaigh).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="574"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="307"/>
        <source>Number of days to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Líon na laethanta le suimiú/dealú le ham físeáin chun iad a shioncronú.
Leid: is féidir leat roth na luiche a úsáid chun luachanna a athrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="613"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="346"/>
        <source>Number of hours to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Líon uaireanta le suimiú/dealú le ham físeáin chun iad a shioncronú.
Leid: is féidir leat roth na luiche a úsáid chun luachanna a athrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="652"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="385"/>
        <source>Number of minutes to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Líon na nóiméad le suimiú/dealú le ham físeáin chun iad a shioncronú.
Leid: is féidir leat roth na luiche a úsáid chun luachanna a athrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="691"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="424"/>
        <source>Number of seconds to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Líon soicind le suimiú/dealú le ham físeáin chun iad a shioncronú.
Leid: is féidir leat roth na luiche a úsáid chun luachanna a athrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="710"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="443"/>
        <source>Sync start of GPS to start of video file.
Tip: use this if you started GPS and video recording at the same time.</source>
        <translation>Sioncronaigh tús GPS le tosú an chomhaid físe.
Leid: bain úsáid as seo má thosaigh tú GPS agus fístaifeadadh ag an am céanna.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="749"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="482"/>
        <source>Sync start of GPS to current video time.
Tip: use this if you recorded the moment of the first GPS fix.</source>
        <translation>Sioncronaigh tús GPS leis an am físeáin reatha.
Leid: bain úsáid as seo má thaifead tú nóiméad an chéad shocrú GPS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="759"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="492"/>
        <source>GPS smoothing</source>
        <translation>Míneáil GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="763"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="496"/>
        <source>Average nearby GPS points to smooth out errors.</source>
        <translation>Meánphointí GPS in aice láimhe chun earráidí a réiteach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="889"/>
        <source>&lt;b&gt;Graph data&lt;/b&gt;</source>
        <translation>&lt;b&gt;Sonraí graf&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="894"/>
        <source>Data source</source>
        <translation>Foinse sonraí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="898"/>
        <source>Choose which data type is used for graph drawing.</source>
        <translation>Roghnaigh cén cineál sonraí a úsáidtear chun graif a tharraingt.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Location (2D map)</source>
        <translation>Suíomh (léarscáil 2D)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Altitude</source>
        <translation>Airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Heart rate</source>
        <translation>Ráta croí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="919"/>
        <source>Graph type</source>
        <translation>Cineál graf</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="923"/>
        <source>Graph types can add advanced interactions.</source>
        <translation>Is féidir le cineálacha graf idirghníomhaíochtaí chun cinn a chur leis.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Standard</source>
        <translation>Caighdeán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Follow dot (cropped)</source>
        <translation>Lean an ponc (gearrtha)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Speedometer</source>
        <translation>Luasmhéadar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="941"/>
        <source>Standard = just a static map.
Follow dot = centers on the current location.
Speedometer = draws a simple speedometer.</source>
        <translation>Caighdeán = díreach léarscáil statach.
Lean dot = ionaid ar an suíomh reatha.
Luasmhéadar = tarraingíonn sé luasmhéadar simplí.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="947"/>
        <source>Trim time</source>
        <translation>Bearr am</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="951"/>
        <source>Hides part of the graph at beginning or end.
This does not recompute min/max for any field.</source>
        <translation>Folaigh cuid den ghraf ag tús nó ag deireadh.
Ní ríomhann sé seo íosmhéid/uas d&apos;aon réimse.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="978"/>
        <source>Hides part of the beginning of the graph.</source>
        <translation>Folaigh cuid de thús an ghraif.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1022"/>
        <source>Hides part of the end of the graph.</source>
        <translation>Folaigh cuid de dheireadh an ghraif.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1039"/>
        <source>Crop horizontal</source>
        <translation>Gearradh cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1043"/>
        <source>Zooms in on the graph on the horizontal axis (longitude if map, time if simple graph).
The number is either a percentage or a numeric value interpreted as the legend type.
This field is not applicable for Speedometer type.</source>
        <translation>Súmaíonn sé isteach ar an ngraf ar an ais chothrománach (fadfhad más léarscáil, am más graf simplí).
Is ionann an uimhir agus céatadán nó luach uimhriúil a léirmhínítear mar an cineál finscéal.
Níl an réimse seo infheidhme maidir le cineál Luasmhéadair.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1065"/>
        <source>Crops the graph from the left side.</source>
        <translation>Gearrtha an graf ón taobh clé.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1108"/>
        <source>Crops the graph from the right side. This value is ignored if mode is Follow dot.</source>
        <translation>Gearrtha an graf ón taobh deas. Ní thugtar aird ar an luach seo más é an modh Lean ponc.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1116"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1225"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1116"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1225"/>
        <source>value</source>
        <translation>luach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1126"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1235"/>
        <source>The crop values are interpreted as a percentage of total or as an absolute value (in legend unit).</source>
        <translation>Léirmhínítear luachanna na gearrtha mar chéatadán den iomlán nó mar luach absalóideach (san aonad aoir).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1130"/>
        <source>Input for horizontal crops can be a percentage or an absolute value.</source>
        <translation>Is féidir le hionchur do gearrtha cothrománacha a bheith ina chéatadán nó ina luach absalóideach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1147"/>
        <source>Crop vertical</source>
        <translation>Gearradh ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1151"/>
        <source>Zooms in on the graph on the vertical axis (latitude if map, value if simple graph).
The number is either a percentage or a numeric value interpreted as the legend type.
This field affects min/max values on the Speedometer type.</source>
        <translation>Súmaíonn sé isteach ar an ngraf ar an ais ingearach (domhanleithead más léarscáil, luach más graf simplí).
Is ionann an uimhir agus céatadán nó luach uimhriúil a léirmhínítear mar an cineál finscéal.
Bíonn tionchar ag an réimse seo ar íosluachanna/uasluachanna ar an gcineál Luasmhéadair.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1174"/>
        <source>Crops the graph from the bottom side.</source>
        <translation>Gearrtha an graf ón taobh bun.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1217"/>
        <source>Crops the graph from the top side. This value is ignored if mode is Follow dot.</source>
        <translation>Gearrtha an graf ón taobh barr. Ní thugtar aird ar an luach seo más é an modh Lean ponc.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1239"/>
        <source>Input for vertical crops can be a percentage or an absolute value.</source>
        <translation>Is féidir le hionchur do bharra ingearacha a bheith ina chéatadán nó ina luach absalóideach.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1257"/>
        <source>&lt;b&gt;Graph design&lt;/b&gt;</source>
        <translation>&lt;b&gt;Dearadh graf&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1262"/>
        <source>Color style</source>
        <translation>Stíl datha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1266"/>
        <source>Choose how you want to color the graph line.</source>
        <translation>Roghnaigh cén chaoi ar mhaith leat an graf-líne a dhathú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>One color</source>
        <translation>Dath amháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Two colors</source>
        <translation>Dhá dhath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Solid past, thin future</source>
        <translation>Am atá caite soladach, todhchaí tanaí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Solid future, thin past</source>
        <translation>Todhchaí soladach, am atá caite tanaí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Vertical gradient</source>
        <translation>Grádán ingearach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Horizontal gradient</source>
        <translation>Grádán cothrománach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by duration</source>
        <translation>Dath de réir ré</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by altitude</source>
        <translation>Dath de réir airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by heart rate</source>
        <translation>Dath de réir ráta croí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by speed</source>
        <translation>Dath de réir luais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by speed (max 100km/h)</source>
        <translation>Dath de réir luais (uasmhéid 100km/u)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by grade (max 90°)</source>
        <translation>Dath de réir gráid (uasta 90°)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by grade (max 20°)</source>
        <translation>Dath de réir gráid (uasta 20°)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1306"/>
        <source>Color by Altitude/HR only work if there are recorded values in the gps file.
For speedometer type, only first 2 colors are used.</source>
        <translation>Ní oibríonn Dath de réir Airde/AD ach amháin má tá luachanna taifeadta sa chomhad gps.
Maidir le cineál luasmhéadair, ní úsáidtear ach an chéad 2 dhath.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1348"/>
        <source>Now dot</source>
        <translation>Anois ponc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1352"/>
        <source>Draw a dot showing current position on the graph.
For speedometer type, this is the needle.</source>
        <translation>Tarraing ponc a thaispeánann an suíomh reatha ar an ngraf.
Maidir le cineál luasmhéadair, is é seo an tsnáthaid.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1370"/>
        <source>Set the color of the inside of the now dot (or needle).</source>
        <translation>Socraigh an dath ar an taobh istigh den anois ponc (nó snáthaid).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1394"/>
        <source>Now text</source>
        <translation>Anois téacs</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1399"/>
        <source>Draw a large white text showing the current value.
The legend unit (if present) will be appended at the end.</source>
        <translation>Tarraing téacs mór bán a thaispeánann an luach reatha.
Cuirfear an t-aonad finscéal (má tá sé i láthair) i gceangal leis ag an deireadh.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1417"/>
        <source>Rotate the entire graph. Speedometer also rotates internal text.</source>
        <translation>Rothlaigh an graf iomlán. Rothlaíonn an luasmhéadar téacs inmheánach freisin.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1451"/>
        <source>Set the thickness of the graph line. Does not affect speedometer.</source>
        <translation>Socraigh tiús na líne graf. Ní chuireann sé isteach ar luasmhéadar.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1481"/>
        <source>Draw legend</source>
        <translation>Tarraing finscéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1485"/>
        <source>Draw 5 horizontal white lines with individual values for graph readability. 2D map also draws vertical (longitude) lines.
For speedometer this draws text for divisions.</source>
        <translation>Tarraing 5 líne bhána chothrománacha le luachanna aonair le haghaidh inléiteacht graif. Tarraingíonn léarscáil 2T línte ingearacha (domhanfhad) freisin.
Le haghaidh luasmhéadair tarraingíonn sé seo téacs le haghaidh rannáin.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1498"/>
        <source>Unit</source>
        <translation>Aonad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1502"/>
        <source>This will be used in legend text if active and in absolute value math.</source>
        <translation>Úsáidfear é seo i bhfinscéalta má tá sé gníomhach agus i matamaitic luach iomlán.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1514"/>
        <source>Defaults are km/h (speed) and meters (altitude).
 Available options: km/h, mi/h, nm/h (kn), m/s, ft/s.</source>
        <translation>Is iad na réamhshocruithe ná km/h (luas) agus méadair (airde).
Roghanna atá ar fáil: km/u, mi/h, nm/h (kn), m/s, ft/s.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1648"/>
        <source>Sets the height to the correct map aspect ratio or 1:1.</source>
        <translation>Socraíonn sé an airde go dtí an cóimheas ceart treoíochta léarscáile nó 1:1.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1655"/>
        <source>&lt;b&gt;Background options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Roghanna cúlra&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1660"/>
        <source>Image path</source>
        <translation>Cosán íomhá</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1664"/>
        <source>Choose an image to overlay behind the graph. Tip: you can use an actual map image to make the GPS track more interesting.</source>
        <translation>Roghnaigh íomhá le forleagan taobh thiar den ghraf. Leid: is féidir leat íomhá léarscáile iarbhír a úsáid chun an rian GPS a dhéanamh níos suimiúla.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1696"/>
        <source>GPS file center is: </source>
        <translation>Is é lárionad comhaid GPS:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1699"/>
        <source>Get the center coordinate of GPS map. This does not change with trim or crop.
TIP:OpenStreetMap website can save the current standard map centered on searched location (but only at screen resolution).
Google Earth for desktop can center on a coordinate and save a 4K image of it. Disable the Terrain layer for best results.</source>
        <translation>Faigh comhordanáidí lár an léarscáil GPS. Ní athraíonn sé seo le bearradh ná le gearradh.
LEID:Is féidir le suíomh Gréasáin OpenStreetMap an léarscáil chaighdeánach reatha atá dírithe ar an suíomh cuardaigh a shábháil (ach ag réiteach scáileáin amháin).
Is féidir le Google Earth do dheasc díriú ar chomhordanáid agus íomhá 4K de a shábháil. Díchumasaigh an ciseal Tír-raon le haghaidh torthaí is fearr.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1710"/>
        <source>Browse for an image file to be assigned as graph background.</source>
        <translation>Brabhsáil le haghaidh comhad íomhá atá le sannadh mar chúlra graf.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1727"/>
        <source>Increase or decrease the size of the background image.
Values smaller than 1 will zoom into image.</source>
        <translation>Méadaigh nó laghdaigh méid na híomhá chúlra.
Déanfaidh luachanna níos lú ná 1 zúmáil isteach san íomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="584"/>
        <source>Processing start</source>
        <translation>Tús próiseála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="589"/>
        <source>Distances are calculated since the start of the gps file, use this field to reset them (GPS time).</source>
        <translation>Ríomhtar achair ó cuireadh tús leis an gcomhad gps, bain úsáid as an réimse seo chun iad a athshocrú (am GPS).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="606"/>
        <source>Insert date and time formatted exactly as: YYYY-MM-DD HH:MM:SS (GPS time).</source>
        <translation>Cuir isteach an dáta agus an t-am formáidithe díreach mar a leanas: BBBB-MM-LL UU:NN:SS (am GPS).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="621"/>
        <source>Set start of GPS processing to current video time.</source>
        <translation>Cuir tús le próiseáil GPS go dtí an t-am físeáin reatha.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="674"/>
        <source>&lt;b&gt;Text options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Roghanna téacs&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="792"/>
        <source>Insert GPS field</source>
        <translation>Cuir isteach réimse GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="881"/>
        <source>Extra arguments can be added inside keywords:
Distance units: m [km|ft|mi].
Speed units: km/h [mi/h|m/s|ft/s].
Time default: %Y-%m-%d %H:%M:%S, extra offset can be added as +/-seconds (+3600).
Extra keyword: RAW (prints only values from file).</source>
        <translation>Is féidir argóintí breise a chur isteach in eochairfhocail:
Cianaonaid: m [km|ft|mi].
Aonaid luais: km/u [mi/h|m/s|ft/s].
Réamhshocrú ama: %Y-%m-%d %H:%M:%S, is féidir fritháireamh breise a chur leis mar +/- soicind (+3600).
Eochairfhocal breise: RAW (ní phriontaí ach luachanna ón gcomhad).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS latitude</source>
        <translation>Domhanleithead GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS longitude</source>
        <translation>GPS domhanfhad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation (m)</source>
        <translation>Airde (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Speed (km/h)</source>
        <translation>Luas (km/u)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance (m)</source>
        <translation>Achar (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS date-time</source>
        <translation>Dáta-am GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Video file date-time</source>
        <translation>Dáta ama comhaid físe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Heart-rate (bpm)</source>
        <translation>Ráta croí (bpm)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Bearing (degrees)</source>
        <translation>Treoshuíomh (céimeanna)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Bearing (compass)</source>
        <translation>Treoshuíomh (compás)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation gain (m)</source>
        <translation>Gnóthachan airde (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation loss (m)</source>
        <translation>Caillteanas airde (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance uphill (m)</source>
        <translation>Fad suas an cnoc (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance downhill (m)</source>
        <translation>Fad síos an cnoc (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance flat (m)</source>
        <translation>Fad cothrom (m)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Cadence</source>
        <translation>Rithim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Temperature (C)</source>
        <translation>Teocht (C)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Grade (%)</source>
        <translation>Grád (%)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Grade (degrees)</source>
        <translation>Grád (céimeanna)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Vertical speed (m/s)</source>
        <translation>Luas ingearach (m/s)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>3D Speed (km/h)</source>
        <translation>Luas 3T (km/u)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="803"/>
        <source>Power (W)</source>
        <translation>Cumhacht (W)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="895"/>
        <source>&lt;b&gt;Advanced options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Ardroghanna&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="848"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="634"/>
        <source>Video speed</source>
        <translation>Luas físeán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="852"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="639"/>
        <source>If the current video is sped up (timelapse) or slowed down use this field to set the speed.</source>
        <translation>Má tá an físeán reatha luas suas (timelapse) nó moill síos úsáid an réimse seo chun an luas a shocrú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="875"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="660"/>
        <source>Fractional times are also allowed (0.25 = 4x slow motion, 5 = 5x timelapse).</source>
        <translation>Ceadaítear amanna codánacha freisin (0.25 = 4x tairiscint mhall, 5 = 5x timelapse).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="900"/>
        <source>Update speed</source>
        <translation>Luas a nuashonrú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="905"/>
        <source>Set how many text updates to show per second.
Set to 0 to only print real points (no interpolation).</source>
        <translation>Socraigh cé mhéad nuashonrú téacs a thaispeáint in aghaidh an tsoicind.
Socraigh ar 0 chun fíorphointí a phriontáil (gan aon idirshuíomh).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="923"/>
        <source>Fractional times are also allowed (0.25 = update every 4 seconds, 5 = 5 updates per second).</source>
        <translation>Ceadaítear amanna codánacha freisin (0.25 = nuashonraigh gach 4 soicind, 5 = 5 nuashonrú in aghaidh an tsoicind).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="933"/>
        <source> per second</source>
        <translation>sa soicind</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1770"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="960"/>
        <source>Video start time:</source>
        <translation>Am tosaithe físeáin:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1775"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="965"/>
        <source>Detected date-time for the video file.</source>
        <translation>Dáta-am braite don chomhad físe.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1793"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="983"/>
        <source>GPS start time:</source>
        <translation>Am tosaithe GPS:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1798"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="988"/>
        <source>Detected date-time for the GPS file.</source>
        <translation>Dáta-am braite don chomhad GPS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1809"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="999"/>
        <source>This time will be used for synchronization.</source>
        <translation>Úsáidfear an t-am seo le haghaidh sioncrónaithe.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="599"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="111"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="259"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="622"/>
        <source>Tip: Mask other video filters by adding filters after this one followed by &lt;b&gt;Mask: Apply&lt;/b&gt;</source>
        <translation>Leid: Masc ar scagairí físeáin eile trí scagairí a chur leis tar éis an ceann seo agus ansin &lt;b&gt;Masc: Cuir i bhfeidhm&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="128"/>
        <source>50 Hz</source>
        <translation>50 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="198"/>
        <source>100 Hz</source>
        <translation>100 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="222"/>
        <source>156 Hz</source>
        <translation>156 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="246"/>
        <source>220 Hz</source>
        <translation>220 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="270"/>
        <source>311 Hz</source>
        <translation>311 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="294"/>
        <source>440 Hz</source>
        <translation>440 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="318"/>
        <source>622 Hz</source>
        <translation>622 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="342"/>
        <source>880 Hz</source>
        <translation>880 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="366"/>
        <source>1250 Hz</source>
        <translation>1250 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="390"/>
        <source>1750 Hz</source>
        <translation>1750 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="414"/>
        <source>2500 Hz</source>
        <translation>2500 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="438"/>
        <source>3500 Hz</source>
        <translation>3500 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="462"/>
        <source>5000 Hz</source>
        <translation>5000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="486"/>
        <source>10000 Hz</source>
        <translation>10000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="510"/>
        <source>20000 Hz</source>
        <translation>20000 Hz</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="130"/>
        <source>Low</source>
        <translation>Íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="188"/>
        <source>Mid</source>
        <translation>Lár</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="212"/>
        <source>High</source>
        <translation>Ard</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="87"/>
        <source>Source</source>
        <translation>Foinse</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <source>Middle (L+R)</source>
        <translation>Meán (Clé+Dheis)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <source>Side (L-R)</source>
        <translation>Taobh (Clé+Dheis)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="117"/>
        <source>Left delay</source>
        <translation>Moill ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="143"/>
        <source>Left delay gain</source>
        <translation>Gnóthachan moill chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="169"/>
        <source>Right delay</source>
        <translation>Moill ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="195"/>
        <source>Right delay gain</source>
        <translation>Gnóthachan moill dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="221"/>
        <source>Output gain</source>
        <translation>Gnóthachan aschuir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="103"/>
        <source>New...</source>
        <translation>Nua...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="114"/>
        <source>New Animation File</source>
        <translation>Comhad Beochana Nua</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="124"/>
        <source>Open Animation File</source>
        <translation>Oscail Comhad Beochana</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="134"/>
        <source>Click &lt;b&gt;New...&lt;/b&gt; or &lt;b&gt;Open...&lt;/b&gt; to use this filter</source>
        <translation>Cliceáil &lt;b&gt;Nua...&lt;/b&gt; nó &lt;b&gt;Oscail...&lt;/b&gt; chun an scagaire seo a úsáid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="149"/>
        <source>Edit...</source>
        <translation>Cuir in eagar...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="154"/>
        <source>Reload</source>
        <translation>Athlódáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="124"/>
        <source>Name</source>
        <translation>Ainm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="139"/>
        <source>Region To Track</source>
        <translation>Réigiún Chun Rianú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="148"/>
        <source>Set the region of interest to track.</source>
        <translation>Socraigh an réigiún spéise a rianú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="267"/>
        <source>Algorithm</source>
        <translation>Algartam</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="270"/>
        <source>Chooses the way (rules) the tracking is calculated.</source>
        <translation>Roghnaíonn an bealach (rialacha) a ríomhtar an rianú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="348"/>
        <source>Show preview</source>
        <translation>Taispeáin réamhamharc</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="88"/>
        <source>Discontinuity threshold</source>
        <translation>Tairseach neamhleanúnachais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="92"/>
        <source>The threshold to apply a seam to splices</source>
        <translation>An tairseach chun seam a chur i bhfeidhm ar splices</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="128"/>
        <source>Seam applied</source>
        <translation>Seam curtha i bhfeidhm</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="132"/>
        <source>Status indicator showing when a splice has been seamed.</source>
        <translation>Táscaire stádais a thaispeánann cathain a bhíonn splice fuaite.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="36"/>
        <source>Fade to White</source>
        <translation>Céimnithe go Bán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="123"/>
        <source>Fade color</source>
        <translation>Céimnithe dath</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="181"/>
        <source>Azimuth</source>
        <translation>Asamat</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="225"/>
        <source>Elevation</source>
        <translation>Ingearchló</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/ui.qml" line="82"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="98"/>
        <source>Intensity</source>
        <translation>Déine</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/ui.qml" line="113"/>
        <source>Subtitle Track</source>
        <translation>Rian Fotheideal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="153"/>
        <source>Horizontal 4:3</source>
        <translation>Cothrománach 4:3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="158"/>
        <source>Horizontal 16:9</source>
        <translation>Cothrománach 16:9</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="163"/>
        <source>Square</source>
        <translation>Cearnóg</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="170"/>
        <source>Vertical 9:16</source>
        <translation>Ingearach 9:16</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="140"/>
        <source>Sepia</source>
        <translation>Séipia</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="146"/>
        <source>Thermal</source>
        <translation>Teirmeach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="205"/>
        <source>Color #%1</source>
        <translation>Dath #%1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="211"/>
        <source>Color: %1
Click to select, drag to change position</source>
        <translation>Dath: % 1
Cliceáil chun roghnú, tarraing chun suíomh a athrú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="344"/>
        <source>Stop</source>
        <translation>Stad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="159"/>
        <source>Overlap</source>
        <translation>Forluí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="186"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="294"/>
        <source>Hue Shift</source>
        <translation>Lí Athrú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="192"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="355"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="518"/>
        <source>Reds</source>
        <translation>Dearganna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="218"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="381"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="544"/>
        <source>Yellows</source>
        <translation>Buíanna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="244"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="407"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="570"/>
        <source>Greens</source>
        <translation>Glasa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="270"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="433"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="596"/>
        <source>Cyans</source>
        <translation>Gorma</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="296"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="459"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="622"/>
        <source>Blues</source>
        <translation>Gormacha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="322"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="485"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="648"/>
        <source>Magentas</source>
        <translation>Púrpura</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="349"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="323"/>
        <source>Saturation Scale</source>
        <translation>Scála Sáithiúcháin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="512"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="352"/>
        <source>Lightness Scale</source>
        <translation>Scála Gile</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="520"/>
        <source>Blur Start</source>
        <translation>Doiléirigh Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="111"/>
        <source>File for zenith correction</source>
        <translation>Comhad le haghaidh ceartú zenith</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="209"/>
        <source>Smooth yaw instead of locking it</source>
        <translation>Mín luascáil in ionad é a ghlasáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/ui.qml" line="116"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ui_av</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="70"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="89"/>
        <source>Amount</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="126"/>
        <source>Blur alpha</source>
        <translation>Doiléirigh alfa</translation>
    </message>
</context>
<context>
    <name>ui_box_blur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="70"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="90"/>
        <source>Width</source>
        <translation>Leithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="119"/>
        <source>Height</source>
        <translation>Airde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="152"/>
        <source>Blur alpha</source>
        <translation>Doiléirigh alfa</translation>
    </message>
</context>
<context>
    <name>ui_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="138"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="169"/>
        <source>Width</source>
        <translation>Leithead</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="208"/>
        <source>Height</source>
        <translation>Airde</translation>
    </message>
</context>
<context>
    <name>ui_dance</name>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="71"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="84"/>
        <source>Initial Zoom</source>
        <translation>Súmáil Tosaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="88"/>
        <source>The amount to zoom the image before any motion occurs.</source>
        <translation>An méid chun an íomhá a zúmáil sula dtarlaíonn aon tairiscint.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="108"/>
        <source>Oscillation</source>
        <translation>Ascalúchán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="112"/>
        <source>Oscillation can be useful to make the image move back and forth during long periods of sound.</source>
        <translation>Is féidir ascalú a bheith úsáideach chun an íomhá a bhogadh siar agus amach le linn tréimhsí fada fuaime.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="132"/>
        <source>Zoom</source>
        <translation>Súmáil</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="136"/>
        <source>The amount that the audio affects the zoom of the image.</source>
        <translation>Bíonn tionchar ag an méid fuaime ar shúmáil na híomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="156"/>
        <source>Up</source>
        <translation>Suas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="160"/>
        <source>The amount that the audio affects the upward offset of the image.</source>
        <translation>Bíonn tionchar ag an méid fuaime ar fhritháireamh aníos na híomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="180"/>
        <source>Down</source>
        <translation>Síos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="184"/>
        <source>The amount that the audio affects the downward offset of the image.</source>
        <translation>Bíonn tionchar ag an méid fuaime ar fhritháireamh anuas na híomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="204"/>
        <source>Left</source>
        <translation>Ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="208"/>
        <source>The amount that the audio affects the left offset of the image.</source>
        <translation>Bíonn tionchar ag an méid fuaime ar fhritháireamh clé na híomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="228"/>
        <source>Right</source>
        <translation>Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="232"/>
        <source>The amount that the audio affects the right offset of the image.</source>
        <translation>Bíonn tionchar ag an méid fuaime ar fhritháireamh ceart na híomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="252"/>
        <source>Clockwise</source>
        <translation>Deiseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="256"/>
        <source>The amount that the audio affects the clockwise rotation of the image.</source>
        <translation>Bíonn tionchar ag an méid fuaime ar rothlú deiseal na híomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="267"/>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="291"/>
        <source> deg</source>
        <translation>céime</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="276"/>
        <source>Counterclockwise</source>
        <translation>tuathalach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="280"/>
        <source>The amount that the audio affects the counterclockwise rotation of the image.</source>
        <translation>Bíonn tionchar ag an méid fuaime ar rothlú tuathalach na híomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="300"/>
        <source>Low Frequency</source>
        <translation>Minicíocht Íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="304"/>
        <source>The low end of the frequency range to be used to influence the image motion.</source>
        <translation>An deireadh íseal den raon minicíochta a úsáid chun tionchar a imirt ar an tairiscint íomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="328"/>
        <source>High Frequency</source>
        <translation>Minicíocht Ard</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="332"/>
        <source>The high end of the frequency range to be used to influence the image motion.</source>
        <translation>Deireadh ard an raon minicíochta atá le húsáid chun tionchar a imirt ar an tairiscint íomhá.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="356"/>
        <source>Threshold</source>
        <translation>Táirseach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="360"/>
        <source>The minimum amplitude of sound that must occur within the frequency range to cause the image to move.</source>
        <translation>An aimplitiúid fuaime íosta a chaithfidh tarlú laistigh den raon minicíochta chun an íomhá a bhogadh.</translation>
    </message>
</context>
<context>
    <name>ui_frei0r</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_frei0r.qml" line="65"/>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="97"/>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="100"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="130"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="116"/>
        <source>Blur</source>
        <translation>Doiléirigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="81"/>
        <source>Grayscale</source>
        <translation>Liathscála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="123"/>
        <source>Level</source>
        <translation>Leibhéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_frei0r.qml" line="84"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="148"/>
        <source>Amount</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="173"/>
        <source>Size</source>
        <translation>Méid</translation>
    </message>
</context>
<context>
    <name>ui_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="56"/>
        <source>Mode</source>
        <translation>Mód</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Shadows (Lift)</source>
        <translation>Scáthanna (Ardaitheoir)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Midtones (Gamma)</source>
        <translation>Toin Mheáin (Gáma)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Highlights (Gain)</source>
        <translation>Buaicphointí (Gain)</translation>
    </message>
</context>
<context>
    <name>ui_lightshow</name>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="79"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="96"/>
        <source>Waveform Color</source>
        <translation>Dath Cruth Tonn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="112"/>
        <source>Position</source>
        <translation>Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="153"/>
        <source>Size</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="194"/>
        <source>Oscillation</source>
        <translation>Ascalúchán</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="198"/>
        <source>Oscillation can be useful to make the light blink during long periods of sound.</source>
        <translation>Is féidir le ascalú a bheith úsáideach chun an solas a chaochadh le linn tréimhsí fada fuaime.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="218"/>
        <source>Low Frequency</source>
        <translation>Minicíocht Íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="222"/>
        <source>The low end of the frequency range to be used to influence the light.</source>
        <translation>Deireadh íseal an raon minicíochta atá le húsáid chun tionchar a imirt ar an solas.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="246"/>
        <source>High Frequency</source>
        <translation>Minicíocht Ard</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="250"/>
        <source>The high end of the frequency range to be used to influence the light.</source>
        <translation>Deireadh ard an raon minicíochta atá le húsáid chun tionchar a imirt ar an solas.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="274"/>
        <source>Threshold</source>
        <translation>Táirseach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="278"/>
        <source>The minimum amplitude of sound that must occur within the frequency range to cause the light to change.</source>
        <translation>Ní mór an aimplitiúid fuaime íosta a tharlaíonn laistigh den raon minicíochta chun an solas a athrú.</translation>
    </message>
</context>
<context>
    <name>ui_movit</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="118"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="149"/>
        <source>Radius</source>
        <translation>Raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="163"/>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="121"/>
        <source>Level</source>
        <translation>Leibhéal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="95"/>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="139"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="129"/>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="98"/>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="136"/>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="127"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="175"/>
        <source>Highlight blurriness</source>
        <translation>Aibhsigh doiléire</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="201"/>
        <source>Highlight cutoff</source>
        <translation>Aibhsigh gearrtha</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="79"/>
        <source>Grayscale</source>
        <translation>Liathscála</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="155"/>
        <source>Circle radius</source>
        <translation>Ga ciorcail</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="181"/>
        <source>Gaussian radius</source>
        <translation>Raon Gaóisianach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="207"/>
        <source>Correlation</source>
        <translation>Comhchoibhneas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="232"/>
        <source>Noise</source>
        <translation>Torann</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="147"/>
        <source>Outer radius</source>
        <translation>Ga seachtrach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="171"/>
        <source>Inner radius</source>
        <translation>Ga istigh</translation>
    </message>
</context>
<context>
    <name>ui_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="137"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="158"/>
        <source>Radius</source>
        <translation>Raon</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="182"/>
        <source>Feathering</source>
        <translation>Cleitíú</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="212"/>
        <source>Non-linear feathering</source>
        <translation>Cleite neamhlíneach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="222"/>
        <source>Opacity</source>
        <translation>Teimhneacht</translation>
    </message>
</context>
<context>
    <name>ui_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="103"/>
        <source>Preset</source>
        <translation>Réamhshocraithe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="120"/>
        <source>Type</source>
        <translation>Cineál</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Line</source>
        <translation>Líne</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Bar</source>
        <translation>Barra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Segment</source>
        <translation>Deighleog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="149"/>
        <source>Spectrum Color</source>
        <translation>Dath Speictrim</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="165"/>
        <source>Background Color</source>
        <translation>Dath Cúlra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="179"/>
        <source>Thickness</source>
        <translation>Tiús</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="199"/>
        <source>Position</source>
        <translation>Seasamh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="246"/>
        <source>Size</source>
        <translation>Méid</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="300"/>
        <source>Fill the area under the spectrum.</source>
        <translation>Líon isteach an limistéar faoin speictream.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="312"/>
        <source>Mirror the spectrum.</source>
        <translation>Scáthán an speictrim.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="324"/>
        <source>Reverse the spectrum.</source>
        <translation>An speictream a aisiompú.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="329"/>
        <source>Tension</source>
        <translation>Teannas</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="348"/>
        <source>Segments</source>
        <translation>Deighleoga</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="371"/>
        <source>Segment Gap</source>
        <translation>Bearna Deighleog</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="394"/>
        <source>Bands</source>
        <translation>Bandaí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="413"/>
        <source>Low Frequency</source>
        <translation>Minicíocht Íseal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="417"/>
        <source>The low end of the frequency range of the spectrum.</source>
        <translation>Deireadh íseal raon minicíochta an speictrim.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="441"/>
        <source>High Frequency</source>
        <translation>Minicíocht Ard</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="445"/>
        <source>The high end of the frequency range of the spectrum.</source>
        <translation>Deireadh ard raon minicíochta an speictrim.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="469"/>
        <source>Threshold</source>
        <translation>Táirseach</translation>
    </message>
</context>
<context>
    <name>vui</name>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="213"/>
        <source>Hold Shift while dragging any corner to drag all corners</source>
        <translation>Coinnigh Shift agus tú ag tarraingt cúinne ar bith chun gach cúinne a tharraingt</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="276"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="318"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="360"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="402"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="366"/>
        <source>Text size</source>
        <translation>Méid an téacs</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="385"/>
        <source>Text color</source>
        <translation>Dath téacs</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="487"/>
        <source>Collapse Toolbar</source>
        <translation>Leacaigh Barra Uirlisí</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="487"/>
        <source>Expand Toolbar</source>
        <translation>Leathnaigh Barra Uirlis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="270"/>
        <source>Menu</source>
        <translation>Roghchlár</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="596"/>
        <source>Left</source>
        <translation>Ar chlé</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="607"/>
        <source>Center</source>
        <translation>Ionad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="618"/>
        <source>Right</source>
        <translation>Ar dheis</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="629"/>
        <source>Justify</source>
        <translation>Comhfhadaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="640"/>
        <source>Bold</source>
        <translation>Trom</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="651"/>
        <source>Italic</source>
        <translation>Iodálach</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="662"/>
        <source>Underline</source>
        <translation>Cuir líne faoi</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="812"/>
        <source>OK</source>
        <translation>Ceart go leor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="820"/>
        <source>Cancel</source>
        <translation>Cealaigh</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="331"/>
        <location filename="../src/qml/filters/richtext/vui.qml" line="673"/>
        <source>Font</source>
        <translation>Cló</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="746"/>
        <source>Insert Table</source>
        <translation>Ionsáigh Tábla</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="686"/>
        <source>Decrease Indent</source>
        <translation>Laghdú eang</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="695"/>
        <source>Insert Indent</source>
        <translation>Ionsáigh eang</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="758"/>
        <source>Rows</source>
        <translation>sraitheanna</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="775"/>
        <source>Columns</source>
        <translation>Colúin</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="791"/>
        <source>Border</source>
        <translation>Teorainn</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/vui.qml" line="26"/>
        <location filename="../src/qml/filters/gpsgraphic/vui.qml" line="26"/>
        <location filename="../src/qml/filters/gradient/vui.qml" line="109"/>
        <location filename="../src/qml/filters/lightshow/vui.qml" line="26"/>
        <location filename="../src/qml/filters/mask_alphaspot/vui.qml" line="108"/>
        <location filename="../src/qml/filters/pillar_echo/vui.qml" line="82"/>
        <location filename="../src/qml/filters/reframe/vui.qml" line="86"/>
        <location filename="../src/qml/filters/spot_remover/vui.qml" line="82"/>
        <location filename="../src/qml/filters/tracker/vui.qml" line="48"/>
        <location filename="../src/qml/filters/waveform/vui.qml" line="26"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Cliceáil i dronuilleog + coinnigh Shift chun tarraing</translation>
    </message>
</context>
<context>
    <name>vui_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/vui_spectrum.qml" line="26"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Cliceáil i dronuilleog + coinnigh Shift chun tarraing</translation>
    </message>
</context>
</TS>
