<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>AbstractJob</name>
    <message>
        <location filename="../src/jobs/abstractjob.cpp" line="53"/>
        <source>Pause This Job</source>
        <translation>Задание на паузу</translation>
    </message>
    <message>
        <location filename="../src/jobs/abstractjob.cpp" line="56"/>
        <source>Resume This Job</source>
        <translation>Продолжить задание</translation>
    </message>
</context>
<context>
    <name>ActionsDialog</name>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="238"/>
        <source>Actions and Shortcuts</source>
        <translation>Действия и горячие клавиши</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="246"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="260"/>
        <source>Clear search</source>
        <translation>Очистить поиск</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="295"/>
        <source>Click on the selected shortcut to show the editor</source>
        <translation>Нажмите выбранную горячую клавишу для показа редактора</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="301"/>
        <source>Reserved shortcuts can not be edited</source>
        <translation>Зарезервированные горячие клавиши нельзя изменить</translation>
    </message>
</context>
<context>
    <name>ActionsModel</name>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="188"/>
        <source>Shortcut %1 is used by %2</source>
        <translation>Сочетание клавиш %1 используется %2</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="198"/>
        <source>Shortcut %1 is reserved for use by %2</source>
        <translation>Сочетание клавиш %1 зарезервировано на %2</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="233"/>
        <source>Action</source>
        <translation>Действие</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="235"/>
        <source>Shortcut 1</source>
        <translation>Горячая клавиша 1</translation>
    </message>
    <message>
        <location filename="../src/models/actionsmodel.cpp" line="237"/>
        <source>Shortcut 2</source>
        <translation>Горячая клавиша 2</translation>
    </message>
</context>
<context>
    <name>AddEncodePresetDialog</name>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>Диалог</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="25"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="52"/>
        <source>File name extension</source>
        <translation>Расширение имени файла</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="59"/>
        <source>for example, mp4</source>
        <translation>например, mp4</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="84"/>
        <source>Make final changes to the preset including removing items you do not want to include, or copy/paste the clipboard.</source>
        <translation>Внесите окончательные правки в предустановки, в том числе удалите элементы, которые хотите исключить, либо скопируйте/вставьте из буфера обмена.</translation>
    </message>
</context>
<context>
    <name>AlignAudioDialog</name>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="234"/>
        <source>Reference audio track</source>
        <translation>Референсный аудио трек</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="251"/>
        <source>Speed adjustment range</source>
        <translation>Диапазон регулировки скорости</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="254"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="255"/>
        <source>Narrow</source>
        <translation>Узкий</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="257"/>
        <source>Normal</source>
        <translation>Обычный</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="259"/>
        <source>Wide</source>
        <translation>Широкий</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="260"/>
        <source>Very wide</source>
        <translation>Очень широкий</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="303"/>
        <source>Process</source>
        <translation>Обработать</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="306"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="309"/>
        <source>Process + Apply</source>
        <translation>Обработать и применить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="347"/>
        <source>This clip will be skipped because it is on the reference track.</source>
        <translation>Этот клип будет пропущен, поскольку находится на контрольной дорожке.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="353"/>
        <source>This item can not be aligned.</source>
        <translation>Этот элемент не может быть выровнен.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="365"/>
        <source>Align Audio</source>
        <translation>Выравнивание звука</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="482"/>
        <source>Analyze Reference Track</source>
        <translation>Анализ контрольной дорожки</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="490"/>
        <source>Analyze Clips</source>
        <translation>Анализ клипов</translation>
    </message>
    <message>
        <location filename="../src/dialogs/alignaudiodialog.cpp" line="500"/>
        <source>Alignment not found.</source>
        <translation>Выравнивание не найдено.</translation>
    </message>
</context>
<context>
    <name>AlignClipsModel</name>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="202"/>
        <source>Clip</source>
        <translation>Клип</translation>
    </message>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="204"/>
        <source>Offset</source>
        <translation>Смещение</translation>
    </message>
    <message>
        <location filename="../src/models/alignclipsmodel.cpp" line="206"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
</context>
<context>
    <name>AlsaWidget</name>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="26"/>
        <source>ALSA Audio</source>
        <translation>Аудио ALSA</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="54"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="61"/>
        <source>PCM Device</source>
        <translation>PCM-устройство</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="71"/>
        <source>default</source>
        <translation>по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="78"/>
        <source>Channels</source>
        <translation>Каналы</translation>
    </message>
</context>
<context>
    <name>AttachedFiltersModel</name>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="236"/>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="238"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="240"/>
        <source>GPU</source>
        <translation>Графический процессор</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="242"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="491"/>
        <source>This file has B-frames, which is not supported by %1.</source>
        <translation>Этот файл содержит B-кадры, которые не поддерживает %1.</translation>
    </message>
</context>
<context>
    <name>AudioLoudnessScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="85"/>
        <source>Momentary Loudness</source>
        <translation>Мгновенная громкость</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="88"/>
        <source>Short Term Loudness</source>
        <translation>Кратковременная громкость</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="91"/>
        <source>Integrated Loudness</source>
        <translation>Интегральная громкость</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="94"/>
        <source>Loudness Range</source>
        <translation>Диапазон громкости</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="97"/>
        <source>Peak</source>
        <translation>Пик</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="100"/>
        <source>True Peak</source>
        <translation>Истинный пик</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="106"/>
        <source>Configure Graphs</source>
        <translation>Настроить кривые</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="114"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="115"/>
        <source>Reset the measurement.</source>
        <translation>Сброс измерения.</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="122"/>
        <source>Time Since Reset</source>
        <translation>Время после сброса</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="178"/>
        <source>Audio Loudness</source>
        <translation>Громкость аудио</translation>
    </message>
</context>
<context>
    <name>AudioPeakMeterScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="90"/>
        <source>Audio Peak Meter</source>
        <translation>Измеритель пиков аудио</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="107"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>L</source>
        <translation>Л</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="107"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>R</source>
        <translation>П</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>C</source>
        <translation>Ц</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>LF</source>
        <translation>ЛФ</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>Ls</source>
        <translation>Лк</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="111"/>
        <source>Rs</source>
        <translation>Пк</translation>
    </message>
</context>
<context>
    <name>AudioSpectrumScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiospectrumscopewidget.cpp" line="217"/>
        <source>Audio Spectrum</source>
        <translation>Аудиоспектр</translation>
    </message>
</context>
<context>
    <name>AudioSurroundScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="70"/>
        <source>Audio Surround</source>
        <translation>Аудио Окружение</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="252"/>
        <source>L</source>
        <translation>Л</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="265"/>
        <source>C</source>
        <translation>Ц</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="279"/>
        <source>R</source>
        <translation>П</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="293"/>
        <source>LS</source>
        <translation>ЛТ</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiosurroundscopewidget.cpp" line="306"/>
        <source>RS</source>
        <translation>ПТ</translation>
    </message>
</context>
<context>
    <name>AudioVectorScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="90"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="91"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="99"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="100"/>
        <source>C</source>
        <translation>Ц</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="93"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="95"/>
        <source>L</source>
        <translation>Л</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="94"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="96"/>
        <source>R</source>
        <translation>П</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="103"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="105"/>
        <source>Ls</source>
        <translation>Лк</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="104"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="106"/>
        <source>Rs</source>
        <translation>Пк</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="109"/>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="110"/>
        <source>LFE</source>
        <translation>САБ</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiovectorscopewidget.cpp" line="215"/>
        <source>Audio Vector</source>
        <translation>Аудио Вектор</translation>
    </message>
</context>
<context>
    <name>AudioWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="181"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="182"/>
        <source>-inf</source>
        <translation>-бесконеч</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="265"/>
        <source>Sample: %1
</source>
        <translation>Фрагмент: %1
</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="273"/>
        <source>Ch: %1: %2 (%3 dBFS)</source>
        <translation>К: %1: %2 (%3 dBFS)</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="298"/>
        <source>Audio Waveform</source>
        <translation>Осциллограмма аудио</translation>
    </message>
</context>
<context>
    <name>AvformatProducerWidget</name>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="60"/>
        <source>Comments:</source>
        <translation>Комментарии:</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="174"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="120"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="289"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="569"/>
        <source>Broadcast Limited (MPEG)</source>
        <translation>Ограниченное широковещание (MPEG)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="574"/>
        <source>Full (JPEG)</source>
        <translation>Полный (JPEG)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="472"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="697"/>
        <source>Track</source>
        <translation>Дорожка</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="460"/>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="525"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="295"/>
        <source>Scan mode</source>
        <translation>Режим сканирования</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="600"/>
        <source>Interlaced</source>
        <translation>Чересстрочный</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="605"/>
        <source>Progressive</source>
        <translation>Последовательный</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="374"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="414"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="783"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="813"/>
        <source>Codec</source>
        <translation>Кодек</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="184"/>
        <source>Timeline</source>
        <translation>Шкала времени</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="199"/>
        <source>Speed Presets</source>
        <translation>Предустановки скорости</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="251"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="258"/>
        <source>Apply pitch compensation when the speed is changed.</source>
        <translation>Компенсировать высоту тона при изменении скорости.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="261"/>
        <source>Pitch Compensation</source>
        <translation>Компенсация высоты тона</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="315"/>
        <source>Rotation</source>
        <translation>Вращение</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="379"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="419"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="384"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="424"/>
        <source>Frame rate</source>
        <translation>Частота кадров</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="389"/>
        <source>Pixel format</source>
        <translation>Формат пикселей</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="394"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="434"/>
        <source>Color space</source>
        <translation>Цветовое пространство</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="399"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="439"/>
        <source>Color transfer</source>
        <translation>Цветопередача</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="404"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="803"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="943"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="409"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="808"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="948"/>
        <source>Value</source>
        <translation>Значение</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="429"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="798"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="828"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="614"/>
        <source>Bottom Field First</source>
        <translation>Нижнее поле первое</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="619"/>
        <source>Top Field First</source>
        <translation>Верхнее поле первое</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="645"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="650"/>
        <source>90</source>
        <translation>90</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="655"/>
        <source>180</source>
        <translation>180</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="660"/>
        <source>270</source>
        <translation>270</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="668"/>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="691"/>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="788"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="818"/>
        <source>Channels</source>
        <translation>Каналы</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="793"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="823"/>
        <source>Sample rate</source>
        <translation>Частота дискретизации</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="836"/>
        <source>Adjust the audio/video synchronization. The center position is equivalent to no alteration.</source>
        <translation>Настройте синхронизацию аудио/видео. Среднее положение соответствует настройке без изменений.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="855"/>
        <source>Sync</source>
        <translation>Синхронизация</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="880"/>
        <source> ms</source>
        <translation> мс</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="909"/>
        <source>Metadata</source>
        <translation>Метаданные</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="979"/>
        <source>Properties Menu</source>
        <translation>Меню свойств</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1032"/>
        <source>Show In Folder</source>
        <translation>Показать в папке</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1062"/>
        <source>Extract Subtitles...</source>
        <translation>Извлечь субтитры...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1095"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1100"/>
        <source>Set Equirectangular...</source>
        <translation>Выбрать равнопрямоугольную...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1105"/>
        <source>Measure Video Quality...</source>
        <translation>Расчёт качества видео...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1113"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1116"/>
        <source>Export GPX</source>
        <translation>Экспорт GPX</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1121"/>
        <source>View Bitrate...</source>
        <translation>Просмотр Битрейта...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1124"/>
        <source>View Bitrate</source>
        <translation>Просмотр битрейта</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1129"/>
        <source>Show In Files</source>
        <translation>Показать в файлах</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1000"/>
        <source>Convert to Edit-friendly</source>
        <translation>Преобразование в удобный формат</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="305"/>
        <source>Color range</source>
        <translation>Цветовой диапазон</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1003"/>
        <source>Convert...</source>
        <translation>Преобразовать...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1037"/>
        <source>Copy Full File Path</source>
        <translation>Копировать полный адрес файла</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1042"/>
        <source>More Information...</source>
        <translation>Больше информации...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1047"/>
        <source>Start Integrity Check Job</source>
        <translation>Запуск задания Проверка целостности</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1052"/>
        <source>Convert to Edit-friendly...</source>
        <translation>Конвертировать для редактирования...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1067"/>
        <source>Set Creation Time...</source>
        <translation>Задать время создания...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1075"/>
        <source>Disable Proxy</source>
        <translation>Отключить прокси</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1080"/>
        <source>Make Proxy</source>
        <translation>Создать прокси</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1085"/>
        <source>Delete Proxy</source>
        <translation>Удалить прокси</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1090"/>
        <source>Copy Hash Code</source>
        <translation>Копировать хеш-код</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="993"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="861"/>
        <source>Reverse...</source>
        <translation>Изменить направление...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1057"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1127"/>
        <source>Extract Sub-clip...</source>
        <translation>Извлечь субклип...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="347"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="418"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="376"/>
        <source>unknown (%1)</source>
        <translation>неизвестно (%1)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="452"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="498"/>
        <source>(PROXY)</source>
        <translation>(ПРОКСИ)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="541"/>
        <source>(variable)</source>
        <translation>(переменный)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="1010"/>
        <source>Proxy</source>
        <translation>Прокси</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="134"/>
        <source> Do you want to convert it to an edit-friendly format?

If yes, choose a format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, it automatically replaces clips, or you can double-click the job to open it.
</source>
        <translation>Вы хотите преобразовать его в удобный для редактирования формат?

Если да, выберите формат ниже, а затем нажмите ОК, чтобы выбрать имя файла. После выбора имени файла создаётся задание. Когда это будет сделано, клипы будут автоматически заменены, либо можно дважды нажать на заданию, чтобы его открыть.
</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="781"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="856"/>
        <source>Choose an edit-friendly format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, double-click the job to open it.
</source>
        <translation>Выберите формат для редактирования ниже и нажмите OK для выбора имени файла. После выбора имени файла создается задание. Когда это будет сделано, дважды щелкните задание, чтобы открыть его.
</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="970"/>
        <source>MP4 (*.mp4);;All Files (*)</source>
        <translation>MP4 (*.mp4);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1015"/>
        <source>MOV (*.mov);;All Files (*)</source>
        <translation>MOV (*.mov);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1032"/>
        <source>MKV (*.mkv);;All Files (*)</source>
        <translation>MKV (*.mkv);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1085"/>
        <source>Convert %1</source>
        <translation>Преобразовать %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1036"/>
        <source>Reversed</source>
        <translation>Направление изменено</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1066"/>
        <source>Reverse canceled</source>
        <translation>Изменение направления отменено</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1095"/>
        <source>Reverse %1</source>
        <translation>Обратить %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1464"/>
        <source>Choose the Other Video</source>
        <translation>Выбрать другое видео</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1517"/>
        <source>Measure %1</source>
        <translation>Измерение %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1126"/>
        <source>Sub-clip</source>
        <translation>Субклип</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1128"/>
        <source>%1 (*.%2);;All Files (*)</source>
        <translation>%1 (*.%2);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1200"/>
        <source>Extract sub-clip %1</source>
        <translation>Извлечь субклип %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1219"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1269"/>
        <source>Track %1</source>
        <translation>Дорожка %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1221"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1271"/>
        <source>Track %1 (%2)</source>
        <translation>Дорожка %1 (%2)</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1225"/>
        <source>Export Subtitles...</source>
        <translation>Экспорт субтитров...</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1227"/>
        <source>No subtitles found</source>
        <translation>Субтитры не найдены</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1286"/>
        <source>Extract subtitles %1</source>
        <translation>Извлечь субтитры %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1399"/>
        <source>The hash code below is already copied to your clipboard:

</source>
        <translation>Хеш-код уже скопирован в буфер обмена:

</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1443"/>
        <source>Set Equirectangular Projection</source>
        <translation>Выбрать равнопрямоугольную проекцию</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1455"/>
        <source>Successfully wrote %1</source>
        <translation>Успешно записано %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1457"/>
        <source>An error occurred saving the projection.</source>
        <translation>Ошибка при сохранении проекции.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1577"/>
        <source>Bitrate %1</source>
        <translation>Битрейт %1</translation>
    </message>
</context>
<context>
    <name>AvfoundationProducerWidget</name>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="26"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="107"/>
        <source>Audio/Video Device</source>
        <translation>Устройство аудио/видео</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="39"/>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="58"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="83"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="84"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="90"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="99"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="47"/>
        <source>Video Input</source>
        <translation>Видеовход</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="66"/>
        <source>Audio Input</source>
        <translation>Звуковой вход</translation>
    </message>
</context>
<context>
    <name>BitrateDialog</name>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="48"/>
        <source>Bitrate Viewer</source>
        <translation>Просмотр битрейта</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="66"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="74"/>
        <source>Average</source>
        <translation>Средний</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="135"/>
        <source>Bitrates for %1 ~~ Avg. %2 Min. %3 Max. %4 Kb/s</source>
        <translation>Битрейт для %1 ~~ Средн. %2 Мин. %3 Макс. %4 Kb/s</translation>
    </message>
    <message>
        <location filename="../src/dialogs/bitratedialog.cpp" line="179"/>
        <source>Save Bitrate Graph</source>
        <translation>Сохранить график битрейта</translation>
    </message>
</context>
<context>
    <name>BitrateViewerJob</name>
    <message>
        <location filename="../src/jobs/bitrateviewerjob.cpp" line="34"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
</context>
<context>
    <name>BlipProducerWidget</name>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="26"/>
        <source>Blip Flash</source>
        <translation>Генератор вспышек</translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>Частота</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/widgets/blipproducerwidget.cpp" line="67"/>
        <source> second(s)</source>
        <translation>
            <numerusform>секунда</numerusform>
            <numerusform>секунды</numerusform>
            <numerusform>секунд</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/widgets/blipproducerwidget.cpp" line="89"/>
        <source>Period: %1s</source>
        <translation>Время: %1 с</translation>
    </message>
</context>
<context>
    <name>ClockSpinner</name>
    <message>
        <location filename="../src/qml/filters/timer/ClockSpinner.qml" line="121"/>
        <source>Decrement</source>
        <translation>Уменьшение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ClockSpinner.qml" line="150"/>
        <source>Increment</source>
        <translation>Приращение</translation>
    </message>
</context>
<context>
    <name>ColorBarsWidget</name>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="26"/>
        <source>Color Bars</source>
        <translation>Цветовые шкалы</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="38"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="55"/>
        <source>100% PAL color bars</source>
        <translation>100% уровень цветности PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="60"/>
        <source>100% PAL color bars with red</source>
        <translation>100% уровень цветности PAL, красный</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="65"/>
        <source>95% BBC PAL color bars</source>
        <translation>95% уровень цветности BBC PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="70"/>
        <source>75% EBU color bars</source>
        <translation>75% уровень цветности EBU</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="75"/>
        <source>SMPTE color bars</source>
        <translation>Шкалы цветов SMPTE</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="80"/>
        <source>Philips PM5544</source>
        <translation>Philips PM5544</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="85"/>
        <source>FuBK</source>
        <translation>FuBK</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="90"/>
        <source>Simplified FuBK</source>
        <translation>Упрощённый FuBK</translation>
    </message>
</context>
<context>
    <name>ColorPicker</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="58"/>
        <source>Click to open color dialog</source>
        <translation>Нажмите, чтобы открыть окно выбора цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="89"/>
        <source>Pick a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation>Выберите цвет на экране. Нажмите кнопку мыши и перемещайте указатель, чтобы выделить область на экране, из которой будет получен усреднённый цвет.</translation>
    </message>
</context>
<context>
    <name>ColorProducerWidget</name>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="20"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="30"/>
        <source>Comments:</source>
        <translation>Комментарии:</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="61"/>
        <source>Color...</source>
        <translation>Цвет...</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="74"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="58"/>
        <source>black</source>
        <translation>чёрный</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="60"/>
        <source>transparent</source>
        <translation>прозрачный</translation>
    </message>
</context>
<context>
    <name>CopyFiltersDialog</name>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="44"/>
        <source>Copy Filters</source>
        <translation>Скопировать фильтры</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="57"/>
        <source>Enter a name to save a filter set, or
leave blank to use the clipboard:</source>
        <translation>Введите имя для сохранения набора фильтров, или
оставьте пустым, чтобы использовать буфер обмена:</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="64"/>
        <source>optional</source>
        <translation>на выбор</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="84"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/CopyFiltersDialog.qml" line="89"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>CountProducerWidget</name>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="26"/>
        <source>Count</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="41"/>
        <source>Direction</source>
        <translation>Направление</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="74"/>
        <source>Style</source>
        <translation>Стиль</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="107"/>
        <source>Sound</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="110"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Silent - No sound&lt;/p&gt;&lt;p&gt;2-Pop - A 1kHz beep exactly two seconds before the out point&lt;/p&gt;&lt;p&gt;Frame 0 - A 1kHz beep at frame 0 of every second&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;head/&gt;&lt;body&gt;&lt;p&gt;Тишина — без звука&lt;/p&gt;&lt;p&gt;2-Pop — сигнал с частотой 1 кГц, воспроизводящийся через две секунды после прохождения выходной точки.&lt;/p&gt;&lt;p&gt;Кадр 0 — сигнал с частотой 1 кГц на нулевом кадре, воспроизводящийся каждую секунду.&lt;/p&gt;&lt;/body&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="143"/>
        <source>Background</source>
        <translation>Задний план</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="146"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;None - No background&lt;/p&gt;&lt;p&gt;Clock  - Film style clock animation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Пусто — без заднего плана&lt;/p&gt;&lt;p&gt;Часы — анимация в стиле кинематографических часов.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="179"/>
        <source>Drop Frame</source>
        <translation>Пропуск кадра</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="182"/>
        <source>Use SMPTE style drop-frame counting for non-integer frame rates. The clock and timecode will advance two frames every minute if necessary to keep time with wall clock time.</source>
        <translation>Использовать стиль SMPTE подсчёта пропуска кадров для нецелочисленных частот кадров. Часы и шкала времени будут сдвигаться на два кадра каждую минуту, если будет необходимо сохранить время для настенных часов.</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.ui" line="189"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="41"/>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="42"/>
        <source>Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="45"/>
        <source>Seconds</source>
        <translation>Секунд</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="46"/>
        <source>Seconds + 1</source>
        <translation>Секунд + 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="47"/>
        <source>Frames</source>
        <translation>Кадров</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="48"/>
        <source>Timecode</source>
        <translation>Временнáя метка</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="49"/>
        <location filename="../src/widgets/countproducerwidget.cpp" line="57"/>
        <source>Clock</source>
        <translation>Часы</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="52"/>
        <source>2-Pop</source>
        <translation>2-Pop</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="53"/>
        <source>Silent</source>
        <translation>Тишина</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="54"/>
        <source>Frame 0</source>
        <translation>Кадр 0</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="58"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/widgets/countproducerwidget.cpp" line="225"/>
        <source>Count: %1 %2</source>
        <translation>Количество: %1 %2</translation>
    </message>
</context>
<context>
    <name>CurveComboBox</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="36"/>
        <source>Natural</source>
        <translation>Естественный</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="40"/>
        <source>S-Curve</source>
        <translation>S-Кривые</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="44"/>
        <source>Fast-Slow</source>
        <translation>Быстро-Медленно</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/CurveComboBox.qml" line="48"/>
        <source>Slow-Fast</source>
        <translation>Медленно-Быстро</translation>
    </message>
</context>
<context>
    <name>CustomProfileDialog</name>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="14"/>
        <source>Add Custom Video Mode</source>
        <translation>Добавить пользовательский Видеорежим</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="29"/>
        <source>Colorspace</source>
        <translation>Цветовое пространство</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="58"/>
        <source>ITU-R BT.2020</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="81"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="112"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="182"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="201"/>
        <source>Interlaced</source>
        <translation>Чересстрочный</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="206"/>
        <source>Progressive</source>
        <translation>Последовательный</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="229"/>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="260"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="348"/>
        <source>Frames/sec</source>
        <translation>Кадров/с</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="449"/>
        <source>Scan mode</source>
        <translation>Режим сканирования</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="481"/>
        <source>&lt;small&gt;(Leave Name blank to skip saving a preset and use a temporary or project-specific Video Mode.)&lt;/small&gt;</source>
        <translation>&lt;small&gt;(Оставьте название пустым, чтобы пропустить сохранение Пресета и использовать временный или специфичный для проекта Видеорежим.)&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.cpp" line="134"/>
        <source>Video Mode Frames/sec</source>
        <translation>Режим видео кадр/с</translation>
    </message>
</context>
<context>
    <name>DecklinkProducerWidget</name>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="26"/>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="85"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="57"/>
        <source>Device</source>
        <translation>Устройство</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="67"/>
        <source>Signal mode</source>
        <translation>Режим сигнала</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="85"/>
        <source>Please be aware that not every card model supports automatic signal detection, and not all cards support all of the signal modes.</source>
        <translation>Имейте в виду, что не все модели карт поддерживают автообнаружение сигнала и разные виды сигналов.</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="31"/>
        <source>Detect Automatically</source>
        <translation>Автообнаружение</translation>
    </message>
</context>
<context>
    <name>DirectShowVideoWidget</name>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="26"/>
        <location filename="../src/widgets/directshowvideowidget.cpp" line="166"/>
        <source>Audio/Video Device</source>
        <translation>Звуковое/видео устройство </translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="52"/>
        <location filename="../src/widgets/directshowvideowidget.ui" line="81"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="60"/>
        <source>Video Input</source>
        <translation>Видеовход</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="70"/>
        <source>Audio Input</source>
        <translation>Звуковой вход</translation>
    </message>
</context>
<context>
    <name>DurationDialog</name>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="17"/>
        <source>Set Duration</source>
        <translation>Установить длительность</translation>
    </message>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="25"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
</context>
<context>
    <name>EditMarkerDialog</name>
    <message>
        <location filename="../src/dialogs/editmarkerdialog.cpp" line="31"/>
        <source>Edit Marker</source>
        <translation>Изменить метку</translation>
    </message>
</context>
<context>
    <name>EditMarkerWidget</name>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="46"/>
        <source>Set the name for this marker.</source>
        <translation>Задать имя для этой метки.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="49"/>
        <source>Color...</source>
        <translation>Цвет...</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="57"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="62"/>
        <source>Set the start time for this marker.</source>
        <translation>Установить время начала для этой метки.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="69"/>
        <source>End</source>
        <translation>Конец</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="74"/>
        <source>Set the end time for this marker.</source>
        <translation>Установить время окончания для этой метки.</translation>
    </message>
    <message>
        <location filename="../src/widgets/editmarkerwidget.cpp" line="78"/>
        <source>Duration:</source>
        <translation>Длительность:</translation>
    </message>
</context>
<context>
    <name>EncodeDock</name>
    <message>
        <location filename="../src/docks/encodedock.ui" line="18"/>
        <source>Export</source>
        <translation>Экспорт</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="45"/>
        <source>&lt;b&gt;Presets&lt;/b&gt;</source>
        <translation>&lt;b&gt;Предустановки&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="58"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="89"/>
        <source>Add current settings as a new custom preset</source>
        <translation>Добавить текущие значения, как новую пользовательскую предустановку </translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="103"/>
        <source>Delete currently selected preset</source>
        <translation>Удалить выбранную предустановку</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="169"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Export Help&lt;/span&gt;&lt;/p&gt;&lt;p&gt;The defaults create a H.264/AAC MP4 file, which is suitable for most users and purposes. Choose a &lt;span style=&quot; font-weight:600;&quot;&gt;Preset&lt;/span&gt; at the left before deciding to use the &lt;span style=&quot; font-weight:600;&quot;&gt;Advanced&lt;/span&gt; mode. The &lt;span style=&quot; font-weight:600;&quot;&gt;Advanced&lt;/span&gt; mode does not prevent creating an invalid combination of options!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Помощь при экспорте&lt;/span&gt;&lt;/p&gt;&lt;p&gt;По умолчанию создаётся файл MP4 с кодеками H.264/AAC, подходящий для большинства применений. Выберите слева &lt;span style=&quot; font-weight:600;&quot;&gt;Пресет&lt;/span&gt; перед использованием &lt;span style=&quot; font-weight:600;&quot;&gt;расширенного&lt;/span&gt; режима. &lt;span style=&quot; font-weight:600;&quot;&gt;Расширенный&lt;/span&gt; режим не защищает от неверной комбинации настроек!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="187"/>
        <source>From</source>
        <translation>Источник</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="217"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="253"/>
        <source>Use hardware encoder</source>
        <translation>Использовать аппаратный кодировщик</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="260"/>
        <source>Configure...</source>
        <translation>Настроить...</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="294"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="485"/>
        <source>Interpolation</source>
        <translation>Интерполяция</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="539"/>
        <source>Field order</source>
        <translation>Порядок полей</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="549"/>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="723"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="579"/>
        <source>Scan mode</source>
        <translation>Режим сканирования</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="664"/>
        <source>Interlaced</source>
        <translation>Чересстрочный</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="669"/>
        <source>Progressive</source>
        <translation>Последовательный</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="617"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="569"/>
        <source>Frames/sec</source>
        <translation>Кадров/с</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="916"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="824"/>
        <source>Bottom Field First</source>
        <translation>Нижнее поле первое</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="829"/>
        <source>Top Field First</source>
        <translation>Верхнее поле первое</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="858"/>
        <source>One Field (fast)</source>
        <translation>Одно поле (быстро)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="863"/>
        <source>Linear Blend (fast)</source>
        <translation>Линейное наложение (быстро)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="868"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF - временной (хорошо)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="559"/>
        <source>Deinterlacer</source>
        <translation>Деинтерлейсер</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="501"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>Ближайший сосед (быстро)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="506"/>
        <source>Bilinear (good)</source>
        <translation>Билинейная (хорошо)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="511"/>
        <source>Bicubic (better)</source>
        <translation>Бикубическая (лучше)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="811"/>
        <source>Use preview scaling</source>
        <translation>Масштабировать предпросмотр</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="599"/>
        <source>This enables multiple image processing threads.
Sometimes, this can be a problem, and you can
test if turning this off helps. For example, some
interlaced AVCHD in conjunction with the YADIF
deinterlacer has been reported as problematic
with parallel processing enabled.</source>
        <translation>Включает поддержку многопоточной обработки изображений.
В случае проблем попробуйте отключить эту
функцию. Например, сообщалось о проблемах
при параллельной обработке некоторых чересстрочных
AVCHD-видео в сочетании с YADIF-деинтерлейсером.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="330"/>
        <source>Reframe</source>
        <translation>Переделать рамку</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="589"/>
        <source>Color range</source>
        <translation>Цветовой диапазон</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="607"/>
        <source>Parallel processing</source>
        <translation>Параллельная обработка</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="630"/>
        <source>Broadcast Limited (MPEG)</source>
        <translation>Ограниченное широковещание (MPEG)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="635"/>
        <source>Full (JPEG)</source>
        <translation>Полный (JPEG)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="873"/>
        <source>YADIF - temporal + spatial (better)</source>
        <translation>YADIF - временной + пространственный (лучше)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="878"/>
        <source>BWDIF (best)</source>
        <translation>BWDIF (лучший)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="955"/>
        <location filename="../src/docks/encodedock.ui" line="964"/>
        <location filename="../src/docks/encodedock.ui" line="1647"/>
        <source>Codec</source>
        <translation>Кодек</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="994"/>
        <source>GOP</source>
        <translation>GOP</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1006"/>
        <source>GOP = group of pictures, which is the maximum key frame interval</source>
        <translation>Группа изображений (ГИ), предельный промежуток между ближайшими ключевыми кадрами</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1019"/>
        <source>frames</source>
        <translation>кадры</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1039"/>
        <source>A fixed GOP means that keyframes will
not be inserted at detected scene changes.</source>
        <translation>Фиксированная ГИ означает, что ключевые кадры
не будут вставлены при обнаружении изменений в сцене.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1043"/>
        <source>Fixed</source>
        <translation>Фиксированный</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1067"/>
        <location filename="../src/docks/encodedock.ui" line="1689"/>
        <source>The average bit rate</source>
        <translation>Средний битрейт</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1220"/>
        <location filename="../src/docks/encodedock.ui" line="1772"/>
        <source>b/s</source>
        <translation>бит/с</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1242"/>
        <source>Disable video</source>
        <translation>Отключить видео</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1249"/>
        <source>Dual pass</source>
        <translation>Двухпроходный</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1256"/>
        <source>B frames</source>
        <translation>B-кадры</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1268"/>
        <source>B frames are the bidirectional &quot;delta&quot; pictures
in temporal compression</source>
        <translation>B-кадры это двунаправленные &quot;дельта&quot;-кадры
при временном сжатии</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1307"/>
        <source>Codec threads</source>
        <translation>Потоки кодека</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1322"/>
        <source>(0 = auto)</source>
        <translation>(0 = авто)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1344"/>
        <location filename="../src/docks/encodedock.ui" line="1814"/>
        <source>Rate control</source>
        <translation>Режим кодирования</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1357"/>
        <location filename="../src/docks/encodedock.ui" line="1827"/>
        <source>Average Bitrate</source>
        <translation>Средний битрейт</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1362"/>
        <location filename="../src/docks/encodedock.ui" line="1832"/>
        <source>Constant Bitrate</source>
        <translation>Постоянный битрейт</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1367"/>
        <location filename="../src/docks/encodedock.ui" line="1837"/>
        <source>Quality-based VBR</source>
        <translation>VBR с приоритетом качества</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1372"/>
        <source>Constrained VBR</source>
        <translation>Ограниченный VBR</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1395"/>
        <source>Buffer size</source>
        <translation>Размер буфера</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1417"/>
        <source>KiB</source>
        <translation>КиБ</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1439"/>
        <location filename="../src/docks/encodedock.ui" line="1860"/>
        <source>Quality</source>
        <translation>Качество</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1451"/>
        <location filename="../src/docks/encodedock.ui" line="1872"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1467"/>
        <location filename="../src/docks/encodedock.ui" line="1888"/>
        <source>TextLabel</source>
        <translation>ТекстоваяМетка</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1489"/>
        <location filename="../src/docks/encodedock.ui" line="1677"/>
        <source>Bitrate</source>
        <translation>Битрейт</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1500"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1509"/>
        <source>Channels</source>
        <translation>Каналы</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1521"/>
        <source>The number of audio channels in the output.</source>
        <translation>Количество аудиоканалов для вывода.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1525"/>
        <source>1 (mono)</source>
        <translation>1 (моно)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1530"/>
        <source>2 (stereo)</source>
        <translation>2 (стерео)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1535"/>
        <source>4 (quad/Ambisonics)</source>
        <translation>4 (квад/Амбисоник)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1540"/>
        <source>6 (5.1 surround)</source>
        <translation>6 (5.1 окружение)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1615"/>
        <source>Hz</source>
        <translation>Гц</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1637"/>
        <source>Sample rate</source>
        <translation>Частота дискретизации</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1794"/>
        <source>Disable audio</source>
        <translation>Отключить звук</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1911"/>
        <source>Other</source>
        <translation>Другие</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1927"/>
        <source>Disable subtitles</source>
        <translation>Отключить субтитры</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1960"/>
        <location filename="../src/docks/encodedock.cpp" line="1328"/>
        <location filename="../src/docks/encodedock.cpp" line="1839"/>
        <location filename="../src/docks/encodedock.cpp" line="2331"/>
        <source>Export File</source>
        <translation>Экспорт</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1970"/>
        <source>Reset options to defaults</source>
        <translation>Сбросить в настройки по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1973"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1980"/>
        <source>Advanced</source>
        <translation>Расширенный</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1990"/>
        <source>Always start in Advanced mode</source>
        <translation>Всегда запускать в расширенном режиме</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="2000"/>
        <location filename="../src/docks/encodedock.cpp" line="2035"/>
        <location filename="../src/docks/encodedock.cpp" line="2042"/>
        <location filename="../src/docks/encodedock.cpp" line="2154"/>
        <source>Stream</source>
        <translation>Поток</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="2027"/>
        <location filename="../src/docks/encodedock.cpp" line="1822"/>
        <location filename="../src/docks/encodedock.cpp" line="1923"/>
        <location filename="../src/docks/encodedock.cpp" line="1933"/>
        <source>Stop Capture</source>
        <translation>Остановить захват изображения</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="135"/>
        <source>Automatic from extension</source>
        <translation>Автоматически по расширению</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="143"/>
        <location filename="../src/docks/encodedock.cpp" line="153"/>
        <source>Default for format</source>
        <translation>По умолчанию для формата</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="465"/>
        <source>Timeline</source>
        <translation>Шкала времени</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="472"/>
        <location filename="../src/docks/encodedock.cpp" line="478"/>
        <source>Source</source>
        <translation>Источник</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="483"/>
        <location filename="../src/docks/encodedock.cpp" line="490"/>
        <source>Marker</source>
        <translation>Метка</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="501"/>
        <source>You must enter numeric values using &apos;%1&apos; as the decimal point.</source>
        <translation>Введите числовые значения, используя &apos;%1&apos; как десятичный разделитель.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="510"/>
        <location filename="../src/docks/encodedock.cpp" line="1769"/>
        <location filename="../src/docks/encodedock.cpp" line="1770"/>
        <source>Custom</source>
        <translation>Пользовательские настройки</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="546"/>
        <source>Stock</source>
        <translation>Основные</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="549"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1395"/>
        <source>You cannot write to a file that is in your project.
Try again with a different folder or file name.</source>
        <translation>Невозможно записать файл проекта.
Попробуйте ещё раз, изменив имя файла или папки.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1493"/>
        <source>Shotcut found filters that require analysis jobs that have not run.
Do you want to run the analysis jobs now?</source>
        <translation>Shotcut обнаружил фильтры, для которых не выполнялся анализ.
Хотите запустить анализ?</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1839"/>
        <location filename="../src/docks/encodedock.cpp" line="2333"/>
        <source>Capture File</source>
        <translation>Файла захвата</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1841"/>
        <source>Export Files</source>
        <translation>Экспорт файлов</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1856"/>
        <source>%1 (*.%2);;All Files (*)</source>
        <translation>%1 (*.%2);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1858"/>
        <source>Determined by Export (*)</source>
        <translation>Определить при экспорте  (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2030"/>
        <location filename="../src/docks/encodedock.cpp" line="2052"/>
        <source>Stop Stream</source>
        <translation>Остановить поток</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2044"/>
        <source>Enter the network protocol scheme, address, port, and parameters as an URL:</source>
        <translation>Укажите тип сетевого протокола, адрес, порт, сетевой адрес:</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2087"/>
        <source>Add Export Preset</source>
        <translation>Добавить предустановку экспорта</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2131"/>
        <source>Delete Preset</source>
        <translation>Удалить предустановку</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2132"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Вы действительно хотите удалить %1?</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2260"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2315"/>
        <source>KiB (%1s)</source>
        <translation>КиБ (%1s)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2463"/>
        <source>Detect</source>
        <translation>Обнаружить</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2520"/>
        <source>(auto)</source>
        <translation>(авто)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2566"/>
        <source>Detecting hardware encoders...</source>
        <translation>Обнаружение аппаратных кодировщиков...</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2623"/>
        <source>Nothing found</source>
        <translation>Ничего не найдено</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2625"/>
        <source>Found %1</source>
        <translation>Найден %1</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2848"/>
        <source>Your project is missing some files.

Save your project, close it, and reopen it.
Shotcut will attempt to repair your project.</source>
        <translation>В проекте отсутствуют некоторые файлы.

Сохраните проект, закройте его и снова откройте.
Shotcut попытается восстановить проект.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2897"/>
        <source>Aspect ratio does not match project Video Mode, which causes black bars.</source>
        <translation>Соотношение сторон не соответствует Видеорежиму проекта, что приводит к появлению черных полос.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2935"/>
        <source>Frame rate is higher than project Video Mode, which causes frames to repeat.</source>
        <translation>Частота кадров выше, чем в Видеорежиме проекта, что приводит к повторению кадров.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2461"/>
        <source>Configure Hardware Encoding</source>
        <translation>Настроить аппаратное кодирование</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="468"/>
        <source>Current Playlist Bin</source>
        <translation>Текущий раздел плейлиста</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="469"/>
        <source>Each Playlist Bin Item</source>
        <translation>Каждый элемент раздела плейлиста</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1842"/>
        <source>Export Each Playlist Bin Item</source>
        <translation>Экспортировать каждый элемент раздела плейлиста</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1887"/>
        <source>Export canceled</source>
        <translation>Экспорт отменен</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="2485"/>
        <source>Export Frames/sec</source>
        <translation>Экспорт кадр/с</translation>
    </message>
</context>
<context>
    <name>EncodeJob</name>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="46"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="48"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>Открыть выходной файл в проигрывале Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="52"/>
        <location filename="../src/jobs/encodejob.cpp" line="53"/>
        <source>Show In Files</source>
        <translation>Показать в файлах</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="57"/>
        <location filename="../src/jobs/encodejob.cpp" line="58"/>
        <source>Show In Folder</source>
        <translation>Показать в папке</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="62"/>
        <source>Measure Video Quality...</source>
        <translation>Расчёт качества видео...</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="66"/>
        <source>Set Equirectangular...</source>
        <translation>Выбрать равнопрямоугольную...</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="75"/>
        <source>Video Quality Report</source>
        <translation>Отчёт по качеству видео</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="76"/>
        <source>Text Documents (*.txt);;All Files (*)</source>
        <translation>Документы (*.txt);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="138"/>
        <source>Set Equirectangular Projection</source>
        <translation>Выбрать равнопрямоугольную проекцию</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="152"/>
        <source>Successfully wrote %1</source>
        <translation>Успешно записано %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="154"/>
        <source>An error occurred saving the projection.</source>
        <translation>При сохранении проекции произошла ошибка.</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="182"/>
        <source>Export job failed; trying again without Parallel processing.</source>
        <translation>Экспорт не выполнен; повторить попытку без параллельной обработки.</translation>
    </message>
</context>
<context>
    <name>FfmpegJob</name>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="43"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="48"/>
        <source>Check %1</source>
        <translation>Проверка %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="77"/>
        <source>FFmpeg Log</source>
        <translation>Журнал FFmpeg</translation>
    </message>
</context>
<context>
    <name>FfprobeJob</name>
    <message>
        <location filename="../src/jobs/ffprobejob.cpp" line="52"/>
        <source>More Information</source>
        <translation>Подробности</translation>
    </message>
</context>
<context>
    <name>FileDateDialog</name>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="46"/>
        <source>%1 File Date</source>
        <translation>%1 Файл Дата</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="102"/>
        <source>Current Value</source>
        <translation>Текущее значение</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="106"/>
        <source>Now</source>
        <translation>Начать</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="112"/>
        <source>System - Modified</source>
        <translation>Система - Изменено</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="113"/>
        <source>System - Created</source>
        <translation>Система - Создано</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="123"/>
        <source>Metadata - Creation Time</source>
        <translation>Метаданные - Время создания</translation>
    </message>
    <message>
        <location filename="../src/dialogs/filedatedialog.cpp" line="130"/>
        <source>Metadata - QuickTime date</source>
        <translation>Метаданные - Дата QuickTime</translation>
    </message>
</context>
<context>
    <name>FilesDock</name>
    <message>
        <location filename="../src/docks/filesdock.ui" line="18"/>
        <location filename="../src/docks/filesdock.cpp" line="597"/>
        <source>Files</source>
        <translation>Файлы</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="61"/>
        <source>Location</source>
        <translation>Каталог</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="90"/>
        <source>Add the current folder to the saved locations</source>
        <translation>Добавить текущий каталог в сохраненные каталоги</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.ui" line="110"/>
        <source>Remove the selected location</source>
        <translation>Удалить выбранный каталог</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="502"/>
        <source>Home</source>
        <comment>The user&apos;s home folder in the file system</comment>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="503"/>
        <source>Current Project</source>
        <translation>Текущий Проект</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="504"/>
        <source>Documents</source>
        <translation>Документы</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="509"/>
        <source>Movies</source>
        <comment>The system-provided videos folder called Movies on macOS</comment>
        <translation>Фильмы</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="513"/>
        <source>Music</source>
        <translation>Музыка</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="516"/>
        <source>Pictures</source>
        <comment>The system-provided photos folder</comment>
        <translation>Картинки</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="520"/>
        <source>Volumes</source>
        <comment>The macOS file system location where external drives and network shares are mounted</comment>
        <translation>Тома</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="525"/>
        <source>Videos</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="607"/>
        <source>Select</source>
        <translation>Выбрать</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="611"/>
        <source>Files Controls</source>
        <translation>Управление файлами</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="616"/>
        <source>Files Menu</source>
        <translation>Меню файлов</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="642"/>
        <location filename="../src/docks/filesdock.cpp" line="652"/>
        <source>Files Filters</source>
        <translation>Фильтры файлов</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="675"/>
        <source>Only show files whose name contains some text</source>
        <translation>Отображать только те файлы, название которых содержит некоторый текст</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="676"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="785"/>
        <source>Tiles</source>
        <translation>Плитки</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="786"/>
        <source>View as tiles</source>
        <translation>Показать как плитку</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="798"/>
        <source>Icons</source>
        <translation>Значки</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="799"/>
        <source>View as icons</source>
        <translation>Показать как значки</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="811"/>
        <source>Details</source>
        <translation>Детали</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="812"/>
        <source>View as details</source>
        <translation>Показать подробности</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="824"/>
        <source>Open In Shotcut</source>
        <translation>Открыть в Shotcut</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="825"/>
        <source>Open the clip in the Source player</source>
        <translation>Открыть клип в исходном проигрывателе</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="833"/>
        <source>System Default</source>
        <translation>Система По умолчанию</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="847"/>
        <source>Other...</source>
        <translation>Другие...</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="855"/>
        <source>Remove...</source>
        <translation>Удалить...</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="863"/>
        <source>Show In File Manager</source>
        <translation>Показать в Файловом менеджере</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="873"/>
        <source>Update Thumbnails</source>
        <translation>Обновить миниатюры</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="881"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="892"/>
        <source>Select None</source>
        <translation>Снять выделение</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="903"/>
        <source>Open Previous</source>
        <translation>Открыть предыдущее</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="915"/>
        <source>Open Next</source>
        <translation>Открыть следующее</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="927"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="928"/>
        <source>Show or hide video files</source>
        <translation>Показать/скрыть видео файлы</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="933"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="934"/>
        <source>Show or hide audio files</source>
        <translation>Показать/скрыть аудио файлы</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="939"/>
        <source>Image</source>
        <translation>изображение</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="940"/>
        <source>Show or hide image files</source>
        <translation>Показать/скрыть файлы изображения</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="945"/>
        <source>Other</source>
        <translation>Другие</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="946"/>
        <source>Show or hide other kinds of files</source>
        <translation>Показать/скрыть другие виды файлов</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="951"/>
        <source>Folders</source>
        <translation>Каталоги</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="952"/>
        <source>Hide or show the list of folders</source>
        <translation>Показать/скрыть список каталогов</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="963"/>
        <source>Go Up</source>
        <translation>Поднять</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="964"/>
        <source>Show the parent folder</source>
        <translation>Показать родительский каталог</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="982"/>
        <source>Refresh Folders</source>
        <translation>Обновить каталоги</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1003"/>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1027"/>
        <source>Open With</source>
        <translation>Открыть с помощью</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1279"/>
        <source>Executable Files (*.exe);;All Files (*)</source>
        <translation>Исполняемые файлы (*.exe);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1284"/>
        <source>Choose Executable</source>
        <translation>Выбрать исполняемый файл</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1308"/>
        <source>Remove From Open With</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/filesdock.cpp" line="1329"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n элемент</numerusform>
            <numerusform>%n элемента</numerusform>
            <numerusform>%n элементов</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1371"/>
        <source>Add Location</source>
        <translation>Добавить каталог</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1372"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1390"/>
        <source>Delete Location</source>
        <translation>Удалить каталог</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="1391"/>
        <source>Are you sure you want to remove %1?</source>
        <translation>Вы действительно хотите удалить %1?</translation>
    </message>
</context>
<context>
    <name>FilesModel</name>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="238"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="239"/>
        <source>Image</source>
        <translation>изображение</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="240"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="241"/>
        <source>Other</source>
        <translation>Другие</translation>
    </message>
</context>
<context>
    <name>FilesTileDelegate</name>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="412"/>
        <source>Date: %1</source>
        <translation>Дата: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/filesdock.cpp" line="421"/>
        <source>Size: %1</source>
        <translation>Размер: %1</translation>
    </message>
</context>
<context>
    <name>FilterController</name>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="119"/>
        <source>(DEPRECATED)</source>
        <translation>(УСТАРЕЛ)</translation>
    </message>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="342"/>
        <source>Only one %1 filter is allowed.</source>
        <translation>Разрешён только один фильтр %1.</translation>
    </message>
</context>
<context>
    <name>FilterMenu</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="77"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="121"/>
        <source>Clear search</source>
        <translation>Очистить поиск</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="177"/>
        <source>Show favorite filters</source>
        <translation>Показать избранные фильтры</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="200"/>
        <source>Show GPU video filters</source>
        <translation>Показать видео фильтры GPU</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="221"/>
        <source>Show video filters</source>
        <translation>Показать видеофильтры</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="242"/>
        <source>Show audio filters</source>
        <translation>Показать звуковые фильтры</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="253"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="264"/>
        <source>Show time filters</source>
        <translation>Показать фильтры времени</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="274"/>
        <source>Sets</source>
        <translation>Наборы</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="285"/>
        <source>Show filter sets</source>
        <translation>Показывать наборы фильтров</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="140"/>
        <source>Close menu</source>
        <translation>Закрыть меню</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="371"/>
        <source>Delete a custom filter set by right-clicking it.</source>
        <translation>Удаление пользовательского фильтра, щелкнув по нему правой кнопкой мыши.</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="165"/>
        <source>Favorite</source>
        <translation>Избранное</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="210"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="231"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
</context>
<context>
    <name>FilterMenuDelegate</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="112"/>
        <source>Delete Filter Set</source>
        <translation>Удалить набор фильтров</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="124"/>
        <source>Are you sure you want to delete this?
%1</source>
        <translation>Вы уверены, что хотите удалить это?
%1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="139"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenuDelegate.qml" line="149"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>FiltersDock</name>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="49"/>
        <source>Filters</source>
        <translation>Фильтры</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="214"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="216"/>
        <source>Choose a filter to add</source>
        <translation>Выберите фильтр для добавления</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="228"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="230"/>
        <source>Remove selected filter</source>
        <translation>Удалить фильтр</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="237"/>
        <source>Copy Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="238"/>
        <source>Copy checked filters to the clipboard</source>
        <translation>Копировать выбранные фильтры в буфер обмена</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="245"/>
        <source>Copy Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="246"/>
        <source>Copy current filter to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="253"/>
        <source>Copy All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="254"/>
        <source>Copy all filters to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="261"/>
        <source>Paste Filters</source>
        <translation>Вставить фильтры</translation>
    </message>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="262"/>
        <source>Paste the filters from the clipboard</source>
        <translation>Вставить фильтры из буфера обмена</translation>
    </message>
</context>
<context>
    <name>FrameRateWidget</name>
    <message>
        <location filename="../src/widgets/frameratewidget.cpp" line="74"/>
        <source>Convert Frames/sec</source>
        <translation>Преобразовать частоту кадров</translation>
    </message>
</context>
<context>
    <name>GlaxnimateIpcServer</name>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="642"/>
        <source>Preparing Glaxnimate preview....</source>
        <translation>Подготовка предпросмотра Glaxnimate....</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="695"/>
        <source>The Glaxnimate program was not found.

Click OK to open a file dialog to choose its location.
Click Cancel if you do not have Glaxnimate.</source>
        <translation>Файл Glaxnimate не найден.

Нажмите ОК, чтобы открыть диалоговое окно с файлом для выбора его местоположения.
Нажмите Отмена, если у вас нет анимации Glaxnimate.</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="705"/>
        <source>Find Glaxnimate</source>
        <translation>Найти файл Glaxnimate</translation>
    </message>
</context>
<context>
    <name>GlaxnimateProducerWidget</name>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="20"/>
        <source>Animation</source>
        <translation>Анимация</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="30"/>
        <source>Comments:</source>
        <translation>Комментарии:</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="61"/>
        <source>Background color...</source>
        <translation>Цвет заднего плана...</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="76"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="103"/>
        <source>Edit...</source>
        <translation>Изменить...</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="110"/>
        <source>Reload</source>
        <translation>Перезагрузить</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.ui" line="132"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="71"/>
        <source>black</source>
        <translation>чёрный</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="73"/>
        <source>transparent</source>
        <translation>прозрачный</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="204"/>
        <source>animation</source>
        <translation>анимация</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="205"/>
        <source>Glaxnimate (*.rawr);;All Files (*)</source>
        <translation>Glaxnimate (*.rawr);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="207"/>
        <source>New Animation</source>
        <translation>Создать Анимацию</translation>
    </message>
</context>
<context>
    <name>GoPro2GpxJob</name>
    <message>
        <location filename="../src/jobs/gopro2gpxjob.cpp" line="34"/>
        <source>Export GPX</source>
        <translation>Экспорт GPX</translation>
    </message>
</context>
<context>
    <name>GradientControl</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="122"/>
        <source>Color #%1</source>
        <translation>Цвет #%1</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="128"/>
        <source>Color: %1
Click to change</source>
        <translation>Цвет: %1
Нажмите для выбора</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/GradientControl.qml" line="178"/>
        <source>colors</source>
        <comment>gradient control</comment>
        <translation>цвета</translation>
    </message>
</context>
<context>
    <name>ImageProducerWidget</name>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="27"/>
        <source>Comments:</source>
        <translation>Комментарии:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="61"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="70"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="82"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="134"/>
        <source>Pixel aspect ratio</source>
        <translation>Пиксельное соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="165"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="193"/>
        <source>Image sequence</source>
        <translation>Последовательность</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="200"/>
        <source>Repeat</source>
        <translation>Повтор</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="218"/>
        <source> frames</source>
        <translation> кадры</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="234"/>
        <source>per picture</source>
        <translation>на кадр</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="261"/>
        <source>Properties Menu</source>
        <translation>Список свойств</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="303"/>
        <source>Copy Full File Path</source>
        <translation>Копировать полный адрес файла</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="308"/>
        <source>Show In Folder</source>
        <translation>Показать в папке</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="341"/>
        <source>Show In Files</source>
        <translation>Показать в файлах</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="313"/>
        <source>Set Creation Time...</source>
        <translation>Задать время создания...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="321"/>
        <source>Disable Proxy</source>
        <translation>Отключить прокси</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="326"/>
        <source>Make Proxy</source>
        <translation>Создать прокси</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="331"/>
        <source>Delete Proxy</source>
        <translation>Удалить прокси</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="336"/>
        <source>Copy Hash Code</source>
        <translation>Копировать хеш-код</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="122"/>
        <source>Make the current duration value the default value</source>
        <translation>Запомнить текущую продолжительность как значение по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="125"/>
        <source>Set Default</source>
        <translation>Установить по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="247"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="99"/>
        <source>(PROXY)</source>
        <translation>(ПРОКСИ)</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="288"/>
        <source>Getting length of image sequence...</source>
        <translation>Получение длины последовательности изображений...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="311"/>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="333"/>
        <source>Reloading image sequence...</source>
        <translation>Перезагрузка последовательности изображений...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="466"/>
        <source>The hash code below is already copied to your clipboard:

</source>
        <translation>Этот хеш-код уже скопирован в буфер обмена:

</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="254"/>
        <source>Proxy</source>
        <translation>Прокси</translation>
    </message>
</context>
<context>
    <name>IsingWidget</name>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="26"/>
        <source>Ising Model</source>
        <translation>Модель Изинга</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="41"/>
        <source>Noise Temperature</source>
        <translation>Шумовая температура</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="106"/>
        <source>Border Growth</source>
        <translation>Увеличение границы</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="174"/>
        <source>Spontaneous Growth</source>
        <translation>Неограниченное увеличение</translation>
    </message>
</context>
<context>
    <name>JobQueue</name>
    <message>
        <location filename="../src/jobqueue.cpp" line="59"/>
        <source>pending</source>
        <translation>в обработке</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="63"/>
        <source>Estimated Hours:Minutes:Seconds</source>
        <translation>Оценка ч:мин:с</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="92"/>
        <source>paused</source>
        <translation>пауза</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="120"/>
        <source>Elapsed Hours:Minutes:Seconds</source>
        <translation>Прошло ч:мин:с</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="123"/>
        <source>stopped</source>
        <translation>остановлено</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="126"/>
        <source>failed</source>
        <translation>прервано</translation>
    </message>
</context>
<context>
    <name>JobsDock</name>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="18"/>
        <source>Jobs</source>
        <translation>Задания</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="115"/>
        <source>Stop automatically processing the next pending job in
the list. This does not stop a currently running job. Right-
-click a job to open a menu to stop a currently running job.</source>
        <translation>Остановить автоматическую обработку следующего задания
в списке. Текущее задание не будет остановлено. Чтобы его остановить,
щёлкните правой кнопкой мыши по заданию.</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="130"/>
        <source>Remove all of the completed and failed jobs from the list</source>
        <translation>Удалить из списка все завершённые и ошибочные задания</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="133"/>
        <source>Clean</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="104"/>
        <source>Jobs Menu</source>
        <translation>Список заданий</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="120"/>
        <source>Pause Queue</source>
        <translation>Пауза Очереди</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="156"/>
        <source>Stop This Job</source>
        <translation>Остановить задание</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="159"/>
        <source>Stop the currently selected job</source>
        <translation>Остановить текущее задание</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="164"/>
        <source>View Log</source>
        <translation>Показать журнал</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="167"/>
        <source>View the messages of MLT and FFmpeg </source>
        <translation>Показать сообщения MLT и FFmpeg </translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="172"/>
        <source>Run</source>
        <translation>Запуск</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="175"/>
        <source>Restart a stopped job</source>
        <translation>Перезапуск остановленного задания</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="180"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="185"/>
        <location filename="../src/docks/jobsdock.ui" line="188"/>
        <source>Remove Finished</source>
        <translation>Удалить завершённые</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.cpp" line="153"/>
        <source>Job Log</source>
        <translation>Журнал заданий</translation>
    </message>
</context>
<context>
    <name>KeyframeClip</name>
    <message>
        <location filename="../src/qml/views/keyframes/KeyframeClip.qml" line="245"/>
        <source>Confirm Removing Advanced Keyframes</source>
        <translation>Подтвердить удаление дополнительных ключевых кадров</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/KeyframeClip.qml" line="246"/>
        <source>This will remove all advanced keyframes to enable simple keyframes.&lt;p&gt;Do you still want to do this?</source>
        <translation>Это удалит все расширенные ключевые кадры, чтобы включить простые ключевые кадры.&lt;p&gt;Вы все еще хотите это сделать?</translation>
    </message>
</context>
<context>
    <name>KeyframesButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="58"/>
        <source>Use Keyframes for this parameter</source>
        <translation>Использовать ключевые кадры для этой настройки</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="45"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Удерживайте %1, чтобы перетащить ключевой кадр только по вертикали, или %2, чтобы перетащить только по горизонтали</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="64"/>
        <source>Confirm Removing Keyframes</source>
        <translation>Подтвердить удаление ключевых кадров</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="65"/>
        <source>This will remove all keyframes for this parameter.&lt;p&gt;Do you still want to do this?</source>
        <translation>Это действие удалит все ключевые кадры для данной настройки.&lt;p&gt;Настаиваете на удалении?</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="80"/>
        <source>Confirm Removing Simple Keyframes</source>
        <translation>Подтвердить удаление простых ключевых кадров</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/KeyframesButton.qml" line="81"/>
        <source>This will remove all simple keyframes for all parameters.&lt;p&gt;Simple keyframes will be converted to advanced keyframes.&lt;p&gt;Do you still want to do this?</source>
        <translation>Это приведёт к удалению всех простых ключевых кадров для всех настроек.&lt;p&gt;Простые ключевые кадры будут преобразованы в расширенные ключевые кадры.&lt;p&gt;Вы всё ещё хотите это сделать?</translation>
    </message>
</context>
<context>
    <name>KeyframesDock</name>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="48"/>
        <location filename="../src/docks/keyframesdock.cpp" line="62"/>
        <source>Keyframes</source>
        <translation>Ключевые кадры</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="71"/>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="78"/>
        <source>Keyframe</source>
        <translation>Ключевой кадр</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="79"/>
        <source>From Previous</source>
        <translation>Предыдущий</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="84"/>
        <source>Ease Out</source>
        <translation>Из</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="101"/>
        <source>To Next</source>
        <translation>Следующий</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="106"/>
        <source>Ease In</source>
        <translation>В</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="121"/>
        <source>Ease In/Out</source>
        <translation>В/Из</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="141"/>
        <source>Keyframes Clip</source>
        <translation>Ключевые кадры клипа</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="149"/>
        <source>Keyframes Controls</source>
        <translation>Управление ключевыми кадрами</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="153"/>
        <source>Keyframes Menu</source>
        <translation>Меню ключевых кадров</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="223"/>
        <source>Set Filter Start</source>
        <translation>Задать начало фильтра</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="242"/>
        <source>Set Filter End</source>
        <translation>Задать конец фильтра</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="261"/>
        <source>Set First Simple Keyframe</source>
        <translation>Задать первый простой ключевой кадр</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="280"/>
        <source>Set Second Simple Keyframe</source>
        <translation>Задать второй простой ключевой кадр</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="299"/>
        <source>Scrub While Dragging</source>
        <translation>Переходить в начало при перетаскивании</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="312"/>
        <source>Zoom Keyframes Out</source>
        <translation>Уменьшить масштаб ключевых кадров</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="323"/>
        <source>Zoom Keyframes In</source>
        <translation>Увеличить масштаб ключевых кадров</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="334"/>
        <source>Zoom Keyframes To Fit</source>
        <translation>Уместить ключевые кадры в масштабе</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="350"/>
        <location filename="../src/docks/keyframesdock.cpp" line="596"/>
        <source>Hold</source>
        <translation>Удержание</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="367"/>
        <location filename="../src/docks/keyframesdock.cpp" line="613"/>
        <source>Linear</source>
        <translation>Линейная</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="384"/>
        <location filename="../src/docks/keyframesdock.cpp" line="630"/>
        <source>Smooth</source>
        <translation>Плавная</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="406"/>
        <source>Ease Out Sinusoidal</source>
        <translation>Синусоидальный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="423"/>
        <source>Ease Out Quadratic</source>
        <translation>Квадратный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="440"/>
        <source>Ease Out Cubic</source>
        <translation>Кубический</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="457"/>
        <source>Ease Out Quartic</source>
        <translation>Четвертной</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="474"/>
        <source>Ease Out Quintic</source>
        <translation>Квинтовый</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="491"/>
        <source>Ease Out Exponential</source>
        <translation>Экспонентный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="508"/>
        <source>Ease Out Circular</source>
        <translation>Круговой</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="525"/>
        <source>Ease Out Back</source>
        <translation>Обратный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="550"/>
        <source>Ease Out Elastic</source>
        <translation>Пружинящий</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="575"/>
        <source>Ease Out Bounce</source>
        <translation>Подпрыгивающий</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="652"/>
        <source>Ease In Sinusoidal</source>
        <translation>Синусоидальный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="668"/>
        <source>Ease In Quadratic</source>
        <translation>Квадратный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="684"/>
        <source>Ease In Cubic</source>
        <translation>Кубический</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="700"/>
        <source>Ease In Quartic</source>
        <translation>Четвертной</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="716"/>
        <source>Ease In Quintic</source>
        <translation>Квинтовый</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="732"/>
        <source>Ease In Exponential</source>
        <translation>Экспонентный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="748"/>
        <source>Ease In Circular</source>
        <translation>Круговой</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="764"/>
        <source>Ease In Back</source>
        <translation>Обратный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="788"/>
        <source>Ease In Elastic</source>
        <translation>Пружинящий</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="812"/>
        <source>Ease In Bounce</source>
        <translation>Подпрыгивающий</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="828"/>
        <source>Ease In/Out Sinusoidal</source>
        <translation>Синусоидальный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="845"/>
        <source>Ease In/Out Quadratic</source>
        <translation>Квадратный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="862"/>
        <source>Ease In/Out Cubic</source>
        <translation>Кубический</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="879"/>
        <source>Ease In/Out Quartic</source>
        <translation>Четвертной</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="896"/>
        <source>Ease In/Out Quintic</source>
        <translation>Квинтовый</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="913"/>
        <source>Ease In/Out Exponential</source>
        <translation>Экспонентный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="930"/>
        <source>Ease In/Out Circular</source>
        <translation>Круговой</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="947"/>
        <source>Ease In/Out Back</source>
        <translation>Обратный</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="972"/>
        <source>Ease In/Out Elastic</source>
        <translation>Пружинящий</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="997"/>
        <source>Ease In/Out Bounce</source>
        <translation>Подпрыгивающий</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1014"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1025"/>
        <source>Rebuild Audio Waveform</source>
        <translation>Воссоздать звуковую осциллограмму</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1037"/>
        <source>Seek Previous Keyframe</source>
        <translation>Перейти к предыдущему ключевому кадру</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1053"/>
        <source>Seek Next Keyframe</source>
        <translation>Перейти к следующему ключевому кадру</translation>
    </message>
    <message>
        <location filename="../src/docks/keyframesdock.cpp" line="1069"/>
        <source>Toggle Keyframe At Playhead</source>
        <translation>Переключить ключевой кадр в начале воспроизведения</translation>
    </message>
</context>
<context>
    <name>KeyframesModel</name>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="74"/>
        <source>Hold</source>
        <translation>Удержание</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="71"/>
        <source>Linear</source>
        <translation>Линейная</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="80"/>
        <location filename="../src/models/keyframesmodel.cpp" line="174"/>
        <source>Smooth</source>
        <translation>Плавная</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="83"/>
        <source>Ease In Sinusoidal</source>
        <translation>Синусоидальный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="86"/>
        <source>Ease Out Sinusoidal</source>
        <translation>Синусоидальный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="89"/>
        <source>Ease In/Out Sinusoidal</source>
        <translation>Синусоидальный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="92"/>
        <source>Ease In Quadratic</source>
        <translation>Квадратный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="95"/>
        <source>Ease Out Quadratic</source>
        <translation>Квадратный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="98"/>
        <source>Ease In/Out Quadratic</source>
        <translation>Квадратный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="101"/>
        <source>Ease In Cubic</source>
        <translation>Кубический</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="104"/>
        <source>Ease Out Cubic</source>
        <translation>Кубический</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="107"/>
        <source>Ease In/Out Cubic</source>
        <translation>Кубический</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="110"/>
        <source>Ease In Quartic</source>
        <translation>Четвертной</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="113"/>
        <source>Ease Out Quartic</source>
        <translation>Четвертной</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="116"/>
        <source>Ease In/Out Quartic</source>
        <translation>Четвертной</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="119"/>
        <source>Ease In Quintic</source>
        <translation>Квинтовый</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="122"/>
        <source>Ease Out Quintic</source>
        <translation>Квинтовый</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="125"/>
        <source>Ease In/Out Quintic</source>
        <translation>Квинтовый</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="128"/>
        <source>Ease In Exponential</source>
        <translation>Экспонентный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="131"/>
        <source>Ease Out Exponential</source>
        <translation>Экспонентный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="134"/>
        <source>Ease In/Out Exponential</source>
        <translation>Экспонентный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="137"/>
        <source>Ease In Circular</source>
        <translation>Круговой</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="140"/>
        <source>Ease Out Circular</source>
        <translation>Круговой</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="143"/>
        <source>Ease In/Out Circular</source>
        <translation>Круговой</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="146"/>
        <source>Ease In Back</source>
        <translation>Обратный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="149"/>
        <source>Ease Out Back</source>
        <translation>Обратный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="152"/>
        <source>Ease In/Out Back</source>
        <translation>Обратный</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="155"/>
        <source>Ease In Elastic</source>
        <translation>Пружинящий</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="158"/>
        <source>Ease Out Elastic</source>
        <translation>Пружинящий</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="161"/>
        <source>Ease In/Out Elastic</source>
        <translation>Пружинящий</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="164"/>
        <source>Ease In Bounce</source>
        <translation>Подпрыгивающий</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="167"/>
        <source>Ease Out Bounce</source>
        <translation>Подпрыгивающий</translation>
    </message>
    <message>
        <location filename="../src/models/keyframesmodel.cpp" line="170"/>
        <source>Ease In/Out Bounce</source>
        <translation>Подпрыгивающий</translation>
    </message>
</context>
<context>
    <name>LissajousWidget</name>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="26"/>
        <source>Lissajous</source>
        <translation>Лиссажу</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="41"/>
        <source>X Ratio</source>
        <translation>Х-коэффициент</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="106"/>
        <source>Y Ratio</source>
        <translation>Y-коэффициент</translation>
    </message>
</context>
<context>
    <name>ListSelectionDialog</name>
    <message>
        <location filename="../src/dialogs/listselectiondialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Диалог</translation>
    </message>
</context>
<context>
    <name>LumaMixTransition</name>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="25"/>
        <source>Transition</source>
        <translation>Переход</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="351"/>
        <source>Preview</source>
        <translation>Предпросмотр</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="360"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="92"/>
        <source>Dissolve</source>
        <translation>Растворение</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="97"/>
        <source>Cut</source>
        <translation>Нарезка с заголовком</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="107"/>
        <source>Bar Horizontal</source>
        <translation>Горизонтальные полосы</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="112"/>
        <source>Bar Vertical</source>
        <translation>Вертикальные полосы</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="117"/>
        <source>Barn Door Horizontal</source>
        <translation>Горизонтальные жалюзи</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="122"/>
        <source>Barn Door Vertical</source>
        <translation>Вертикальные жалюзи</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="127"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Диагональные жалюзи слева снизу</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="132"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Диагональные жалюзи слева сверху</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="137"/>
        <source>Diagonal Top Left</source>
        <translation>Диагональ верхний левый</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="142"/>
        <source>Diagonal Top Right</source>
        <translation>Диагональ верхний правый</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="147"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Матрица водопад горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="152"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Матрица водопад вертикальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="157"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Матрица змейка горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="162"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Матрица змейка параллельная горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="167"/>
        <source>Matrix Snake Vertical</source>
        <translation>Матрица змейка вертикальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="172"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Матрица змейка параллельная вертикальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="177"/>
        <source>Barn V Up</source>
        <translation>Жалюзи углом вверх</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="182"/>
        <source>Iris Circle</source>
        <translation>Круг диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="187"/>
        <source>Double Iris</source>
        <translation>Двойной круг диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="192"/>
        <source>Iris Box</source>
        <translation>Вставка диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="197"/>
        <source>Box Bottom Right</source>
        <translation>Вставка снизу справа</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="202"/>
        <source>Box Bottom Left</source>
        <translation>Вставка снизу слева</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="207"/>
        <source>Box Right Center</source>
        <translation>Вставка справа по центру</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="212"/>
        <source>Clock Top</source>
        <translation>Циферблат по часовой стрелке</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="370"/>
        <source>Get custom transitions on our Web site.</source>
        <translation>Получить пользовательские переходы на нашем сайте.</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="102"/>
        <source>Custom...</source>
        <translation>Пользовательский...</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="243"/>
        <source>TextLabel</source>
        <translation>ТекстоваяМетка</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="341"/>
        <source>Swap the appearance of the A and B clips</source>
        <translation>Поменять местами клипы А и В</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="344"/>
        <source>Invert Wipe</source>
        <translation>Инвертировать ластик</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="39"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="234"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="240"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="261"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="265"/>
        <source>Softness</source>
        <translation>Мягкость</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="52"/>
        <source>Change the softness of the edge of the wipe</source>
        <translation>Изменить мягкость края ластика</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="68"/>
        <location filename="../src/widgets/lumamixtransition.ui" line="311"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="222"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="232"/>
        <source>Save the custom transition as a favorite</source>
        <translation>Сохранить пользовательский переход в избранное</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="252"/>
        <source>Automatically fade-out the audio of clip A
and fade-in the audio of clip B over the
duration of the transition.</source>
        <translation>Автоматическое затухание звука из клипа А
и нарастание звука из клипа Б при переходе.</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="257"/>
        <source>Cross-fade</source>
        <translation>Плавный переход</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="271"/>
        <source>Do not alter the audio levels during the
course of the transition. Instead, set a
fixed mixing level, or choose only clip A&apos;s
audio (0%) or clip B&apos;s audio (100%).</source>
        <translation>Не менять уровни аудио при переходе.
Вместо этого установить фиксированный уровень
микширования или выбрать только аудио из клипа A (0%)
или из клипа B (100%).</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="277"/>
        <source>Mix:</source>
        <translation>Микшировать:</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="287"/>
        <source>A</source>
        <translation>А</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="304"/>
        <source>B</source>
        <translation>Б</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="64"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="237"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="106"/>
        <source>Preview Not Available</source>
        <translation>Предпросмотр недоступен</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="247"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Shotcut</source>
        <translation>Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>&amp;View</source>
        <translation>&amp;Вид</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Layout</source>
        <translation>Оформление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>&amp;Edit</source>
        <translation>&amp;Правка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>&amp;Help</source>
        <translation>&amp;Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="145"/>
        <source>Audio Channels</source>
        <translation>Каналы аудио</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="246"/>
        <source>Deinterlacer</source>
        <translation>Деинтерлейсер</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="256"/>
        <source>Interpolation</source>
        <translation>Интерполяция</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="154"/>
        <source>Video Mode</source>
        <translation>Режим видео</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="265"/>
        <source>External Monitor</source>
        <translation>Внешний монитор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="160"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="165"/>
        <source>Theme</source>
        <translation>Тема</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="173"/>
        <source>Display Method</source>
        <translation>Метод отображения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="199"/>
        <source>App Data Directory</source>
        <translation>Папка с данными приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="206"/>
        <source>Preview Scaling</source>
        <translation>Масштаб предпросмотра</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="224"/>
        <source>Proxy</source>
        <translation>Прокси</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Storage</source>
        <translation>Хранилище</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Toolbar</source>
        <translation>Панель инструментов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="378"/>
        <source>&amp;Open File...</source>
        <translation>&amp;Открыть файл...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>E&amp;xit</source>
        <translation>В&amp;ыход</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="395"/>
        <source>Quit the application</source>
        <translation>Выход из приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <source>&amp;About Shotcut</source>
        <translation>&amp;О приложении Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>About Qt</source>
        <translation>О фреймворке Qt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="419"/>
        <source>Open Other...</source>
        <translation>Открыть прочее...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="422"/>
        <source>Open a device, stream or generator</source>
        <translation>Открыть устройство, поток или генератор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="437"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <source>Save project as a MLT XML file</source>
        <translation>Сохранить проект как файл MLT XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>Save &amp;As...</source>
        <translation>Сохранить &amp;как...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="454"/>
        <source>Save project to a different MLT XML file</source>
        <translation>Сохранить проект как другой файл MLT XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="51"/>
        <location filename="../src/mainwindow.ui" line="466"/>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Export</source>
        <translation>Экспорт</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Job Priority</source>
        <translation>Приоритет заданий</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="478"/>
        <source>&amp;Undo</source>
        <translation>&amp;Отменить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="487"/>
        <source>&amp;Redo</source>
        <translation>В&amp;ернуть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="492"/>
        <source>Forum...</source>
        <translation>Форум...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="497"/>
        <source>FAQ...</source>
        <translation>ЧАВО...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="506"/>
        <location filename="../src/mainwindow.cpp" line="3922"/>
        <source>Enter Full Screen</source>
        <translation>Полноэкранный режим</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="518"/>
        <source>Peak Meter</source>
        <translation>Измеритель пиков</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="530"/>
        <location filename="../src/mainwindow.cpp" line="401"/>
        <location filename="../src/mainwindow.cpp" line="2408"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <location filename="../src/mainwindow.cpp" line="2417"/>
        <source>Recent</source>
        <translation>Недавние</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <location filename="../src/mainwindow.ui" line="548"/>
        <source>Playlist</source>
        <translation>Список воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <source>History</source>
        <translation>История</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="568"/>
        <source>Realtime (frame dropping)</source>
        <translation>В настоящем времени (пропуск кадров)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="579"/>
        <source>Progressive</source>
        <translation>Последовательный</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="587"/>
        <source>GPU Effects (unstable)</source>
        <translation>Эффекты ГП (нестабильно)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="590"/>
        <source>Use GPU filters</source>
        <translation>Использовать фильтры ГП</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="601"/>
        <source>1 (mono)</source>
        <translation>1 (моно)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="609"/>
        <source>2 (stereo)</source>
        <translation>2 (стерео)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="636"/>
        <source>One Field (fast)</source>
        <translation>Одно поле (быстро)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="644"/>
        <source>Linear Blend (fast)</source>
        <translation>Линейное наложение (быстро)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="652"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF - только временной (хорошо)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>Ближайший сосед (быстро)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="687"/>
        <source>Bilinear (good)</source>
        <translation>Билинейная (хорошо)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="695"/>
        <source>Bicubic (better)</source>
        <translation>Бикубическая (лучшее)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="714"/>
        <location filename="../src/mainwindow.ui" line="847"/>
        <location filename="../src/mainwindow.cpp" line="2613"/>
        <source>Automatic</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="725"/>
        <location filename="../src/mainwindow.ui" line="1191"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="733"/>
        <source>Use JACK Audio</source>
        <translation>Использовать JACK-аудио</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="742"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <source>Filters</source>
        <translation>Фильтры</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <source>Add...</source>
        <translation>Добавить...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="758"/>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="761"/>
        <source>Use the user or platform style, colors, and icons.</source>
        <translation>Использовать пользовательские или системные стили, цвета и значки.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="769"/>
        <source>Fusion Dark</source>
        <translation>Тёмный Fusion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="777"/>
        <source>Fusion Light</source>
        <translation>Светлый Fusion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="782"/>
        <source>Tutorials...</source>
        <translation>Уроки...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <location filename="../src/mainwindow.ui" line="791"/>
        <location filename="../src/mainwindow.cpp" line="2427"/>
        <source>Timeline</source>
        <translation>Шкала времени</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="796"/>
        <location filename="../src/mainwindow.ui" line="799"/>
        <source>Restore Default Layout</source>
        <translation>Восстановить оформление по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="807"/>
        <source>Show Title Bars</source>
        <translation>Показать заголовки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="815"/>
        <source>Show Toolbar</source>
        <translation>Показать панель инструментов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="820"/>
        <source>Upgrade...</source>
        <translation>Обновление...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="825"/>
        <source>Open MLT XML As Clip...</source>
        <translation>Открыть MLT XML как клип...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="828"/>
        <source>Open a MLT XML project file as a virtual clip</source>
        <translation>Открыть файл проекта MLT XML как виртуальный клип</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="836"/>
        <source>Scrub Audio</source>
        <translation>Прокручивать аудио в начало при перетаскивании бегунка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="871"/>
        <source>Software (Mesa)</source>
        <extracomment>Do not translate &quot;Mesa&quot;</extracomment>
        <translation>Программный (Mesa)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <source>Low</source>
        <translation>Низкий</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="887"/>
        <source>Normal</source>
        <translation>Обычный</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="897"/>
        <source>Application Log...</source>
        <translation>Журнал приложения...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="905"/>
        <location filename="../src/mainwindow.ui" line="996"/>
        <location filename="../src/mainwindow.ui" line="999"/>
        <source>Project</source>
        <translation>Проект</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="1329"/>
        <source>Player</source>
        <translation>Проигрыватель</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="913"/>
        <source>User Interface</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="921"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1144"/>
        <source>Notes</source>
        <translation>Заметки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1358"/>
        <source>Markers as Chapters...</source>
        <translation>Маркеры серией...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1361"/>
        <location filename="../src/mainwindow.ui" line="1364"/>
        <location filename="../src/mainwindow.cpp" line="5861"/>
        <source>Export Chapters</source>
        <translation>Экспорт глав</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1369"/>
        <source>Audio/Video Device...</source>
        <translation>Звуковое/видео устройство...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="971"/>
        <location filename="../src/mainwindow.ui" line="1269"/>
        <source>Set...</source>
        <translation>Задать...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Other Versions</source>
        <translation>Другие Версии</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>&amp;Player</source>
        <translation>&amp;Проигрыватель</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="141"/>
        <source>&amp;Settings</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Time Format</source>
        <translation>Формат Времени</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Backup</source>
        <translation>Резервная копия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="381"/>
        <source>Open a video, audio, image, or project file</source>
        <translation>Открыть видео, звуковую дорожку, изображение или файл проекта</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="521"/>
        <source>Audio Peak Meter</source>
        <translation>Измеритель пиков звука</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="617"/>
        <source>4 (quad/Ambisonics)</source>
        <translation>4 (квад/Амбисоник)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="625"/>
        <source>6 (5.1 surround)</source>
        <translation>6 (5.1 окружение)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="660"/>
        <source>YADIF - temporal + spatial (better)</source>
        <translation>YADIF - временной + пространственный (лучше)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="668"/>
        <source>BWDIF (best)</source>
        <translation>BWDIF (лучший)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Lanczos (best)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="892"/>
        <source>Resources...</source>
        <translation>Источники...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="976"/>
        <location filename="../src/mainwindow.ui" line="1277"/>
        <source>Show...</source>
        <translation>Показать...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="979"/>
        <source>Show</source>
        <translation>Показать</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="988"/>
        <location filename="../src/mainwindow.ui" line="991"/>
        <source>Keyframes</source>
        <translation>Ключевые кадры</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1002"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1018"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1021"/>
        <source>Switch to the audio layout</source>
        <translation>Переключиться в режим звука</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1024"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1032"/>
        <source>Logging</source>
        <translation>Журнал</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1035"/>
        <source>Switch to the logging layout</source>
        <translation>Переключиться на журнал</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1038"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1046"/>
        <source>Editing</source>
        <translation>Редактор</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1049"/>
        <source>Switch to the editing layout</source>
        <translation>Переключиться в режим правки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1052"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1060"/>
        <source>FX</source>
        <translation>Эффекты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <source>Switch to the effects layout</source>
        <translation>Переключиться в режим эффектов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1066"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <source>New Generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1135"/>
        <source>Markers</source>
        <translation>Метки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1153"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1183"/>
        <source>1080p</source>
        <translation type="unfinished">1080p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Timecode (Drop-Frame)</source>
        <translation>Временной код (с пропуском кадров)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1221"/>
        <source>Frames</source>
        <translation>Кадров</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1229"/>
        <source>Clock</source>
        <translation>Часы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1237"/>
        <source>Timecode (Non-Drop Frame)</source>
        <translation>Временной код (без пропусков кадров)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1242"/>
        <source>Topics</source>
        <translation>Статьи</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1250"/>
        <source>Synchronization...</source>
        <translation>Синхронизация...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1253"/>
        <source>Synchronization</source>
        <translation>Синхронизация</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Use Proxy</source>
        <translation>Использовать прокси</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1272"/>
        <source>Set the proxy storage folder</source>
        <translation>Задать папку хранения прокси</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1280"/>
        <source>Show the proxy storage folder</source>
        <translation>Показать папку хранения прокси</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1291"/>
        <source>Use Project Folder</source>
        <translation>Использовать папку проекта</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1294"/>
        <source>Store proxies in the project folder if defined</source>
        <translation>Хранить прокси в папке проекта, если она задана</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1302"/>
        <source>Use Hardware Encoder</source>
        <translation>Использовать аппаратное кодирование</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1307"/>
        <source>Configure Hardware Encoder...</source>
        <translation>Настроить аппаратное кодирование...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1318"/>
        <source>Switch to the color layout</source>
        <translation>Переключиться в режим цвета</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1321"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1332"/>
        <source>Switch to the player only layout</source>
        <translation>Переключиться в режим только с проигрывателем</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1335"/>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1348"/>
        <source>Playlist Project</source>
        <translation>Проект списка воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1353"/>
        <source>Clip-only Project</source>
        <translation>Проект клипа</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1374"/>
        <source>Reset...</source>
        <translation>Сброс…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1379"/>
        <location filename="../src/mainwindow.ui" line="1382"/>
        <source>Backup and Save</source>
        <translation>Backup and Save</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1393"/>
        <source>Manually</source>
        <translation>Вручную</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1401"/>
        <source>Hourly</source>
        <translation>Почасовой</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1409"/>
        <source>Daily</source>
        <translation>Ежедневный</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1420"/>
        <source>Weekly</source>
        <translation>Еженедельно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1425"/>
        <source>Show Project in Folder</source>
        <translation>Показать проект в папке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1436"/>
        <source>Pause After Seek</source>
        <translation>Пауза после перехода</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1445"/>
        <source>Files</source>
        <translation>Файлы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1076"/>
        <location filename="../src/mainwindow.ui" line="1081"/>
        <source>Remove...</source>
        <translation>Удалить...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="509"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="932"/>
        <source>EDL...</source>
        <translation>EDL...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="943"/>
        <source>Frame...</source>
        <translation>Кадр…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <source>Video...</source>
        <translation>Видео…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="960"/>
        <location filename="../src/mainwindow.ui" line="963"/>
        <source>Export Video</source>
        <translation>Экспорт видео</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1007"/>
        <source>Actions and Shortcuts...</source>
        <translation>Действия и горячие клавиши…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <source>Clear Recent on Exit</source>
        <translation>Очищать недавние при выходе</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <source>Show Text Under Icons</source>
        <translation>Текст под значками</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1117"/>
        <source>Show Small Icons</source>
        <translation>Маленькие значки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1126"/>
        <source>Jobs</source>
        <translation>Задания</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1161"/>
        <source>540p</source>
        <translation>540p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1172"/>
        <source>720p</source>
        <translation>720p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1202"/>
        <source>360p</source>
        <translation>360p</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <source>Error: This program requires the SDL 2 library.

Please install it using your package manager. It may be named libsdl2-2.0-0, SDL2, or similar.</source>
        <translation>ОШИБКА: Для работы необходима библиотека SDL 2.

Установите её с помощью пакетного менеджера. Она может называться libsdl2-2.0-0, SDL2 или т.п.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1162"/>
        <source>Screen %1 (%2 x %3 @ %4 Hz)</source>
        <translation>Экран %1 (%2 x %3 @ %4 Гц)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1198"/>
        <source>Off</source>
        <translation>Откл.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1201"/>
        <source>Internal</source>
        <translation>Внутренний</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1204"/>
        <source>External</source>
        <translation>Внешний</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1227"/>
        <source>DeckLink Keyer</source>
        <translation>Плата DeckLink</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1315"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1491"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1498"/>
        <source>Animation</source>
        <translation>Анимация</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1503"/>
        <source>Noise</source>
        <translation>Шум</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1508"/>
        <source>Color Bars</source>
        <translation>Цветовые шкалы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1513"/>
        <source>Audio Tone</source>
        <translation>Тембр звука</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1518"/>
        <source>Count</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1523"/>
        <source>Blip Flash</source>
        <translation>Генератор вспышек</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1548"/>
        <location filename="../src/mainwindow.cpp" line="1550"/>
        <location filename="../src/mainwindow.cpp" line="1988"/>
        <location filename="../src/mainwindow.cpp" line="1996"/>
        <location filename="../src/mainwindow.cpp" line="2019"/>
        <location filename="../src/mainwindow.cpp" line="2079"/>
        <location filename="../src/mainwindow.cpp" line="4659"/>
        <location filename="../src/mainwindow.cpp" line="4672"/>
        <location filename="../src/mainwindow.cpp" line="5637"/>
        <source>Failed to open </source>
        <translation>Не удалось открыть </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1583"/>
        <source>The file you opened uses GPU effects, but GPU effects are not enabled.</source>
        <translation>В открытом вами файле используются эффекты графического процессора, но эффекты графического процессора не включены.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1595"/>
        <source>The file you opened uses CPU effects that are incompatible with GPU effects, but GPU effects are enabled.
Do you want to disable GPU effects and restart?</source>
        <translation>Этот файл использует эффекты ЦП, несовместимые со включёнными эффектами ГП.
Хотите отключить эффекты ГП и выполнить перезапуск?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1618"/>
        <source>Repaired</source>
        <translation>Восстановлено</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1619"/>
        <source>Save Repaired XML</source>
        <translation>Сохранить восстановленный XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1656"/>
        <source>Repairing the project failed.</source>
        <translation>Восстановление проекта не удалось.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1669"/>
        <source>Shotcut noticed some problems in your project.
Do you want Shotcut to try to repair it?

If you choose Yes, Shotcut will create a copy of your project
with &quot;- Repaired&quot; in the file name and open it.</source>
        <translation>В проекте Shotcut обнаружены проблемы .
Хотите попробовать их устранить?

При выборе &quot;Да&quot; будет создана и открыта копия 
проекта с суффиксом &quot;- Repaired&quot; в имени файла.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1704"/>
        <source>Auto-saved files exist. Do you want to recover them now?</source>
        <translation>Обнаружены автосохранённые файлы. Восстановить их?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1776"/>
        <source>You cannot add a project to itself!</source>
        <translation>Невозможно добавить проект сам в себя!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1814"/>
        <source>There was an error saving. Please try again.</source>
        <translation>Ошибка при сохранении. Попробуйте ещё раз.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1899"/>
        <source>This project file requires a newer version!

It was made with version </source>
        <translation>Этому проекту требуется более новая версия!

Он сделан с другой версией </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1930"/>
        <source>You are running low on available memory!

Please close other applications or web browser tabs and retry.
Or save and restart Shotcut.</source>
        <translation>У вас мало доступной памяти!

Закройте другие приложения или вкладки браузера и повторите попытку.
Или сохраните и перезапустите Shotcut.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1982"/>
        <source>Opening %1</source>
        <translation>Открытие %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2121"/>
        <location filename="../src/mainwindow.cpp" line="4646"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2123"/>
        <source>All Files (*);;MLT XML (*.mlt)</source>
        <translation>Все файлы (*);;MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2391"/>
        <source>Preferences</source>
        <translation>Preferences</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2401"/>
        <source>Rename Clip</source>
        <translation>Переименовать клип</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2410"/>
        <source>Find</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2419"/>
        <source>Reload</source>
        <translation>Перезагрузить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2429"/>
        <source>Rerun Filter Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="2443"/>
        <source>This will start %n analysis job(s). Continue?</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2461"/>
        <source>No filters to analyze.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2602"/>
        <source>Untitled</source>
        <translation>Без названия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2607"/>
        <source>%1x%2 %3fps %4ch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2634"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2763"/>
        <source>Non-Broadcast</source>
        <translation>Невещательные</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2768"/>
        <source>DVD Widescreen NTSC</source>
        <translation>DVD Широкоэкранный NTSC</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2769"/>
        <source>DVD Widescreen PAL</source>
        <translation>DVD Широкоэкранный PAL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2780"/>
        <source>Square 1080p 30 fps</source>
        <translation>Широкоэкранное 1080p 30 кадров/с</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2781"/>
        <source>Square 1080p 60 fps</source>
        <translation>Широкоэкранное 1080p 60 кадров/с</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2782"/>
        <source>Vertical HD 30 fps</source>
        <translation>Вертикальное HD 30 кадров/с</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2783"/>
        <source>Vertical HD 60 fps</source>
        <translation>Вертикальное HD 60 кадров/с</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2784"/>
        <source>Custom</source>
        <translation>Пользовательские настройки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2815"/>
        <location filename="../src/mainwindow.cpp" line="3110"/>
        <source>Saved %1</source>
        <translation>Сохранён %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3101"/>
        <location filename="../src/mainwindow.cpp" line="3124"/>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <source>Save XML</source>
        <translation>Сохранить XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3220"/>
        <source>Timeline is not loaded</source>
        <translation>Шкала времени не загружена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3230"/>
        <source>Range marker not found under the timeline cursor</source>
        <translation>Диапазон не найден под курсором на шкале времени</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3295"/>
        <source>There are incomplete jobs.
Do you still want to exit?</source>
        <translation>Есть незавершённые задания.
Вы все еще хотите выйти?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3307"/>
        <source>An export is in progress.
Do you still want to exit?</source>
        <translation>Сейчас выполняется экспорт.
Вы все еще хотите выйти?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4448"/>
        <source>Saved backup %1</source>
        <translation>Saved backup %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3186"/>
        <source>Do you also want to change the Video Mode to %1 x %2?</source>
        <translation>Хотите ли вы изменить Видео на %1 x %2?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4101"/>
        <source>Opened Files</source>
        <translation>Открытые файлы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4183"/>
        <source>GPU effects are experimental and do not work good on all computers. Plan to do some testing after turning this on.
At this time, a project created with GPU effects cannot be converted to a CPU-only project later.

Do you want to enable GPU effects and restart Shotcut?</source>
        <translation>Эффекты графического процессора являются экспериментальными и хорошо работают не на всех компьютерах. Запланируйте провести некоторое тестирование включения этого устройства.
В настоящее время проект, созданный с эффектами графического процессора, не может быть позже преобразован в проект, предназначенный только для ЦП.

Вы хотите включить эффекты графического процессора и перезапустить Shotcut?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5281"/>
        <source>Add To Timeline</source>
        <translation>Добавить на шкалу времени</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5837"/>
        <source>Include ranges (Duration &gt; 1 frame)?</source>
        <translation>Включить диапазоны (Продолжительность &gt; 1 кадра)?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5848"/>
        <source>Choose Markers</source>
        <translation>Выбрать Маркеры</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5865"/>
        <source>Text (*.txt);;All Files (*)</source>
        <translation>Текст (*.txt);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5920"/>
        <source>Failed to open export-chapters.js</source>
        <translation>Не удалось открыть export-chapters.js</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5961"/>
        <source>This will reset &lt;b&gt;all&lt;/b&gt; settings, and Shotcut must restart afterwards.
Do you want to reset and restart now?</source>
        <translation>Это сбросит &lt;b&gt;все&lt;/b&gt; настройки, а затем Shotcut должен перезапуститься.
Хотите сбросить и перезапустить сейчас?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1623"/>
        <location filename="../src/mainwindow.cpp" line="3128"/>
        <source>MLT XML (*.mlt)</source>
        <translation>MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <source>View Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3268"/>
        <source>The project has been modified.
Do you want to save your changes?</source>
        <translation>Проект был изменён.
Сохранить изменения?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3925"/>
        <source>Exit Full Screen</source>
        <translation>Выйти из полноэкранного режима</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <source>Turn Proxy On</source>
        <translation>Включить прокси</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <source>Turn Proxy Off</source>
        <translation>Выключить прокси</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5601"/>
        <source>Converting</source>
        <translation>Преобразование</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5617"/>
        <source>Do you want to create missing proxies for every file in this project?

You must reopen your project after all proxy jobs are finished.</source>
        <translation>Вы хотите создать недостающие прокси для каждого файла в этом проекте?

После всех изменений в прокси закройте и откройте проект заново.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5655"/>
        <source>Proxy Folder</source>
        <translation>Папка прокси</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5673"/>
        <source>Do you want to move all files from the old folder to the new folder?</source>
        <translation>Вы хотите переместить все файлы из старой папки в новую?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5681"/>
        <source>Moving Files</source>
        <translation>Перемещение файлов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3937"/>
        <source>GPU effects are not supported</source>
        <translation>GPU эффекты не поддерживаются</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>Set Loop Range</source>
        <translation>Выбрать диапозон</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="474"/>
        <source>Thumbnails</source>
        <translation>Миниатюры</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <source>Scrolling</source>
        <translation>Scrolling</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1043"/>
        <source>Audio API</source>
        <translation>Аудио API</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1064"/>
        <source>default</source>
        <translation>по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1071"/>
        <source>You must restart Shotcut to change the audio API.
Do you want to restart now?</source>
        <translation>Вы должны перезапустить Shotcut, чтобы изменить аудио API.
Вы хотите перезапустить сейчас?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1189"/>
        <source>SDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>HLG HDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>DeckLink Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3957"/>
        <source>Click here to check for a new version of Shotcut.</source>
        <translation>Нажмите здесь, чтобы проверить наличие новой версии Shotcut.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4072"/>
        <source>Open Files</source>
        <translation>Открыть файлы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4131"/>
        <source>You must restart Shotcut to switch to the new language.
Do you want to restart now?</source>
        <translation>Чтобы переключить язык, нужно перезапустить Shotcut.
Перезапустить сейчас?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4174"/>
        <source>Failed to connect to JACK.
Please verify that JACK is installed and running.</source>
        <translation>Не удалось подключиться к библиотеке JACK.
Убедитесь, что JACK установлена и запущена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4203"/>
        <source>Shotcut must restart to disable GPU effects.

Disable GPU effects and restart?</source>
        <translation>Для отключения эффектов ГП нужно перезапустить Shotcut.

Отключить эффекты ГП и выполнить перезапуск?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4425"/>
        <source>You must restart %1 to switch to the new theme.
Do you want to restart now?</source>
        <translation>Вы должны перезапустить %1, чтобы переключиться на новую тему.
Вы хотите перезапустить сейчас?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4468"/>
        <source>&lt;p&gt;Please review your entire project after making this change.&lt;/p&gt;&lt;p&gt;Shotcut does not automatically adjust things that are sensitive to size and position if you change resolution or aspect ratio.&lt;/p&lt;br&gt;The timing of edits and keyframes may be slightly different if you change frame rate.&lt;/p&gt;&lt;p&gt;It is a good idea to use &lt;b&gt;File &gt; Backup and Save&lt;/b&gt; before or after this operation.&lt;/p&gt;&lt;p&gt;Do you want to change the &lt;b&gt;Video Mode&lt;/b&gt; now?&lt;/p&gt;</source>
        <translation>&lt;p&gt;Пожалуйста, просмотрите весь свой проект после внесения этого изменения.&lt;/p&gt;&lt;p&gt;Программа Shotcut не выполняет автоматическую настройку объектов, чувствительных к размеру и положению, при изменении разрешения или соотношения сторон.&lt;/p&lt;br&gt;При изменении частоты кадров время редактирования и ключевых кадров может немного отличаться.&lt;/p&gt;&lt;p&gt;Хороший совет использовать&lt;b&gt;Файл &gt; Резервное копирование и сохранение&lt;/b&gt; до или после этой операции.&lt;/p&gt;&lt;p&gt;Хотите ли вы изменить режим &lt;b&gt;видеозаписи&lt;/b&gt; сейчас?&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4482"/>
        <source>Do not show this anymore.</source>
        <comment>Change video mode warning dialog</comment>
        <translation>Больше не показывать.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4493"/>
        <source>Shotcut must restarto change external monitoring.
Do you want to restart now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4623"/>
        <source>Do you want to automatically check for updates in the future?</source>
        <translation>Хотите проверять обновления автоматически?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4630"/>
        <source>Do not show this anymore.</source>
        <comment>Automatic upgrade check dialog</comment>
        <translation>Больше не показывать.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4648"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4702"/>
        <source>You must restart Shotcut to change the display method.
Do you want to restart now?</source>
        <translation>Чтобы переключить метод отображения, нужно перезапустить Shotcut .
Перезапустить программу сейчас?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4732"/>
        <source>Application Log</source>
        <translation>Журнал программы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4735"/>
        <source>Previous</source>
        <translation>Предыдущий</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4797"/>
        <source>Shotcut version %1 is available! Click here to get it.</source>
        <translation>Доступен Shotcut %1! Нажмите для получения.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <source>You are running the latest version of Shotcut.</source>
        <translation>У вас самая новая версия Shotcut.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4817"/>
        <source>Failed to read version.json when checking. Click here to go to the Web site.</source>
        <translation>Не удалось прочитать version.json при проверке. Нажмите здесь, чтобы перейти на сайт.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="935"/>
        <location filename="../src/mainwindow.ui" line="938"/>
        <location filename="../src/mainwindow.cpp" line="4837"/>
        <source>Export EDL</source>
        <translation>Экспорт EDL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4841"/>
        <source>EDL (*.edl);;All Files (*)</source>
        <translation>EDL (*.edl);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4888"/>
        <location filename="../src/mainwindow.cpp" line="5917"/>
        <source>A JavaScript error occurred during export.</source>
        <translation>Ошибка JavaScript при экспорте.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4891"/>
        <source>Failed to open export-edl.js</source>
        <translation>Не удалось открыть export-edl.js</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4922"/>
        <source>Export frame from proxy?</source>
        <translation>Экспортировать кадр из прокси?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4923"/>
        <source>This frame may be from a lower resolution proxy instead of the original source.

Do you still want to continue?</source>
        <translation>Этот кадр может быть с более низким разрешением из прокси вместо исходного источника.

Вы все еще хотите продолжить?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="946"/>
        <location filename="../src/mainwindow.ui" line="949"/>
        <location filename="../src/mainwindow.cpp" line="4935"/>
        <source>Export Frame</source>
        <translation>Экспорт кадра</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4941"/>
        <source>Unable to export frame.</source>
        <translation>Невозможно экспортировать кадр.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4949"/>
        <source>You must restart Shotcut to change the data directory.
Do you want to continue?</source>
        <translation>Чтобы изменить папку с данными, нужно перезапустить Shotcut. Перезапустить программу сейчас?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4960"/>
        <source>Data Directory</source>
        <translation>Папка с данными</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5170"/>
        <source>Add Custom Layout</source>
        <translation>Добавить своё оформление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5171"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5210"/>
        <source>Remove Video Mode</source>
        <translation>Удалить Видеорежим</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5227"/>
        <source>Remove Layout</source>
        <translation>Удалить оформление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5381"/>
        <source>GPU effects are EXPERIMENTAL, UNSTABLE and UNSUPPORTED! Unsupported means do not report bugs about it.

Do you want to disable GPU effects and restart Shotcut?</source>
        <translation>Эффекты ГП - ЭКСПЕРИМЕНТАЛЬНЫЕ, НЕСТАБИЛЬНЫЕ и НЕ ПОДДЕРЖИВАЮТСЯ! Пожалуйста, не присылайте связанные с ними отчёты об ошибках.

Хотите отключить эффекты ГП и перезапустить Shotcut?</translation>
    </message>
</context>
<context>
    <name>MarkersDock</name>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="129"/>
        <source>Markers</source>
        <translation>Метки</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="200"/>
        <source>Add a marker at the current time</source>
        <translation>Добавить метку в текущее время</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="209"/>
        <source>Remove the selected marker</source>
        <translation>Удалить выбранную метку</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="218"/>
        <source>Deselect the marker</source>
        <translation>Отменить выбор метки</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="191"/>
        <source>Markers Menu</source>
        <translation>Меню меток</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="165"/>
        <source>Remove All Markers</source>
        <translation>Удалить все метки</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="167"/>
        <source>Columns</source>
        <translation>Столбцы</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="168"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="171"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="174"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="177"/>
        <source>End</source>
        <translation>Конец</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="180"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="186"/>
        <source>Markers Controls</source>
        <translation>Управление метками</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="228"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/docks/markersdock.cpp" line="236"/>
        <source>Clear search</source>
        <translation>Очистить поиск</translation>
    </message>
</context>
<context>
    <name>MarkersModel</name>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="788"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="790"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="792"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="794"/>
        <source>End</source>
        <translation>Конец</translation>
    </message>
    <message>
        <location filename="../src/models/markersmodel.cpp" line="796"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
</context>
<context>
    <name>MeltJob</name>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="47"/>
        <source>View XML</source>
        <translation>Просмотр XML</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="48"/>
        <source>View the MLT XML for this job</source>
        <translation>Просмотр MLT XML для этого задания</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="57"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="59"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>Открыть выходной файл в плеере Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="63"/>
        <location filename="../src/jobs/meltjob.cpp" line="68"/>
        <location filename="../src/jobs/meltjob.cpp" line="69"/>
        <source>Show In Folder</source>
        <translation>Показать в папке</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="64"/>
        <source>Show In Files</source>
        <translation>Показать в файлах</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="192"/>
        <source>MLT XML</source>
        <translation>MLT XML</translation>
    </message>
</context>
<context>
    <name>Mlt::VideoWidget</name>
    <message>
        <location filename="../src/videowidget.cpp" line="196"/>
        <source>You cannot drag from Project.</source>
        <translation>Перетаскивание из проекта невозможно.</translation>
    </message>
    <message>
        <location filename="../src/videowidget.cpp" line="199"/>
        <source>You cannot drag a non-seekable source</source>
        <translation>Невозможно перетащить недоступный источник</translation>
    </message>
</context>
<context>
    <name>MltClipProducerWidget</name>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="47"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="53"/>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="59"/>
        <source>Frame rate</source>
        <translation>Частота кадров</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="65"/>
        <source>Scan mode</source>
        <translation>Режим сканирования</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="71"/>
        <source>Colorspace</source>
        <translation>Цветовое пространство</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="77"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="150"/>
        <source>%L1 fps</source>
        <translation>%L1 кадр/с</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="153"/>
        <source>Progressive</source>
        <translation>Последовательный</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="155"/>
        <source>Interlaced</source>
        <translation>Чересстрочный</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="202"/>
        <source>Subclip profile does not match project profile.
This may provide unexpected results</source>
        <translation>Профиль вложенного клипа не соответствует профилю проекта.
Это может привести к неожиданным результатам</translation>
    </message>
    <message>
        <location filename="../src/widgets/mltclipproducerwidget.cpp" line="207"/>
        <source>Subclip profile matches project profile.</source>
        <translation>Профиль вложенного клипа соответствует профилю проекта.</translation>
    </message>
</context>
<context>
    <name>MotionTrackerDialog</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="39"/>
        <source>Load Keyframes from Motion Tracker</source>
        <translation>Загрузка ключевых кадров с Датчика движения</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="55"/>
        <source>Motion tracker</source>
        <translation>Датчик движения</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="75"/>
        <source>Adjust</source>
        <translation>Наладка</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="92"/>
        <source>Relative Position</source>
        <translation>Относительное положение</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="96"/>
        <source>Offset Position</source>
        <translation>Положение смещения</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="100"/>
        <source>Absolute Position</source>
        <translation>Абсолютное положение</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="104"/>
        <source>Size And Position</source>
        <translation>Размер и положение</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="123"/>
        <source>From start</source>
        <translation>От начала</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="128"/>
        <source>Current position</source>
        <translation>Текущая позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="142"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="154"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/MotionTrackerDialog.qml" line="165"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>MotionTrackerModel</name>
    <message>
        <location filename="../src/models/motiontrackermodel.cpp" line="180"/>
        <source>Tracker %1</source>
        <translation>Трекер %1</translation>
    </message>
</context>
<context>
    <name>MultiFileExportDialog</name>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="63"/>
        <source>Directory</source>
        <translation>Папка</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="76"/>
        <source>Prefix</source>
        <translation>Префикс</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="77"/>
        <source>export</source>
        <translation>экспортировать</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="82"/>
        <source>Field 1</source>
        <translation>Поле 1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="92"/>
        <source>Field 2</source>
        <translation>Поле 2</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="102"/>
        <source>Field 3</source>
        <translation>Поле 3</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="113"/>
        <source>Extension</source>
        <translation>Расширение</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="207"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="208"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="209"/>
        <source>Index</source>
        <translation>Индекс</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="210"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="211"/>
        <source>Hash</source>
        <translation>Хэш</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="234"/>
        <source>Empty File Name</source>
        <translation>Пустое Имя Файла</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="236"/>
        <source>Directory does not exist: %1</source>
        <translation>Каталог не существует: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="243"/>
        <source>File Exists: %1</source>
        <translation>Файл существует: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="248"/>
        <source>Duplicate File Name: %1</source>
        <translation>Дубликат Имя файла: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="274"/>
        <source>Fix file name errors before export.</source>
        <translation>Исправьте ошибки имени файла перед экспортом.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/multifileexportdialog.cpp" line="281"/>
        <source>Export Directory</source>
        <translation>Экспорт папки</translation>
    </message>
</context>
<context>
    <name>MultitrackModel</name>
    <message>
        <location filename="../src/models/multitrackmodel.cpp" line="115"/>
        <source>(PROXY)</source>
        <translation>(ПРОКСИ)</translation>
    </message>
    <message>
        <location filename="../src/models/multitrackmodel.cpp" line="2653"/>
        <source>Error: Shotcut could not find the %1 plugin on your system.

Please install the %2 plugins.</source>
        <translation>Ошибка: Shotcut не удалось найти %1 плагин в вашей системе.

Пожалуйста, установите %2 плагины.</translation>
    </message>
</context>
<context>
    <name>NetworkProducerWidget</name>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="26"/>
        <source>Network Stream</source>
        <translation>Сетевой поток</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="41"/>
        <source>&amp;URL</source>
        <translation>&amp;URL</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="57"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
</context>
<context>
    <name>NewProjectFolder</name>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="20"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="61"/>
        <source>Projects</source>
        <translation>Проекты</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="188"/>
        <location filename="../src/widgets/newprojectfolder.ui" line="205"/>
        <source>PushButton</source>
        <translation>PushButton</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="231"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="372"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="218"/>
        <source>A folder with this name will be created containing
a project file with the same name.</source>
        <translation>Будет создана папка с этим именем,
содержащая одноимённый файл проекта.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="159"/>
        <source>Projects folder</source>
        <translation>Папка с проектами</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="263"/>
        <source>Project name</source>
        <translation>Название проекта</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="253"/>
        <source>Video mode</source>
        <translation>Видеорежим</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="201"/>
        <source>This is the folder to contain Shotcut project folders.
A folder will be created in this folder for each project.</source>
        <translation>Это папка, содержащая папки с проектами Shotcut.
Для каждого проекта будет создаваться отдельная подпапка в этой папке.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="315"/>
        <source>Automatic means the resolution and frame rate are based on the &lt;b&gt;first&lt;/b&gt; file you &lt;b&gt;add&lt;/b&gt; to your project. If the first file is not a video clip (for example, image or audio), then it will be 1920x1080p 25 fps.</source>
        <translation>В автоматическом режиме разрешение и частота кадров выбираются на основе &lt;b&gt;первого&lt;/b&gt; файла, &lt;b&gt;добавленного&lt;/b&gt; вами в проект. Если первый файл — не видео (например, картинка или аудио), то используются 1920x1080p и 25 кадров/с.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="143"/>
        <source>New Project</source>
        <translation>Новый проект</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="357"/>
        <source>Automatic</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="362"/>
        <source>Add...</source>
        <translation>Добавить...</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.ui" line="367"/>
        <source>Remove...</source>
        <translation>Удалить...</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="130"/>
        <source>Projects Folder</source>
        <translation>Папка с проектами</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="167"/>
        <source>Custom</source>
        <translation>Пользовательские настройки</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="184"/>
        <source>Remove Video Mode</source>
        <translation>Удалить видеорежим</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="213"/>
        <source>The project name cannot include a slash.</source>
        <translation>Имя проекта не может содержать косую черту.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="229"/>
        <source>There is already a project with that name.
Try again with a different name.</source>
        <translation>Проект с таким именем уже существует.
Выберите другое название.</translation>
    </message>
    <message>
        <location filename="../src/widgets/newprojectfolder.cpp" line="238"/>
        <source>Unable to create folder %1
Perhaps you do not have permission.
Try again with a different folder.</source>
        <translation>Невозможно создать папку %1
Возможно, у вас недостаточно прав.
Попробуйте выбрать другую папку.</translation>
    </message>
</context>
<context>
    <name>NoiseWidget</name>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="26"/>
        <source>Noise</source>
        <translation>Шум</translation>
    </message>
</context>
<context>
    <name>NotesDock</name>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="79"/>
        <source>Notes</source>
        <translation>Заметки</translation>
    </message>
</context>
<context>
    <name>OpenOtherDialog</name>
    <message>
        <location filename="../src/openotherdialog.ui" line="17"/>
        <source>Open Other</source>
        <translation>Открыть прочее</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.ui" line="55"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="32"/>
        <source>Add To Timeline</source>
        <translation>Добавить на шкалу времени</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="38"/>
        <location filename="../src/openotherdialog.cpp" line="143"/>
        <source>Network</source>
        <translation>Сеть</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="43"/>
        <source>Device</source>
        <translation>Устройство</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="45"/>
        <location filename="../src/openotherdialog.cpp" line="145"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="49"/>
        <location filename="../src/openotherdialog.cpp" line="135"/>
        <source>Video4Linux</source>
        <translation>Video4Linux</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="51"/>
        <location filename="../src/openotherdialog.cpp" line="137"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="53"/>
        <location filename="../src/openotherdialog.cpp" line="139"/>
        <source>ALSA Audio</source>
        <translation>ALSA Audio</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="56"/>
        <location filename="../src/openotherdialog.cpp" line="59"/>
        <location filename="../src/openotherdialog.cpp" line="141"/>
        <source>Audio/Video Device</source>
        <translation>Устройство аудио/видео</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="64"/>
        <source>Generator</source>
        <translation>Генератор</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="66"/>
        <location filename="../src/openotherdialog.cpp" line="147"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="69"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="74"/>
        <location filename="../src/openotherdialog.cpp" line="149"/>
        <source>Animation</source>
        <translation>Анимация</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="78"/>
        <location filename="../src/openotherdialog.cpp" line="151"/>
        <source>Noise</source>
        <translation>Шум</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="82"/>
        <location filename="../src/openotherdialog.cpp" line="153"/>
        <source>Ising</source>
        <translation>Изинг</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="87"/>
        <location filename="../src/openotherdialog.cpp" line="155"/>
        <source>Lissajous</source>
        <translation>Лиссажу</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="91"/>
        <location filename="../src/openotherdialog.cpp" line="157"/>
        <source>Plasma</source>
        <translation>Плазма</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="95"/>
        <location filename="../src/openotherdialog.cpp" line="159"/>
        <source>Color Bars</source>
        <translation>Цветовые шкалы</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="99"/>
        <location filename="../src/openotherdialog.cpp" line="161"/>
        <source>Audio Tone</source>
        <translation>Тембр аудио</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="103"/>
        <location filename="../src/openotherdialog.cpp" line="163"/>
        <source>Count</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="107"/>
        <location filename="../src/openotherdialog.cpp" line="165"/>
        <source>Blip Flash</source>
        <translation>Генератор вспышек</translation>
    </message>
</context>
<context>
    <name>ParameterHead</name>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="151"/>
        <source>Seek to previous keyframe</source>
        <translation>Перейти к предыдущему ключевому кадру</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="151"/>
        <source>Seek backwards</source>
        <translation>Перейти назад</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="171"/>
        <source>Add a keyframe at play head</source>
        <translation>Добавить ключевой кадр в начало воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="199"/>
        <source>Delete the selected keyframe</source>
        <translation>Удалить выбранный ключевой кадр</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="228"/>
        <source>Seek to next keyframe</source>
        <translation>Перейти к следующему ключевому кадру</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="228"/>
        <source>Seek forwards</source>
        <translation>Перейти вперед</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="245"/>
        <source>Unlock track</source>
        <translation>Разблокировать дорожку</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="245"/>
        <source>Lock track</source>
        <translation>Заблокировать дорожку</translation>
    </message>
    <message>
        <location filename="../src/qml/views/keyframes/ParameterHead.qml" line="256"/>
        <source>Zoom keyframe values</source>
        <translation>Значения ключевых кадров масштабирования</translation>
    </message>
</context>
<context>
    <name>PlasmaWidget</name>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="26"/>
        <source>Plasma</source>
        <translation>Плазма</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="41"/>
        <source>Speed 1</source>
        <translation>Скорость 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="112"/>
        <source>Speed 2</source>
        <translation>Скорость 2</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="180"/>
        <source>Speed 3</source>
        <translation>Скорость 3</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="252"/>
        <source>Speed 4</source>
        <translation>Скорость 4</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="323"/>
        <source>Move 1</source>
        <translation>Шаг 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="391"/>
        <source>Move 2</source>
        <translation>Шаг 2</translation>
    </message>
</context>
<context>
    <name>Player</name>
    <message>
        <location filename="../src/player.cpp" line="91"/>
        <source>Source</source>
        <translation>Исходник</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="92"/>
        <source>Project</source>
        <translation>Проект</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="155"/>
        <source>Adjust the audio volume</source>
        <translation>Изменить громкость</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="177"/>
        <source>Silence the audio</source>
        <translation>Отключить звук</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="196"/>
        <source>Current position</source>
        <translation>Текущая позиция</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="202"/>
        <source>Total Duration</source>
        <translation>Общее время</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="380"/>
        <source>In Point</source>
        <translation>Начало выделения</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="388"/>
        <source>Selected Duration</source>
        <translation>Выбранное время</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="242"/>
        <source>Zoom Fit</source>
        <translation>Уместить</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="191"/>
        <source>Current/Total Times</source>
        <translation>Текущее/Общее время</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="210"/>
        <source>Player Controls</source>
        <translation>Управление</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="221"/>
        <location filename="../src/player.cpp" line="375"/>
        <source>Player Options</source>
        <translation>Опции</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="248"/>
        <source>Zoom 10%</source>
        <translation>Масштаб 10%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="254"/>
        <source>Zoom 25%</source>
        <translation>Масштаб 25%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="260"/>
        <source>Zoom 50%</source>
        <translation>Масштаб 50%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="267"/>
        <source>Zoom 100%</source>
        <translation>Масштаб 100%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="273"/>
        <source>Zoom 200%</source>
        <translation>Масштаб 200%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="311"/>
        <source>Toggle zoom</source>
        <translation>Переключить масштаб</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="318"/>
        <source>2x2 Grid</source>
        <translation>Сетка 2x2</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="323"/>
        <source>3x3 Grid</source>
        <translation>Сетка 3x3</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="327"/>
        <source>4x4 Grid</source>
        <translation>Сетка 4x4</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="331"/>
        <source>16x16 Grid</source>
        <translation>Сетка 16x16</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="339"/>
        <source>10 Pixel Grid</source>
        <translation>Сетка 10 пкс</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="462"/>
        <source>Play/Pause</source>
        <translation>Играть/пауза</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="466"/>
        <source>Toggle play or pause</source>
        <translation>Воспроизвести или приостановить</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="477"/>
        <source>Loop</source>
        <translation>Повтор</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="483"/>
        <source>Toggle player looping</source>
        <translation>Переключить повтор</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="487"/>
        <source>Loop All</source>
        <translation>Повторять все</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="488"/>
        <source>Loop back to the beginning when the end is reached</source>
        <translation>Повтор сначала при достижений окончания</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="495"/>
        <source>Loop Marker</source>
        <translation>Повтор Метки</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="496"/>
        <source>Loop around the marker under the cursor in the timeline</source>
        <translation>Повтор метки под курсором на временной шкале</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="507"/>
        <source>Loop Selection</source>
        <translation>Повтор Выделения</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="508"/>
        <source>Loop around the selected clips</source>
        <translation>Повтор выбранных клипов</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="516"/>
        <source>Nothing selected</source>
        <translation>Ничего не выбрано</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="521"/>
        <source>Loop Around Cursor</source>
        <translation>Повтор вокруг курсора</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="522"/>
        <source>Loop around the current cursor position</source>
        <translation>Повтор вокруг текущей позиции курсора</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="551"/>
        <source>Skip to the next point</source>
        <translation>Пропустить к следующей точке</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="574"/>
        <source>Skip to the previous point</source>
        <translation>Пропустить к предыдущей точке</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="599"/>
        <source>Play quickly backwards</source>
        <translation>Быстро проиграть назад</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="609"/>
        <source>Play quickly forwards</source>
        <translation>Быстро проиграть вперёд</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="613"/>
        <source>Seek Start</source>
        <translation>Начало перемотки</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="618"/>
        <source>Seek End</source>
        <translation>Конец перемотки</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="628"/>
        <source>Next Frame</source>
        <translation>Следующий кадр</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="634"/>
        <source>Previous Frame</source>
        <translation>Предыдущий кадр</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="640"/>
        <source>Forward One Second</source>
        <translation>Вперёд на одну секунду</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="645"/>
        <source>Backward One Second</source>
        <translation>Назад на одну секунду</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="650"/>
        <source>Forward Two Seconds</source>
        <translation>Вперёд на две секунды</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="655"/>
        <source>Backward Two Seconds</source>
        <translation>Назад на две секунды</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="660"/>
        <source>Forward Five Seconds</source>
        <translation>Вперёд на пять секунд</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="665"/>
        <source>Backward Five Seconds</source>
        <translation>Назад на пять секунд</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="670"/>
        <source>Forward Ten Seconds</source>
        <translation>Вперёд на десять секунд</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="675"/>
        <source>Backward Ten Seconds</source>
        <translation>Назад на десять секунд</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="680"/>
        <source>Forward Jump</source>
        <translation>Переход вперед</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="687"/>
        <source>Backward Jump</source>
        <translation>Переход назад</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="694"/>
        <source>Set Jump Time</source>
        <translation>Настройка времени перехода</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="705"/>
        <source>Trim Clip In</source>
        <translation>Обрезать клип в точке</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="718"/>
        <source>Trim Clip Out</source>
        <translation>Обрезать клип вне точки</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="731"/>
        <source>Set Time Position</source>
        <translation>Указать позицию по времени</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="761"/>
        <source>Pause playback</source>
        <translation>Приостановить воспроизведение</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="763"/>
        <location filename="../src/player.cpp" line="768"/>
        <location filename="../src/player.cpp" line="773"/>
        <source>Player</source>
        <translation>Проигрыватель</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="765"/>
        <source>Focus Player</source>
        <translation>Фокус на проигрыватель</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="770"/>
        <source>Toggle Filter Overlay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="923"/>
        <source>Not Seekable</source>
        <translation>Не поддерживает поиск</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="335"/>
        <source>20 Pixel Grid</source>
        <translation>Сетка 20 пкс</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="279"/>
        <source>Zoom 300%</source>
        <translation>Масштаб 300%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="285"/>
        <source>Zoom 400%</source>
        <translation>Масштаб 400%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="291"/>
        <source>Zoom 500%</source>
        <translation>Масштаб 500%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="297"/>
        <source>Zoom 750%</source>
        <translation>Масштаб 750%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="303"/>
        <source>Zoom 1000%</source>
        <translation>Масштаб 1000%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="343"/>
        <source>80/90% Safe Areas</source>
        <translation>Безопасные зоны 80/90%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="347"/>
        <source>EBU R95 Safe Areas</source>
        <translation>Безопасные зоны EBU R95</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="352"/>
        <source>Snapping</source>
        <translation>Привязка</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="362"/>
        <source>Toggle grid display on the player</source>
        <translation>Вкл./выкл. показ сетки в проигрывателе</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="738"/>
        <source>Switch Source/Project</source>
        <translation>Переключить источник/проект</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="758"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="545"/>
        <source>Skip Next</source>
        <translation>Пропустить следующий</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="568"/>
        <source>Skip Previous</source>
        <translation>Пропустить предыдущий</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="593"/>
        <source>Rewind</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="603"/>
        <source>Fast Forward</source>
        <translation>Вперёд</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="369"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="370"/>
        <source>Show the volume control</source>
        <translation>Показать регулятор громкости</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1278"/>
        <source>Proxy and preview scaling are ON at %1p</source>
        <translation>Прокси и масштаб предпросмотра задействованы на %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1283"/>
        <source>Proxy is ON at %1p</source>
        <translation>Прокси на %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1288"/>
        <source>Preview scaling is ON at %1p</source>
        <translation>Масштаб предпросмотра задействован на %1p</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1403"/>
        <source>Unmute</source>
        <translation>Включить звук</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="1372"/>
        <location filename="../src/player.cpp" line="1412"/>
        <source>Mute</source>
        <translation>Без звука</translation>
    </message>
</context>
<context>
    <name>PlaylistDock</name>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="18"/>
        <location filename="../src/docks/playlistdock.cpp" line="382"/>
        <source>Playlist</source>
        <translation>Список воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="59"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; a playlist item to open it in the player.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can freely preview clips without necessarily adding them to the playlist or closing it.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To trim or adjust a playlist item &lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; to open it, make the changes, and click the &lt;span style=&quot; font-weight:600;&quot;&gt;Update&lt;/span&gt; icon.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drag-n-drop&lt;/span&gt; to rearrange the items.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Двойной щелчок мышью&lt;/span&gt; по элементу в списке воспроизведения — открыть в проигрывателе.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Просматривать клипы можно без добавления их в список воспроизведения или закрытия.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Чтобы обрезать или изменить элемент списка воспроизведения, откройте &lt;span style=&quot; font-weight:600;&quot;&gt;двойным щелчком мыши&lt;/span&gt;, внесите изменения и нажмите значок &lt;span style=&quot; font-weight:600;&quot;&gt;Обновить&lt;/span&gt;.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Перетаскиванием мышью&lt;/span&gt; можно менять элементы местами.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="127"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Double-click a playlist item to open it in the player.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Дважды щёлкните по элементу в списке воспроизведения, чтобы открыть его в проигрывателе.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="601"/>
        <source>Add the Source to the playlist</source>
        <translation>Добавить источник в список воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="612"/>
        <source>Remove cut</source>
        <translation>Удалить нарезку</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="630"/>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="642"/>
        <source>View as tiles</source>
        <translation>Показать как плитку</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="655"/>
        <source>View as icons</source>
        <translation>Показать как значки</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="668"/>
        <source>View as details</source>
        <translation>Показать подробности</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="607"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="720"/>
        <source>Set Creation Time...</source>
        <translation>Задать время создания...</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="706"/>
        <location filename="../src/docks/playlistdock.cpp" line="707"/>
        <source>Insert</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="451"/>
        <source>Playlist Menu</source>
        <translation>Меню списка воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="599"/>
        <source>Append</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="681"/>
        <source>Open the clip in the Source player</source>
        <translation>Открыть клип в исходном проигрывателе</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="691"/>
        <source>Go to the start of this clip in the Project player</source>
        <translation>Перейти к началу этого клипа в проигрывателе проекта</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="728"/>
        <source>Remove All</source>
        <translation>Удалить все</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="729"/>
        <source>Remove all items from the playlist</source>
        <translation>Удалить все элементы из списка воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="805"/>
        <source>Hidden</source>
        <translation>Скрытый</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="817"/>
        <source>In and Out - Left/Right</source>
        <translation>До и после преобразования - слева и справа</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="833"/>
        <source>In and Out - Top/Bottom</source>
        <translation>До и после преобразования - друг под другом</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="850"/>
        <source>In Only - Small</source>
        <translation>До преобразования - маленькие</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="866"/>
        <source>In Only - Large</source>
        <translation>До преобразования - большие</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="772"/>
        <source>Add Selected to Timeline</source>
        <translation>Добавить выбранное на шкалу времени</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="779"/>
        <source>Add Selected to Slideshow</source>
        <translation>Добавить выбранное в слайд-шоу</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="883"/>
        <source>Play After Open</source>
        <translation>Воспроизвести после открытия</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="734"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="740"/>
        <source>Select None</source>
        <translation>Снять выделение</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="712"/>
        <source>Update Thumbnails</source>
        <translation>Обновить миниатюры</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="786"/>
        <source>Sort By Name</source>
        <translation>Сортировать по имени</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="794"/>
        <source>Sort By Date</source>
        <translation>Сортировать по дате</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="667"/>
        <source>Details</source>
        <translation>Детали</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="412"/>
        <source>Select</source>
        <translation>Выбрать</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="429"/>
        <location filename="../src/docks/playlistdock.cpp" line="1134"/>
        <source>Bins</source>
        <translation>Разделы</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="436"/>
        <source>Columns</source>
        <translation>Столбцы</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="446"/>
        <source>Playlist Controls</source>
        <translation>Управление списком воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="480"/>
        <location filename="../src/docks/playlistdock.cpp" line="484"/>
        <source>Playlist Filters</source>
        <translation>Фильтры плейлиста</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="508"/>
        <source>Only show files whose name, path, or comment contains some text</source>
        <translation>Отображать только те файлы, название, путь или комментарий к которым содержат некоторый текст</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="509"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="623"/>
        <source>Add files to playlist</source>
        <translation>Добавить файлы в список воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="641"/>
        <source>Tiles</source>
        <translation>Плитки</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="654"/>
        <source>Icons</source>
        <translation>Значки</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="680"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="690"/>
        <source>GoTo</source>
        <translation>Перейти</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="696"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="697"/>
        <source>Open a copy of the clip in the Source player</source>
        <translation>Открыть копию клипа в исходном проигрывателе</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="748"/>
        <source>Move Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="760"/>
        <source>Move Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="891"/>
        <source>Open Previous</source>
        <translation>Открыть предыдущее</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="904"/>
        <source>Open Next</source>
        <translation>Открыть следующее</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="917"/>
        <source>Select Clip 1</source>
        <translation>Выбрать клип 1</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="929"/>
        <source>Select Clip 2</source>
        <translation>Выбрать клип 2</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="941"/>
        <source>Select Clip 3</source>
        <translation>Выбрать клип 3</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="953"/>
        <source>Select Clip 4</source>
        <translation>Выбрать клип 4</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="965"/>
        <source>Select Clip 5</source>
        <translation>Выбрать клип 5</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="977"/>
        <source>Select Clip 6</source>
        <translation>Выбрать клип 6</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="989"/>
        <source>Select Clip 7</source>
        <translation>Выбрать клип 7</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1001"/>
        <source>Select Clip 8</source>
        <translation>Выбрать клип 8</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1013"/>
        <source>Select Clip 9</source>
        <translation>Выбрать клип 9</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1025"/>
        <source>Thumbnails</source>
        <translation>Миниатюры</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1034"/>
        <source>Clip</source>
        <translation>Клип</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1043"/>
        <source>In</source>
        <translation>От</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1052"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1061"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1070"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1079"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1088"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1089"/>
        <source>Show or hide video files</source>
        <translation>Показать/скрыть видео файлы</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1094"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1095"/>
        <source>Show or hide audio files</source>
        <translation>Показать/скрыть аудио файлы</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1100"/>
        <source>Image</source>
        <translation>изображение</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1101"/>
        <source>Show or hide image files</source>
        <translation>Показать/скрыть файлы изображения</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1106"/>
        <source>Other</source>
        <translation>Другие</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1107"/>
        <source>Show or hide other kinds of files</source>
        <translation>Показать/скрыть другие виды файлов</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1112"/>
        <location filename="../src/docks/playlistdock.cpp" line="1113"/>
        <source>New Bin</source>
        <translation>Новый раздел</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1124"/>
        <location filename="../src/docks/playlistdock.cpp" line="1164"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1135"/>
        <source>Show or hide the list of bins</source>
        <translation>Показать/скрыть список разделов</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1144"/>
        <location filename="../src/docks/playlistdock.cpp" line="1145"/>
        <source>Remove Bin</source>
        <translation>Удалить раздел</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1156"/>
        <location filename="../src/docks/playlistdock.cpp" line="1157"/>
        <source>Rename Bin</source>
        <translation>Переименовать раздел</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1178"/>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="1213"/>
        <source>Replace %n playlist items</source>
        <translation>
            <numerusform>Заменить %n элемент плейлиста</numerusform>
            <numerusform>Заменить %n элемента плейлиста</numerusform>
            <numerusform>Заменить %n элементов плейлиста</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="2138"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n элемент</numerusform>
            <numerusform>%n элемента</numerusform>
            <numerusform>%n элементов</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="433"/>
        <source>Sort</source>
        <translation>Сортировать</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1536"/>
        <location filename="../src/docks/playlistdock.cpp" line="1768"/>
        <source>You cannot insert a playlist into a playlist!</source>
        <translation>Нельзя вставить один список воспроизведения в другой!</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/playlistdock.cpp" line="1553"/>
        <source>Remove %n playlist items</source>
        <translation>
            <numerusform>Удалить %n элемент плейлиста</numerusform>
            <numerusform>Удалить %n элемента плейлиста</numerusform>
            <numerusform>Удалить %n элементов плейлиста</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="622"/>
        <location filename="../src/docks/playlistdock.cpp" line="1312"/>
        <source>Add Files</source>
        <translation>Добавить файлы</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1266"/>
        <source>Appending</source>
        <translation>Добавление</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1322"/>
        <location filename="../src/docks/playlistdock.cpp" line="1331"/>
        <source>Failed to open </source>
        <translation>Не удалось открыть </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1395"/>
        <source>Dropped Files</source>
        <translation>Dropped Files</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1857"/>
        <source>Generating</source>
        <translation>Генерирование</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="2076"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="2078"/>
        <source>All Files (*);;MLT XML (*.mlt)</source>
        <translation>Все файлы (*);;MLT XML (*.mlt)</translation>
    </message>
</context>
<context>
    <name>PlaylistIconView</name>
    <message>
        <location filename="../src/widgets/playlisticonview.cpp" line="175"/>
        <source>P</source>
        <comment>The first letter or symbol of &quot;proxy&quot;</comment>
        <translation>P</translation>
    </message>
</context>
<context>
    <name>PlaylistModel</name>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="269"/>
        <source>(PROXY)</source>
        <translation>(ПРОКСИ)</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="409"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="411"/>
        <source>Image</source>
        <translation>изображение</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="413"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="415"/>
        <source>Other</source>
        <translation>Другие</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="494"/>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="496"/>
        <source>Thumbnails</source>
        <translation>Миниатюры</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="498"/>
        <source>Clip</source>
        <translation>Клип</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="500"/>
        <source>In</source>
        <translation>От</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="502"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="504"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="506"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="508"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="510"/>
        <source>Comment</source>
        <translation>Комментарии</translation>
    </message>
</context>
<context>
    <name>PlaylistProxyModel</name>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Duplicates</source>
        <translation>Дубликаты</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Not In Timeline</source>
        <translation>Нет на шкале времени</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="294"/>
        <source>Not In a Bin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preset</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="43"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="73"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="87"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="111"/>
        <source>Save Preset</source>
        <translation>Сохранить Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="121"/>
        <source>Name:</source>
        <translation>Название:</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="147"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="185"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="152"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="197"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="165"/>
        <source>Delete Preset</source>
        <translation>Удалить Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="175"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Вы действительно хотите удалить %1?</translation>
    </message>
</context>
<context>
    <name>ProducerPreviewWidget</name>
    <message>
        <location filename="../src/widgets/producerpreviewwidget.cpp" line="168"/>
        <source>Play</source>
        <translation>Пуск</translation>
    </message>
</context>
<context>
    <name>PulseAudioWidget</name>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="26"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
</context>
<context>
    <name>QImageJob</name>
    <message>
        <location filename="../src/jobs/qimagejob.cpp" line="34"/>
        <source>Make proxy for %1</source>
        <translation>Создать прокси для %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="38"/>
        <source>Append playlist item %1</source>
        <translation>Добавить элемент плейлиста %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="65"/>
        <source>Insert playist item %1</source>
        <translation>Вставить элемент плейлиста %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="92"/>
        <source>Update playlist item %1</source>
        <translation>Обновить элемент плейлиста %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="135"/>
        <source>Remove playlist item %1</source>
        <translation>Удалить элемент плейлиста %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="158"/>
        <source>Clear playlist</source>
        <translation>Очистить плейлист</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="203"/>
        <source>Move item from %1 to %2</source>
        <translation>Переместить элемент из %1 в %2</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="226"/>
        <source>Sort playlist by %1</source>
        <translation>Сортировать плейлист по %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="273"/>
        <source>Trim playlist item %1 in</source>
        <translation>Обрезать элемент плейлиста %1 в начале</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="311"/>
        <source>Trim playlist item %1 out</source>
        <translation>Обрезать элемент плейлиста %1 в конце</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="350"/>
        <source>Replace playlist item %1</source>
        <translation>Заменить элементы плейлиста %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="381"/>
        <source>Add new bin: %1</source>
        <translation>Добавить новый раздел: %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/playlistcommands.cpp" line="427"/>
        <source>Move %n item(s) to bin: %1</source>
        <translation>
            <numerusform>Переместить %n элемент в раздел: %1</numerusform>
            <numerusform>Переместить %n элемента в раздел: %1</numerusform>
            <numerusform>Переместить %n элементов в раздел: %1</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="462"/>
        <source>Remove bin: %1</source>
        <translation>Удалить раздел: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="464"/>
        <source>Rename bin: %1</source>
        <translation>Переименовать раздел: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="97"/>
        <source>Append to track</source>
        <translation>Добавить на дорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="103"/>
        <source>Append to Timeline</source>
        <translation>Добавить на шкалу времени</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="105"/>
        <source>Preparing</source>
        <translation>Подготовка</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="120"/>
        <source>Appending</source>
        <translation>Добавление</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="136"/>
        <source>Finishing</source>
        <translation>Завершение</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="166"/>
        <source>Insert into track</source>
        <translation>Вставить на дорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="185"/>
        <location filename="../src/commands/timelinecommands.cpp" line="251"/>
        <source>Add Files</source>
        <translation>Добавить файлы</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="238"/>
        <source>Overwrite onto track</source>
        <translation>Перезаписать на дорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="287"/>
        <source>Lift from track</source>
        <translation>Поднять с дорожки</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="321"/>
        <source>Remove from track</source>
        <translation>Удалить с дорожки</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="402"/>
        <source>Group %n clips</source>
        <translation>
            <numerusform>Сгруппировать %n клипы</numerusform>
            <numerusform>Сгруппировать %n клипов</numerusform>
            <numerusform>Сгруппировать %n клипов</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="455"/>
        <source>Ungroup %n clips</source>
        <translation>
            <numerusform>Разгруппировать %n клипы</numerusform>
            <numerusform>Разгруппировать %n клипов</numerusform>
            <numerusform>Разгруппировать %n клипов</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="496"/>
        <source>Change track name</source>
        <translation>Переименовать дорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="521"/>
        <source>Merge adjacent clips</source>
        <translation>Объединить прилегающие клипы</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="544"/>
        <source>Toggle track mute</source>
        <translation>Вкл./выкл. звук дорожки</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="565"/>
        <source>Toggle track hidden</source>
        <translation>Вкл./выкл. видимость дорожки</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="590"/>
        <source>Change track compositing</source>
        <translation>Изменить компоновку дорожки</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="615"/>
        <source>Lock track</source>
        <translation>Заблокировать дорожку</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/timelinecommands.cpp" line="676"/>
        <source>Move %n timeline clips</source>
        <translation>
            <numerusform>Переместить %n клип на шкале времени</numerusform>
            <numerusform>Переместить %n клипа на шкале времени</numerusform>
            <numerusform>Переместить %n клипов на шкале времени</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="678"/>
        <source>Move timeline clip</source>
        <translation>Переместить клип шкалы времени</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="903"/>
        <source>Trim clip in point</source>
        <translation>Обрезать клип в точке</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1013"/>
        <source>Trim clip out point</source>
        <translation>Обрезать клип вне точки</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1118"/>
        <source>Split clip</source>
        <translation>Разделить клип</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1120"/>
        <source>Split clips</source>
        <translation>Разделить клипы</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1157"/>
        <source>Adjust fade in</source>
        <translation>Настройка нарастания</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1192"/>
        <source>Adjust fade out</source>
        <translation>Настройка затухания</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1238"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1429"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1620"/>
        <source>Add transition</source>
        <translation>Добавить переход</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1321"/>
        <source>Trim transition in point</source>
        <translation>Обрезать переход в точке</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1373"/>
        <source>Trim transition out point</source>
        <translation>Обрезать переход вне точки</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1485"/>
        <location filename="../src/commands/timelinecommands.cpp" line="1552"/>
        <source>Remove transition</source>
        <translation>Удалить переход</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1664"/>
        <source>Add video track</source>
        <translation>Добавить видеодорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1666"/>
        <source>Add audio track</source>
        <translation>Добавить аудиодорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1710"/>
        <source>Insert audio track</source>
        <translation>Вставить аудиодорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1712"/>
        <source>Insert video track</source>
        <translation>Вставить видеодорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1749"/>
        <source>Remove audio track</source>
        <translation>Удалить аудиодорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1751"/>
        <source>Remove video track</source>
        <translation>Удалить видеодорожку</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1821"/>
        <source>Move track down</source>
        <translation>Перенести дорожку ниже</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1823"/>
        <source>Move track up</source>
        <translation>Перенести дорожку выше</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1847"/>
        <source>Change track blend mode</source>
        <translation>Изменить режим наложения дорожки</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1889"/>
        <source>Change clip properties</source>
        <translation>Изменить свойства клипа</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="1958"/>
        <source>Detach Audio</source>
        <translation>Отделить аудио</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2109"/>
        <source>Replace timeline clip</source>
        <translation>Заменить клип на шкале времени</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2138"/>
        <source>Align clips to reference track</source>
        <translation>Выровнять клипы по контрольной дорожке</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="2219"/>
        <source>Apply copied filters</source>
        <translation>Применить скопированные фильтры</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4084"/>
        <source>You cannot add a project to itself!</source>
        <translation>Невозможно добавить проект сам в себя!</translation>
    </message>
    <message>
        <location filename="../src/mltxmlchecker.cpp" line="118"/>
        <source>The file is not a MLT XML file.</source>
        <translation>Это не файл MLT XML.</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="95"/>
        <location filename="../src/util.cpp" line="142"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1050"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1140"/>
        <source>Unable to write file %1
Perhaps you do not have permission.
Try again with a different folder.</source>
        <translation>Невозможно выполнить запись в файл %1
Вероятно, у вас недостаточно прав.
Попробуйте с другой папкой.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="159"/>
        <source>Transition</source>
        <translation>Переход</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="161"/>
        <source>Track: %1</source>
        <translation>Дорожка: %1</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="163"/>
        <source>Output</source>
        <translation>Вывод</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="326"/>
        <source>The value you entered is very similar to the common,
more standard %1 = %2/1001.

Do you want to use %1 = %2/1001 instead?</source>
        <translation>Введённое значение очень похоже на общее,
более стандартное %1 = %2/1001.

Хотите вместо этого использовать %1 = %2/1001?</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="717"/>
        <source>The drive you chose only has %1 MiB of free space.
Do you still want to continue?</source>
        <translation>На выбранном диске свободно всего %1 МиБ.
Всё равно хотите продолжить?</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="725"/>
        <source>Do not show this anymore.</source>
        <comment>Export free disk space warning dialog</comment>
        <translation>Больше не показывать.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="761"/>
        <source>unknown (%1)</source>
        <translation>неизвестно (%1)</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="764"/>
        <source>NA</source>
        <translation>НД</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="815"/>
        <source>This file uses color transfer characteristics %1, which may result in incorrect colors or brightness in Shotcut.</source>
        <translation>Этот файл использует характеристики цветопередачи %1, что может привести к неправильным цветам или яркости в Shotcut.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="820"/>
        <source>This file is variable frame rate, which is not reliable for editing.</source>
        <translation>Этот файл имеет переменную частоту кадров, поэтому его нельзя редактировать.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="824"/>
        <source>This file does not support seeking and cannot be used for editing.</source>
        <translation>Этот файл не поддерживает поиск и не может быть использован для редактирования.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="827"/>
        <source>This file format (HDV) is not reliable for editing.</source>
        <translation>Этот формат файла (HDV) не подходит для редактирования.</translation>
    </message>
    <message>
        <location filename="../src/util.cpp" line="843"/>
        <source> Do you want to convert it to an edit-friendly format?

If yes, choose a format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, it automatically replaces clips, or you can double-click the job to open it.
</source>
        <translation>Вы хотите преобразовать его в удобный для редактирования формат?

Если да, выберите формат ниже, а затем нажмите ОК, чтобы выбрать имя файла. После выбора имени файла создаётся задание. Когда это будет сделано, клипы будут автоматически заменены, либо можно дважды нажать на заданию, чтобы его открыть.
</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.cpp" line="30"/>
        <location filename="../src/widgets/textproducerwidget.cpp" line="29"/>
        <source>transparent</source>
        <comment>Open Other &gt; Color</comment>
        <translation>прозрачный</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3114"/>
        <source>Drop Files</source>
        <translation>Пропуск файлов</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3121"/>
        <source>Failed to open </source>
        <translation>Не удалось открыть </translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3137"/>
        <source>Not adding non-seekable file: </source>
        <translation>Не добавлять файл, недоступный для поиска: </translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1250"/>
        <source>Generating Playlist for Bin</source>
        <translation>Сгенерировать плейлист для раздела</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="1855"/>
        <source>Generate Slideshow</source>
        <translation>Генератор слайд-шоу</translation>
    </message>
    <message>
        <location filename="../src/proxymanager.cpp" line="366"/>
        <source>Make proxy for %1</source>
        <translation>Создать прокси для %1</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="67"/>
        <source>Converting Thumbnails</source>
        <translation>Преобразование Миниатюр</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="86"/>
        <source>Please wait for this one-time update to the thumbnail cache...</source>
        <translation>Пожалуйста, подождите, идет одноразовое обновление кэша миниатюр...</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="30"/>
        <source>Delete marker: %1</source>
        <translation>Удалить метку: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="49"/>
        <source>Add marker: %1</source>
        <translation>Добавить метку: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="73"/>
        <source>Move marker: %1</source>
        <translation>Передвинуть метку: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="75"/>
        <source>Edit marker: %1</source>
        <translation>Изменить метку: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/markercommands.cpp" line="115"/>
        <source>Clear markers</source>
        <translation>Очистить метки</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="43"/>
        <source>transparent</source>
        <comment>Open Other &gt; Animation</comment>
        <translation>прозрачный</translation>
    </message>
    <message>
        <location filename="../src/widgets/glaxnimateproducerwidget.cpp" line="637"/>
        <source>Edit With Glaxnimate</source>
        <translation>Править в Glaxnimate</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="43"/>
        <source>Playlist Clip: %1</source>
        <translation>Playlist Clip: %1</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="46"/>
        <source>Track: %1, Clip: %2 (transition)</source>
        <translation>Track: %1, Clip: %2 (transition)</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="50"/>
        <source>Track: %1, Clip: %2</source>
        <translation>Track: %1, Clip: %2</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="289"/>
        <source>%1x%2</source>
        <translation>%1x%2</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="107"/>
        <source>Add %1 filter</source>
        <translation>Добавить %1 фильтр</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="109"/>
        <source>Add %1 filter set</source>
        <translation>Добавить %1 набор фильтров</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="173"/>
        <source>Remove %1 filter</source>
        <translation>Удалить %1 фильтр</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="207"/>
        <source>Move %1 filter</source>
        <translation>Переместить %1 фильтр</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="247"/>
        <source>Disable %1 filter</source>
        <translation>Отключить %1 фильтр</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="249"/>
        <source>Enable %1 filter</source>
        <translation>Включить %1 фильтр</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="305"/>
        <source>Paste filters</source>
        <translation>Вставить фильтры</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="359"/>
        <source>Change %1 filter</source>
        <translation>Выбрать %1 фильтр</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.cpp" line="361"/>
        <source>Change %1 filter: %2</source>
        <translation>Выбрать %1 фильтра: %2</translation>
    </message>
    <message>
        <location filename="../src/models/audiolevelstask.cpp" line="183"/>
        <source>generating audio waveforms for</source>
        <translation>генерация аудио осциллограммы для</translation>
    </message>
    <message>
        <location filename="../src/models/audiolevelstask.cpp" line="266"/>
        <source>Done</source>
        <translation>Выполнено</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="188"/>
        <source>add keyframe</source>
        <translation>добавить ключевой кадр</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="203"/>
        <source>remove keyframe</source>
        <translation>удалить ключевой кадр</translation>
    </message>
    <message>
        <location filename="../src/commands/filtercommands.h" line="220"/>
        <source>modify keyframe</source>
        <translation>изменить ключевой кадр</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="35"/>
        <source>Add subtitle track: %1</source>
        <translation>Добавить дорожку: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="55"/>
        <source>Remove subtitle track: %1</source>
        <translation>Удалить дорожку: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="83"/>
        <source>Edit subtitle track: %1</source>
        <translation>Редактировать дорожку: %1</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="106"/>
        <source>Add subtitle</source>
        <translation>Добавление субтитров</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="108"/>
        <source>Add %n subtitles</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="162"/>
        <source>Remove %n subtitles</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../src/commands/subtitlecommands.cpp" line="301"/>
        <source>Move %n subtitles</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="160"/>
        <source>Remove subtitle</source>
        <translation>Удаление субтитров</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="190"/>
        <source>Edit subtitle text</source>
        <translation>Редактировать текст субтитров</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="225"/>
        <source>Change subtitle start</source>
        <translation>Выбрать начало субтитров</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="259"/>
        <source>Change subtitle end</source>
        <translation>Выбрать окончание субтитров</translation>
    </message>
    <message>
        <location filename="../src/commands/subtitlecommands.cpp" line="299"/>
        <source>Move subtitle</source>
        <translation>Переместить субтитры</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/subtitlesdock.cpp" line="504"/>
        <source>Imported %1 subtitle item(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="606"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="621"/>
        <source>Importing subtitles...</source>
        <translation>импортировать субтитры...</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/subtitlesdock.cpp" line="642"/>
        <source>Imported %n subtitle item(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="494"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="637"/>
        <source>No subtitles found to import</source>
        <translation>Не найдено субтитров для импорта</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="311"/>
        <location filename="../src/models/subtitlesmodel.cpp" line="326"/>
        <source>Import %1 subtitle items</source>
        <translation>импорт %1 элементов</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="366"/>
        <source>Append subtitle</source>
        <translation>Добавить подзаголовок</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1335"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1059"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="1149"/>
        <source>A job already exists for %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QmlApplication</name>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="133"/>
        <source>Select a filter to copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="212"/>
        <source>&lt;p&gt;Do you really want to add filters to &lt;b&gt;Output&lt;/b&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timeline &gt; Output&lt;/b&gt; is currently selected. Adding filters to &lt;b&gt;Output&lt;/b&gt; affects ALL clips in the timeline including new ones that will be added.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Вы действительно хотите добавить фильтры для &lt;b&gt;Вывода&lt;/b&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Шкала времени &gt; Вывод&lt;/b&gt; в данный момент выбрано. Добавление фильтров для &lt;b&gt;Вывода&lt;/b&gt; влияет на ВСЕ клипы на временной шкале, включая новые, которые будут добавлены.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlapplication.cpp" line="222"/>
        <source>Do not show this anymore.</source>
        <comment>confirm output filters dialog</comment>
        <translation>Больше не показывать.</translation>
    </message>
</context>
<context>
    <name>QmlEditMenu</name>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="32"/>
        <source>Undo</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="38"/>
        <source>Redo</source>
        <translation>Вернуть</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="47"/>
        <source>Cut</source>
        <translation>Нарезка с заголовком</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="53"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="58"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="64"/>
        <source>Paste Text Only</source>
        <translation>Вставить только текст</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="70"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="76"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmleditmenu.cpp" line="84"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
</context>
<context>
    <name>QmlFilter</name>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="394"/>
        <source>(defaults)</source>
        <translation>(по умолчанию)</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="518"/>
        <source>Analyze %1</source>
        <translation>Анализ %1</translation>
    </message>
</context>
<context>
    <name>QmlMarkerMenu</name>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="62"/>
        <source>Edit...</source>
        <translation>Изменить...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="67"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="72"/>
        <source>Choose Color...</source>
        <translation>Выбрать цвет…</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlmarkermenu.cpp" line="86"/>
        <source>Choose Recent Color</source>
        <translation>Выбрать недавний цвет</translation>
    </message>
</context>
<context>
    <name>QmlRichText</name>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="141"/>
        <source>Cannot save: </source>
        <translation>Невозможно сохранить: </translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="172"/>
        <source>Row</source>
        <translation>Строка</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtext.cpp" line="174"/>
        <source>Column</source>
        <translation>Столбец</translation>
    </message>
</context>
<context>
    <name>QmlRichTextMenu</name>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="30"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="32"/>
        <source>Open...</source>
        <translation>Открыть...</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="36"/>
        <source>Save As...</source>
        <translation>Сохранить как…</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="40"/>
        <source>Edit</source>
        <translation>Правка</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="42"/>
        <source>Undo</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="47"/>
        <source>Redo</source>
        <translation>Вернуть</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="54"/>
        <source>Cut</source>
        <translation>Нарезка с заголовком</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="59"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="64"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="69"/>
        <source>Paste Text Only</source>
        <translation>Вставить только текст</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="74"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlrichtextmenu.cpp" line="79"/>
        <source>Insert Table</source>
        <translation>Вставить таблицу</translation>
    </message>
</context>
<context>
    <name>RecentDock</name>
    <message>
        <location filename="../src/docks/recentdock.ui" line="24"/>
        <source>Recent</source>
        <translation>Недавние</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="46"/>
        <source>Show only files with name matching text</source>
        <translation>Показать только файлы с именами, содержащими текст</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="49"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="76"/>
        <location filename="../src/docks/recentdock.ui" line="79"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
</context>
<context>
    <name>ResourceDialog</name>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="35"/>
        <source>Resources</source>
        <translation>Источники</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="47"/>
        <source>Convert Selected</source>
        <translation>Преобразовать выбранные</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="98"/>
        <source>No resources to convert</source>
        <translation>Нет выбранных для преобразования</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="103"/>
        <source>Choose an edit-friendly format below and then click OK to choose a file name. After choosing a file name, a job is created. When it is done, double-click the job to open it.
</source>
        <translation>Выберите формат для редактирования ниже и нажмите OK для выбора имени файла. После выбора имени файла создается задание. Когда это будет сделано, дважды щелкните задание, чтобы открыть его.
</translation>
    </message>
    <message>
        <location filename="../src/dialogs/resourcedialog.cpp" line="108"/>
        <source>Convert...</source>
        <translation>Преобразовать...</translation>
    </message>
</context>
<context>
    <name>ResourceModel</name>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="266"/>
        <source>%1MB</source>
        <translation>%1MB</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="281"/>
        <source>%1 %2x%3 %4fps</source>
        <translation>%1 %2x%3 %4fps</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="392"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="394"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="396"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/models/resourcemodel.cpp" line="398"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
</context>
<context>
    <name>SaveDefaultButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SaveDefaultButton.qml" line="27"/>
        <source>Set as default</source>
        <translation>Установить как значение по умолчанию</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../src/dialogs/saveimagedialog.cpp" line="47"/>
        <source>PNG (*.png);;BMP (*.bmp);;JPEG (*.jpg *.jpeg);;PPM (*.ppm);;TIFF (*.tif *.tiff);;WebP (*.webp);;All Files (*)</source>
        <translation>PNG (*.png);;BMP (*.bmp);;JPEG (*.jpg *.jpeg);;PPM (*.ppm);;TIFF (*.tif *.tiff);;WebP (*.webp);;Все файлы (*)</translation>
    </message>
</context>
<context>
    <name>ScopeController</name>
    <message>
        <location filename="../src/controllers/scopecontroller.cpp" line="41"/>
        <source>Scopes</source>
        <translation>Области</translation>
    </message>
</context>
<context>
    <name>ServicePresetWidget</name>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="25"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="45"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="52"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="80"/>
        <source>(defaults)</source>
        <translation>(по умолчанию)</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="87"/>
        <source>Save Preset</source>
        <translation>Сохранить Пресет</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="88"/>
        <source>Name:</source>
        <translation>Название:</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="173"/>
        <source>Delete Preset</source>
        <translation>Удалить Пресет</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="174"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Вы действительно хотите удалить %1?</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="58"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="59"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="66"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="67"/>
        <source>Set to default</source>
        <translation>Сделать стандартным</translation>
    </message>
    <message>
        <location filename="../src/dialogs/actionsdialog.cpp" line="76"/>
        <location filename="../src/dialogs/actionsdialog.cpp" line="77"/>
        <source>Clear shortcut</source>
        <translation>Очистить горячую клавишу</translation>
    </message>
</context>
<context>
    <name>ShotcutActions</name>
    <message>
        <location filename="../src/actions.cpp" line="52"/>
        <source>Other</source>
        <translation>Другие</translation>
    </message>
</context>
<context>
    <name>ShotcutSettings</name>
    <message>
        <location filename="../src/settings.cpp" line="104"/>
        <source>Old (before v23) Layout</source>
        <translation>Старое оформление (до версии 23)</translation>
    </message>
</context>
<context>
    <name>SimplePropertyUI</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SimplePropertyUI.qml" line="15"/>
        <source>Custom Properties</source>
        <translation>Пользовательские свойства</translation>
    </message>
</context>
<context>
    <name>SizePositionUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="338"/>
        <source>Bottom Left</source>
        <translation>Внизу слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="342"/>
        <source>Bottom Right</source>
        <translation>Внизу справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="346"/>
        <source>Top Left</source>
        <translation>Вверху слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="350"/>
        <source>Top Right</source>
        <translation>Вверху справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="356"/>
        <source>Slide In From Left</source>
        <translation>Сдвинуть слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="358"/>
        <source>Slide In From Right</source>
        <translation>Сдвинуть справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="360"/>
        <source>Slide In From Top</source>
        <translation>Сдвинуть сверху</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="362"/>
        <source>Slide In From Bottom</source>
        <translation>Сдвинуть снизу</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="366"/>
        <source>Slide Out Left</source>
        <translation>Выдвинуть влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="368"/>
        <source>Slide Out Right</source>
        <translation>Выдвинуть вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="370"/>
        <source>Slide Out Top</source>
        <translation>Выдвинуть вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="372"/>
        <source>Slide Out Bottom</source>
        <translation>Выдвинуть вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="377"/>
        <source>Slow Zoom In</source>
        <translation>Медленное увеличение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="379"/>
        <source>Slow Zoom Out</source>
        <translation>Медленное уменьшение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="381"/>
        <source>Slow Pan Left</source>
        <translation>Медленное панорамирование влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="382"/>
        <source>Slow Move Left</source>
        <translation>Медленное движение влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="384"/>
        <source>Slow Pan Right</source>
        <translation>Медленное панорамирование вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="385"/>
        <source>Slow Move Right</source>
        <translation>Медленное движение вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="387"/>
        <source>Slow Pan Up</source>
        <translation>Медленное панорамирование вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="388"/>
        <source>Slow Move Up</source>
        <translation>Медленное движение вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="390"/>
        <source>Slow Pan Down</source>
        <translation>Медленное панорамирование вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="391"/>
        <source>Slow Move Down</source>
        <translation>Медленное движение вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="393"/>
        <source>Slow Zoom In, Pan Up Left</source>
        <translation>Медленное увеличение, панорамирование вверх и влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="394"/>
        <source>Slow Zoom In, Move Up Left</source>
        <translation>Медленное увеличение, движение вверх влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="396"/>
        <source>Slow Zoom In, Pan Down Right</source>
        <translation>Медленное увеличение, панорамирование вниз и вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="397"/>
        <source>Slow Zoom In, Move Down Right</source>
        <translation>Медленное увеличение, движение вниз вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="399"/>
        <source>Slow Zoom Out, Pan Up Right</source>
        <translation>Медленное уменьшение, панорамирование вверх и вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="400"/>
        <source>Slow Zoom Out, Move Up Right</source>
        <translation>Медленное уменьшение, движение вверх вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="402"/>
        <source>Slow Zoom Out, Pan Down Left</source>
        <translation>Медленное уменьшение, панорамирование вниз и влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="403"/>
        <source>Slow Zoom Out, Move Down Left</source>
        <translation>Медленное уменьшение, движение вниз влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="405"/>
        <source>Slow Zoom In, Hold Bottom</source>
        <translation>Медленное увеличение, удерживая внизу</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="407"/>
        <source>Slow Zoom In, Hold Top</source>
        <translation>Медленное увеличение, удерживая вверху</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="409"/>
        <source>Slow Zoom In, Hold Left</source>
        <translation>Медленное увеличение, удерживая слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="411"/>
        <source>Slow Zoom In, Hold Right</source>
        <translation>Медленное увеличение, удерживая справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="413"/>
        <source>Slow Zoom Out, Hold Bottom</source>
        <translation>Медленное уменьшение, удерживая внизу</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="415"/>
        <source>Slow Zoom Out, Hold Top</source>
        <translation>Медленное уменьшение, удерживая вверху</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="417"/>
        <source>Slow Zoom Out, Hold Left</source>
        <translation>Медленное уменьшение, удерживая слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="419"/>
        <source>Slow Zoom Out, Hold Right</source>
        <translation>Медленное уменьшение, удерживая справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="487"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="522"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="632"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="707"/>
        <source>Zoom</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="755"/>
        <source>Size mode</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="762"/>
        <source>Fit</source>
        <translation>Вписать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="776"/>
        <source>Fill</source>
        <translation>Заливка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="796"/>
        <source>Distort</source>
        <translation>Искажение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="824"/>
        <source>Horizontal fit</source>
        <translation>Горизонтальное вписывание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="831"/>
        <source>Left</source>
        <translation>Левый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="843"/>
        <source>Center</source>
        <translation>Центральный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="855"/>
        <source>Right</source>
        <translation>Правый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="879"/>
        <source>Vertical fit</source>
        <translation>Вертикальное вписывание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="886"/>
        <source>Top</source>
        <translation>Верхний</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="898"/>
        <source>Middle</source>
        <comment>Size and Position video filter</comment>
        <translation>Средние</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="910"/>
        <source>Bottom</source>
        <translation>Нижний</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="934"/>
        <source>Rotation</source>
        <translation>Вращение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="947"/>
        <source> °</source>
        <comment>degrees</comment>
        <translation> °</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="974"/>
        <source>Background color</source>
        <translation>Цвет фона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="425"/>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="430"/>
        <source>Shake 1 Second - Scaled</source>
        <translation>Тряска 1 секунду - с масштабированием</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="427"/>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="432"/>
        <source>Shake 1 Second - Unscaled</source>
        <translation>Тряска 1 секунду - без масштабирования</translation>
    </message>
</context>
<context>
    <name>SizePositionVUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionVUI.qml" line="156"/>
        <source>Click in rectangle + hold Shift to drag, Wheel to zoom, or %1+Wheel to rotate</source>
        <translation>Щелкните в прямоугольнике + удерживайте Shift для перетаскивания, Колесико мыши для увеличения или %1+Колесико мыши для поворота</translation>
    </message>
</context>
<context>
    <name>SlideshowGeneratorDialog</name>
    <message numerus="yes">
        <location filename="../src/dialogs/slideshowgeneratordialog.cpp" line="33"/>
        <source>Slideshow Generator - %n Clips</source>
        <translation>
            <numerusform>Генератор слайдшоу - %n кадр</numerusform>
            <numerusform>Генератор слайдшоу - %n кадра</numerusform>
            <numerusform>Генератор слайдшоу - %n кадров</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>SlideshowGeneratorWidget</name>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="58"/>
        <source>Clip duration</source>
        <translation>Длительность клипа</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="60"/>
        <source>Set the duration of each clip in the slideshow.</source>
        <translation>Установить продолжительность каждого клипа в слайд-шоу.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="69"/>
        <source>Aspect ratio conversion</source>
        <translation>Соотношения сторон</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="71"/>
        <source>Pad Black</source>
        <translation>Чёрная подложка</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="72"/>
        <source>Crop Center</source>
        <translation>Обрезать центр</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="73"/>
        <source>Crop and Pan</source>
        <translation>Обрезка и панорама</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="77"/>
        <source>Pad Blur</source>
        <translation>Нечеткая подложка</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="80"/>
        <source>Choose an aspect ratio conversion method.</source>
        <translation>Выбрать метод преобразования соотношения сторон.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="89"/>
        <source>Zoom effect</source>
        <translation>Эффект масштаба</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="92"/>
        <source>Set the percentage of the zoom-in effect.
0% will result in no zoom effect.</source>
        <translation>Установить процент эффекта масштабирования.
0% - без масштабирования.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="100"/>
        <source>Transition duration</source>
        <translation>Длительность перехода</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="103"/>
        <source>Set the duration of the transition.
May not be longer than half the duration of the clip.
If the duration is 0, no transition will be created.</source>
        <translation>Установить длительность перехода.
Не может быть больше половины длительности клипа.
Если 0, то переход не будет создан.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="116"/>
        <source>Transition type</source>
        <translation>Тип перехода</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="119"/>
        <source>Random</source>
        <translation>Случайный</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="120"/>
        <source>Cut</source>
        <translation>Нарезка с заголовком</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="121"/>
        <source>Dissolve</source>
        <translation>Растворение</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="122"/>
        <source>Bar Horizontal</source>
        <translation>Горизонтальные полосы</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="123"/>
        <source>Bar Vertical</source>
        <translation>Вертикальные полосы</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="124"/>
        <source>Barn Door Horizontal</source>
        <translation>Горизонтальные жалюзи</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="125"/>
        <source>Barn Door Vertical</source>
        <translation>Вертикальные жалюзи</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="126"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Диагональные жалюзи слева снизу</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="127"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Диагональные жалюзи слева сверху</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="128"/>
        <source>Diagonal Top Left</source>
        <translation>Диагональ верхний левый</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="129"/>
        <source>Diagonal Top Right</source>
        <translation>Диагональ верхний правый</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="130"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Матрица водопад горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="131"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Матрица водопад вертикальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="132"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Матрица змейка горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="133"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Матрица змейка параллельная горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="134"/>
        <source>Matrix Snake Vertical</source>
        <translation>Матрица змейка вертикальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="135"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Матрица змейка параллельная вертикальная</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="136"/>
        <source>Barn V Up</source>
        <translation>Жалюзи углом вверх</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="137"/>
        <source>Iris Circle</source>
        <translation>Круг диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="138"/>
        <source>Double Iris</source>
        <translation>Двойной круг диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="139"/>
        <source>Iris Box</source>
        <translation>Вставка диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="140"/>
        <source>Box Bottom Right</source>
        <translation>Вставка снизу справа</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="141"/>
        <source>Box Bottom Left</source>
        <translation>Вставка снизу слева</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="142"/>
        <source>Box Right Center</source>
        <translation>Вставка справа по центру</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="143"/>
        <source>Clock Top</source>
        <translation>Циферблат почасовой стрелке</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="147"/>
        <source>Choose a transition effect.</source>
        <translation>Выбор эффекта перехода.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="155"/>
        <source>Transition softness</source>
        <translation>Мягкость перехода</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="157"/>
        <source>Change the softness of the edge of the wipe.</source>
        <translation>Изменить мягкость края ластика.</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="499"/>
        <source>Preview is not available with GPU Effects</source>
        <translation>Предварительный просмотр недоступен для GPU эффектов</translation>
    </message>
    <message>
        <location filename="../src/widgets/slideshowgeneratorwidget.cpp" line="500"/>
        <source>Generating Preview...</source>
        <translation>Создание предпросмотра...</translation>
    </message>
</context>
<context>
    <name>SpeedUI</name>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="96"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Удерживайте %1, чтобы перетащить ключевой кадр только по вертикали, или %2, чтобы перетащить только по горизонтали</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="108"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="130"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="134"/>
        <source>Map the specified speed to the current time. Use keyframes to vary the speed mappings over time.</source>
        <translation>Сопоставить указанную скорость с текущим временем. Используйте ключевые кадры, чтобы изменять отображение скорости во времени.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="158"/>
        <source>Image mode</source>
        <translation>Режим изображения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="162"/>
        <source>Use the specified image selection mode. Nearest will output the image that is nearest to the mapped time. Blend will blend all images that occur during the mapped time.</source>
        <translation>Использование указанного режима выбора изображения. Вывод близкого изображения, которое ближе всего к отображенному времени. Смешение смешает все изображения, которые появляются в течение отображенного времени.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="181"/>
        <source>Nearest</source>
        <translation>Ближайший</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="186"/>
        <source>Blend</source>
        <translation>Смешение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/SpeedUI.qml" line="201"/>
        <source>Enable pitch compensation</source>
        <translation>Включить компенсацию высоты тона</translation>
    </message>
</context>
<context>
    <name>SubtitleBar</name>
    <message>
        <location filename="../src/qml/views/timeline/SubtitleBar.qml" line="73"/>
        <source>Unable to move. Subtitles already exist at this time.</source>
        <translation>Невозможно переместить. На данный момент субтитры уже существуют.</translation>
    </message>
</context>
<context>
    <name>SubtitleTrackDialog</name>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="54"/>
        <source>New Subtitle Track</source>
        <translation>Новая дорожка</translation>
    </message>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="58"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../src/dialogs/subtitletrackdialog.cpp" line="63"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
</context>
<context>
    <name>SubtitlesDock</name>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="131"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="177"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="147"/>
        <source>Add clips to the Timeline to begin editing subtitles.</source>
        <translation>Добавьте клипы на шкалу времени, чтобы начать редактирование субтитров.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="178"/>
        <source>Tracks</source>
        <translation>Дорожки</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="198"/>
        <source>Columns</source>
        <translation>Столбцы</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="199"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="202"/>
        <source>End</source>
        <translation>Конец</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="205"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="211"/>
        <source>Subtitle Controls</source>
        <translation>Управление</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="217"/>
        <source>Subtitles Menu</source>
        <translation>Меню Субтитры</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="268"/>
        <source>Previous</source>
        <translation>Предыдущий</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="270"/>
        <source>Current</source>
        <translation>Текущий</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="272"/>
        <source>Next</source>
        <translation>Далее</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="304"/>
        <source>Add Subtitle Track</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="307"/>
        <source>Add a subtitle track</source>
        <translation>Добавить дорожки субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="315"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="545"/>
        <source>Remove Subtitle Track</source>
        <translation>Удалить дорожку субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="318"/>
        <source>Remove this subtitle track</source>
        <translation>Удалить дорожку субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="326"/>
        <source>Edit Subtitle Track</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="329"/>
        <source>Edit this subtitle track</source>
        <translation>Редактировать дорожку субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="337"/>
        <source>Import Subtitles From File</source>
        <translation>импорт Субтитров из файла</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="340"/>
        <source>Import subtitles from an srt file at the current position</source>
        <translation>Импорт субтитров из файла srt в текущее положение</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="348"/>
        <source>Export Subtitles To File</source>
        <translation>Экспорт Субтитров в файл</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="351"/>
        <source>Export the current subtitle track to an SRT file</source>
        <translation>Экспорт текущих субтитров в файл SRT</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="359"/>
        <source>Create/Edit Subtitle</source>
        <translation>Создать/Редактировать Субтитры</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="363"/>
        <source>Create or Edit a subtitle at the cursor position.</source>
        <translation>Создать или редактировать субтитры с положения курсора.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="367"/>
        <source>Add Subtitle Item</source>
        <translation>Добавить элемент субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="371"/>
        <source>Add a subtitle at the cursor position</source>
        <translation>Добавить субтитры с положения курсора.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="375"/>
        <source>Remove Subtitle Item</source>
        <translation>Удалить элемент субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="379"/>
        <source>Remove the selected subtitle item</source>
        <translation>Удалить выделенные элементы субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="383"/>
        <source>Set Subtitle Start</source>
        <translation>Установить начало субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="388"/>
        <source>Set the selected subtitle to start at the cursor position</source>
        <translation>Установить начало выбранного субтитра с положения курсора</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="392"/>
        <source>Set Subtitle End</source>
        <translation>Установить конец субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="397"/>
        <source>Set the selected subtitle to end at the cursor position</source>
        <translation>Установить конец выбранного субтитра с положения курсора</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="401"/>
        <source>Move Subtitles</source>
        <translation>Переместить субтитры</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="405"/>
        <source>Move the selected subtitles to the cursor position</source>
        <translation>Переместить выбранный субтитр в положение курсора</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="409"/>
        <source>Burn In Subtitles on Output</source>
        <translation>Записать субтитры на выходе</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="410"/>
        <source>Create or edit a Burn In Subtitles filter on the timeline output.</source>
        <translation>Создать или редактировать Фильтр субтитров на выходе при записи временной шкалы.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="415"/>
        <source>Generate Text on Timeline</source>
        <translation>Создание текста на шкале времени</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="417"/>
        <source>Create a new video track on the timeline with text showing these subtitles.</source>
        <translation>Создайте новую видео дорожку на шкале времени с текстом, содержащим субтитры.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="421"/>
        <source>Speech to Text...</source>
        <translation>Речь в Текст...</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="422"/>
        <source>Detect speech and transcribe to a new subtitle track.</source>
        <translation>Распознавание речи и транскрибирование в новую дорожку субтитров.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="428"/>
        <source>Track Timeline Cursor</source>
        <translation>Указатель</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="429"/>
        <source>Track the timeline cursor</source>
        <translation>Указатель дорожки шкалы времени</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="437"/>
        <source>Show Previous/Next</source>
        <translation>Показать Предыдущий/Следующий</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="438"/>
        <source>Show the previous and next subtitles</source>
        <translation>Показать предыдущие и следующие субтитры</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="511"/>
        <source>Add a clip to the timeline to create subtitles.</source>
        <translation>Добавьте клип на шкалу времени, чтобы создать субтитры.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1067"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1069"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1089"/>
        <source>Subtitle Track %1</source>
        <translation>Дорожка субтитров %1</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1131"/>
        <source>Generate subtitle text on timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1132"/>
        <source>Text style preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1134"/>
        <source>Default subtitle style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1277"/>
        <source>Extracting Audio</source>
        <translation>Извлечение аудио</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="1295"/>
        <source>Speech to Text</source>
        <translation>Речь в текст</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="522"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="575"/>
        <location filename="../src/docks/subtitlesdock.cpp" line="1226"/>
        <source>Subtitle track already exists: %1</source>
        <translation>Дорожка с субтитрами уже существует: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="546"/>
        <source>This track is in use by a subtitle filter.
Remove the subtitle filter before removing this track.</source>
        <translation>Дорожка используется фильтром субтитров.
Перед удалением дорожки снимите фильтр субтитров.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="592"/>
        <source>Import Subtitle File</source>
        <translation>Импорт файла субтитров</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="594"/>
        <source>Subtitle Files (*.srt *.SRT *.vtt *.VTT *.ass *.ASS *.ssa *.SSA)</source>
        <translation>Файлы субтитров (*.srt *.SRT *.vtt *.VTT *.ass *.ASS *.ssa *.SSA)</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="602"/>
        <source>Unable to find subtitle file.</source>
        <translation>Не удалось найти файл субтитров.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="650"/>
        <source>Export SRT File</source>
        <translation>Экспорт SRT файла</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="652"/>
        <source>SRT Files (*.srt *.SRT)</source>
        <translation>SRT файлы (*.srt *.SRT)</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="717"/>
        <source>A subtitle already exists at this time.</source>
        <translation>На данный момент субтитры уже существуют.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="727"/>
        <source>Not enough space to add subtitle.</source>
        <translation>Недостаточно места для добавления субтитров.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="764"/>
        <source>Start time can not be after end time.</source>
        <translation>Время начала не может быть позже времени окончания.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="770"/>
        <source>Start time can not be before previous subtitle.</source>
        <translation>Время начала не может быть раньше предыдущего субтитра.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="788"/>
        <source>End time can not be before start time.</source>
        <translation>Время окончания не может быть раньше времени начала.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="795"/>
        <source>End time can not be after next subtitle.</source>
        <translation>Время окончания не может быть после следующего субтитра.</translation>
    </message>
    <message>
        <location filename="../src/docks/subtitlesdock.cpp" line="817"/>
        <source>Unable to move. Subtitles already exist at this time.</source>
        <translation>Невозможно переместить. На данный момент субтитры уже существуют.</translation>
    </message>
</context>
<context>
    <name>SubtitlesModel</name>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="818"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="820"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="822"/>
        <source>End</source>
        <translation>Окончание</translation>
    </message>
    <message>
        <location filename="../src/models/subtitlesmodel.cpp" line="824"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
</context>
<context>
    <name>SystemSyncDialog</name>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="14"/>
        <source>Player Synchronization</source>
        <translation>Синхронизация проигрывателя</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="20"/>
        <source>Adjust your playback audio/video synchronization</source>
        <translation>Настройка синхронизации воспроизведения аудио/видео</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="48"/>
        <source>Reset to default value 0</source>
        <translation>Сброс к значению 0 по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="65"/>
        <source>Video offset</source>
        <translation>Смещение видео</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="75"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/dialogs/systemsyncdialog.ui" line="82"/>
        <source> ms</source>
        <translation> мс</translation>
    </message>
</context>
<context>
    <name>TextEditor</name>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="41"/>
        <source>Decrease Text Size</source>
        <translation>Уменьшить размер текста</translation>
    </message>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="44"/>
        <location filename="../src/docks/notesdock.cpp" line="49"/>
        <source>Notes</source>
        <translation>Заметки</translation>
    </message>
    <message>
        <location filename="../src/docks/notesdock.cpp" line="46"/>
        <source>Increase Text Size</source>
        <translation>Увеличить размер текста</translation>
    </message>
</context>
<context>
    <name>TextFilterUi</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="78"/>
        <source>Bold</source>
        <translation>Жирный</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="80"/>
        <source>Italic</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="208"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="267"/>
        <source>Use font size</source>
        <translation>Использовать размер шрифта</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="282"/>
        <source>Outline</source>
        <translation>Контурный</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="303"/>
        <source>Thickness</source>
        <translation>Толщина</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="318"/>
        <source>Background</source>
        <translation>Фон</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="339"/>
        <source>Padding</source>
        <translation>Заполнение</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="354"/>
        <source>Opacity</source>
        <translation>Непрозрачность</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="384"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="461"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="520"/>
        <source>Horizontal fit</source>
        <translation>Вписать по горизонтали</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="527"/>
        <source>Left</source>
        <translation>Левый</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="535"/>
        <source>Center</source>
        <translation>Центральный</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="543"/>
        <source>Right</source>
        <translation>Правый</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="560"/>
        <source>Vertical fit</source>
        <translation>Вписать по вертикали</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="567"/>
        <source>Top</source>
        <translation>Верхний</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="575"/>
        <source>Middle</source>
        <comment>Text video filter</comment>
        <translation>Средние</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterUi.qml" line="583"/>
        <source>Bottom</source>
        <translation>Нижний</translation>
    </message>
</context>
<context>
    <name>TextFilterVui</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TextFilterVui.qml" line="85"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Нажмите прямоугольник + удерживайте Shift для перетаскивания</translation>
    </message>
</context>
<context>
    <name>TextProducerWidget</name>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="26"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="39"/>
        <source>Type or paste the text here</source>
        <translation>Наберите или вставьте здесь текст</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="48"/>
        <source>Background color...</source>
        <translation>Цвет фона...</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="61"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="88"/>
        <source>Simple</source>
        <translation>Простой</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="98"/>
        <source>Rich</source>
        <translation>Богатый</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.ui" line="120"/>
        <source>Text attributes are available in the &lt;b&gt;Filters&lt;/b&gt; panel after clicking &lt;b&gt;OK&lt;/b&gt;.</source>
        <translation>Атрибуты текста доступны в панели &lt;b&gt;Фильтры&lt;/b&gt; после нажатия &lt;b&gt;OK&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="59"/>
        <source>black</source>
        <translation>черный</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="61"/>
        <source>transparent</source>
        <translation>прозрачный</translation>
    </message>
    <message>
        <location filename="../src/widgets/textproducerwidget.cpp" line="179"/>
        <location filename="../src/widgets/textproducerwidget.cpp" line="212"/>
        <source>Edit your text using the Filters panel.</source>
        <translation>Измените текст, используя панель фильтров.</translation>
    </message>
</context>
<context>
    <name>TextViewerDialog</name>
    <message>
        <location filename="../src/dialogs/textviewerdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>Диалог</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="35"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="64"/>
        <source>Save Text</source>
        <translation>Сохранить текст</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="65"/>
        <source>Text Documents (*.txt);;All Files (*)</source>
        <translation>Документы (*.txt);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="67"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;Все файлы (*)</translation>
    </message>
</context>
<context>
    <name>TiledItemDelegate</name>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="123"/>
        <source>Duration: %1</source>
        <translation>Длительность: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="128"/>
        <source>Date: %1</source>
        <translation>Дата: %1</translation>
    </message>
</context>
<context>
    <name>TimeSpinner</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="70"/>
        <source>Decrement</source>
        <translation>Уменьшение</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="99"/>
        <source>Increment</source>
        <translation>Увеличение</translation>
    </message>
</context>
<context>
    <name>TimelineDock</name>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="83"/>
        <location filename="../src/docks/timelinedock.cpp" line="94"/>
        <source>Timeline</source>
        <translation>Шкала времени</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1704"/>
        <source>This track is locked</source>
        <translation>Дорожка заблокирована</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1709"/>
        <source>You cannot add a non-seekable source.</source>
        <translation>Невозможно добавить недоступный для поиска источник.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2107"/>
        <location filename="../src/docks/timelinedock.cpp" line="2141"/>
        <source>Track %1 was not moved</source>
        <translation>Дорожка %1 не была перемещена</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2112"/>
        <source>Can not move audio track above video track</source>
        <translation>Не удаётся переместить звуковую дорожку выше видеодорожки</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2128"/>
        <source>Can not move video track below audio track</source>
        <translation>Невозможно переместить видеодорожку ниже звуковой дорожки</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1434"/>
        <location filename="../src/docks/timelinedock.cpp" line="2269"/>
        <source>Align To Reference Track</source>
        <translation>Выровнять по контрольной дорожке</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="95"/>
        <source>Track Operations</source>
        <translation>Действия с дорожкой</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="107"/>
        <source>Track Height</source>
        <translation>Высота дорожки</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="112"/>
        <source>Selection</source>
        <translation>Выделение</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="125"/>
        <source>Edit</source>
        <translation>Правка</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="142"/>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="148"/>
        <source>Marker</source>
        <translation>Метка</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="158"/>
        <source>Timeline Clip</source>
        <translation>Клип временной шкалы</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="182"/>
        <source>Timeline Controls</source>
        <translation>Управление шкалой времени</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="186"/>
        <source>Timeline Menu</source>
        <translation>Меню шкалы времени</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="377"/>
        <source>Add Audio Track</source>
        <translation>Добавить аудиотрек</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="386"/>
        <source>Add Video Track</source>
        <translation>Добавить видеотрек</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="395"/>
        <source>Insert Track</source>
        <translation>Вставить дорожку</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="404"/>
        <source>Remove Track</source>
        <translation>Удалить дорожку</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="415"/>
        <source>Move Track Up</source>
        <translation>Дорожку выше</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="426"/>
        <source>Move Track Down</source>
        <translation>Дорожку ниже</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="437"/>
        <source>Show/Hide Selected Track</source>
        <translation>Показать/скрыть выбранную дорожку</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="453"/>
        <source>Lock/Unlock Selected Track</source>
        <translation>Заблокировать/разблокировать выбранную дорожку</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="472"/>
        <source>Mute/Unmute Selected Track</source>
        <translation>Заглушить/разглушить выбранную дорожку</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="488"/>
        <source>Blend/Unblend Selected Track</source>
        <translation>Объединить/разъединить выбранную дорожку</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="506"/>
        <source>Make Tracks Shorter</source>
        <translation>Укоротить треки</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="515"/>
        <source>Make Tracks Taller</source>
        <translation>Удлинить треки</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="524"/>
        <source>Reset Track Height</source>
        <translation>Сбросить высоту трека</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="533"/>
        <source>Select All</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="544"/>
        <source>Select All On Current Track</source>
        <translation>Выбрать все на текущей дорожке</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="555"/>
        <source>Select None</source>
        <translation>Снять выделение</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="567"/>
        <source>Select Next Clip</source>
        <translation>Выбрать следующий клип</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="582"/>
        <source>Select Previous Clip</source>
        <translation>Выбрать предыдущий клип</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="597"/>
        <source>Select Clip Above</source>
        <translation>Выбрать клип сверху</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="618"/>
        <source>Select Clip Below</source>
        <translation>Выбрать клип снизу</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="639"/>
        <source>Set Current Track Above</source>
        <translation>Поместить текущую дорожку выше</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="648"/>
        <source>Set Current Track Below</source>
        <translation>Поместить текущую дорожку ниже</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="657"/>
        <source>Select Clip Under Playhead</source>
        <translation>Выбрать клип под указателем</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="672"/>
        <source>Cu&amp;t</source>
        <translation>Выре&amp;зать</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="693"/>
        <source>&amp;Copy</source>
        <translation>&amp;Копировать</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="722"/>
        <source>&amp;Paste</source>
        <translation>&amp;Вставить</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="736"/>
        <source>Nudge Forward</source>
        <translation>Переместить вперед</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="751"/>
        <source>Nudge Forward is not available</source>
        <translation>Перемещение вперед недоступно</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="773"/>
        <source>Nudge Backward</source>
        <translation>Переместить назад</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="783"/>
        <source>Nudge Backward is not available</source>
        <translation>Перемещение назад недоступно</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="805"/>
        <source>Append</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="816"/>
        <source>Ripple Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="833"/>
        <source>Lift</source>
        <translation>Поднять</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="851"/>
        <source>Overwrite</source>
        <translation>Перезаписать</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="864"/>
        <source>Split At Playhead</source>
        <translation>Разделение по точкам воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="921"/>
        <source>Split All Tracks At Playhead</source>
        <translation>Разделить Все Треки по точкам воспроизведения</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="952"/>
        <source>Replace</source>
        <translation>Заменить</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="971"/>
        <source>Create/Edit Marker</source>
        <translation>Создать/изменить метку</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="984"/>
        <source>Previous Marker</source>
        <translation>Предыдущая метка</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="998"/>
        <source>Next Marker</source>
        <translation>Следующая метка</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1012"/>
        <source>Delete Marker</source>
        <translation>Удалить метку</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1023"/>
        <source>Cycle Marker Color</source>
        <translation>Цвет метки цикла</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1039"/>
        <source>Create Marker Around Selected Clip</source>
        <translation>Создать метку вокруг выбранного клипа</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1050"/>
        <source>Rectangle Selection</source>
        <translation>Прямоугольное выделение</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1061"/>
        <source>Automatically Add Tracks</source>
        <translation>Автоматическое добавление треков</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1072"/>
        <source>Snap</source>
        <translation>Привязка</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1086"/>
        <source>Scrub While Dragging</source>
        <translation>Переходить в начало при перетаскивании</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1099"/>
        <source>Ripple</source>
        <translation>Сдвинуть</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1113"/>
        <source>Ripple All Tracks</source>
        <translation>Сдвинуть все треки</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1127"/>
        <source>Ripple Markers</source>
        <translation>Сдвинуть маркеры</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1142"/>
        <source>Toggle Ripple And All Tracks</source>
        <translation>Кнопка Сдвиг и Все треки</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1150"/>
        <source>Toggle Ripple, All Tracks, And Markers</source>
        <translation>Кнопка Сдвиг, Все треки, и Маркеры</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1159"/>
        <source>Show Audio Waveforms</source>
        <translation>Показать осциллограмму аудио</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1173"/>
        <source>Use Higher Performance Waveforms</source>
        <translation>Продвинутая осциллограмма</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1189"/>
        <source>Show Video Thumbnails</source>
        <translation>Показать миниатюры</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1200"/>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1213"/>
        <source>Page</source>
        <translation>Страница</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1226"/>
        <source>Smooth</source>
        <translation>Плавная</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1239"/>
        <source>Center the Playhead</source>
        <translation>Центрировать указатель</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1253"/>
        <source>Scroll to Playhead on Zoom</source>
        <translation>Прокрутка указателя для масштабирования</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1265"/>
        <source>Zoom Timeline Out</source>
        <translation>Уменьшить масштаб шкалы времени</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1276"/>
        <source>Zoom Timeline In</source>
        <translation>Увеличить масштаб шкалы времени</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1287"/>
        <source>Zoom Timeline To Fit</source>
        <translation>Уместить шкалу времени в масштабе</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1299"/>
        <source>New Generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1307"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1309"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1313"/>
        <source>Animation</source>
        <translation>Анимация</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1317"/>
        <source>Noise</source>
        <translation>Шум</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1320"/>
        <source>Color Bars</source>
        <translation>Цветовые шкалы</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1324"/>
        <source>Audio Tone</source>
        <translation>Тембр звука</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1327"/>
        <source>Count</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1330"/>
        <source>Blip Flash</source>
        <translation>Генератор вспышек</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1353"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1360"/>
        <source>Rejoin With Next Clip</source>
        <translation>Переподсоединить к следующему клипу</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1376"/>
        <source>Detach Audio</source>
        <translation>Отделить аудио</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1404"/>
        <source>Freeze Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1454"/>
        <source>Apply Copied Filters</source>
        <translation>Применить скопированные фильтры</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1478"/>
        <source>Update Thumbnails</source>
        <translation>Обновить миниатюры</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1502"/>
        <source>Rebuild Audio Waveform</source>
        <translation>Воссоздать аудиоосциллограмму</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1526"/>
        <source>Ripple Trim Clip In</source>
        <translation>Обрезать клип в точке сдвига</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1533"/>
        <source>Ripple Trim Clip Out</source>
        <translation>Обрезать клип вне точки сдвига</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1540"/>
        <source>Group/Ungroup</source>
        <translation>Группировать/Разгруппировать</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2367"/>
        <source>Append multiple to timeline</source>
        <translation>Добавить несколько</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2427"/>
        <source>Ripple delete transition</source>
        <translation>Удалить переход сдвигом</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2476"/>
        <source>Lift transition</source>
        <translation>Поднять переход</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2551"/>
        <source>Cut %1 from timeline</source>
        <translation>Вырезать %1 из шкалы времени</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2553"/>
        <source>Remove %1 from timeline</source>
        <translation>Удалить %1 из шкалы времени</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2576"/>
        <source>Lift %1 from timeline</source>
        <translation>Поднять %1 на шкале времени</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2927"/>
        <source>There is nothing in the Source player.</source>
        <translation>В исходном проигрывателе ничего нет.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2942"/>
        <source>You cannot replace a transition.</source>
        <translation>Невозможно заменить переход.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2972"/>
        <source>Select a clip in the timeline to create a marker around it</source>
        <translation>Выберите клип на шкале времени, чтобы создать возле него маркер</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="2993"/>
        <source>Added marker: &quot;%1&quot;.</source>
        <translation>Добавлена метка: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3013"/>
        <source>Added marker: &quot;%1&quot;. Hold %2 and drag to create a range</source>
        <translation>Добавлен маркер: &quot;%1&quot;. Удерживайте %2 и перетаскивайте, чтобы создать диапазон</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3129"/>
        <source>Failed to open </source>
        <translation>Не удалось открыть </translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3162"/>
        <source>Dropped Files</source>
        <translation>Dropped Files</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3207"/>
        <source>You cannot freeze a frame of a transition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3226"/>
        <source>Freeze Frame is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3260"/>
        <source>Insert Freeze Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3264"/>
        <source>The play head is not over the selected clip.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3616"/>
        <source>Insert multiple into timeline</source>
        <translation>Вставить несколько</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="3755"/>
        <source>Overwrite multiple onto timeline</source>
        <translation>Перезаписать несколько</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="904"/>
        <location filename="../src/docks/timelinedock.cpp" line="936"/>
        <source>You cannot split a transition.</source>
        <translation>Невозможно разделить переход.</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/docks/timelinedock.cpp" line="4171"/>
        <source>Replace %n timeline clips</source>
        <translation>
            <numerusform>Заменить %n клип на шкале времени</numerusform>
            <numerusform>Заменить %n клипа на шкале времени</numerusform>
            <numerusform>Заменить %n клипов на шкале времени</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4224"/>
        <source>voiceover</source>
        <translation>голос за кадром</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4225"/>
        <source>Opus (*.opus);;All Files (*)</source>
        <translation>Opus (*.opus);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="1336"/>
        <location filename="../src/docks/timelinedock.cpp" line="4227"/>
        <location filename="../src/docks/timelinedock.cpp" line="4343"/>
        <source>Record Audio</source>
        <translation>Записать звук</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4241"/>
        <source>Record Audio: %1</source>
        <translation>Запись звука: %1</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4308"/>
        <source>Audio Recording In Progress</source>
        <translation>Ведется аудиозапись</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4318"/>
        <source>Record Audio error: check PulseAudio settings</source>
        <translation>Запись звука: проверьте настройки PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4322"/>
        <source>Record Audio error: choose File &gt; Open Other &gt; Audio/Video Device</source>
        <translation>Ошибка записи звука: выберите Файл &gt; Открыть прочее &gt; Устройство аудио/видео</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="4349"/>
        <source>Saving audio recording...</source>
        <translation>Сохранение аудиозаписи...</translation>
    </message>
</context>
<context>
    <name>TimelinePropertiesWidget</name>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="26"/>
        <source>Timeline</source>
        <translation>Шкала времени</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="104"/>
        <source>Frame rate</source>
        <translation>Частота кадров</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="246"/>
        <source>Edit...</source>
        <translation>Изменить...</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="73"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="114"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="179"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="186"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="237"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="39"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="227"/>
        <source>Scan mode</source>
        <translation>Режим сканирования</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="169"/>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="193"/>
        <source>Colorspace</source>
        <translation>Цветовое пространство</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="39"/>
        <source>%L1 fps</source>
        <translation>%L1 кадр/с</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="41"/>
        <source>Progressive</source>
        <translation>Последовательный</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="43"/>
        <source>Interlaced</source>
        <translation>Чересстрочный</translation>
    </message>
</context>
<context>
    <name>ToneProducerWidget</name>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="26"/>
        <source>Audio Tone</source>
        <translation>Тембр аудио</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="51"/>
        <source> Hz</source>
        <translation> Гц</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="80"/>
        <source>Level</source>
        <translation>Уровень</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="90"/>
        <source> dB</source>
        <translation> дБ</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.cpp" line="98"/>
        <source>Tone: %1Hz %2dB</source>
        <translation>Тон: %1 Гц %2 дБ</translation>
    </message>
</context>
<context>
    <name>TrackHead</name>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="219"/>
        <source>Unmute</source>
        <translation>Восстановить звук</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="219"/>
        <source>Mute</source>
        <translation>Без звука</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="236"/>
        <source>Show</source>
        <translation>Показать</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="236"/>
        <source>Hide</source>
        <translation>Скрыть</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="183"/>
        <source>Unlock track</source>
        <translation>Разблокировать дорожку</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="183"/>
        <source>Lock track</source>
        <translation>Заблокировать дорожку</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/TrackHead.qml" line="255"/>
        <source>Filters</source>
        <translation>Фильтры</translation>
    </message>
</context>
<context>
    <name>TrackPropertiesWidget</name>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="38"/>
        <source>Blend mode</source>
        <translation>Режим наложения</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="38"/>
        <source>Track: %1</source>
        <translation>Дорожка: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="45"/>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="77"/>
        <source>None</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="46"/>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="78"/>
        <source>Over</source>
        <translation>Свыше</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="47"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="48"/>
        <source>Saturate</source>
        <translation>Насыщение</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="49"/>
        <source>Multiply</source>
        <translation>Умножение</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="50"/>
        <source>Screen</source>
        <translation>Экран</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="51"/>
        <source>Overlay</source>
        <translation>Наложение</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="52"/>
        <source>Darken</source>
        <translation>Затемнение</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="53"/>
        <source>Dodge</source>
        <translation>Осветление</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="54"/>
        <source>Burn</source>
        <translation>Затемнение</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="55"/>
        <source>Hard Light</source>
        <translation>Жёсткий свет</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="56"/>
        <source>Soft Light</source>
        <translation>Мягкий свет</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="57"/>
        <source>Difference</source>
        <translation>Различие</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="58"/>
        <source>Exclusion</source>
        <translation>Исключение</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="59"/>
        <source>HSL Hue</source>
        <translation>HLS тон</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="60"/>
        <source>HSL Saturation</source>
        <translation>HLS насыщенность</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="61"/>
        <source>HSL Color</source>
        <translation>HLS цвет</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="62"/>
        <source>HSL Luminosity</source>
        <translation>HLS яркость</translation>
    </message>
</context>
<context>
    <name>TranscodeDialog</name>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="38"/>
        <source>good</source>
        <translation>хороший</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="48"/>
        <source>better</source>
        <translation>лучший</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="58"/>
        <source>best</source>
        <translation>наилучший</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="94"/>
        <source>medium</source>
        <translation>средний</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="136"/>
        <source>Do not show this anymore.</source>
        <comment>Convert to edit-friendly format dialog</comment>
        <translation>Больше не показывать.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="206"/>
        <source>Change the frame rate from its source.</source>
        <translation>Измените частоту кадров источника.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="262"/>
        <location filename="../src/dialogs/transcodedialog.ui" line="266"/>
        <source>Same as original</source>
        <translation>Как и оригинал</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="271"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="276"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="155"/>
        <source>This is useful when the source video is HDR (High Dynamic Range), which requires tone-mapping to the old, standard range.</source>
        <translation>Это полезно, когда исходным видео является HDR (расширенный динамический диапазон), который требует преобразования тона в старый стандартный диапазон.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="249"/>
        <source>Frame rate conversion</source>
        <translation>Конвертирование частоты кадров</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="165"/>
        <source>This option converts only the trimmed portion of the source
clip plus a little instead of the entire clip. When this option is
used not all of the matching source clips are replaced, instead
only the currently selected one.</source>
        <translation>Эта опция преобразует только обрезанную часть исходного
клипа, вместо всего целиком. Когда используется этот параметр,
заменяются не все исходные клипы,
а только текущий выбранный.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="104"/>
        <source>BIG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="114"/>
        <source>&lt;span style=&quot; font-weight:700; color:#ff0000;&quot;&gt;HUGE&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="171"/>
        <source>Use sub-clip</source>
        <translation>Использовать Субклип</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="219"/>
        <source>Sample rate</source>
        <translation>Частота дискретизации</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="239"/>
        <source>If the source is interlaced, each interlaced field will be converted to a progressive frame resulting in double frame rate.</source>
        <translation>Если источник чересстрочный, каждое чересстрочное поле будет преобразовано в прогрессивный кадр, что приведет к удвоению частоты кадров.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="242"/>
        <source>Deinterlace</source>
        <translation>Деинтерлейсинг</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="178"/>
        <source>Enable this to keep the Advanced section open for the next time this dialog appears.</source>
        <translation>Включите, чтобы сохранить раздел Расширенный открытым при следующем появлении этого диалогового окна.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="181"/>
        <source>Keep Advanced open</source>
        <translation>Оставить Расширенный открытым</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="148"/>
        <source>Override the frame rate to a specific value.</source>
        <translation>Замена частоты кадров на определенное значение.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="188"/>
        <source>Frame rate conversion method

Duplicate: Duplicate frames.
Blend: Blend frames.
Motion Compensation: Interpolate new frames using motion compensation. This method is very slow and may result in artifacts.</source>
        <translation>Способ преобразования частоты кадров

Дубликат: Повторяющиеся кадры.
Смешение: Смешение кадров.
Компенсация движения: Интерполяция новых кадров с помощью компенсации движения. Этот метод очень медленный и может привести к артефактам.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="209"/>
        <source>Override frame rate</source>
        <translation>Коррекция частоты кадров</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="229"/>
        <source>Frames/sec</source>
        <translation>Кадров/с</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.ui" line="158"/>
        <source>Convert to BT.709 colorspace</source>
        <translation>Преобразовать в BT.709</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="34"/>
        <source>Convert to Edit-friendly...</source>
        <translation>Преобразовать для редактирования...</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="51"/>
        <source>Duplicate (fast)</source>
        <translation>Дубликат (быстро)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="52"/>
        <source>Blend</source>
        <translation>Смешение</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="53"/>
        <source>Motion Compensation (slow)</source>
        <translation>Компенсация движения (медленно)</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="56"/>
        <source>Advanced</source>
        <translation>Расширенный</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="146"/>
        <source>Lossy: I-frame–only %1</source>
        <translation>С потерями: только I-кадры %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="150"/>
        <source>Intermediate: %1</source>
        <translation>Средний: %1</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcodedialog.cpp" line="153"/>
        <source>Lossless: %1</source>
        <translation>Без потерь: %1</translation>
    </message>
</context>
<context>
    <name>Transcoder</name>
    <message>
        <location filename="../src/transcoder.cpp" line="58"/>
        <source>Sub-clip</source>
        <translation>Субклип</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="58"/>
        <source>Converted</source>
        <translation>Преобразован</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="66"/>
        <source>MP4 (*.mp4);;All Files (*)</source>
        <translation>MP4 (*.mp4);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="70"/>
        <source>MOV (*.mov);;All Files (*)</source>
        <translation>MOV (*.mov);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="74"/>
        <source>MKV (*.mkv);;All Files (*)</source>
        <translation>MKV (*.mkv);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="102"/>
        <location filename="../src/transcoder.cpp" line="138"/>
        <source>A job already exists for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="109"/>
        <location filename="../src/transcoder.cpp" line="120"/>
        <location filename="../src/transcoder.cpp" line="127"/>
        <source>Convert canceled</source>
        <translation>Преобразование отменено</translation>
    </message>
    <message>
        <location filename="../src/transcoder.cpp" line="349"/>
        <source>Convert %1</source>
        <translation>Преобразовать %1</translation>
    </message>
</context>
<context>
    <name>TranscribeAudioDialog</name>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="73"/>
        <source>Speech to Text</source>
        <translation>Речь в текст</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="85"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="90"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="116"/>
        <source>Translate to English</source>
        <translation>Перевести на английский</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="118"/>
        <source>Maximum line length</source>
        <translation>Максимальная длина строки</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="128"/>
        <source>Include non-spoken sounds</source>
        <translation>Включить непроизносимые звуки</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="130"/>
        <source>Tracks with speech</source>
        <translation>Дорожки с речью</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="131"/>
        <source>Select tracks that contain speech to be transcribed.</source>
        <translation>Выберите треки, содержащие речь для транскрибирования.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="180"/>
        <source>Whisper.cpp executable</source>
        <translation>Исполняемый файл Whisper.cpp</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="190"/>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="213"/>
        <source>Find Whisper.cpp</source>
        <translation>Найти Whisper.cpp</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="203"/>
        <source>GGML Model</source>
        <translation>Модель GGML</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="232"/>
        <source>Configuration</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="326"/>
        <source>Path to Whisper.cpp executable</source>
        <translation>Путь к исполняемому файлу Whisper.cpp</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="331"/>
        <source>Whisper.cpp executable not found</source>
        <translation>Исполняемый файл Whisper.cpp не найден</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="337"/>
        <source>Path to GGML model</source>
        <translation>Путь к модели GGML</translation>
    </message>
    <message>
        <location filename="../src/dialogs/transcribeaudiodialog.cpp" line="342"/>
        <source>GGML model not found</source>
        <translation>Модель GGML не найдена</translation>
    </message>
</context>
<context>
    <name>UndoButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/UndoButton.qml" line="28"/>
        <source>Reset to default</source>
        <translation>Сброс в значения по умолчанию</translation>
    </message>
</context>
<context>
    <name>UnlinkedFilesDialog</name>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="14"/>
        <source>Missing Files</source>
        <translation>Отсутствуют файлы</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="26"/>
        <source>There are missing files in your project. Double-click each row to locate a file.</source>
        <translation>В проекте отсутствуют файлы. Дважды щёлкните по каждой строке для поиска файла.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="78"/>
        <source>This looks at every file in a folder to see if it matches any of the missing files.</source>
        <translation>Просмотр каждого файла в папке, чтобы выяснить, соответствует ли он какому-либо из отсутствующих файлов.</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="81"/>
        <source>Search in Folder...</source>
        <translation>Поиск в папке...</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="43"/>
        <source>Missing</source>
        <translation>Отсутствует</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="44"/>
        <source>Replacement</source>
        <translation>Замена</translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="58"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
</context>
<context>
    <name>Video4LinuxWidget</name>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="36"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="43"/>
        <source>Set the path to the video device file</source>
        <translation>Укажите путь к файлу видеоустройства</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="46"/>
        <source>/dev/video0</source>
        <translation>/dev/video0</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="72"/>
        <source>Video4Linux</source>
        <translation>Video4Linux</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="82"/>
        <source>fps</source>
        <translation>кадр/с</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="102"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="115"/>
        <source>Frame rate</source>
        <translation>Частота кадров</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="125"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="135"/>
        <source>Device</source>
        <translation>Устройство</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="145"/>
        <source>TV Tuner</source>
        <translation>ТВ-тюнер</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="157"/>
        <source>Standard</source>
        <translation>Стандарт</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="167"/>
        <source>Set the television standard</source>
        <translation>Укажите телевизионный стандарт</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="171"/>
        <source>Automatic</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="176"/>
        <source>NTSC</source>
        <translation>NTSC</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="181"/>
        <source>PAL</source>
        <translation>PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="186"/>
        <source>SECAM</source>
        <translation>SECAM</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="194"/>
        <source>Channel</source>
        <translation>Канал</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="213"/>
        <source>Audio Input</source>
        <translation>Аудиовход</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="223"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="236"/>
        <source>pixels</source>
        <translation>пкс</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="249"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="257"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="262"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="267"/>
        <source>ALSA</source>
        <translation>ALSA</translation>
    </message>
</context>
<context>
    <name>VideoHistogramScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="103"/>
        <source>Luma</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="108"/>
        <source>Red</source>
        <translation>Красный</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="113"/>
        <source>Green</source>
        <translation>Зелёный</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="118"/>
        <source>Blue</source>
        <translation>Синий</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="205"/>
        <source>Value: %1
IRE: %2</source>
        <translation>Значение: %1
IRE: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="207"/>
        <source>Value: %1</source>
        <translation>Значение: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videohistogramscopewidget.cpp" line="215"/>
        <source>Video Histogram</source>
        <translation>Гистограмма</translation>
    </message>
</context>
<context>
    <name>VideoQualityJob</name>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="39"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="41"/>
        <source>Open original and encoded side-by-side in the Shotcut player</source>
        <translation>Показать исходный и кодированный файлы рядом в проигрывателе Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="45"/>
        <source>View Report</source>
        <translation>Показать отчёт</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="49"/>
        <source>Show In Files</source>
        <translation>Показать в файлах</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="53"/>
        <source>Show In Folder</source>
        <translation>Показать в папке</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="57"/>
        <source>Measure %1</source>
        <translation>Измерение %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="96"/>
        <source>Video Quality Measurement</source>
        <translation>Измерение качества видео</translation>
    </message>
</context>
<context>
    <name>VideoRgbParadeScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="132"/>
        <source>255</source>
        <translation>255</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="136"/>
        <source>191</source>
        <translation>191</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="140"/>
        <source>127</source>
        <translation>127</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="144"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="148"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="158"/>
        <source>Red</source>
        <translation>Красный</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="160"/>
        <source>Green</source>
        <translation>Зелёный</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="162"/>
        <source>Blue</source>
        <translation>Синий</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="173"/>
        <source>Channel: %1
Pixel: %2
Value: %3</source>
        <translation>Канал: %1
Пикселей: %2
Значение: %3</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="175"/>
        <source>Channel: %1
Value: %2</source>
        <translation>Канал: %1
Значение: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbparadescopewidget.cpp" line="182"/>
        <source>Video RGB Parade</source>
        <translation>RGB Parade</translation>
    </message>
</context>
<context>
    <name>VideoRgbWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="128"/>
        <source>255</source>
        <translation>255</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="132"/>
        <source>191</source>
        <translation>191</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="136"/>
        <source>127</source>
        <translation>127</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="140"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="144"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="159"/>
        <source>Pixel: %1
Value: %2</source>
        <translation>Пикселей %1
Значение: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="161"/>
        <source>Value: %1</source>
        <translation>Значение: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videorgbwaveformscopewidget.cpp" line="168"/>
        <source>Video RGB Waveform</source>
        <translation>RGB Waveform</translation>
    </message>
</context>
<context>
    <name>VideoVectorScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videovectorscopewidget.cpp" line="53"/>
        <source>Video Vector</source>
        <translation>Вектроскоп</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videovectorscopewidget.cpp" line="243"/>
        <source>U: %1
V: %2</source>
        <translation>U: %1
V: %2</translation>
    </message>
</context>
<context>
    <name>VideoWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="120"/>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="124"/>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="125"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="144"/>
        <source>Pixel: %1
IRE: %2</source>
        <translation>Пикселей: %1
IRE: %2</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="146"/>
        <source>IRE: %1</source>
        <translation>IRE: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="153"/>
        <source>Video Waveform</source>
        <translation>Осциллограмма</translation>
    </message>
</context>
<context>
    <name>VideoZoomScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="123"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="125"/>
        <source>y</source>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="128"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="130"/>
        <source>G</source>
        <translation>G</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="132"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="135"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="137"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="139"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="157"/>
        <source>Pick a pixel from the source player</source>
        <translation>Выберите пиксель из проигрывателя</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="164"/>
        <source>Lock/Unlock the selected pixel</source>
        <translation>Блокировать/разблокировать выбранный пиксель</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="273"/>
        <source>%1x</source>
        <translation>%1x</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/videozoomscopewidget.cpp" line="321"/>
        <source>Video Zoom</source>
        <translation>Лупа</translation>
    </message>
</context>
<context>
    <name>WhisperJob</name>
    <message>
        <location filename="../src/jobs/whisperjob.cpp" line="94"/>
        <source>SRT</source>
        <translation>SRT</translation>
    </message>
</context>
<context>
    <name>audioloudnessscope</name>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="186"/>
        <source>Momentary Loudness.</source>
        <translation>Мгновенная громкость.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="229"/>
        <source>Short-term Loudness.</source>
        <translation>Кратковременная громкость.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="272"/>
        <source>Integrated Loudness.</source>
        <translation>Интегральная громкость.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="315"/>
        <source>Loudness Range.</source>
        <translation>Диапазон громкости.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="358"/>
        <source>Peak.</source>
        <translation>Пик.</translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="401"/>
        <source>True Peak.</source>
        <translation>Истинный пик.</translation>
    </message>
</context>
<context>
    <name>filterview</name>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="173"/>
        <source>Select a clip</source>
        <translation>Выбрать клип</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="193"/>
        <source>Add a filter</source>
        <translation>Добавить фильтр</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="210"/>
        <source>Remove selected filter</source>
        <translation>Удалить фильтр</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="232"/>
        <source>Copy filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="247"/>
        <source>Paste filters</source>
        <translation>Вставить фильтры</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="262"/>
        <source>Save a filter set</source>
        <translation>Сохранить набор фильтров</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="284"/>
        <source>Move filter up</source>
        <translation>Переместить фильтр вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="299"/>
        <source>Move filter down</source>
        <translation>Переместить фильтр вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="326"/>
        <source>Deselect the filter</source>
        <translation>Снять выделение фильтра</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="154"/>
        <source>Fill the screen with the Shotcut window.</source>
        <translation>Развернуть окно Shotcut на весь экран.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="158"/>
        <source>Hide upgrade prompt and menu item.</source>
        <translation>Скрыть подсказку об обновлении и пункт меню.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="162"/>
        <source>Run Glaxnimate instead of Shotcut.</source>
        <translation>Запустить Glaxnimate вместо Shotcut.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <source>Use GPU processing.</source>
        <translation>Использовать ГП-обработку.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="169"/>
        <source>Clear Recent on Exit</source>
        <translation>Очищать недавние при выходе</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="174"/>
        <source>The directory for app configuration and data.</source>
        <translation>Папка с данными и конфигурацией программы.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="175"/>
        <source>directory</source>
        <translation>Папка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="179"/>
        <source>The scale factor for a high-DPI screen</source>
        <translation>Коэффициент масштабирования для экрана с высоким разрешением</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="181"/>
        <source>number</source>
        <translation>число</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="185"/>
        <source>A semicolon-separated list of scale factors for each screen</source>
        <translation>Разделённый точкой с запятой список коэффициентов масштаба для каждого экрана</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="188"/>
        <source>list</source>
        <translation>список</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="192"/>
        <source>How to handle a fractional display scale: %1</source>
        <translation>Обработка дробного масштаба отображения: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="194"/>
        <location filename="../src/main.cpp" line="202"/>
        <location filename="../src/main.cpp" line="210"/>
        <source>string</source>
        <translation>строка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="200"/>
        <location filename="../src/main.cpp" line="208"/>
        <source>Which operating system audio API to use: %1</source>
        <translation>Какой звуковой API операционной системы использовать: % 1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="216"/>
        <source>Zero or more files or folders to open</source>
        <translation>Ноль или более файлов или папок для открытия</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="460"/>
        <source>Loading plugins...</source>
        <translation>Загрузка плагинов...</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="437"/>
        <source>Expiring cache...</source>
        <translation>Лимит кеша...</translation>
    </message>
</context>
<context>
    <name>meta</name>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="22"/>
        <source>Alpha Channel: Adjust</source>
        <translation>Альфа-канал: подстройка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="23"/>
        <source>transparency shave shrink grow soft feather</source>
        <comment>search keywords for the Alpha Channel: Adjust video filter</comment>
        <translation>прозрачность срезать сжать увеличить слабый перо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="22"/>
        <source>Alpha Channel: View</source>
        <translation>Альфа-канал: вид</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="23"/>
        <source>transparency</source>
        <comment>search keywords for the Alpha Channel: View video filter</comment>
        <translation>прозрачность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="7"/>
        <source>Balance</source>
        <translation>Баланс</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="8"/>
        <source>pan channel mixer</source>
        <comment>search keywords for the Balance audio filter</comment>
        <translation>панорамирование канал микшер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="19"/>
        <location filename="../src/qml/filters/reframe/meta.qml" line="22"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="7"/>
        <source>Band Pass</source>
        <translation>Полоса частот</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the Band Pass audio filter</comment>
        <translation>частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="18"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="18"/>
        <source>Center Frequency</source>
        <translation>Center Frequency</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="26"/>
        <source>Bandwidth</source>
        <translation>Ширина полосы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/meta.qml" line="8"/>
        <source>Bass &amp; Treble</source>
        <translation>НЧ и ВЧ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="7"/>
        <source>Copy Channel</source>
        <translation>Копировать канал</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="8"/>
        <source>duplicate</source>
        <comment>search keywords for the Copy Channel audio filter</comment>
        <translation>копия</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="7"/>
        <source>Compressor</source>
        <translation>Компрессор</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="8"/>
        <source>loudness dynamics range</source>
        <comment>search keywords for the Compressor audio filter</comment>
        <translation>динамический диапазон громкости</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="7"/>
        <source>Delay</source>
        <translation>Задержка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="8"/>
        <source>time echo</source>
        <comment>search keywords for the Delay audio filter</comment>
        <translation>эхо времени</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="7"/>
        <source>Expander</source>
        <translation>Расширение звука</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="8"/>
        <source>dynamics range</source>
        <comment>search keywords for the Expander audio filter</comment>
        <translation>динамический диапазон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="8"/>
        <source>Fade In Audio</source>
        <translation>Нарастание аудио</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Fade In audio filter</comment>
        <translation>громкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="8"/>
        <source>Fade Out Audio</source>
        <translation>Затухание аудио</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Fade Out audio filter</comment>
        <translation>громкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="7"/>
        <source>Gain / Volume</source>
        <translation>Усиление / Громкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="9"/>
        <source>loudness</source>
        <comment>search keywords for the Gain/Volume audio filter</comment>
        <translation>громкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="20"/>
        <location filename="../src/qml/filters/brightness/meta.qml" line="20"/>
        <location filename="../src/qml/filters/contrast/meta.qml" line="21"/>
        <location filename="../src/qml/filters/dither/meta.qml" line="19"/>
        <location filename="../src/qml/filters/opacity/meta.qml" line="20"/>
        <location filename="../src/qml/filters/threshold/meta.qml" line="18"/>
        <source>Level</source>
        <translation>Уровень</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="7"/>
        <source>High Pass</source>
        <translation>Высокие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the High Pass audio filter</comment>
        <translation>частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="18"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="18"/>
        <source>Cutoff</source>
        <translation>Срез</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="34"/>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="26"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="34"/>
        <source>Rolloff rate</source>
        <translation>Скорость спада</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="41"/>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="33"/>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="33"/>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="25"/>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="41"/>
        <source>Wetness</source>
        <translation>Влажность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="7"/>
        <source>Limiter</source>
        <translation>Предел</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="8"/>
        <source>dynamics range loudness</source>
        <comment>search keywords for the Limiter audio filter</comment>
        <translation>динамический диапазон громкости</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="7"/>
        <source>Low Pass</source>
        <translation>Низкие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="8"/>
        <source>frequency</source>
        <comment>search keywords for the Low Pass audio filter</comment>
        <translation>частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="7"/>
        <source>Downmix</source>
        <translation>Сведение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="8"/>
        <source>stereo mixdown channel</source>
        <comment>search keywords for the Downmix audio filter</comment>
        <translation>канал микширования стерео</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="8"/>
        <source>Mute</source>
        <translation>Без звука</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="9"/>
        <source>silent silence volume</source>
        <comment>search keywords for the Mute audio filter</comment>
        <translation>тихий тишина громкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="7"/>
        <source>Normalize: One Pass</source>
        <translation>Нормализация: один проход</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="8"/>
        <source>volume loudness gain dynamics</source>
        <comment>search keywords for the Normalize: One Pass audio filter</comment>
        <translation>громкость усиление динамика</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="7"/>
        <source>Normalize: Two Pass</source>
        <translation>Нормализация: два прохода</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="9"/>
        <source>volume loudness gain dynamics</source>
        <comment>search keywords for the Normalize: Two Pass audio filter</comment>
        <translation>громкость усиление динамика</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="7"/>
        <source>Notch</source>
        <translation>Засечки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="8"/>
        <source>frequency pass</source>
        <comment>search keywords for the Notch audio filter</comment>
        <translation>частотный пропуск</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="7"/>
        <source>Pan</source>
        <translation>Панорамирование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="8"/>
        <source>stereo balance channel mixer</source>
        <comment>search keywords for the Pan audio filter</comment>
        <translation>стерео баланс канал микшер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="7"/>
        <source>Reverb</source>
        <translation>Реверберация</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="9"/>
        <source>delay time echo</source>
        <comment>search keywords for the Reverb audio filter</comment>
        <translation>задержка время эхо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="18"/>
        <source>Room size</source>
        <translation>Размер комнаты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="26"/>
        <source>Reverb time</source>
        <translation>Время реверберации</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="34"/>
        <source>Damping</source>
        <translation>Демпфирование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="42"/>
        <source>Input bandwidth</source>
        <translation>Входящая ширина полосы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="50"/>
        <source>Dry signal level</source>
        <translation>Уровень сухого сигнала</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="58"/>
        <source>Early reflection level</source>
        <translation>Уровень раннего отражения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="66"/>
        <source>Tail level</source>
        <translation>Уровень хвоста</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="7"/>
        <source>Swap Channels</source>
        <translation>Поменять каналы местами</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="9"/>
        <source>switch stereo</source>
        <comment>search keywords for the Swap Channels audio filter</comment>
        <translation>поменять каналы стерео местами</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="23"/>
        <source>Chroma Key: Simple</source>
        <translation>Хромакей: простой</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="24"/>
        <source>green blue screen</source>
        <comment>search keywords for the Chroma Key: Simple video filter</comment>
        <translation>зелёно-синий экран</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="6"/>
        <source>Brightness</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="8"/>
        <source>lightness value exposure</source>
        <comment>search keywords for the Brightness video filter</comment>
        <translation>значение освещённости выдержка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="6"/>
        <source>Color Grading</source>
        <translation>Сортировка по цвету</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="7"/>
        <source>correct shadows lift midtones gamma highlights gain hue lightness brightness value</source>
        <comment>search keywords for the Color Grading video filter</comment>
        <translation>исправить тени поднять средние тона гамма яркие участки усиление оттенок освещённость яркость значение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="17"/>
        <source>Shadows (Lift)</source>
        <translation>Тени</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="22"/>
        <source>Midtones (Gamma)</source>
        <translation>Полутона (Гамма)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="27"/>
        <source>Highlights (Gain)</source>
        <translation>Яркие участки (Усиление)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="6"/>
        <source>Contrast</source>
        <translation>Контраст</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="7"/>
        <source>variation value</source>
        <comment>search keywords for the Contrast video filter</comment>
        <translation>значение изменения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="6"/>
        <source>Old Film: Dust</source>
        <translation>Старая плёнка: пыль</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="7"/>
        <source>noise dirt hair fiber</source>
        <comment>search keywords for the Old Film: Dust video filter</comment>
        <translation>шум грязь волосы волокно</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="7"/>
        <source>Text: Simple</source>
        <translation>Текст: Простой</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="8"/>
        <source>type font timecode timestamp date filename</source>
        <comment>search keywords for the Text: Simple video filter</comment>
        <translation>тип шрифт временной код временная метка дата имя файла</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="25"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="40"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="26"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="25"/>
        <source>Font color</source>
        <translation>Font color</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="31"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="46"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="32"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="31"/>
        <source>Outline</source>
        <translation>Контурный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="37"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="52"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="38"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="37"/>
        <source>Background</source>
        <translation>Задний план</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="20"/>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="20"/>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="36"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="35"/>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="20"/>
        <location filename="../src/qml/filters/richtext/meta.qml" line="21"/>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="20"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="21"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="20"/>
        <source>Position / Size</source>
        <translation>Позиция / Размер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="7"/>
        <source>Fade In Video</source>
        <translation>Нарастание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="8"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="8"/>
        <source>brightness lightness opacity alpha</source>
        <comment>search keywords for the Fade In video filter</comment>
        <translation>яркость освещённость непрозрачность альфа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="7"/>
        <source>Fade Out Video</source>
        <translation>Затухание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="8"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="8"/>
        <source>brightness lightness opacity alpha</source>
        <comment>search keywords for the Fade Out video filter</comment>
        <translation>яркость освещённость непрозрачность альфа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="6"/>
        <source>Old Film: Grain</source>
        <translation>Старая плёнка: зерно</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="7"/>
        <source>dots particles noise dirt</source>
        <comment>search keywords for the Old Film: Grain video filter</comment>
        <translation>точки частицы шум грязь</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="22"/>
        <source>Hue/Lightness/Saturation</source>
        <translation>Оттенок/Освещённость/Насыщенность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="23"/>
        <source>color value desaturate grayscale</source>
        <comment>search keywords for the Hue/Lightness/Saturation video filter</comment>
        <translation>цвет значение обесцвечивание оттенки серого</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="34"/>
        <source>Hue</source>
        <translation>Оттенок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="41"/>
        <source>Lightness</source>
        <translation>Светлота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/meta.qml" line="48"/>
        <source>Saturation</source>
        <translation>Насыщенность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="6"/>
        <source>Invert Colors</source>
        <translation>Инвертировать цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="7"/>
        <source>reverse opposite negative</source>
        <comment>search keywords for the Invert Colors video filter</comment>
        <translation>обратить противоположный негатив</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="22"/>
        <source>Key Spill: Advanced</source>
        <translation>Хромакей-заливка ключевого: расширенный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="23"/>
        <source>chroma alpha clean suppress</source>
        <comment>search keywords for the Key Spill: Advanced video filter</comment>
        <translation>цветность альфа очистить подавить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="22"/>
        <source>Lens Correction</source>
        <translation>Коррекция объектива</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="23"/>
        <source>deform lens distort wide angle panoramic hemispherical fisheye</source>
        <comment>search keywords for the Lens Correction video filter</comment>
        <translation>деформирующий объектив искажает широкий панорамный полусферический угол рыбий глаз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="34"/>
        <source>X Center</source>
        <translation>Х-центр</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="41"/>
        <source>Y Center</source>
        <translation>Y-центр</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="48"/>
        <source>Correction at Center</source>
        <translation>Коррекция в центре</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/meta.qml" line="55"/>
        <source>Correction at Edges</source>
        <translation>Коррекция по краям</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="6"/>
        <source>Old Film: Scratches</source>
        <translation>Старая плёнка: царапины</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="7"/>
        <source>noise projector lines defect</source>
        <comment>search keywords for the Old Film: Scratches video filter</comment>
        <translation>шум проектор линии дефект</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/meta.qml" line="22"/>
        <source>LUT (3D)</source>
        <translation>LUT (3D)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/meta.qml" line="23"/>
        <source>lookup table color</source>
        <comment>search keywords for the LUT (3D) video filter</comment>
        <translation>поиск таблица цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/meta.qml" line="6"/>
        <source>Mask</source>
        <translation>Маска</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="7"/>
        <source>360: Rectilinear to Equirectangular</source>
        <translation>360: Прямолинейное в равнопрямоугольное</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="8"/>
        <source>spherical projection</source>
        <comment>search keywords for the 360: Rectilinear to Equirectangular video filter</comment>
        <translation>сферическая проекция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="20"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="17"/>
        <location filename="../src/qml/filters/nosync/meta.qml" line="26"/>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="41"/>
        <source>Horizontal</source>
        <translation>По горизонтали</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/meta.qml" line="27"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="24"/>
        <location filename="../src/qml/filters/nosync/meta.qml" line="19"/>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="34"/>
        <source>Vertical</source>
        <translation>По вертикали</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="7"/>
        <source>Mid-Side Matrix</source>
        <translation>Средняя матрица</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="8"/>
        <source>middle stereo microphone</source>
        <comment>search keywords for the Mid-Side Matrix audio filter</comment>
        <translation>средний стереомикрофон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/meta.qml" line="18"/>
        <location filename="../src/qml/filters/mask/meta.qml" line="31"/>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="34"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/meta.qml" line="38"/>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="41"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="6"/>
        <source>Mirror</source>
        <translation>Зеркальное отражение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="7"/>
        <source>horizontal flip transpose flop</source>
        <comment>search keywords for the Mirror video filter</comment>
        <translation>горизонтальный отражение транспонировать переворот</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="22"/>
        <source>Mosaic</source>
        <translation>Мозаика</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mosaic/meta.qml" line="23"/>
        <source>pixelize pixelate</source>
        <comment>search keywords for the Mosaic video filter</comment>
        <translation>пикселизировать точечный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="6"/>
        <source>Diffusion</source>
        <translation>Диффузия</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="7"/>
        <source>blur smooth clean beauty</source>
        <comment>search keywords for the Diffusion video filter</comment>
        <translation>размыть плавный очистить красота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="6"/>
        <source>Old Film: Projector</source>
        <translation>Старая плёнка: проектор</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="7"/>
        <source>glitch flashing brightness vertical slip</source>
        <comment>search keywords for the Old Film: Projector video filter</comment>
        <translation>искажение мерцание яркость вертикальный смещение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="43"/>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="58"/>
        <location filename="../src/qml/filters/opacity/meta.qml" line="7"/>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="44"/>
        <location filename="../src/qml/filters/timer/meta.qml" line="43"/>
        <source>Opacity</source>
        <translation>Непрозрачность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta.qml" line="8"/>
        <source>alpha transparent translucent</source>
        <comment>search keywords for the Opacity video filter</comment>
        <translation>альфа прозрачный просвечивающий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="7"/>
        <source>Rotate and Scale</source>
        <translation>Поворот и масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="7"/>
        <source>matte stencil alpha rectangle ellipse circle triangle diamond</source>
        <comment>search keywords for the Mask: Simple Shape video filter</comment>
        <translation>матовый трафарет альфа прямоугольник эллипс круг треугольник ромб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="20"/>
        <source>Size &amp; Position</source>
        <translation>Размер и позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="26"/>
        <location filename="../src/qml/filters/rotate/meta.qml" line="18"/>
        <source>Rotation</source>
        <translation>Вращение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="25"/>
        <source>Scale</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="33"/>
        <source>X offset</source>
        <translation>Смещение по X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="37"/>
        <source>Y offset</source>
        <translation>Смещение по Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="22"/>
        <source>Chroma Key: Advanced</source>
        <translation>Хромакей: расширенный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="23"/>
        <source>green blue screen</source>
        <comment>search keywords for the Chroma Key: Advanced video filter</comment>
        <translation>зелёно-синий экран</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="6"/>
        <source>Sepia Tone</source>
        <translation>Сепия</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="7"/>
        <source>color old photograph print</source>
        <comment>search keywords for the Sepia Tone video filter</comment>
        <translation>цвет старый фотография печать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/meta.qml" line="6"/>
        <source>Sketch</source>
        <translation>Набросок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/meta.qml" line="7"/>
        <source>drawing painting cartoon</source>
        <comment>search keywords for the Sketch video filter</comment>
        <translation>рисование картина мультфильм</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="23"/>
        <source>Key Spill: Simple</source>
        <translation>Хромакей заливка ключевого: простой</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="24"/>
        <source>chroma alpha clean suppress</source>
        <comment>search keywords for the Key Spill: Simple video filter</comment>
        <translation>цветность альфа очистить подавить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="6"/>
        <source>Stabilize</source>
        <translation>Стабилизировать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="7"/>
        <source>smooth deshake</source>
        <comment>search keywords for the Stabilize video filter</comment>
        <translation>плавный удалить тряску</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="6"/>
        <source>Old Film: %1</source>
        <translation>Старая плёнка: %1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="7"/>
        <source>projector movie</source>
        <comment>search keywords for the Old Film: Technocolor video filter</comment>
        <translation>проектор фильм</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/unpremultiply/meta.qml" line="22"/>
        <source>Unpremultiply Alpha</source>
        <translation>Отменить умножение альфа-канала в обратном порядке</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/unpremultiply/meta.qml" line="23"/>
        <source>disassociate associated straight</source>
        <comment>search keywords for the Unpremultiply Alpha video filter</comment>
        <translation>отменить связь связанный прямой</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="6"/>
        <source>Wave</source>
        <translation>Волна</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="7"/>
        <source>distort deform frequency water warp bend</source>
        <comment>search keywords for the Wave video filter</comment>
        <translation>исказить деформировать частота вода искривить изогнуть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="7"/>
        <source>Crop: Circle</source>
        <translation>Кадрирование: Круг</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="8"/>
        <source>trim remove oval ellipse</source>
        <comment>search keywords for the Crop: Circle video filter</comment>
        <translation>обрезать удалить овал эллипс</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="26"/>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="18"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="6"/>
        <source>Halftone</source>
        <translation>Полутон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="7"/>
        <source>360: Hemispherical to Equirectangular</source>
        <translation>360: Полусферическое в равнопрямоугольное</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="9"/>
        <source>spherical projection dual fisheye</source>
        <comment>search keywords for the 360: Hemispherical to Equirectangular video filter</comment>
        <translation>сферическая проекция двойной рыбий глаз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="48"/>
        <location filename="../src/qml/filters/crop_circle/meta.qml" line="19"/>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="24"/>
        <location filename="../src/qml/filters/halftone/meta.qml" line="19"/>
        <source>Radius</source>
        <translation>Радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="55"/>
        <source>Front X</source>
        <translation>Фронт X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="62"/>
        <source>Front Y</source>
        <translation>Фронт Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="69"/>
        <source>Front Up</source>
        <translation>Фронт верх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="76"/>
        <source>Back X</source>
        <translation>Тыл X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="83"/>
        <source>Back Y</source>
        <translation>Тыл Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="90"/>
        <source>Back Up</source>
        <translation>Тыл верх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="97"/>
        <source>Nadir Radius</source>
        <translation>Радиус надира</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="104"/>
        <source>Nadir Start</source>
        <translation>Надир начало</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="7"/>
        <source>noise dots newsprint</source>
        <comment>search keywords for the Halftone video filter</comment>
        <translation>шум точки газетная бумага</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="26"/>
        <source>Cyan</source>
        <translation>Голубой</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="33"/>
        <source>Magenta</source>
        <translation>Пурпурный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/meta.qml" line="40"/>
        <source>Yellow</source>
        <translation>Жёлтый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="7"/>
        <source>Spot Remover</source>
        <translation>Удаление пятен</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spot_remover/meta.qml" line="8"/>
        <source>delogo dirt clean watermark</source>
        <comment>search keywords for the Spot Remover video filter</comment>
        <translation>удалить логотип грязь очистить водяной знак</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/meta.qml" line="7"/>
        <source>Timer</source>
        <translation>Таймер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/meta.qml" line="8"/>
        <source>text seconds timestamp</source>
        <comment>search keywords for the Timer video filter</comment>
        <translation>текст секунды временная метка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="6"/>
        <source>Levels</source>
        <comment>Levels video filter</comment>
        <translation>Уровни</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="7"/>
        <source>gamma value black white color</source>
        <comment>search keywords for the Levels video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="18"/>
        <source>Input Black</source>
        <translation>Входной чёрный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="25"/>
        <source>Input White</source>
        <translation>Входной белый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/meta.qml" line="32"/>
        <source>Gamma</source>
        <translation>Гамма</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/meta.qml" line="6"/>
        <source>Mask: Simple Shape</source>
        <translation>Маска: Простая</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_apply/meta.qml" line="6"/>
        <source>Mask: Apply</source>
        <translation>Маска: Применить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_apply/meta.qml" line="7"/>
        <source>matte stencil alpha confine composite bounce</source>
        <comment>search keywords for the Mask: Apply video filter</comment>
        <translation>матовый трафарет альфа ограничить составной возврат</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="6"/>
        <source>Mask: From File</source>
        <translation>Маска: Из файла</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="7"/>
        <source>matte stencil alpha luma wipe custom</source>
        <comment>search keywords for the Mask: From File video filter</comment>
        <translation>матовый трафарет альфа яркость ластик пользовательский</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="7"/>
        <source>Noise Gate</source>
        <translation>Пороговый шумоподавитель</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="8"/>
        <source>hum hiss distortion clean</source>
        <comment>search keywords for the Noise Gate audio filter</comment>
        <translation>гудение шипение искажение очистить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="18"/>
        <source>Key Filter: Low Frequency</source>
        <translation>Ключ. фильтр: НЧ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="25"/>
        <source>Key Filter: High Frequency</source>
        <translation>Ключ. фильтр: ВЧ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="32"/>
        <location filename="../src/qml/filters/mask_shape/meta.qml" line="20"/>
        <location filename="../src/qml/filters/threshold/meta.qml" line="6"/>
        <source>Threshold</source>
        <translation>Порог</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="39"/>
        <source>Attack</source>
        <translation>Атака</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="46"/>
        <source>Hold</source>
        <translation>Удержание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="53"/>
        <source>Decay</source>
        <translation>Распад</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/meta.qml" line="60"/>
        <source>Range</source>
        <translation>Диапазон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/meta.qml" line="7"/>
        <source>Audio Waveform Visualization</source>
        <translation>Визуализация осциллограммы аудио</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/meta.qml" line="8"/>
        <source>music visualizer reactive</source>
        <comment>search keywords for the Audio Waveform Visualization video filter</comment>
        <translation>музыкальный визуализатор реактивный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="22"/>
        <source>Chroma Hold</source>
        <translation>Удержание цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="23"/>
        <source>color hue select choose pick</source>
        <comment>search keywords for the Chroma Hold video filter</comment>
        <translation>цвет оттенок выбрать задать указать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/meta.qml" line="34"/>
        <source>Distance</source>
        <translation>Дистанция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="6"/>
        <source>Grid</source>
        <translation>Сетка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="7"/>
        <source>repeat</source>
        <comment>search keywords for the Grid video filter</comment>
        <translation>повтор</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="18"/>
        <source>Rows</source>
        <translation>Строки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/meta.qml" line="25"/>
        <source>Columns</source>
        <translation>Столбцы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="22"/>
        <source>Distort</source>
        <translation>Искажение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="23"/>
        <source>deform wiggle wave</source>
        <comment>search keywords for the Distort video filter</comment>
        <translation>деформировать колебание волна</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="34"/>
        <source>Amplitude</source>
        <translation>Амплитуда</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="41"/>
        <location filename="../src/qml/filters/glitch/meta.qml" line="34"/>
        <source>Frequency</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/meta.qml" line="48"/>
        <source>Velocity</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="22"/>
        <source>Glitch</source>
        <translation>Искажение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="23"/>
        <source>defect broken distort</source>
        <comment>search keywords for the Glitch video filter</comment>
        <translation>дефект повреждённый исказить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="41"/>
        <source>Block height</source>
        <translation>Высота блока</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="48"/>
        <source>Shift intensity</source>
        <translation>Интенсивность сдвига</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/meta.qml" line="55"/>
        <source>Color intensity</source>
        <translation>Интенсивность цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="22"/>
        <source>RGB Shift</source>
        <translation>RGB-сдвиг</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rgbsplit0r/meta.qml" line="23"/>
        <source>glitch chroma analog split</source>
        <comment>search keywords for the RGB Shift video filter</comment>
        <translation>сбой в аналоговом разделителе цветности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="22"/>
        <source>Blur: Exponential</source>
        <translation>Размытие: Экспоненциальное</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Exponential video filter</comment>
        <translation>смягчить замутнить скрыть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="7"/>
        <source>360: Equirectangular to Stereographic</source>
        <translation>360: Равноугольный к стереографическому</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="8"/>
        <source>spherical projection tiny small planet</source>
        <comment>search keywords for the 360: Equirectangular to Stereographic video filter</comment>
        <translation>сферическая проекция крошечный маленький планета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="49"/>
        <location filename="../src/qml/filters/blur_exponential/meta.qml" line="35"/>
        <location filename="../src/qml/filters/blur_gaussian/meta.qml" line="34"/>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="35"/>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="35"/>
        <source>Amount</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta.qml" line="22"/>
        <source>Blur: Gaussian</source>
        <translation>Размытие: Гауссово</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="22"/>
        <source>Blur: Low Pass</source>
        <translation>Размытие: Простое</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_lowpass/meta.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Low Pass video filter</comment>
        <translation>смягчить замутнить скрыть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="6"/>
        <source>Crop: Source</source>
        <translation>Кадрирование: Источник</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="7"/>
        <source>trim remove edges</source>
        <comment>search keywords for the Crop: Source video filter</comment>
        <translation>обрезать удалить края</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta.qml" line="6"/>
        <source>Flip</source>
        <translation>Переворот</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta.qml" line="7"/>
        <source>vertical flop transpose rotate</source>
        <comment>search keywords for the Flip video filter</comment>
        <translation>вертикальный переворот транспонировать повернуть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="22"/>
        <source>Reduce Noise: HQDN3D</source>
        <translation>Уменьшить шум: HQDN3D</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="23"/>
        <source>denoise artifact dirt smooth</source>
        <comment>search keywords for the Reduce Noise: HQDN3D video filter</comment>
        <translation>убрать шум артифакт грязь плавный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="34"/>
        <source>Spatial</source>
        <translation>Пространственный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/meta.qml" line="41"/>
        <source>Temporal</source>
        <translation>Временной</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_fast/meta.qml" line="22"/>
        <source>Noise: Fast</source>
        <translation>Шум: Сильно</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_fast/meta.qml" line="23"/>
        <source>dirt grunge</source>
        <comment>search keywords for the Noise: Fast video filter</comment>
        <translation>грязь гранж</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="22"/>
        <source>Noise: Keyframes</source>
        <translation>Шум: Ключевые кадры</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/noise_keyframes/meta.qml" line="23"/>
        <source>dirt grunge</source>
        <comment>search keywords for the Noise: Keyframes video filter</comment>
        <translation>грязь гранж</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="22"/>
        <source>Reduce Noise: Smart Blur</source>
        <translation>Уменьшить шум: Умное размытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="23"/>
        <source>denoise artifact clean</source>
        <comment>search keywords for the Reduce Noise: Smart Blur video filter</comment>
        <translation>убрать шум артифакт очистить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="7"/>
        <source>Crop: Rectangle</source>
        <translation>Кадрирование: Прямоугольник</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="8"/>
        <source>trim remove square</source>
        <comment>search keywords for the Crop: Rectangle video filter</comment>
        <translation>обрезать удалить квадрат</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="25"/>
        <source>Corner radius</source>
        <translation>Радиус закругления</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/meta.qml" line="32"/>
        <source>Padding color</source>
        <translation>Цвет заполнения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/meta.qml" line="6"/>
        <source>Blend Mode</source>
        <translation>Режим наложения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/meta.qml" line="7"/>
        <source>blending composite porter duff</source>
        <comment>search keywords for the Blend Mode video filter</comment>
        <translation>смешение составной портер дафф</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/meta.qml" line="6"/>
        <source>Dither</source>
        <translation>Сглаживание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/meta.qml" line="7"/>
        <source>noise dots</source>
        <comment>search keywords for the Dither video filter</comment>
        <translation>шум точки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="22"/>
        <source>Elastic Scale</source>
        <translation>Гибкое масштабирование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="23"/>
        <source>stretch nonlinear</source>
        <comment>search keywords for the Elastic Scale video filter</comment>
        <translation>растянуть нелинейный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="35"/>
        <source>Center</source>
        <translation>Центральный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="42"/>
        <source>Linear width</source>
        <translation>Линейная ширина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="49"/>
        <source>Linear scale factor</source>
        <translation>Величина линейного масштаба</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/meta.qml" line="56"/>
        <source>Non-Linear scale factor</source>
        <translation>Величина нелинейного масштаба</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="6"/>
        <source>Posterize</source>
        <translation>Постеризация</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="7"/>
        <source>reduce colors banding cartoon</source>
        <comment>search keywords for the Posterize video filter</comment>
        <translation>уменьшить цветовые полосы мультфильм</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/meta.qml" line="19"/>
        <source>Levels</source>
        <comment>Posterize filter</comment>
        <translation>Уровни</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nervous/meta.qml" line="6"/>
        <source>Nervous</source>
        <translation>Дрожание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nervous/meta.qml" line="7"/>
        <source>random shake twitch glitch</source>
        <comment>search keywords for the Nervous video filter</comment>
        <translation>случайный тряска дрожание искажение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nosync/meta.qml" line="6"/>
        <source>No Sync</source>
        <translation>Рассинхронизация</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/nosync/meta.qml" line="7"/>
        <source>horizontal vertical synchronization slip analog</source>
        <comment>search keywords for the No Sync video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/trails/meta.qml" line="6"/>
        <source>Trails</source>
        <translation>Полосы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/trails/meta.qml" line="7"/>
        <source>temporal mix psychedelic motion blur</source>
        <comment>search keywords for the Trails video filter</comment>
        <translation>временной микс психоделический движение размыть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="22"/>
        <source>Vertigo</source>
        <translation>Круговорот</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="23"/>
        <source>temporal mix dizzy psychedelic</source>
        <comment>search keywords for the Vertigo video filter</comment>
        <translation>временной микс головокружение психоделический</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="35"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="41"/>
        <location filename="../src/qml/filters/vertigo/meta.qml" line="42"/>
        <source>Zoom</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="6"/>
        <source>Choppy</source>
        <translation>Растрескивание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="7"/>
        <source>fps framerate</source>
        <comment>search keywords for the Choppy video filter</comment>
        <translation>частота кадров</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/meta.qml" line="19"/>
        <source>Repeat</source>
        <translation>Повтор</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/meta.qml" line="7"/>
        <source>Gradient</source>
        <translation>Градиент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/meta.qml" line="8"/>
        <source>graduated color spectrum</source>
        <comment>search keywords for the Gradient video filter</comment>
        <translation>градуированный цветовой спектр</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/scanlines/meta.qml" line="6"/>
        <source>Scan Lines</source>
        <translation>Линии сканера</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/scanlines/meta.qml" line="7"/>
        <source>analog horizontal television</source>
        <comment>search keywords for the Scan Lines video filter</comment>
        <translation>аналоговый горизонтальный телевидение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="7"/>
        <source>360: Equirectangular Mask</source>
        <translation>360: Равнопрямоугольная маска</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="9"/>
        <source>spherical matte stencil</source>
        <comment>search keywords for the 360: Equirectangular Mask video filter</comment>
        <translation>сферический матовый трафарет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="20"/>
        <source>Horizontal Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="27"/>
        <source>Horizontal End</source>
        <translation>Конец</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="34"/>
        <source>Vertical Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/meta.qml" line="41"/>
        <source>Vertical End</source>
        <translation>Конец</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="7"/>
        <source>360: Equirectangular to Rectilinear</source>
        <translation>360: Равнопрямоугольное в прямолинейное</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="9"/>
        <source>spherical projection</source>
        <comment>search keywords for the 360: Equirectangular to Rectilinear video filter</comment>
        <translation>сферическая проекция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="7"/>
        <source>Ambisonic Decoder</source>
        <translation>Амбисоник декодер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="9"/>
        <source>spatial surround binaural</source>
        <comment>search keywords for the Ambisonic Decoder audio filter</comment>
        <translation>пространственное объемное бинауральное</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="20"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="21"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="21"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="20"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="21"/>
        <source>Yaw</source>
        <translation>Смещение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="27"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="28"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="28"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="27"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="28"/>
        <source>Pitch</source>
        <comment>rotation around the side-to-side axis (roll, pitch, yaw)</comment>
        <translation>Питч</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/meta.qml" line="34"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="35"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="35"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="34"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="35"/>
        <source>Roll</source>
        <translation>Наклон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="42"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/meta.qml" line="42"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/meta.qml" line="41"/>
        <source>FOV</source>
        <comment>field of view</comment>
        <translation>Поле зрения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/meta.qml" line="49"/>
        <location filename="../src/qml/filters/fisheye/meta.qml" line="22"/>
        <source>Fisheye</source>
        <translation>Рыбий глаз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="22"/>
        <source>Corner Pin</source>
        <translation>Привязка по углам</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="23"/>
        <source>stretch distort pinch twist deform</source>
        <comment>search keywords for the Corner Pin video filter</comment>
        <translation>растянуть исказить сжать изогнуть деформировать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="35"/>
        <source>Corners</source>
        <translation>Углы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="40"/>
        <source>Stretch X</source>
        <translation>Тянуть по X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="47"/>
        <source>Stretch Y</source>
        <translation>Тянуть по Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/meta.qml" line="54"/>
        <source>Feathering</source>
        <translation>Растушёвка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/meta.qml" line="7"/>
        <source>360: Stabilize</source>
        <translation>360: Стабилизация</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/meta.qml" line="8"/>
        <source>spherical smooth deshake</source>
        <comment>search keywords for the 360: Stabilize video filter</comment>
        <translation>сферический плавный удалить тряску</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="7"/>
        <source>360: Transform</source>
        <translation>360: Трансформация</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/meta.qml" line="9"/>
        <source>spherical yaw pitch roll</source>
        <comment>search keywords for the 360: Transform video filter</comment>
        <translation>сферический смещение питч наклон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/meta.qml" line="23"/>
        <source>Reduce Noise: Wavelet</source>
        <translation>Уменьшить шум: Вейвлет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/meta.qml" line="24"/>
        <source>vague denoise artifact dirt</source>
        <comment>search keywords for the Reduce Noise: Wavelet video filter</comment>
        <translation>нечёткий убрать шум артифакт грязь</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="7"/>
        <source>Text: Rich</source>
        <translation>Текст: RTF</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="8"/>
        <source>type font format overlay</source>
        <comment>search keywords for the Text: Rich video filter</comment>
        <translation>тип шрифт формат наложение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/meta.qml" line="26"/>
        <source>Background color</source>
        <translation>Цвет фона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="7"/>
        <source>Blur: Pad</source>
        <translation>Размытие: Планшет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/pillar_echo/meta.qml" line="8"/>
        <source>pillar echo fill</source>
        <comment>search keywords for the Blur: Pad video filter</comment>
        <translation>колонна эхо заполнить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_invert/meta.qml" line="7"/>
        <source>Invert</source>
        <translation>Инвертировать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_invert/meta.qml" line="8"/>
        <source>phase</source>
        <comment>search keywords for the Invert audio filter</comment>
        <translation>фаза</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/meta.qml" line="22"/>
        <source>Reduce Noise: Quantization</source>
        <translation>Уменьшение шума: Квантование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/meta.qml" line="23"/>
        <source>denoise artifact postprocess compress</source>
        <comment>search keywords for the Reduce Noise: Quantization video filter</comment>
        <translation>убрать шум артифакт постобработка сжать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="7"/>
        <source>Time Remap</source>
        <translation>Изменение времени</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="8"/>
        <source>temporal speed ramp reverse fast slow motion</source>
        <comment>search keywords for the Time: Remap filter</comment>
        <translation>временная рампа скорости с обратным быстрым замедлением движения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/meta.qml" line="21"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/meta.qml" line="23"/>
        <source>Deband</source>
        <translation>Удаление полос</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/meta.qml" line="24"/>
        <source>mean average median contour</source>
        <comment>search keywords for the Deband video filter</comment>
        <translation>среднее медиана контур</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="22"/>
        <source>GPS Text</source>
        <translation>GPS-текст</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/meta.qml" line="23"/>
        <source>gpx</source>
        <comment>search keywords for the GPS Text video filter</comment>
        <translation>gpx</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reflect/meta.qml" line="6"/>
        <source>Reflect</source>
        <translation>Отразить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reflect/meta.qml" line="7"/>
        <source>mirror repeat</source>
        <comment>search keywords for the Reflect video filter</comment>
        <translation>повтор отражения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_chromakey/meta.qml" line="22"/>
        <source>Mask: Chroma Key</source>
        <translation>Маска: Хромакей</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_chromakey/meta.qml" line="23"/>
        <source>matte stencil alpha color</source>
        <comment>search keywords for the Mask: Chroma Key video filter</comment>
        <translation>матовый трафарет альфа цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="7"/>
        <source>Equalizer: 15-Band</source>
        <translation>Эквалайзер: 15-полос</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: 15-Band audio filter</comment>
        <translation>тон частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="19"/>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="19"/>
        <source>Equalizer</source>
        <translation>Эквалайзер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="7"/>
        <source>Equalizer: Parametric</source>
        <translation>Эквалайзер: Параметрический</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: Parametric audio filter</comment>
        <translation>тон частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/meta.qml" line="7"/>
        <source>Audio Level Visualization</source>
        <translation>Визуализация Уровня звука</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/meta.qml" line="8"/>
        <source>music visualizer reactive</source>
        <comment>search keywords for the Audio Level Visualization video filter</comment>
        <translation>музыкальный визуализатор реактивный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="7"/>
        <source>Equalizer: 3-Band (Bass &amp; Treble)</source>
        <translation>Эквалайзер: 3-полосы (НЧ и ВЧ)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/meta.qml" line="8"/>
        <source>tone frequency</source>
        <comment>search keywords for the Equalizer: 3-Band audio filter</comment>
        <translation>тон частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="7"/>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="19"/>
        <source>Pitch</source>
        <comment>audio pitch or tone</comment>
        <translation>Питч</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/meta.qml" line="9"/>
        <source>frequency tone</source>
        <comment>search keywords for the Pitch audio filter</comment>
        <translation>частота тон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/meta.qml" line="7"/>
        <source>Stereo Enhancer</source>
        <translation>Стереоусилитель</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/meta.qml" line="9"/>
        <source>channel spatial delay</source>
        <comment>search keywords for the Stereo Enhancer audio filter</comment>
        <translation>канал пространственный задержка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/meta.qml" line="6"/>
        <source>Mask: Draw</source>
        <translation>Маска: Рисовать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/meta.qml" line="7"/>
        <source>rotoscope matte stencil alpha</source>
        <comment>search keywords for the Mask: Draw video filter</comment>
        <translation>ротоскоп матовый трафарет альфа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/meta.qml" line="23"/>
        <source>deform lens distort wide angle panoramic hemispherical</source>
        <comment>search keywords for the Fisheye video filter</comment>
        <translation>деформирующий объектив искажает широкий панорамный полусферический  угол</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="22"/>
        <source>GPS Graphic</source>
        <translation>График GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/meta.qml" line="23"/>
        <source>gpx sticker decal gauge map graph speedometer</source>
        <comment>search keywords for the GPS Graphic video filter</comment>
        <translation>gpx стикер маркер датчик карта диаграмма спидометр</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/threshold/meta.qml" line="7"/>
        <source>black white luma</source>
        <comment>search keywords for the Threshold video filter</comment>
        <translation>чёрный белый яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/meta.qml" line="6"/>
        <source>Motion Tracker</source>
        <translation>Датчик движения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/meta.qml" line="8"/>
        <source>tracking</source>
        <comment>search keywords for the Motion Tracker video filter</comment>
        <translation>отслеживание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/meta.qml" line="7"/>
        <source>Track Auto Fade Audio</source>
        <translation>Отслеживать автоматическое затухание звука</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/meta.qml" line="8"/>
        <source>click splice fade</source>
        <comment>search keywords for the Auto Fade audio filter</comment>
        <translation>щелкните по соединению затухания</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/meta.qml" line="7"/>
        <source>Track Seam</source>
        <translation>Стык дорожки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/meta.qml" line="8"/>
        <source>click splice seam</source>
        <comment>search keywords for the Seam audio filter</comment>
        <translation>щелкните по соединению шва</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/meta.qml" line="6"/>
        <source>Declick Audio</source>
        <translation>Отклонить Аудио</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/meta.qml" line="8"/>
        <source>declick crackle pop</source>
        <comment>search keywords for the Declick audio filter</comment>
        <translation>отклонить треск поп</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/meta.qml" line="7"/>
        <source>Track Auto Fade Video</source>
        <translation>Отслеживать автоматическое затухание видео</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/meta.qml" line="8"/>
        <source>splice fade dip</source>
        <comment>search keywords for the Track Auto Fade Video filter</comment>
        <translation>стык с затуханием</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="7"/>
        <source>Ambisonic Encoder</source>
        <translation>Амбисоник-кодер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="9"/>
        <source>spatial surround panner</source>
        <comment>search keywords for the Ambisonic Encoder audio filter</comment>
        <translation>панорама объёмного звучания</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="20"/>
        <source>Azimuth</source>
        <translation>Азимут</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/meta.qml" line="27"/>
        <source>Elevation</source>
        <translation>Высота над уровнем моря</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="6"/>
        <source>Drop Shadow</source>
        <translation>Тень</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="7"/>
        <source></source>
        <comment>search keywords for the Drop Shadow video filter</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="31"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dropshadow/meta.qml" line="38"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="22"/>
        <source>Vibrance</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="23"/>
        <source>color intensity saturation vibe</source>
        <comment>search keywords for the Vibrance video filter</comment>
        <translation>интенсивность цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="34"/>
        <source>Intensity</source>
        <translation>Интенсивность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="41"/>
        <source>Red</source>
        <translation>Красный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="48"/>
        <source>Green</source>
        <translation>Зелёный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vibrance/meta.qml" line="55"/>
        <source>Blue</source>
        <translation>Синий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="7"/>
        <source>Subtitle Burn In</source>
        <translation>Записать субтитры в</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/meta.qml" line="8"/>
        <source>subtitle overlay burn</source>
        <comment>search keywords for the Subtitle Burn In video filter</comment>
        <translation>запись наложения субтитров</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/meta.qml" line="7"/>
        <source>Reframe</source>
        <translation>Переделать рамку</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/meta.qml" line="8"/>
        <source>crop trim remove square vertical portrait</source>
        <comment>search keywords for the Reframe video filter</comment>
        <translation>обрезать в вертикальный портрет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/meta.qml" line="7"/>
        <source>Gradient Map</source>
        <translation>Градиентная карта</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/meta.qml" line="8"/>
        <source>color mapping intensity</source>
        <comment>search keywords for the Gradient Map video filter</comment>
        <translation>карта цветовой интенсивности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="6"/>
        <source>HSL Primaries</source>
        <translation>Первичный HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="8"/>
        <source>hue saturation lightness color</source>
        <comment>search keywords for the HSL Primaries video filter</comment>
        <translation>оттенок насыщенность яркость цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="18"/>
        <source>Overlap</source>
        <translation>Перекрытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="25"/>
        <source>Red Hue</source>
        <translation>Красный оттенок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="32"/>
        <source>Red Saturation</source>
        <translation>Багрянец</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="39"/>
        <source>Red Lightness</source>
        <translation>Светло-красный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="46"/>
        <source>Yellow Hue</source>
        <translation>Жёлтый оттенок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="53"/>
        <source>Yellow Saturation</source>
        <translation>Канареечный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="60"/>
        <source>Yellow Lightness</source>
        <translation>Светло-желтый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="67"/>
        <source>Green Hue</source>
        <translation>Зелёный оттенок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="74"/>
        <source>Green Saturation</source>
        <translation>Травяной</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="81"/>
        <source>Green Lightness</source>
        <translation>Светло-зеленый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="88"/>
        <source>Cyan Hue</source>
        <translation>Голубой оттенок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="95"/>
        <source>Cyan Saturation</source>
        <translation>Кобальтовый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="102"/>
        <source>Cyan Lightness</source>
        <translation>Светло-голубой</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="109"/>
        <source>Blue Hue</source>
        <translation>Синий оттенок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="116"/>
        <source>Blue Saturation</source>
        <translation>Индиго</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="123"/>
        <source>Blue Lightness</source>
        <translation>Светло-синий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="130"/>
        <source>Magenta Hue</source>
        <translation>Фиолетовый оттенок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="137"/>
        <source>Magenta Saturation</source>
        <translation>Черничный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/meta.qml" line="144"/>
        <source>Magenta Lightness</source>
        <translation>Светло-фиолетовый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="6"/>
        <source>HSL Range</source>
        <translation>Диапазон HSL</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="8"/>
        <source>hue saturation lightness color primaries</source>
        <comment>search keywords for the HSL Range video filter</comment>
        <translation>оттенок насыщенность яркость основных цветов</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="18"/>
        <source>Blend</source>
        <translation>Смешение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="25"/>
        <source>Hue Shift</source>
        <translation>Изменение оттенка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="32"/>
        <source>Saturation Scale</source>
        <translation>Шкала Насыщенности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="39"/>
        <source>Lightness Scale</source>
        <translation>Шкала Светлоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="46"/>
        <source>Hue Center</source>
        <translation>Центр оттенка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/meta.qml" line="53"/>
        <source>Hue Range</source>
        <translation>Диапазон оттенков</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="7"/>
        <source>360: Cap Top &amp; Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="9"/>
        <source>spherical fill blur zenith nadir</source>
        <comment>search keywords for the 360: Cap Top &amp; Bottom video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="38"/>
        <source>topStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="45"/>
        <source>topEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="52"/>
        <source>topBlendIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="59"/>
        <source>topBlendOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="66"/>
        <source>topFadeIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="73"/>
        <source>topBlurWidthStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="80"/>
        <source>topBlurWidthEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="87"/>
        <source>topBlurHeightStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="94"/>
        <source>topBlurHeightEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="102"/>
        <source>bottomStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="109"/>
        <source>bottomEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="116"/>
        <source>bottomBlendIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="123"/>
        <source>bottomBlendOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="130"/>
        <source>bottomFadeIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="137"/>
        <source>bottomBlurWidthStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="144"/>
        <source>bottomBlurWidthEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="151"/>
        <source>bottomBlurHeightStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/meta.qml" line="158"/>
        <source>bottomBlurHeightEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="7"/>
        <source>360: Equirectangular Wrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="9"/>
        <source>spherical stretch</source>
        <comment>search keywords for the 360: Equirectangular Wrap video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="18"/>
        <source>hfov0</source>
        <translation>hfov0</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="25"/>
        <source>hfov1</source>
        <translation>hfov1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="32"/>
        <source>vfov0</source>
        <translation>vfov0</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="39"/>
        <source>vfov1</source>
        <translation>vfov1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="46"/>
        <source>blurStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/meta.qml" line="53"/>
        <source>blurEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/meta.qml" line="7"/>
        <source>360: Zenith Correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/meta.qml" line="8"/>
        <source>spherical level</source>
        <comment>search keywords for the 360: Zenith correction filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/meta.qml" line="6"/>
        <source>Clarity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/meta.qml" line="7"/>
        <source>histogram equalization constrast detail color distribution</source>
        <comment>search keywords for the Clarity video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="6"/>
        <source>Alpha Strobe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="7"/>
        <source>strobe alpha</source>
        <comment>search keywords for the Strobe video filter</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/meta.qml" line="17"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_affine</name>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="7"/>
        <source>Size, Position &amp; Rotate</source>
        <translation>Размер, позиция и поворот</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="8"/>
        <source>transform zoom rotation distort fill move</source>
        <comment>search keywords for the Size, Position &amp; Rotate video filter</comment>
        <translation>преобразовать масштаб вращение исказить заполнить переместить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="21"/>
        <source>Size &amp; Position</source>
        <translation>Размер и позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="26"/>
        <source>Rotation</source>
        <translation>Вращение</translation>
    </message>
</context>
<context>
    <name>meta_av</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="22"/>
        <source>Blur: Gaussian</source>
        <translation>Размытие: Гауссово</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="23"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur: Box video filter</comment>
        <translation>смягчить замутнить скрыть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/meta_av.qml" line="35"/>
        <source>Amount</source>
        <translation>Количество</translation>
    </message>
</context>
<context>
    <name>meta_box_blur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="6"/>
        <source>Blur: Box</source>
        <translation>Размытие: По рамке</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="7"/>
        <source>soften obscure hide directional</source>
        <comment>search keywords for the Blur: Box video filter</comment>
        <translation>смягчить замутнить скрыть направленный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="18"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_box_blur.qml" line="25"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
</context>
<context>
    <name>meta_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="6"/>
        <source>Blur: Box</source>
        <translation>Размытие: По рамке</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="17"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="24"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
</context>
<context>
    <name>meta_dance</name>
    <message>
        <location filename="../src/qml/filters/dance/meta_dance.qml" line="7"/>
        <source>Audio Dance Visualization</source>
        <translation>Визуализация движения звука</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/meta_dance.qml" line="8"/>
        <source>music visualizer reactive transform move size position rotate rotation</source>
        <comment>search keywords for the Audio Dance Visualization video filter</comment>
        <translation>музыкальный визуализатор реактивный преобразовать переместить размер положение позиция повернуть вращение</translation>
    </message>
</context>
<context>
    <name>meta_forward</name>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="8"/>
        <source>Speed: Forward Only</source>
        <translation>Скорость: Только вперед</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="9"/>
        <source>temporal speed ramp fast slow motion</source>
        <comment>search keywords for the Speed filter</comment>
        <translation>временная рампа скорости с быстрым замедлением движения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward.qml" line="23"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
</context>
<context>
    <name>meta_forward_reverse</name>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="8"/>
        <source>Speed: Forward &amp; Reverse</source>
        <translation>Скорость: Вперед и Обратно</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="9"/>
        <source>temporal speed ramp fast slow motion reverse</source>
        <comment>search keywords for the Speed filter</comment>
        <translation>временный эффект рампы скорости с противоположным быстрым замедлением движения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/speed/meta_forward_reverse.qml" line="24"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
</context>
<context>
    <name>meta_frei0r</name>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="6"/>
        <source>Glow</source>
        <translation>Цветовая яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="7"/>
        <source>shine blur</source>
        <comment>search keywords for the Glow video filter</comment>
        <translation>блеск размытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="19"/>
        <source>Blur</source>
        <translation>Размытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="6"/>
        <source>Saturation</source>
        <translation>Насыщенность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="7"/>
        <source>color desaturate grayscale chroma</source>
        <comment>search keywords for the Saturation video filter</comment>
        <translation>цвет обесцвечивание оттенки серого цветность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="19"/>
        <source>Level</source>
        <translation>Уровень</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="6"/>
        <source>Sharpen</source>
        <translation>Повысить резкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="7"/>
        <source>sharpness focus clear crisp</source>
        <comment>search keywords for the Sharpen video filter</comment>
        <translation>резкость фокус очистить чёткий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="19"/>
        <source>Amount</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="26"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="6"/>
        <source>White Balance</source>
        <translation>Баланс белого</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="7"/>
        <source>color correct light temperature neutral</source>
        <comment>search keywords for the White Balance video filter</comment>
        <translation>цвет исправить свет температура нейтральный</translation>
    </message>
</context>
<context>
    <name>meta_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/meta_frei0r_coloradj.qml" line="7"/>
        <source>Color Grading</source>
        <translation>Цветовая шкала</translation>
    </message>
</context>
<context>
    <name>meta_lightshow</name>
    <message>
        <location filename="../src/qml/filters/lightshow/meta_lightshow.qml" line="7"/>
        <source>Audio Light Visualization</source>
        <translation>Визуализация свечения звука</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/meta_lightshow.qml" line="8"/>
        <source>music visualizer reactive color</source>
        <comment>search keywords for the Audio Light Visualization video filter</comment>
        <translation>музыкальный визуализатор реактивный цвет</translation>
    </message>
</context>
<context>
    <name>meta_movit</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="6"/>
        <source>Blur</source>
        <translation>Размытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="7"/>
        <source>soften obscure hide</source>
        <comment>search keywords for the Blur video filter</comment>
        <translation>смягчить замутнить скрыть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="19"/>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="19"/>
        <source>Radius</source>
        <translation>Радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="6"/>
        <source>Brightness</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="7"/>
        <source>lightness value</source>
        <comment>search keywords for the Brightness video filter</comment>
        <translation>значение освещённости</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="21"/>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="21"/>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="20"/>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="19"/>
        <source>Level</source>
        <translation>Уровень</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="6"/>
        <source>Color Grading</source>
        <translation>Цветовая шкала</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="7"/>
        <source>correct shadows lift midtones gamma highlights gain hue lightness brightness value</source>
        <comment>search keywords for the Color Grading video filter</comment>
        <translation>исправить тени поднять средние тона гамма яркие участки усиление оттенок освещённость яркость значение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="17"/>
        <source>Shadows (Lift)</source>
        <translation>Тени</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="22"/>
        <source>Midtones (Gamma)</source>
        <translation>Полутона (Гамма)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="27"/>
        <source>Highlights (Gain)</source>
        <translation>Яркие участки (Усиление)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="6"/>
        <source>Contrast</source>
        <translation>Контраст</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="7"/>
        <source>variation value</source>
        <comment>search keywords for the Contrast video filter</comment>
        <translation>значение изменения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="6"/>
        <source>Glow</source>
        <translation>Цветовая яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="7"/>
        <source>shine blur</source>
        <comment>search keywords for the Glow video filter</comment>
        <translation>блеск размытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="26"/>
        <source>Highlight blurriness</source>
        <translation>Подсветить размытость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="33"/>
        <source>Highlight cutoff</source>
        <translation>Подсветить отсечки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="6"/>
        <source>Mirror</source>
        <translation>Зеркальное отражение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="7"/>
        <source>horizontal flip transpose flop</source>
        <comment>search keywords for the Mirror video filter</comment>
        <translation>горизонтальный отражение транспонировать переворот</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="7"/>
        <source>Opacity</source>
        <translation>Непрозрачность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="8"/>
        <source>alpha transparent translucent</source>
        <comment>search keywords for the Opacity video filter</comment>
        <translation>альфа прозрачный просвечивающий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="6"/>
        <source>Saturation</source>
        <translation>Насыщенность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="7"/>
        <source>color desaturate grayscale chroma</source>
        <comment>search keywords for the Saturation video filter</comment>
        <translation>цвет обесцвечивание оттенки серого цветность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="6"/>
        <source>Sharpen</source>
        <translation>Повысить резкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="7"/>
        <source>sharpness focus clear crisp</source>
        <comment>search keywords for the Sharpen video filter</comment>
        <translation>резкость фокус очистить чёткий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="19"/>
        <source>Circle radius</source>
        <translation>Радиус окружности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="26"/>
        <source>Gaussian radius</source>
        <translation>Радиус Гаусса</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="33"/>
        <source>Correlation</source>
        <translation>Взаимосвязь</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="40"/>
        <source>Noise</source>
        <translation>Шум</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="6"/>
        <source>Vignette</source>
        <translation>Виньетирование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="7"/>
        <source>dark edges fade</source>
        <comment>search keywords for the Vignette video filter</comment>
        <translation>тёмный края исчезание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="19"/>
        <source>Outer radius</source>
        <translation>Внешний радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="26"/>
        <source>Inner radius</source>
        <translation>Внутренний радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="6"/>
        <source>White Balance</source>
        <translation>Баланс белого</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="7"/>
        <source>color correct light temperature neutral</source>
        <comment>search keywords for the White Balance video filter</comment>
        <translation>цвет исправить свет температура нейтральный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta_movit.qml" line="6"/>
        <source>Flip</source>
        <translation>Перевернуть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/flip/meta_movit.qml" line="7"/>
        <source>vertical flop transpose rotate</source>
        <comment>search keywords for the Flip video filter</comment>
        <translation>вертикальный переворот транспонировать повернуть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="6"/>
        <source>Crop: Source</source>
        <translation>Кадрирование: Источник</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="7"/>
        <source>trim remove edges</source>
        <comment>search keywords for the Crop: Source video filter</comment>
        <translation>обрезать удалить края</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="7"/>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="24"/>
        <source>Size &amp; Position</source>
        <translation>Размер и позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="8"/>
        <source>transform zoom distort fill move</source>
        <comment>search keywords for the Size and Position filter</comment>
        <translation>преобразовать масштаб исказить заполнить переместить</translation>
    </message>
</context>
<context>
    <name>meta_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="6"/>
        <source>Vignette</source>
        <translation>Виньетирование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="7"/>
        <source>dark edges fade</source>
        <comment>search keywords for the Vignette video filter</comment>
        <translation>тёмный края исчезание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="18"/>
        <source>Radius</source>
        <translation>Радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="25"/>
        <source>Feathering</source>
        <translation>Растушёвка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="32"/>
        <source>Opacity</source>
        <translation>Непрозрачность</translation>
    </message>
</context>
<context>
    <name>meta_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/meta_spectrum.qml" line="7"/>
        <source>Audio Spectrum Visualization</source>
        <translation>Визуализация спектра аудио</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/meta_spectrum.qml" line="8"/>
        <source>music visualizer reactive frequency</source>
        <comment>search keywords for the Audio Spectrum Visualization video filter</comment>
        <translation>реактивная частота музыкального визуализатора</translation>
    </message>
</context>
<context>
    <name>timeline</name>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="178"/>
        <source>Output</source>
        <translation>Вывод</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="208"/>
        <source>Filters</source>
        <translation>Фильтры</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="313"/>
        <source>Move %1</source>
        <translation>Шаг %1</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="355"/>
        <source>Can not move audio track above video track</source>
        <translation>Не удаётся переместить звуковую дорожку выше видеодорожки</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="357"/>
        <source>Can not move video track below audio track</source>
        <translation>Невозможно переместить видеодорожку ниже звуковой дорожки</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="359"/>
        <source>Track %1 was not moved</source>
        <translation>Дорожка %1 не была перемещена</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="706"/>
        <source>Insert</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="706"/>
        <source>Overwrite</source>
        <translation>Перезаписать</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1028"/>
        <source>Do you want to insert an audio or video track?</source>
        <translation>Вы хотите вставить аудио или видео дорожку?</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1038"/>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <location filename="../src/qml/views/timeline/timeline.qml" line="1046"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
</context>
<context>
    <name>ui</name>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="58"/>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="296"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="353"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="46"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="82"/>
        <source>No Change</source>
        <translation>Не изменять</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="87"/>
        <source>Shave</source>
        <translation>Срезать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="92"/>
        <source>Shrink Hard</source>
        <translation>Сильное сжатие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="97"/>
        <source>Shrink Soft</source>
        <translation>Слабое сжатие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="102"/>
        <source>Grow Hard</source>
        <translation>Сильное увеличение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="107"/>
        <source>Grow Soft</source>
        <translation>Слабое увеличение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="112"/>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="98"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="150"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="138"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="189"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="570"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="118"/>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="158"/>
        <source>Threshold</source>
        <translation>Порог</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="117"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="653"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="916"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="129"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="287"/>
        <source>Blur</source>
        <translation>Размытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="136"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="547"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="543"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="618"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="693"/>
        <location filename="../src/qml/filters/blur_exponential/ui.qml" line="84"/>
        <location filename="../src/qml/filters/blur_lowpass/ui.qml" line="84"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="79"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="82"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="55"/>
        <location filename="../src/qml/filters/noise_fast/ui.qml" line="60"/>
        <location filename="../src/qml/filters/noise_keyframes/ui.qml" line="84"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="63"/>
        <source>Amount</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="164"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="171"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="445"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="405"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="124"/>
        <source>Invert</source>
        <translation>Инвертировать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="50"/>
        <source>Display</source>
        <translation>Дисплей</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="66"/>
        <source>Gray Alpha</source>
        <translation>Серый альфа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="71"/>
        <source>Red &amp; Gray Alpha</source>
        <translation>Красный и серый альфа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="76"/>
        <source>Checkered Background</source>
        <translation>Контролируемый фон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="81"/>
        <source>Black Background</source>
        <translation>Чёрный фон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="86"/>
        <source>Gray Background</source>
        <translation>Серый фон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="91"/>
        <source>White Background</source>
        <translation>Белый фон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="122"/>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="134"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="139"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="61"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="200"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="68"/>
        <source>Left</source>
        <translation>Левый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="132"/>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="134"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="148"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="61"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="220"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="63"/>
        <source>Right</source>
        <translation>Правый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="254"/>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="152"/>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="54"/>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="80"/>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="99"/>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="79"/>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="174"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="68"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="49"/>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="109"/>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="111"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="109"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="56"/>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="142"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="74"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="74"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="68"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="87"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="78"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="138"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="137"/>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="75"/>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="72"/>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="92"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="451"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="232"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="294"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="295"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="314"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="692"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="150"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="308"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="211"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="125"/>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="50"/>
        <location filename="../src/qml/filters/blur_exponential/ui.qml" line="65"/>
        <location filename="../src/qml/filters/blur_lowpass/ui.qml" line="65"/>
        <location filename="../src/qml/filters/brightness/ui.qml" line="138"/>
        <location filename="../src/qml/filters/choppy/ui.qml" line="62"/>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="69"/>
        <location filename="../src/qml/filters/color/ui.qml" line="177"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="144"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="304"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="99"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="185"/>
        <location filename="../src/qml/filters/deband/ui.qml" line="197"/>
        <location filename="../src/qml/filters/distort/ui.qml" line="77"/>
        <location filename="../src/qml/filters/dither/ui.qml" line="67"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="81"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="47"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="157"/>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="83"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="432"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="720"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="900"/>
        <location filename="../src/qml/filters/fspp/ui.qml" line="52"/>
        <location filename="../src/qml/filters/glitch/ui.qml" line="82"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="482"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="679"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="196"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="246"/>
        <location filename="../src/qml/filters/grain/ui.qml" line="48"/>
        <location filename="../src/qml/filters/grid/ui.qml" line="137"/>
        <location filename="../src/qml/filters/halftone/ui.qml" line="82"/>
        <location filename="../src/qml/filters/histeq/ui.qml" line="50"/>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="70"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="140"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="109"/>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="75"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="96"/>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="82"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="154"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="51"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="153"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="326"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="52"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="204"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="71"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="42"/>
        <location filename="../src/qml/filters/noise_fast/ui.qml" line="47"/>
        <location filename="../src/qml/filters/noise_keyframes/ui.qml" line="65"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="71"/>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="59"/>
        <location filename="../src/qml/filters/opacity/ui.qml" line="106"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="129"/>
        <location filename="../src/qml/filters/posterize/ui.qml" line="65"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="192"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="70"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="271"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="136"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="105"/>
        <location filename="../src/qml/filters/sepia/ui.qml" line="37"/>
        <location filename="../src/qml/filters/sketch/ui.qml" line="52"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="55"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="161"/>
        <location filename="../src/qml/filters/strobe/ui.qml" line="97"/>
        <location filename="../src/qml/filters/subtitle/ui.qml" line="83"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="47"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="70"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="290"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="117"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="109"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="50"/>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="108"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="70"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="81"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="85"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="42"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="79"/>
        <location filename="../src/qml/filters/white/ui.qml" line="64"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="72"/>
        <source>The size of the window, in milliseconds, which will be processed at once.</source>
        <translation>The size of the window, in milliseconds, which will be processed at once.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="101"/>
        <source>The strength of impulsive noise which is going to be removed. The lower value, the more samples will be detected as impulsive noise.</source>
        <translation>The strength of impulsive noise which is going to be removed. The lower value, the more samples will be detected as impulsive noise.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="126"/>
        <source>Burst Fusion</source>
        <translation>Burst Fusion</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="129"/>
        <source>Treat small bursts that are close together as one large burst. Units are percent of the window size. A higher percent will combine bursts that are farther apart.</source>
        <translation>Treat small bursts that are close together as one large burst. Units are percent of the window size. A higher percent will combine bursts that are farther apart.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="32"/>
        <source>Fast Fade</source>
        <translation>Быстрое затухание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="93"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="98"/>
        <source>Fade duration</source>
        <translation>Продолжительность затухания</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="97"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="102"/>
        <source>The duration of fade to apply at the begining and end of each clip</source>
        <translation>Длительность затухания, применяемая в начале и конце каждого клипа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="133"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="168"/>
        <source>Fade in</source>
        <translation>Затухание вход</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="137"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="172"/>
        <source>Status indicator showing when a fade in has occured.</source>
        <translation>Индикатор состояния, показывающий, когда произошло затухание.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="163"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="198"/>
        <source>Fade out</source>
        <translation>Затухание выход</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_autofade/ui.qml" line="167"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="202"/>
        <source>Status indicator showing when a fade out has occured.</source>
        <translation>Индикатор состояния, показывающий, когда произошло затухание.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="98"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="97"/>
        <source>Center frequency</source>
        <translation>Центральная частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="125"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="124"/>
        <source>Bandwidth</source>
        <translation>Ширина полосы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="152"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="151"/>
        <source>Rolloff rate</source>
        <translation>Скорость спада</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="178"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="110"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="146"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="146"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="114"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="177"/>
        <source>Dry</source>
        <translation>Сухие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="188"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="120"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="156"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="156"/>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="124"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="187"/>
        <source>Wet</source>
        <translation>Мокрые</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="215"/>
        <source>Bass</source>
        <translation>Низкие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="245"/>
        <source>Middle</source>
        <comment>Bass &amp; Treble audio filter</comment>
        <translation>Средние</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="275"/>
        <source>Treble</source>
        <translation>Высокие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Front left</source>
        <translation>Передний левый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Front right</source>
        <translation>Передний правый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="117"/>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="102"/>
        <source>Center</source>
        <translation>Центральный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Low frequency</source>
        <translation>Низкие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Left surround</source>
        <translation>Левый объемный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="33"/>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="33"/>
        <source>Right surround</source>
        <translation>Правый объемный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="54"/>
        <source>Copy from</source>
        <translation>Копировать из</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="65"/>
        <source>to</source>
        <translation>в</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="81"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="69"/>
        <source>RMS</source>
        <translation>RMS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="85"/>
        <source>The balance between the RMS and peak envelope followers. RMS is generally better for subtle, musical compression and peak is better for heavier, fast compression and percussion.</source>
        <translation>Выбор между RMS и &quot;Пик&quot; имеет свои предпочтения. RMS обычно лучше для тонкой музыкальной компрессии, а &quot;Пик&quot; - для тяжёлой, быстрой компрессии и перкуссии.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="95"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="83"/>
        <source>Peak</source>
        <translation>Пик</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="96"/>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="218"/>
        <source>Attack</source>
        <translation>Атака</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="129"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="117"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="125"/>
        <source>Release</source>
        <translation>Время спада</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="154"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="142"/>
        <source>The point at which the compressor will start to kick in.</source>
        <translation>Точка, в которой компрессор начнёт отступать.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="176"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="164"/>
        <source>Ratio</source>
        <translation>Коэффициент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="180"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="168"/>
        <source>The gain reduction ratio used when the signal level exceeds the threshold.</source>
        <translation>Коэффициент уменьшения усиления используется, когда уровень сигнала превышает порог.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="201"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="189"/>
        <source>Knee radius</source>
        <translation>Радиус перегиба</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="205"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="193"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="315"/>
        <source>The distance from the threshold where the knee curve starts.</source>
        <translation>Расстояние от порога, где начинается кривая колена.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="227"/>
        <source>Makeup gain</source>
        <translation>Усиление структуры</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="231"/>
        <source>The gain of the makeup input signal.</source>
        <translation>Усиление структуры входного сигнала.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="270"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="166"/>
        <source>Gain Reduction</source>
        <translation>Уменьшение усиления</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="274"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="170"/>
        <source>Status indicator showing the gain reduction applied by the compressor.</source>
        <translation>Индикатор уменьшения усиления компрессором.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="294"/>
        <source>About dynamic range compression</source>
        <translation>О сжатии динамического диапазона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="62"/>
        <source>Delay</source>
        <translation>Задержка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="66"/>
        <source>The neutral delay time is 2 seconds.
Times above 2 seconds will have reduced quality.
Times below will have increased CPU usage.</source>
        <translation>Нейтральное время задержки составляет 2 секунды.
Время, превышающее 2 секунды, приведет к снижению качества.
Время, указанное ниже, приведет к увеличению нагрузки ЦП.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="88"/>
        <source>Feedback</source>
        <translation>Обратная связь</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="73"/>
        <source>The balance between the RMS and peak envelope followers.
RMS is generally better for subtle, musical compression.
Peak is better for heavier, fast compression and percussion.</source>
        <translation>Выбор между RMS и &quot;Пик&quot; имеет свои предпочтения.
RMS обычно лучше для тонкой музыкальной компрессии.
&quot;Пик&quot; - для тяжёлой, быстрой компрессии и перкуссии.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="215"/>
        <source>Attenuation</source>
        <translation>Смягчение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="219"/>
        <source>The gain of the output signal.
Used to correct for excessive amplitude caused by the extra dynamic range.</source>
        <translation>Коэффициент усиления выходного сигнала.
Используется для коррекции чрезмерной амплитуды, вызванной дополнительным динамическим диапазоном.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="67"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="72"/>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="62"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="67"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="271"/>
        <source>Duration</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="166"/>
        <location filename="../src/qml/filters/brightness/ui.qml" line="162"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="167"/>
        <location filename="../src/qml/filters/opacity/ui.qml" line="131"/>
        <location filename="../src/qml/filters/threshold/ui.qml" line="89"/>
        <source>Level</source>
        <translation>Уровень</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="93"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="93"/>
        <source>Cutoff frequency</source>
        <translation>Отсечка частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="73"/>
        <source>Input gain</source>
        <translation>Усиление входа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="77"/>
        <source>Gain that is applied to the input stage. Can be used to trim gain to bring it roughly under the limit or to push the signal against the limit.</source>
        <translation>Усиление, которое применяется к входной стадии. Может быть использовано для обрезки усиления, чтобы привести его примерно под предел или отправить сигнал за предел.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="99"/>
        <source>Limit</source>
        <translation>Предел</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="103"/>
        <source>The maximum output amplitude. Peaks over this level will be attenuated as smoothly as possible to bring them as close as possible to this level.</source>
        <translation>Максимальная выходная амплитуда. Пики более этого уровня будут ослаблены так гладко, как только возможно, чтобы довести их как можно ближе до этого уровня.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="129"/>
        <source>The time taken for the limiter&apos;s attenuation to return to 0 dB&apos;s.</source>
        <translation>Время, затраченное для затухания до 0 dB.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="100"/>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="67"/>
        <source>Target Loudness</source>
        <translation>Требуемая громкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="104"/>
        <source>The target loudness of the output in LUFS.</source>
        <translation>Целевая громкость выходного сигнала в LUFS (Loudness Unit relative to Full Scale - единица громкости относительно полной шкалы).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="125"/>
        <source>Analysis Window</source>
        <translation>Окно анализа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="129"/>
        <source>The amount of history to use to calculate the input loudness.</source>
        <translation>Объём истории, используемый для расчёта входной громкости.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="150"/>
        <source>Maximum Gain</source>
        <translation>Максимальное усиление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="154"/>
        <source>The maximum that the gain can be increased.</source>
        <translation>Максимум, до которого усиление может быть увеличено.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="175"/>
        <source>Minimum Gain</source>
        <translation>Минимальное усиление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="179"/>
        <source>The maximum that the gain can be decreased.</source>
        <translation>Максимум, до которого усиление может быть уменьшено.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="200"/>
        <source>Maximum Rate</source>
        <translation>Максимальное отношение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="204"/>
        <source>The maximum rate that the gain can be changed.</source>
        <translation>Максимальная степень изменения усиления.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="230"/>
        <source>Reset on discontinuity</source>
        <translation>Сброс при перерыве</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="234"/>
        <source>Reset the measurement if a discontinuity is detected - such as seeking or clip change.</source>
        <translation>Сбросьте измерение, если появился перерыв - например, поиск или смена клипа.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="260"/>
        <source>Input Loudness</source>
        <translation>Входная громкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="264"/>
        <source>Status indicator showing the loudness measured on the input.</source>
        <translation>Индикатор, отображающий громкость, измеренную на входе.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="283"/>
        <source>Output Gain</source>
        <translation>Выходное усиление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="287"/>
        <source>Status indicator showing the gain being applied.</source>
        <translation>Индикатор, отображающий, что было применено усиление.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="122"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="304"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="308"/>
        <source>Status indicator showing when the loudness measurement is reset.</source>
        <translation>Индикатор, отображающий, что измерение громкости сброшено.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="26"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="35"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="30"/>
        <source>Analyzing...</source>
        <translation>Анализ...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="30"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="38"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="32"/>
        <source>Analysis complete.</source>
        <translation>Анализ завершён.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="33"/>
        <source>%1 LUFS</source>
        <translation>%1 LUFS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="36"/>
        <source>%1 dB</source>
        <translation> %1 дБ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="38"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="34"/>
        <source>Click &quot;Analyze&quot; to use this filter.</source>
        <translation>Нажмите &quot;Анализ&quot;, чтобы использовать этот фильтр.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="97"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="360"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="165"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="376"/>
        <source>Analyze</source>
        <translation>Анализ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="128"/>
        <source>Detected Loudness:</source>
        <translation>Обнаруженная громкость:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="132"/>
        <source>The loudness calculated by the analysis.</source>
        <translation>Громкость, рассчитанная с помощью анализа.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="143"/>
        <source>Normalization Gain:</source>
        <translation>Усиление нормализации:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="147"/>
        <source>The gain applied to normalize to the Target Loudness.</source>
        <translation>Усиление применяется для нормализации Требуемой громкости.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="126"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="175"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="491"/>
        <source>Channel</source>
        <translation>Канал</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="83"/>
        <source>Quick fix</source>
        <translation>Быстрое исправление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="91"/>
        <source>Small hall</source>
        <translation>Малый зал</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="99"/>
        <source>Large hall</source>
        <translation>Большой зал</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="107"/>
        <source>Sewer</source>
        <translation>Водосток</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="115"/>
        <source>Church</source>
        <translation>Церковь</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="156"/>
        <source>Room size</source>
        <translation>Размер комнаты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="160"/>
        <source>The size of the room, in meters. Excessively large, and excessively small values will make it sound a bit unrealistic. Values of around 30 sound good.</source>
        <translation>Размер комнаты в метрах. Очень большие или очень маленькие значения могут сделать звук нереалистичным. Хороший результат дают значения, близкие к 30.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="187"/>
        <source>Reverb time</source>
        <translation>Время реверберации</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="215"/>
        <source>Damping</source>
        <translation>Демпфирование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="219"/>
        <source>This controls the high frequency damping (a lowpass filter), values near 1 will make it sound very bright, values near 0 will make it sound very dark.</source>
        <translation>Контроль высоких частот демпфирования (фильтр нижних частот), значения около 1 - очень яркий звук, около 0 - очень тёмный.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="247"/>
        <source>Input bandwidth</source>
        <translation>Входящая ширина полосы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="251"/>
        <source>This is like a damping control for the input, it has a similar effect to the damping control, but is subtly different.</source>
        <translation>Похоже на управление демпфированием для ввода, эффект похож на контроль демпфирования, но немного иной.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="279"/>
        <source>Dry signal level</source>
        <translation>Уровень сухого сигнала</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="283"/>
        <source>The amount of dry signal to be mixed with the reverberated signal.</source>
        <translation>Количество сухого сигнала для смешивания с сигналом реверберации.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="311"/>
        <source>Early reflection level</source>
        <translation>Уровень раннего отражения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="342"/>
        <source>Tail level</source>
        <translation>Уровень хвоста</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="346"/>
        <source>The quantity of early reflections (scatter reflections directly from the source).</source>
        <translation>Количество ранних отражений (разброс отражения непосредственно из источника).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="375"/>
        <source>About reverb</source>
        <translation>О реверберации</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="55"/>
        <source>Swap</source>
        <translation>Подкачка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/ui.qml" line="66"/>
        <source>with</source>
        <translation>с</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="66"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="109"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="68"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="118"/>
        <source>Key color</source>
        <translation>Ключевой цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="86"/>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="110"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="88"/>
        <source>Distance</source>
        <translation>Дистанция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="203"/>
        <source>Shadows (Lift)</source>
        <translation>Тени</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="241"/>
        <source>Midtones (Gamma)</source>
        <translation>Полутона (Гамма)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="279"/>
        <source>Highlights (Gain)</source>
        <translation>Яркие участки (Усиление)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/ui.qml" line="140"/>
        <source>Center bias</source>
        <translation>Центр смещения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="503"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="160"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="78"/>
        <source>Top</source>
        <translation>Верхний</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="566"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="829"/>
        <source>Fade</source>
        <translation>Затухание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="601"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="864"/>
        <source>In</source>
        <translation>От</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="627"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="890"/>
        <source>Out</source>
        <translation>Вывод</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="662"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="925"/>
        <source>Width at start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="688"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="951"/>
        <source>Height at start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="714"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="977"/>
        <source>Width at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="740"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="1003"/>
        <source>Height at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="766"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="180"/>
        <location filename="../src/qml/filters/reflect/ui.qml" line="73"/>
        <source>Bottom</source>
        <translation>Нижний</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="239"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="291"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="60"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1584"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="370"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="471"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="231"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="301"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="265"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="204"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="187"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="61"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="87"/>
        <source>Bottom Left</source>
        <translation>Внизу слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="65"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="91"/>
        <source>Bottom Right</source>
        <translation>Внизу справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="69"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>Top Left</source>
        <translation>Вверху слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="73"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>Top Right</source>
        <translation>Вверху справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="77"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="206"/>
        <source>Lower Third</source>
        <translation>Нижняя треть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="81"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="222"/>
        <source>Slide In From Left</source>
        <translation>Выезд слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="83"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="224"/>
        <source>Slide In From Right</source>
        <translation>Выезд справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="85"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="226"/>
        <source>Slide In From Top</source>
        <translation>Выезд сверху</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="87"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="228"/>
        <source>Slide In From Bottom</source>
        <translation>Выезд снизу</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="91"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="232"/>
        <source>Slide Out Left</source>
        <translation>Отъезд влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="93"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="234"/>
        <source>Slide Out Right</source>
        <translation>Отъезд вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="95"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="236"/>
        <source>Slide Out Top</source>
        <translation>Отъезд вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="97"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="238"/>
        <source>Slide Out Bottom</source>
        <translation>Отъезд вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="101"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="242"/>
        <source>Slow Zoom In</source>
        <translation>Медленное увеличение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="103"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="244"/>
        <source>Slow Zoom Out</source>
        <translation>Медленное уменьшение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="105"/>
        <source>Slow Pan Left</source>
        <translation>Медленное панорамирование влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="106"/>
        <source>Slow Move Left</source>
        <translation>Медленное движение влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="108"/>
        <source>Slow Pan Right</source>
        <translation>Медленное панорамирование вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="109"/>
        <source>Slow Move Right</source>
        <translation>Медленное движение вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="111"/>
        <source>Slow Pan Up</source>
        <translation>Медленное панорамирование вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="112"/>
        <source>Slow Move Up</source>
        <translation>Медленное движение вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="114"/>
        <source>Slow Pan Down</source>
        <translation>Медленное панорамирование вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="115"/>
        <source>Slow Move Down</source>
        <translation>Медленное движение вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="117"/>
        <source>Slow Zoom In, Pan Up Left</source>
        <translation>Медленное увеличение, панорамирование вверх и влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="118"/>
        <source>Slow Zoom In, Move Up Left</source>
        <translation>Медленное увеличение, движение вверх влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="120"/>
        <source>Slow Zoom In, Pan Down Right</source>
        <translation>Медленное увеличение, панорамирование вниз и вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="121"/>
        <source>Slow Zoom In, Move Down Right</source>
        <translation>Медленное увеличение, движение вниз вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="123"/>
        <source>Slow Zoom Out, Pan Up Right</source>
        <translation>Медленное уменьшение, панорамирование вверх и вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="124"/>
        <source>Slow Zoom Out, Move Up Right</source>
        <translation>Медленное уменьшение, движение вверх вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="126"/>
        <source>Slow Zoom Out, Pan Down Left</source>
        <translation>Медленное уменьшение, панорамирование вниз и влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="127"/>
        <source>Slow Zoom Out, Move Down Left</source>
        <translation>Медленное уменьшение, движение вниз влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="187"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="709"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="277"/>
        <source>Insert field</source>
        <translation>Вставить поле</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="299"/>
        <source># (Hash sign)</source>
        <translation># (решётка)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="304"/>
        <source>Timecode (drop frame)</source>
        <translation>Timecode (drop frame)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="309"/>
        <source>Timecode (non-drop frame)</source>
        <translation>Timecode (non-drop frame)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="339"/>
        <source>File base name</source>
        <translation>File base name</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="314"/>
        <source>Frame #</source>
        <comment>Frame number</comment>
        <translation>Кадр #</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="319"/>
        <source>File date</source>
        <translation>Дата файла</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="324"/>
        <source>Creation date</source>
        <translation>Creation date</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="329"/>
        <source>File name and path</source>
        <translation>File name and path</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="334"/>
        <source>File name</source>
        <translation>Имя файла</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="130"/>
        <source>Bar</source>
        <translation>Панель</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="130"/>
        <source>Segment</source>
        <translation>Сегмент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="138"/>
        <source>Graph Colors</source>
        <translation>Цвета графика</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="168"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1447"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="126"/>
        <source>Thickness</source>
        <translation>Толщина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="192"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="216"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1529"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="313"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="367"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="390"/>
        <location filename="../src/qml/filters/pillar_echo/ui.qml" line="156"/>
        <location filename="../src/qml/filters/reframe/ui.qml" line="222"/>
        <location filename="../src/qml/filters/richtext/ui.qml" line="310"/>
        <location filename="../src/qml/filters/spot_remover/ui.qml" line="188"/>
        <location filename="../src/qml/filters/tracker/ui.qml" line="144"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="146"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="293"/>
        <source>Mirror the levels.</source>
        <translation>Отражение уровней.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="305"/>
        <source>Reverse the levels.</source>
        <translation>Реверс уровней.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="314"/>
        <source>Channels</source>
        <translation>Каналы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="337"/>
        <source>Segments</source>
        <translation>Сегменты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="360"/>
        <source>Segment Gap</source>
        <translation>Разрыв сегмента</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="98"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="92"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="98"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="95"/>
        <source>Adjust opacity instead of fade with black</source>
        <translation>Изменить прозрачность вместо затухания в темноту</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="61"/>
        <source>Noise</source>
        <translation>Шум</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="80"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="503"/>
        <source>Brightness</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="92"/>
        <source>Hue</source>
        <translation>Оттенок</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1428"/>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="101"/>
        <source> °</source>
        <comment>degrees</comment>
        <translation> °</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="119"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="118"/>
        <source>Lightness</source>
        <translation>Свет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hue_lightness_saturation/ui.qml" line="146"/>
        <source>Saturation</source>
        <translation>Насыщенность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="135"/>
        <source>Target color</source>
        <translation>Целевой цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="162"/>
        <source>Mask type</source>
        <translation>Тип маски</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Color Distance</source>
        <translation>Цветовая дистанция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Transparency</source>
        <translation>Прозрачность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Edge Inwards</source>
        <translation>Край внутрь</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="170"/>
        <source>Edge Outwards</source>
        <translation>Край наружу</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="182"/>
        <source>Tolerance</source>
        <translation>Допуск</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="128"/>
        <source>&lt;b&gt;Low Shelf&lt;/b&gt;</source>
        <translation>&lt;b&gt;Нижний отступ&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="204"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="281"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="359"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="437"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="515"/>
        <source>Gain</source>
        <translation>Усиление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="228"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="539"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="202"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="315"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="329"/>
        <source>Slope</source>
        <translation>Наклон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="251"/>
        <source>&lt;b&gt;Band 1&lt;/b&gt;</source>
        <translation>&lt;b&gt;Полоса 1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="305"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="383"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="461"/>
        <source>Bandwidth</source>
        <comment>Parametric equalizer bandwidth</comment>
        <translation>Ширина полосы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="316"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="394"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="472"/>
        <source> octaves</source>
        <translation>октавы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="329"/>
        <source>&lt;b&gt;Band 2&lt;/b&gt;</source>
        <translation>&lt;b&gt;Полоса 2&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="407"/>
        <source>&lt;b&gt;Band 3&lt;/b&gt;</source>
        <translation>&lt;b&gt;Полоса 3&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="485"/>
        <source>&lt;b&gt;High Shelf&lt;/b&gt;</source>
        <translation>&lt;b&gt;Верхний отступ&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="222"/>
        <source>Hue gate</source>
        <translation>Интервал оттенка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="242"/>
        <source>Saturation threshold</source>
        <translation>Порог Насыщенность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="262"/>
        <source>Operation 1</source>
        <translation>Операция 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="50"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="427"/>
        <source>Blend mode</source>
        <translation>Режим смешивания</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="65"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="442"/>
        <source>Over</source>
        <translation>Свыше</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="70"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="447"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <location filename="../src/qml/filters/levels/ui.qml" line="205"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="80"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="457"/>
        <source>Saturate</source>
        <translation>Насыщение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="85"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="462"/>
        <source>Multiply</source>
        <translation>Умножение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="90"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="467"/>
        <source>Screen</source>
        <translation>Экран</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="95"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="472"/>
        <source>Overlay</source>
        <translation>Наложение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="100"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="477"/>
        <source>Darken</source>
        <translation>Затемнение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="105"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="482"/>
        <source>Dodge</source>
        <translation>Осветление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="110"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="487"/>
        <source>Burn</source>
        <translation>Засветление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="115"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="492"/>
        <source>Hard Light</source>
        <translation>Жёсткий свет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="120"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="497"/>
        <source>Soft Light</source>
        <translation>Мягкий свет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="125"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="502"/>
        <source>Difference</source>
        <translation>Разница</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="130"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="507"/>
        <source>Exclusion</source>
        <translation>Исключение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="135"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="512"/>
        <source>HSL Hue</source>
        <translation>HLS тон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="140"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="517"/>
        <source>HSL Saturation</source>
        <translation>HLS насыщенность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="145"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="522"/>
        <source>HSL Color</source>
        <translation>HLS цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="150"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="527"/>
        <source>HSL Luminosity</source>
        <translation>HLS яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>De-Key</source>
        <translation>Убрать прозрачность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>Desaturate</source>
        <translation>Обесцвечивание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="270"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="310"/>
        <source>Adjust Luma</source>
        <translation>Подстроить яркость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="282"/>
        <source>Amount 1</source>
        <translation>Количество 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="302"/>
        <source>Operation 2</source>
        <translation>Операция 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="322"/>
        <source>Amount 2</source>
        <translation>Количество 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="346"/>
        <source>Show mask</source>
        <translation>Показать маску</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="359"/>
        <source>Send mask to alpha channel</source>
        <translation>Отправить маску в альфа-канал</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="101"/>
        <source>X Center</source>
        <translation>Центр Х</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="130"/>
        <source>Y Center</source>
        <translation>Центр Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="159"/>
        <source>Correction at Center</source>
        <translation>Коррекция в центре</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lenscorrection/ui.qml" line="188"/>
        <source>Correction at Edges</source>
        <translation>Коррекция по краям</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_matrix_ms/ui.qml" line="87"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="64"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="265"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="90"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/ui.qml" line="100"/>
        <source>Darkness</source>
        <translation>Темнота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="43"/>
        <source>No File Loaded</source>
        <translation>Нет загруженных файлов</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="45"/>
        <source>No 3D LUT file loaded.
Click &quot;Open&quot; to load a file.</source>
        <translation>Файл 3D LUT не загружен.
Нажмите &quot;Открыть&quot;, чтобы загрузить файл.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="81"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="121"/>
        <source>Open...</source>
        <translation>Открыть...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="84"/>
        <source>Open 3D LUT File</source>
        <translation>Открыть файл 3D LUT</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="488"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="343"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="344"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="791"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="181"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="418"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="248"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="189"/>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="101"/>
        <source>Interpolation</source>
        <translation>Интерполяция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="305"/>
        <source>Stereo</source>
        <translation>Стерео</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="314"/>
        <source>Binaural</source>
        <translation>Бинауральный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="323"/>
        <source>Quad</source>
        <translation>Quad</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="354"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="366"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="368"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="820"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="537"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="271"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="204"/>
        <source>Yaw</source>
        <translation>Смещение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="400"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="410"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="412"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="864"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="612"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="315"/>
        <source>Pitch</source>
        <comment>rotation around the side-to-side axis (roll, pitch, yaw)</comment>
        <translation>Питч</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="446"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="454"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="456"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="909"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="687"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="359"/>
        <source>Roll</source>
        <translation>Наклон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="541"/>
        <source>Paste Parameters</source>
        <translation>Вставить Параметры</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="498"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="500"/>
        <source>FOV</source>
        <comment>field of view</comment>
        <translation>Поле зрения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="501"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="503"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="985"/>
        <source>Field of view</source>
        <translation>Область просмотра</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="590"/>
        <location filename="../src/qml/filters/bigsh0t_eq_to_stereo/ui.qml" line="592"/>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="414"/>
        <source>Copy Parameters</source>
        <translation>Скопировать Параметры</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="982"/>
        <source>FOV</source>
        <translation>Поле зрения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_to_rect/ui.qml" line="545"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="450"/>
        <source>Fisheye</source>
        <translation>Рыбий глаз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="403"/>
        <source>Nearest</source>
        <translation>Ближайший</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <source>Trilinear</source>
        <translation>Трилинейная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lut3d/ui.qml" line="122"/>
        <source>Tetrahedral</source>
        <translation>Тетраэдральная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="173"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="348"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="202"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="349"/>
        <source>Operation</source>
        <translation>Операция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="336"/>
        <source>Corner 1 X</source>
        <translation>Угол 1 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="431"/>
        <source>Corner 2 X</source>
        <translation>Угол 2 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="483"/>
        <source>Corner 3 X</source>
        <translation>Угол 3 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="535"/>
        <source>Corner 4 X</source>
        <translation>Угол 4 X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="587"/>
        <source>Stretch X</source>
        <translation>Растянуть X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="645"/>
        <source>Interpolator</source>
        <translation>Интерполятор</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Nearest Neighbor</source>
        <translation>Ближайший сосед</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="557"/>
        <source>Bilinear</source>
        <translation>Билинейный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Bicubic Smooth</source>
        <translation>Бикубический гладкий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <source>Bicubic Sharp</source>
        <translation>Бикубический острый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="572"/>
        <source>Spline 4x4</source>
        <translation>Сплайн 4x4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="653"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="577"/>
        <source>Spline 6x6</source>
        <translation>Сплайн 6x6</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="667"/>
        <source>Alpha Operation</source>
        <translation>Операции с альфа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="226"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="533"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="369"/>
        <source>Maximum</source>
        <translation>Максимум</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="231"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="538"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="374"/>
        <source>Minimum</source>
        <translation>Минимум</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <source>Opaque</source>
        <translation>Непрозрачность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="221"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="528"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="364"/>
        <source>Overwrite</source>
        <translation>Перезаписать</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="694"/>
        <source>Feathering</source>
        <translation>Растушёвка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blend_mode/ui.qml" line="75"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="480"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="452"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="236"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="543"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="379"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/ui.qml" line="675"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="181"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="356"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="241"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="548"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="384"/>
        <source>Subtract</source>
        <translation>Вычесть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="194"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="369"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="241"/>
        <source>Shape</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Rectangle</source>
        <translation>Прямоугольник</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Ellipse</source>
        <translation>Эллипс</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <source>Triangle</source>
        <translation>Треугольник</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="202"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="377"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="266"/>
        <source>Diamond</source>
        <translation>Ромб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="273"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="362"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="204"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="164"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="215"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="120"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="116"/>
        <source>Horizontal</source>
        <translation>Горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="514"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="777"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="279"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="373"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="446"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1395"/>
        <source>Start</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="540"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="803"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="323"/>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="417"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="404"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="483"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="557"/>
        <source>End</source>
        <translation>Конец</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="105"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="108"/>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="109"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="222"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="230"/>
        <source>Linear</source>
        <translation>Линейная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="241"/>
        <source>Radial</source>
        <translation>Радиальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradient/ui.qml" line="277"/>
        <source>Colors</source>
        <translation>Цветная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_mask/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="441"/>
        <location filename="../src/qml/filters/bigsh0t_rect_to_eq/ui.qml" line="248"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="240"/>
        <location filename="../src/qml/filters/nosync/ui.qml" line="91"/>
        <location filename="../src/qml/filters/rgbsplit0r/ui.qml" line="87"/>
        <source>Vertical</source>
        <translation>Вертикальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="290"/>
        <location filename="../src/qml/filters/mosaic/ui.qml" line="119"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1413"/>
        <location filename="../src/qml/filters/mask/ui.qml" line="315"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="530"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="158"/>
        <source>Rotation</source>
        <translation>Вращение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="336"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="566"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="596"/>
        <source>Softness</source>
        <translation>Мягкость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="814"/>
        <source>Alignment</source>
        <translation>Выравнивание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="953"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="597"/>
        <source>Lens</source>
        <translation>Объектив</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="959"/>
        <source>Projection</source>
        <translation>Проекция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1029"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1352"/>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="63"/>
        <location filename="../src/qml/filters/halftone/ui.qml" line="104"/>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="33"/>
        <source>Radius</source>
        <translation>Радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1072"/>
        <source>Front</source>
        <translation>Фронт</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1078"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1215"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="157"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1121"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1258"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="405"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="457"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="509"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="561"/>
        <location filename="../src/qml/filters/corners/ui.qml" line="616"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="185"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="768"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1209"/>
        <source>Back</source>
        <translation>Тыл</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1346"/>
        <source>Nadir</source>
        <translation>Надир</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="133"/>
        <source>Cyan</source>
        <translation>Голубой</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="162"/>
        <source>Magenta</source>
        <translation>Пурпурный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="54"/>
        <source>Blurriness</source>
        <translation>Размытость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="72"/>
        <source>Vertical amount</source>
        <translation>Вертикальное количество</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="90"/>
        <source>Vertical frequency</source>
        <translation>Вертикальная частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="109"/>
        <source>Brightness up</source>
        <translation>Яркость +</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="127"/>
        <source>Brightness down</source>
        <translation>Яркость -</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="145"/>
        <source>Brightness frequency</source>
        <translation>Частота яркости</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="164"/>
        <source>Uneven develop up</source>
        <translation>Неравномерное развитие выше</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="182"/>
        <source>Uneven develop down</source>
        <translation>Неравномерное развитие ниже</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="200"/>
        <source>Uneven develop duration</source>
        <translation>Длительность неравномерного развития</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask/ui.qml" line="326"/>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="549"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="169"/>
        <source> deg</source>
        <comment>degrees</comment>
        <translation> град.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="454"/>
        <source>Add or remove fisheye effect</source>
        <translation>Добавить или убрать эффект рыбьего глаза</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="466"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="501"/>
        <source>Focal ratio</source>
        <translation>Фокусное расстояние</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="506"/>
        <source>The amount of lens distortion</source>
        <translation>Величина искажения объектива</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="531"/>
        <source>Quality</source>
        <translation>Качество</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="535"/>
        <source>Resample quality</source>
        <translation>Качество повторной выборки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="552"/>
        <source>Nearest neighbor</source>
        <translation>Ближайший сосед</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="562"/>
        <source>Bicubic smooth</source>
        <translation>Бикубический гладкий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="567"/>
        <source>Bicubic sharp</source>
        <translation>Бикубический резкий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="582"/>
        <source>Lanczos 16x16</source>
        <translation>Ланцош 16x16</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="601"/>
        <source>Select a lens distortion pattern that best matches your camera</source>
        <translation>Выберите схему искажения объектива, которая наилучшим образом соответствует вашей камере</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="619"/>
        <source>Equidistant</source>
        <translation>Равноудаленный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="624"/>
        <source>Orthographic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="629"/>
        <source>Equiarea</source>
        <translation>Равноденствие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="634"/>
        <source>Stereographic</source>
        <translation>Стереографический</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="643"/>
        <source>Non-Linear scale</source>
        <translation>Нелинейный масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="657"/>
        <source>The image will be stretched/squished to fix camera scaling between 4:3 and 16:9
Like used in GoPro&apos;s superview</source>
        <translation>Изображение будет растянуто/сжато для исправления масштабирования камеры между 4:3 и 16:9
Как в суперпредставлении GoPro</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="673"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="707"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1723"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="187"/>
        <source>Scale</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="677"/>
        <source>Use negative values for up-scaled videos
Use positive values for down-scaled videos</source>
        <translation>Использовать отрицательные значения для увеличенных видео
Используйте положительные значения для уменьшенных видео</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="724"/>
        <source>Preset scale methods
Lock pixels at specific locations</source>
        <translation>Заданные методы масштабирования
Заблокировать пикселы в определённых расположениях</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="744"/>
        <source>Scale to Fill</source>
        <translation>Подогнать для заполнения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="749"/>
        <source>Keep Center Scale</source>
        <translation>Сохранить масштаб центра</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="754"/>
        <source>Scale to Fit</source>
        <translation>Подогнать для умещения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="759"/>
        <source>Manual Scale</source>
        <translation>Масштаб вручную</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="782"/>
        <source>Scale Y separately
This changes video aspect ratio</source>
        <translation>Масштабировать Y отдельно
Это изменяет соотношение сторон видео</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="789"/>
        <source>Crop</source>
        <translation>Кадрирование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="801"/>
        <source>Remove distorted edges</source>
        <translation>Убрать искажённые края</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="820"/>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="962"/>
        <source>Manual</source>
        <translation>Ручно</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="825"/>
        <source>User set zoom/scale
Sides of image are not fixed</source>
        <translation>Установленное пользователем увеличение/масштаб
Стороны изображения не зафиксированы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="852"/>
        <source>Y ratio</source>
        <translation>Y-коэффициент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="857"/>
        <source>Separate Y scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="887"/>
        <source>Aspect</source>
        <translation>Соотношение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="904"/>
        <source>Preset pixel aspect ratio</source>
        <translation>Заданное пиксельное соотношение сторон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="944"/>
        <source>Manual Aspect</source>
        <translation>Ручное соотношение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="967"/>
        <source>User set pixel aspect ratios
Change top/side distortion bias</source>
        <translation>Установленное пользователем соотношение сторон в пикселах
Изменить смещение искажения сверху/сбоку</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="998"/>
        <source>Cameras</source>
        <translation>Камеры</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1012"/>
        <source>Camera</source>
        <translation>Камера</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1032"/>
        <source>Record mode</source>
        <translation>Режим записи</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1053"/>
        <source>Result</source>
        <translation>Результат</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fisheye/ui.qml" line="1073"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="234"/>
        <source>X offset</source>
        <translation>смещение по X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="272"/>
        <source>Y offset</source>
        <translation>смещение по Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="208"/>
        <source>Full Screen</source>
        <translation>Полноэкранный режим</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="212"/>
        <source>Scroll Down</source>
        <translation>Прокрутить вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="214"/>
        <source>Scroll Up</source>
        <translation>Прокрутить вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="216"/>
        <source>Scroll Right</source>
        <translation>Прокрутить вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="218"/>
        <source>Scroll Left</source>
        <translation>Прокрутить влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="305"/>
        <source>Click in the rectangle atop the video to edit the text.</source>
        <translation>Щёлкните по прямоугольнику сверху видео, чтобы изменить текст.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="396"/>
        <source>Background size</source>
        <translation>Размер фона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="459"/>
        <source>Text size</source>
        <translation>Размер шрифта</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="524"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="310"/>
        <source>Background color</source>
        <translation>Цвет фона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="556"/>
        <source>Overflow</source>
        <translation>Заполнение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="570"/>
        <source>Automatic</source>
        <translation>Авто</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="583"/>
        <source>Visible</source>
        <translation>Видимый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/ui.qml" line="595"/>
        <source>Hidden</source>
        <translation>Скрытый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="144"/>
        <source>Color space</source>
        <translation>Цветовое пространство</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="156"/>
        <source>Red-Green-Blue</source>
        <translation>Красный-Зелёный-Синий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="167"/>
        <source>Hue-Chroma-Intensity</source>
        <translation>Оттенок-Цветность-Интенсивность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="181"/>
        <source>Red delta</source>
        <translation>Дельта красного</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="181"/>
        <source>Hue delta</source>
        <translation>Дельта тона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Green delta</source>
        <translation>Дельта зелёного</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Chroma delta</source>
        <translation>Дельта цветности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="221"/>
        <source>Blue delta</source>
        <translation>Дельта синего</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="221"/>
        <source>Intensity delta</source>
        <translation>Дельта интенсивности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="256"/>
        <source>Box</source>
        <translation>Прямоугольник</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="261"/>
        <source>Ellipsoid</source>
        <translation>Эллипсоид</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="280"/>
        <source>Edge</source>
        <translation>Край</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="295"/>
        <source>Hard</source>
        <comment>Chroma Key Advanced filter</comment>
        <translation>Жёсткий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="300"/>
        <source>Fat</source>
        <translation>Жирный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="305"/>
        <source>Normal</source>
        <translation>Обычный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="310"/>
        <source>Thin</source>
        <translation>Тонкий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="53"/>
        <source>Yellow-Blue</source>
        <translation>Жёлтый-Синий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="71"/>
        <source>Cyan-Red</source>
        <translation>Голубой-Красный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="65"/>
        <source>Line Width</source>
        <translation>Толщина линии</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="85"/>
        <source>Line Height</source>
        <translation>Высота линии</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sketch/ui.qml" line="105"/>
        <source>Contrast</source>
        <translation>Контраст</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/chromahold/ui.qml" line="86"/>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="91"/>
        <location filename="../src/qml/filters/dropshadow/ui.qml" line="98"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1302"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1366"/>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="383"/>
        <location filename="../src/qml/filters/sketch/ui.qml" line="126"/>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="68"/>
        <source>Blur Radius</source>
        <translation>Радиус размытия</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="72"/>
        <source>The radius of the gaussian blur.</source>
        <translation>Радиус размытия по Гауссу.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="93"/>
        <source>Blur Strength</source>
        <translation>Сила размытия</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="97"/>
        <source>The strength of the gaussian blur.</source>
        <translation>Сила размытия по Гауссу.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="122"/>
        <source>If the difference between the original pixel and the blurred pixel is less than threshold, the pixel will be replaced with the blurred pixel.</source>
        <translation>Если разница между исходными и размытыми пикселами менее порогового значения, исходные пикселы будут заменены на размытые.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="50"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="60"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="152"/>
        <source>Green</source>
        <translation>Зеленый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="58"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="89"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="179"/>
        <source>Blue</source>
        <translation>Синий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="125"/>
        <source>Red</source>
        <translation>Красный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="182"/>
        <source>Value</source>
        <translation>Значение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="198"/>
        <source>Histogram</source>
        <translation>Гистограмма</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="227"/>
        <source>Input Black</source>
        <translation>Входной чёрный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="251"/>
        <source>Input White</source>
        <translation>Входной белый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="275"/>
        <source>Gamma</source>
        <translation>Гамма</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="299"/>
        <source>Output Black</source>
        <translation>Выходной чёрный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/levels/ui.qml" line="320"/>
        <source>Output White</source>
        <translation>Выходной белый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="27"/>
        <source>Click Analyze to use this filter.</source>
        <translation>Нажмите &quot;Анализ&quot;, чтобы использовать этот фильтр.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="90"/>
        <source>Select a file to store analysis results.</source>
        <translation>Выберите файл для сохранения результатов анализа.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="116"/>
        <source>&lt;b&gt;Analyze Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Настройки анализа&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="121"/>
        <source>Shakiness</source>
        <translation>Дрожание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="142"/>
        <source>Accuracy</source>
        <translation>Точность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="184"/>
        <source>&lt;b&gt;Filter Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Настройки фильтра&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_decoder/ui.qml" line="492"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="189"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="118"/>
        <source>Zoom</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="248"/>
        <source>Stabilization file:</source>
        <translation>Файл стабилизации:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="252"/>
        <source>The stabilization file generated by the analysis.</source>
        <translation>Файл стабилизации, созданный с помощью анализа.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="189"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="291"/>
        <source>File for motion analysis</source>
        <translation>Файл для анализа движения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="390"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="168"/>
        <source>Browse...</source>
        <translation>Обзор...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="395"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="172"/>
        <source>Start Offset</source>
        <translation>Начальное Смещение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="407"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="181"/>
        <source>seconds</source>
        <translation>секунды</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="438"/>
        <source>Analysis</source>
        <translation>Анализ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="448"/>
        <source>Apply transform</source>
        <translation>Применить преобразование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="454"/>
        <source>Sample Radius</source>
        <translation>Радиус отбора</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="477"/>
        <source>Search Radius</source>
        <translation>Радиус поиска</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="523"/>
        <source>Track Points</source>
        <translation>Точки трека</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="530"/>
        <source>Use backwards-facing track points</source>
        <translation>Использовать точки трека в обратном направлении</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="566"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="641"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="716"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="215"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="212"/>
        <source>Smoothing</source>
        <translation>Сглаживание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="589"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="664"/>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="739"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="233"/>
        <source>Time Bias</source>
        <translation>Смещение времени</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="70"/>
        <source> Red</source>
        <translation> Красный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/halftone/ui.qml" line="191"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="79"/>
        <source>Yellow</source>
        <translation>Жёлтый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/ui.qml" line="96"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="60"/>
        <source>Amplitude</source>
        <translation>Амплитуда</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="180"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="257"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="335"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="413"/>
        <location filename="../src/qml/filters/audio_eqparametric/ui.qml" line="491"/>
        <location filename="../src/qml/filters/distort/ui.qml" line="125"/>
        <location filename="../src/qml/filters/glitch/ui.qml" line="101"/>
        <source>Frequency</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/distort/ui.qml" line="154"/>
        <source>Velocity</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="68"/>
        <source>Hold %1 to drag a keyframe vertical only or %2 to drag horizontal only</source>
        <translation>Удерживайте %1, чтобы перетащить ключевой кадр только по вертикали, или %2, чтобы перетащить только по горизонтали</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="50"/>
        <source>Forward</source>
        <translation>Вперёд</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="52"/>
        <source>Freeze</source>
        <translation>Мороз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="53"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="54"/>
        <source>%L1s</source>
        <translation>%L1s</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="205"/>
        <source>Set Speed After</source>
        <translation>Задать скорость После</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="205"/>
        <source>Set Speed Before</source>
        <translation>Задать скорость До</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="242"/>
        <source>Modify current mapping</source>
        <translation>Изменение текущего отображения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="247"/>
        <source>Lock current mapping</source>
        <translation>Заблокировать текущее отображение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="257"/>
        <source>&quot;Modify current mapping&quot; will modify the input time at the current position.
&quot;Lock current mapping&quot; will lock the input time at the current position and modify the value of an adjacent keyframe</source>
        <translation>&quot;Изменение текущего отображения&quot; изменит время ввода в текущей позиции.
&quot;Заблокировать текущее отображение&quot; заблокирует время ввода в текущей позиции и изменит значение соседнего ключевого кадра</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="265"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="273"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="309"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="313"/>
        <source>Map the specified input time to the current time. Use keyframes to vary the time mappings over time.</source>
        <translation>Сопоставьте указанное время ввода с текущим временем. Используйте ключевые кадры для изменения отображения.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="345"/>
        <source>Set the input time to achieve a desired speed before the current frame.</source>
        <translation>Для достижения желаемой скорости установите время до текущего кадра.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="361"/>
        <source>Set the input time to achieve a desired speed after the current frame.</source>
        <translation>Для достижения желаемой скорости установите время после текущего кадра.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="379"/>
        <source>Image mode</source>
        <translation>Режим изображения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="383"/>
        <source>Use the specified image selection mode. Nearest will output the image that is nearest to the mapped time. Blend will blend all images that occur during the mapped time.</source>
        <translation>Использование указанного режима выбора изображения. Вывод близкого изображения, которое ближе всего к отображенному времени. Смешение смешает все изображения, которые появляются в течение отображенного времени.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="128"/>
        <source>Hue Center</source>
        <translation>Центр оттенка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="131"/>
        <source>The center of the color range to be changed.</source>
        <translation>Центр цветовой гаммы, который необходимо изменить.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="157"/>
        <source>Hue Range</source>
        <translation>Диапазон оттенков</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="160"/>
        <source>The width of the color range to be changed.</source>
        <translation>Ширина цветовой гаммы, которую необходимо изменить.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="260"/>
        <source>Pick the center hue from a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation>Выберите центральный оттенок из цветов на экране. Нажав кнопку мыши, а затем переместив ее, вы можете выбрать участок экрана, из которого будет получен средний цвет.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="592"/>
        <location filename="../src/qml/filters/bigsh0t_eq_cap/ui.qml" line="855"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="265"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="408"/>
        <source>Blend</source>
        <translation>Смешение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="268"/>
        <source>The amount of blending to apply to the edges of the color range.</source>
        <translation>Степень растушевки, применяемая к краям цветовой гаммы.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="297"/>
        <source>The amount to shift the Hue of the color range.</source>
        <translation>На сколько можно изменить начальную цветовую гамму.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="326"/>
        <source>The amount to scale the saturation of the color range.</source>
        <translation>Величина масштабирования насыщенности цветовой гаммы.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="355"/>
        <source>The amount to scale the lightness of the color range.</source>
        <translation>Количество, необходимое для увеличения яркости цветовой гаммы.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="424"/>
        <source>Enable pitch compensation</source>
        <translation>Включить компенсацию высоты тона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="452"/>
        <source>Speed:</source>
        <translation>Скорость:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="482"/>
        <source>Input Time:</source>
        <translation>Время ввода:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="497"/>
        <source>Output Time:</source>
        <translation>Время вывода:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="338"/>
        <location filename="../src/qml/filters/vertigo/ui.qml" line="89"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="78"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="456"/>
        <source>The instantaneous speed of the last frame that was processed.</source>
        <translation>Моментальная скорость последнего обработанного кадра.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="467"/>
        <source>Direction:</source>
        <translation>Направление:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="471"/>
        <source>The instantaneous direction of the last frame that was processed.</source>
        <translation>Моментальное направление последнего обработанного кадра.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="486"/>
        <source>The original clip time of the frame.</source>
        <translation>Исходное время клипа кадра.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="501"/>
        <source>The mapped output time for the input frame.</source>
        <translation>Отображает время вывода для входного кадра.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="102"/>
        <source>Deform horizontally?</source>
        <translation>Деформировать горизонтально?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="119"/>
        <source>Deform vertically?</source>
        <translation>Деформировать вертикально?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="81"/>
        <source>Neutral color</source>
        <translation>Нейтральный цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="111"/>
        <source>Color temperature</source>
        <translation>Цветовая температура</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="183"/>
        <source>degrees</source>
        <translation>градусы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="147"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="161"/>
        <source>HH:MM:SS</source>
        <translation>ЧЧ:ММ:СС</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="166"/>
        <source>HH:MM:SS.S</source>
        <translation>ЧЧ:ММ:СС.С</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="171"/>
        <source>MM:SS</source>
        <translation>ММ:СС</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="176"/>
        <source>MM:SS.SS</source>
        <translation>ММ:СС.СС</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="181"/>
        <source>MM:SS.SSS</source>
        <translation>ММ:СС.ССС</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="186"/>
        <source>SS</source>
        <translation>СС</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="191"/>
        <source>SS.S</source>
        <translation>СС.С</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="196"/>
        <source>SS.SS</source>
        <translation>СС.СС</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="201"/>
        <source>SS.SSS</source>
        <translation>СС.ССС</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="290"/>
        <source>A value of 0 will run the timer to the end of the filter</source>
        <translation>Значение 0 приведёт к запуску таймера до конца фильтра</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="332"/>
        <source>When the direction is Down, the timer will count down to Offset.
When the direction is Up, the timer will count up starting from Offset.</source>
        <translation>Когда направление Вниз, таймер будет вести обратный отсчет до смещения.
Если направление Вверх, таймер будет отсчитывать, начиная со смещения.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="359"/>
        <source>Timer seconds per playback second. Scales Duration but does not affect Start Delay or Offset.</source>
        <translation>Секунды таймера на секунду воспроизведения. Масштабирует продолжительность, но не влияет на Задержку или Смещение.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="122"/>
        <source>Minimal strength</source>
        <translation>Минимальная сила</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="133"/>
        <source>Average strength</source>
        <translation>Средняя сила</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="144"/>
        <source>Blue sky</source>
        <translation>Небеса</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="155"/>
        <source>Red sky</source>
        <translation>Закат</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="166"/>
        <source>Full range to limited range</source>
        <translation>Полный диапазон до ограниченного диапазона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="210"/>
        <source>Contrast threshold</source>
        <translation>Порог Контрастность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="214"/>
        <source>Banding similarity within first component
Y (luma) in YCbCr mode
Red in RGB mode</source>
        <translation>Сходство полос в пределах первого компонента
Y (яркость) в режиме YCbCr
Красный в режиме RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="233"/>
        <source>Blue threshold</source>
        <translation>Порог Синий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="237"/>
        <source>Banding similarity within second component
Cb (blue) in YCbCr mode
Green in RGB mode</source>
        <translation>Сходство полос во втором компоненте
Cb (синий) в режиме YCbCr
Зеленый в режиме RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="256"/>
        <source>Red threshold</source>
        <translation>Порог Красный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="260"/>
        <source>Banding similarity within third component
Cr (red) in YCbCr mode
Blue in RGB mode</source>
        <translation>Сходство полос в третьем компоненте
Cr (красный) в режиме YCbCr
Синий в режиме RGB</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="279"/>
        <source>Alpha threshold</source>
        <translation>Порог Альфаканал</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="283"/>
        <source>Banding similarity within fourth component</source>
        <translation>Сходство полос в четвёртом компоненте</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="308"/>
        <source>Link thresholds</source>
        <translation>Пороговые значения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="317"/>
        <source>Pixel range</source>
        <translation>Диапазон пикселей</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="321"/>
        <source>The size of bands being targeted</source>
        <translation>Размер целевых групп</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="348"/>
        <source>Randomize pixel range between zero and value</source>
        <translation>Рандомизирование диапазона пикселей между нулем и значением</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="357"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="208"/>
        <source>Direction</source>
        <translation>Направление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="361"/>
        <source>Up = 270°
Down = 90°
Left = 180°
Right = 0° or 360°
All = 360° + Randomize</source>
        <translation>Вверх = 270°
Вниз = 90°
Влево = 180°
Вправо = 0° or 360°
Все = 360° + Случайно</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="388"/>
        <source>Randomize direction between zero degrees and value</source>
        <translation>Рандомизирование направления между нулем градусов и значением</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="403"/>
        <source>Measure similarity using average of neighbors</source>
        <translation>Измерение сходства, используя среднее значение соседних значений</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="407"/>
        <source>Compare to thresholds using average versus exact neighbor values</source>
        <translation>Сравнение с пороговыми значениями, используя средние и точные соседние значения.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="425"/>
        <source>All components required to trigger deband</source>
        <translation>Все компоненты, необходимые для запуска удаления полос</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/deband/ui.qml" line="429"/>
        <source>Deband only if all pixel components (including alpha) are within thresholds</source>
        <translation>Удалять полосы только в том случае, если все пиксельные компоненты (включая альфа-канал) находятся в пределах пороговых значений</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1164"/>
        <location filename="../src/qml/filters/bigsh0t_hemi_to_eq/ui.qml" line="1301"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="222"/>
        <source>Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="227"/>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="234"/>
        <source>Start Delay</source>
        <translation>Задержка запуска</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="253"/>
        <source>The timer will be frozen from the beginning of the filter until the Start Delay time has elapsed.</source>
        <translation>Таймер будет заморожен с начала фильтра до тех пор, пока не истечет время задержки запуска.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="265"/>
        <source>Set start to begin at the current position</source>
        <translation>Установить начало, чтобы начать с текущей позиции</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="290"/>
        <source>The timer will be frozen after the Duration has elapsed.</source>
        <translation>Время, по истечении которого, таймер будет заморожен.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/timer/ui.qml" line="307"/>
        <source>Set duration to end at the current position</source>
        <translation>Установить длительность до конца в текущей позиции</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="500"/>
        <location filename="../src/qml/filters/gradient/ui.qml" line="258"/>
        <location filename="../src/qml/filters/timer/ui.qml" line="313"/>
        <source>Offset</source>
        <translation>Смещение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_stabilize_360/ui.qml" line="367"/>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="149"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="223"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="285"/>
        <source>Custom...</source>
        <translation>Пользовательский...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="280"/>
        <source>Bar Horizontal</source>
        <translation>Горизонтальные полосы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="290"/>
        <source>Bar Vertical</source>
        <translation>Вертикальные полосы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="295"/>
        <source>Barn Door Horizontal</source>
        <translation>Горизонтальные жалюзи</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="300"/>
        <source>Barn Door Vertical</source>
        <translation>Вертикальные жалюзи</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="305"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Диагональные жалюзи из левого нижнего</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="310"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Диагональные жалюзи из левого верхнего</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="315"/>
        <source>Diagonal Top Left</source>
        <translation>Диагональ верхний левый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="320"/>
        <source>Diagonal Top Right</source>
        <translation>Диагональ верхний правый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="325"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Матрица водопад горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="330"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Матрица водопад вертикальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="335"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Матрица змейка горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="340"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Матрица змейка параллельная горизонтальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="345"/>
        <source>Matrix Snake Vertical</source>
        <translation>Матрица змейка вертикальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="350"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Матрица змейка параллельная вертикальная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="355"/>
        <source>Barn V Up</source>
        <translation>Жалюзи углом вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="360"/>
        <source>Iris Circle</source>
        <translation>Круг диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="365"/>
        <source>Double Iris</source>
        <translation>Двойной круг диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="370"/>
        <source>Iris Box</source>
        <translation>Вставка диафрагмы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="375"/>
        <source>Box Bottom Right</source>
        <translation>Вставка снизу справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="380"/>
        <source>Box Bottom Left</source>
        <translation>Вставка снизу слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="385"/>
        <source>Box Right Center</source>
        <translation>Вставка справа по центру</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="390"/>
        <source>Clock Top</source>
        <translation>Циферблат по часовой стрелке</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="262"/>
        <source>Set a mask from another file&apos;s brightness or alpha.</source>
        <translation>Настройка маски из яркости другого файла или альфа-канала.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="238"/>
        <source>Open Mask File</source>
        <translation>Открыть файл маски</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="189"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="464"/>
        <location filename="../src/qml/filters/time_remap/ui.qml" line="48"/>
        <source>Reverse</source>
        <translation>Обратить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="511"/>
        <source>Alpha</source>
        <translation>Альфа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="96"/>
        <source>Waveform Color</source>
        <translation>Цвет волны</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/ui.qml" line="154"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="112"/>
        <source>Background Color</source>
        <translation>Цвет фона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="235"/>
        <source>Fill the area under the waveform.</source>
        <translation>Заливка области под осциллограммой.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/waveform/ui.qml" line="247"/>
        <source>Combine all channels into one waveform.</source>
        <translation>Объединение всех каналов в одну волну.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_adeclick/ui.qml" line="69"/>
        <location filename="../src/qml/filters/waveform/ui.qml" line="252"/>
        <source>Window</source>
        <translation>Окно</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/ui.qml" line="166"/>
        <source>Rows</source>
        <translation>Строки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grid/ui.qml" line="206"/>
        <source>Columns</source>
        <translation>Столбцы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="130"/>
        <source>Block height</source>
        <translation>Высота блока</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="159"/>
        <source>Shift intensity</source>
        <translation>Интенсивность сдвига</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glitch/ui.qml" line="188"/>
        <source>Color intensity</source>
        <translation>Интенсивность цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="89"/>
        <source>Spatial</source>
        <translation>Пространственный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hqdn3d/ui.qml" line="118"/>
        <source>Temporal</source>
        <translation>Временной</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="353"/>
        <source>Apply to Source</source>
        <translation>Применить к источнику</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="379"/>
        <source>Corner radius</source>
        <translation>Радиус закругления</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="407"/>
        <source>Padding color</source>
        <translation>Цвет заполнения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="86"/>
        <source>Levels</source>
        <comment>Dither video filter</comment>
        <translation>Уровни</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="115"/>
        <source>Matrix</source>
        <translation>Матрица</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>2x2 Magic Square</source>
        <translation>2x2 Магический квадрат</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Magic Square</source>
        <translation>4x4 Магический квадрат</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Ordered</source>
        <translation>4x4 Квадратная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>4x4 Lines</source>
        <translation>4x4 Линейная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>6x6 90 Degree Halftone</source>
        <translation>6x6 90-градусный полутон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>6x6 Ordered</source>
        <translation>6x6 Квадратная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>8x8 Ordered</source>
        <translation>8x8 Квадратная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-3 Clustered</source>
        <translation>Симметричная-3 кластерная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-4 Ordered</source>
        <translation>Симметричная-4 упорядоченная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dither/ui.qml" line="123"/>
        <source>Order-8 Ordered</source>
        <translation>Симметричная-8 упорядоченная</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="106"/>
        <source>Horizontal center position of the linear area.</source>
        <translation>Горизонтальное центральное положение линейной области.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="135"/>
        <source>Linear width</source>
        <translation>Линейная ширина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="139"/>
        <source>Width of the linear area.</source>
        <translation>Ширина линейной области.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="168"/>
        <source>Linear scale factor</source>
        <translation>Линейный масштабный коэффициент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="172"/>
        <source>Amount the linear area is scaled.</source>
        <translation>Величина масштабируемой линейной области.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="201"/>
        <source>Non-Linear scale factor</source>
        <translation>Величина нелинейного масштаба</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/elastic_scale/ui.qml" line="205"/>
        <source>Amount the outer left and outer right areas are scaled non linearly.</source>
        <translation>Величина внешних левых и правых областей, масштабируемых нелинейно.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/threshold/ui.qml" line="141"/>
        <source>Compare with alpha channel</source>
        <translation>Сравнить с альфа-каналом</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/ui.qml" line="91"/>
        <location filename="../src/qml/filters/nervous/ui.qml" line="65"/>
        <location filename="../src/qml/filters/trails/ui.qml" line="73"/>
        <source> frames</source>
        <translation> кадры</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/choppy/ui.qml" line="81"/>
        <source>Repeat</source>
        <translation>Повтор</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="121"/>
        <source>Key Filter: Low Frequency</source>
        <translation>Ключ. фильтр: НЧ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="150"/>
        <source>Key Filter: High Frequency</source>
        <translation>Ключ. фильтр: ВЧ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="184"/>
        <source>Output key only</source>
        <translation>Только ключ выхода</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="246"/>
        <source>Hold</source>
        <translation>Удержание</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="274"/>
        <source>Decay</source>
        <translation>Распад</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_noisegate/ui.qml" line="302"/>
        <source>Range</source>
        <translation>Диапазон</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="161"/>
        <source>Octave Shift</source>
        <translation>Сдвиг октавы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="165"/>
        <source>Specify the pitch shift in octaves.
-1 shifts down an octave.
+1 shifts up an octave.
0 is unchanged.</source>
        <translation>Укажите сдвиг высоты тона в октавах.
-1 сдвигает на октаву вниз.
+1 - на октаву вверх.
0 - остаётся неизменным.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="205"/>
        <source>Specify the speed change that should be compensated for.
2x will halve the pitch to compensate for the speed being doubled.</source>
        <translation>Укажите изменение скорости, которое должно быть компенсировано.
2x уменьшит шаг вдвое, чтобы компенсировать удвоение скорости.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pitch/ui.qml" line="201"/>
        <source>Speed Compensation</source>
        <translation>Компенсация скорости</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="69"/>
        <source>Light</source>
        <translation>Облегчённый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="75"/>
        <source>Medium</source>
        <translation>Средний</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="81"/>
        <source>Heavy</source>
        <translation>Тяжёлый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="121"/>
        <source>Method</source>
        <translation>Метод</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Soft</source>
        <translation>Мягкий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Garrote</source>
        <translation>Гаррота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="129"/>
        <source>Hard</source>
        <comment>Remove Noise Wavelet filter</comment>
        <translation>Жёсткий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="141"/>
        <source>Decompose</source>
        <translation>Распад</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="175"/>
        <source>Percent</source>
        <translation>Процент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="193"/>
        <source>Max decompositions for the current video mode</source>
        <translation>Максимальное разложение для текущего видеорежима</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vaguedenoiser/ui.qml" line="199"/>
        <source>More information</source>
        <translation>Больше информации</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/posterize/ui.qml" line="84"/>
        <source>Levels</source>
        <comment>Posterize filter</comment>
        <translation>Уровни</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop_circle/ui.qml" line="113"/>
        <location filename="../src/qml/filters/crop_rectangle/ui.qml" line="430"/>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="143"/>
        <source>Transparent</source>
        <translation>Прозрачный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_transform_360/ui.qml" line="408"/>
        <source>Show grid</source>
        <translation>Показать сетку</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/ui.qml" line="65"/>
        <source>Quantization</source>
        <translation>Квантование</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fspp/ui.qml" line="83"/>
        <location filename="../src/qml/filters/histeq/ui.qml" line="63"/>
        <source>Strength</source>
        <translation>Сила</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="105"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="40"/>
        <source>No File Loaded.</source>
        <translation>Нет загруженных файлов.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="107"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="42"/>
        <source>No GPS file loaded.
Click &quot;Open&quot; to load a file.</source>
        <translation>Файл GPS не загружен.
Нажмите &quot;Открыть&quot;, чтобы загрузить файл.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="401"/>
        <source>Select GPS File</source>
        <translation>Выбрать файл GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="443"/>
        <source>Select Background Image</source>
        <translation>Выбрать Фоновое изображение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="463"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="218"/>
        <source>Open file</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="221"/>
        <source>Open GPS File</source>
        <translation>Открыть файл GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="503"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="238"/>
        <source>&lt;b&gt;GPS options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Настройки GPS&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="510"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="245"/>
        <source>GPS offset</source>
        <translation>Смещение GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="514"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="249"/>
        <source>This is added to video time to sync with gps time.</source>
        <translation>Добавление к времени видео для синхронизации с временем GPS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="533"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="266"/>
        <source>+ : Adds time to video (use if GPS is ahead).
 - : Subtracts time from video (use if video is ahead).</source>
        <translation>+ : Добавляет время к видео (используйте, если GPS впереди).
- : вычитает время из видео (используйте, если видео идет впереди).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="574"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="307"/>
        <source>Number of days to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Число дней добавляемых/вычитаемых из времени видео для их синхронизации.
Совет: вы можете использовать колесо мыши для изменения значений.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="613"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="346"/>
        <source>Number of hours to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Число часов добавляемых/вычитаемых из времени видео для их синхронизации.
Совет: вы можете использовать колесо мыши для изменения значений.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="652"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="385"/>
        <source>Number of minutes to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Число минут добавляемых/вычитаемых из времени видео для их синхронизации.
Совет: вы можете использовать колесо мыши для изменения значений.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="691"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="424"/>
        <source>Number of seconds to add/subtract to video time to sync them.
Tip: you can use mousewheel to change values.</source>
        <translation>Число секунд добавляемых/вычитаемых из времени видео для их синхронизации.
Совет: вы можете использовать колесо мыши для изменения значений.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="710"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="443"/>
        <source>Sync start of GPS to start of video file.
Tip: use this if you started GPS and video recording at the same time.</source>
        <translation>Синхронизируйте запуск GPS с запуском видеофайла.
Совет: используйте это, если вы одновременно запустили GPS и видеозапись.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="749"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="482"/>
        <source>Sync start of GPS to current video time.
Tip: use this if you recorded the moment of the first GPS fix.</source>
        <translation>Синхронизируйте запуск GPS с текущим временем видео.
Совет: используйте это, если вы записали момент первой фиксации GPS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="759"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="492"/>
        <source>GPS smoothing</source>
        <translation>Сглаживание GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="763"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="496"/>
        <source>Average nearby GPS points to smooth out errors.</source>
        <translation>Усредняйте близлежащие точки GPS, чтобы сгладить ошибки.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="889"/>
        <source>&lt;b&gt;Graph data&lt;/b&gt;</source>
        <translation>&lt;b&gt;Данные графика&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="894"/>
        <source>Data source</source>
        <translation>Источник данных</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="898"/>
        <source>Choose which data type is used for graph drawing.</source>
        <translation>Выберите, какой тип данных будет использоваться для построения графика.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Location (2D map)</source>
        <translation>Расположение (2D-карта)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Altitude</source>
        <translation>Высотность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="907"/>
        <source>Heart rate</source>
        <translation>Частота сердцебиения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="919"/>
        <source>Graph type</source>
        <translation>Тип графика</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="923"/>
        <source>Graph types can add advanced interactions.</source>
        <translation>Типы графиков могут добавлять расширенные взаимодействия.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Standard</source>
        <translation>Стандарт</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Follow dot (cropped)</source>
        <translation>Следовать за точкой (обрезано)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="932"/>
        <source>Speedometer</source>
        <translation>Спидометр</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="941"/>
        <source>Standard = just a static map.
Follow dot = centers on the current location.
Speedometer = draws a simple speedometer.</source>
        <translation>Стандарт = просто статичная карта.
Следовать за точкой = центром является текущее расположение.
Спидометр = рисует простой спидометр.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="947"/>
        <source>Trim time</source>
        <translation>Время обрезки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="951"/>
        <source>Hides part of the graph at beginning or end.
This does not recompute min/max for any field.</source>
        <translation>Скрывает часть графика в начале или в конце.
При этом мин/макс для полей не пересчитывается.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="978"/>
        <source>Hides part of the beginning of the graph.</source>
        <translation>Скрывает часть начала графика.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1022"/>
        <source>Hides part of the end of the graph.</source>
        <translation>Скрывает часть конца графика.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1039"/>
        <source>Crop horizontal</source>
        <translation>Обрезка по горизонтали</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1043"/>
        <source>Zooms in on the graph on the horizontal axis (longitude if map, time if simple graph).
The number is either a percentage or a numeric value interpreted as the legend type.
This field is not applicable for Speedometer type.</source>
        <translation>Увеличивает график по горизонтальной оси (долгота, если это карта, время, если обычный график).
Число является либо процентным значением, либо числовым значением, интерпретированным как тип легенды.
Это поле неприменимо для типа &quot;Спидометр&quot;.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1065"/>
        <source>Crops the graph from the left side.</source>
        <translation>Обрезает график с левой стороны.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1108"/>
        <source>Crops the graph from the right side. This value is ignored if mode is Follow dot.</source>
        <translation>Обрезает график с правой стороны. Это значение игнорируется, если установлен режим &quot;Следовать за точкой&quot;.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1116"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1225"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1116"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1225"/>
        <source>value</source>
        <translation>значение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1126"/>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1235"/>
        <source>The crop values are interpreted as a percentage of total or as an absolute value (in legend unit).</source>
        <translation>Значения обрезки интерпретируются как процент от итога или как абсолютное значение (в единицах легенды).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1130"/>
        <source>Input for horizontal crops can be a percentage or an absolute value.</source>
        <translation>Ввод для горизонтальной обрезки может быть процентным или абсолютным значением.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1147"/>
        <source>Crop vertical</source>
        <translation>Обрезка по вертикали</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1151"/>
        <source>Zooms in on the graph on the vertical axis (latitude if map, value if simple graph).
The number is either a percentage or a numeric value interpreted as the legend type.
This field affects min/max values on the Speedometer type.</source>
        <translation>Увеличивает график по вертикальной оси (широта, если это карта, значение, если обычный график).
Число является либо процентным значением, либо числовым значением, интерпретированным как тип легенды.
Это поле влияет на мин/макс значения для типа &quot;Спидометр&quot;.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1174"/>
        <source>Crops the graph from the bottom side.</source>
        <translation>Обрезает график с нижней стороны.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1217"/>
        <source>Crops the graph from the top side. This value is ignored if mode is Follow dot.</source>
        <translation>Обрезает график сверху. Это значение игнорируется, если установлен режим &quot;Следовать за точкой&quot;.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1239"/>
        <source>Input for vertical crops can be a percentage or an absolute value.</source>
        <translation>Ввод для вертикальной обрезки может быть процентным или абсолютным значением.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1257"/>
        <source>&lt;b&gt;Graph design&lt;/b&gt;</source>
        <translation>&lt;b&gt;Макет графика&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1262"/>
        <source>Color style</source>
        <translation>Цветовой стиль</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1266"/>
        <source>Choose how you want to color the graph line.</source>
        <translation>Выберите, как вы хотите раскрасить линию графика.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>One color</source>
        <translation>Один цвет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Two colors</source>
        <translation>Два цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Solid past, thin future</source>
        <translation>Твёрдое прошлое, тонкое будущее</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Solid future, thin past</source>
        <translation>Твердое будущее, тонкое прошлое</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Vertical gradient</source>
        <translation>Вертикальный градиент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Horizontal gradient</source>
        <translation>Горизонтальный градиент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by duration</source>
        <translation>Цвет по длительности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by altitude</source>
        <translation>Цвет по высотности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by heart rate</source>
        <translation>Цвет по частоте сердцебиения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1285"/>
        <source>Color by speed</source>
        <translation>Цвет по скорости</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by speed (max 100km/h)</source>
        <translation>Цвет в зависимости от скорости (макс. 100 км/ч)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by grade (max 90°)</source>
        <translation>Цвет в зависимости от уровня (максимум 90°)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1287"/>
        <source>Color by grade (max 20°)</source>
        <translation>Цвет в зависимости от уровня (max 20°)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1306"/>
        <source>Color by Altitude/HR only work if there are recorded values in the gps file.
For speedometer type, only first 2 colors are used.</source>
        <translation>Цвет по Высота/Частота работает только в том случае, если в файле GPS есть записанные значения.
Для типа &quot;Спидометр&quot; используются только первые 2 цвета.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1348"/>
        <source>Now dot</source>
        <translation>Начать ставить точки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1352"/>
        <source>Draw a dot showing current position on the graph.
For speedometer type, this is the needle.</source>
        <translation>Нарисовать точку, отображающую текущую позицию на графике.
Для типа &quot;Спидометр&quot; это стрелка.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1370"/>
        <source>Set the color of the inside of the now dot (or needle).</source>
        <translation>Установить цвет внутренней части точки (или иглы).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1394"/>
        <source>Now text</source>
        <translation>Начать текст</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1399"/>
        <source>Draw a large white text showing the current value.
The legend unit (if present) will be appended at the end.</source>
        <translation>Нарисовать большой белый текст, отображающий текущее значение.
Единицы легенды (если имеются) будут добавлены в конце.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1417"/>
        <source>Rotate the entire graph. Speedometer also rotates internal text.</source>
        <translation>Повернуть весь график. Спидометр также вращает внутренний текст.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1451"/>
        <source>Set the thickness of the graph line. Does not affect speedometer.</source>
        <translation>Установите толщину линии графика. Не влияет на спидометр.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1481"/>
        <source>Draw legend</source>
        <translation>Рисовать легенду</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1485"/>
        <source>Draw 5 horizontal white lines with individual values for graph readability. 2D map also draws vertical (longitude) lines.
For speedometer this draws text for divisions.</source>
        <translation>Нарисовать 5 горизонтальных белых линий с отдельными значениями для удобства чтения графика. На 2D-карте также отображаются вертикальные линии (долгота).
Для &quot;Спидометра&quot; будет нарисован текст для делений.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1498"/>
        <source>Unit</source>
        <translation>Ед. изм.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1502"/>
        <source>This will be used in legend text if active and in absolute value math.</source>
        <translation>Будет использоваться в тексте легенды, если включено, и в математических вычислениях абсолютного значения.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1514"/>
        <source>Defaults are km/h (speed) and meters (altitude).
 Available options: km/h, mi/h, nm/h (kn), m/s, ft/s.</source>
        <translation>По умолчанию: км/ч (скорость) и метры (высота).
 Доступные варианты: км/ч, миль/ч, морских миль/ч (узлов), м/с, фут/с.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1648"/>
        <source>Sets the height to the correct map aspect ratio or 1:1.</source>
        <translation>Устанавливает высоту в соответствии с правильным соотношением сторон карты или 1:1.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1655"/>
        <source>&lt;b&gt;Background options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Параметры фона&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1660"/>
        <source>Image path</source>
        <translation>Путь изображения</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1664"/>
        <source>Choose an image to overlay behind the graph. Tip: you can use an actual map image to make the GPS track more interesting.</source>
        <translation>Выберите изображения для наложения за графиком. Совет: можно использовать изображение настоящей карты, чтобы GPS-маршрут выглядел интереснее.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1696"/>
        <source>GPS file center is: </source>
        <translation>Центр файла GPS:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1699"/>
        <source>Get the center coordinate of GPS map. This does not change with trim or crop.
TIP:OpenStreetMap website can save the current standard map centered on searched location (but only at screen resolution).
Google Earth for desktop can center on a coordinate and save a 4K image of it. Disable the Terrain layer for best results.</source>
        <translation>Получить координаты GPS-карты. Это значение не меняется при обрезке или кадрировании.
СОВЕТ: веб-сайт OpenStreetMap позволяет сохранить текущую стандартную карту с центром в искомом расположении (но только с разрешением экрана).
Google Earth для ПК позволяет установить центр по координатам и сохранить 4K-изображение. Для получения наилучшего результата отключите слой рельефа.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1710"/>
        <source>Browse for an image file to be assigned as graph background.</source>
        <translation>Обзор файла изображения, который будет назначен в качестве фона графика.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1727"/>
        <source>Increase or decrease the size of the background image.
Values smaller than 1 will zoom into image.</source>
        <translation>Увеличение или уменьшение размера фонового изображения.
Значения меньше 1 будут увеличивать изображение.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="584"/>
        <source>Processing start</source>
        <translation>Начать обработку</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="589"/>
        <source>Distances are calculated since the start of the gps file, use this field to reset them (GPS time).</source>
        <translation>Расстояния рассчитываются с момента начала файла gps, используйте это поле для их сброса (время GPS).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="606"/>
        <source>Insert date and time formatted exactly as: YYYY-MM-DD HH:MM:SS (GPS time).</source>
        <translation>Введите дату и время в точном формате: ГГГГ-ММ-ДД ЧЧ:ММ:СС (время по GPS).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="621"/>
        <source>Set start of GPS processing to current video time.</source>
        <translation>Установите начало обработки GPS на текущее время видео.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="674"/>
        <source>&lt;b&gt;Text options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Настройки текста&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="792"/>
        <source>Insert GPS field</source>
        <translation>Вставить поле GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="881"/>
        <source>Extra arguments can be added inside keywords:
Distance units: m [km|ft|mi].
Speed units: km/h [mi/h|m/s|ft/s].
Time default: %Y-%m-%d %H:%M:%S, extra offset can be added as +/-seconds (+3600).
Extra keyword: RAW (prints only values from file).</source>
        <translation>Внутрь ключевых слов можно добавить дополнительные аргументы:
Расстояние: м [км|фут|ми].
Скорость: км/ч [миль/ч|м/с|фут/с].
Исходное время: %Г-%м-%д %Ч:%М:%С, дополнительное смещение может быть добавлено в виде +/-секунд (+3600).
Дополнительное ключевое слово: RAW (выводит только значения из файла).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS latitude</source>
        <translation>Широта GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS longitude</source>
        <translation>Долгота GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation (m)</source>
        <translation>Высота над уровнем моря (м)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Speed (km/h)</source>
        <translation>Скорость (км/ч)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance (m)</source>
        <translation>Расстояние (м)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>GPS date-time</source>
        <translation>Дата и время GPS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Video file date-time</source>
        <translation>Дата и время видеофайла</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Heart-rate (bpm)</source>
        <translation>Число ударов (уд/мин)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Bearing (degrees)</source>
        <translation>Азимут (градусы)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Bearing (compass)</source>
        <translation>Азимут (компас)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation gain (m)</source>
        <translation>Увеличение высоты (м)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Elevation loss (m)</source>
        <translation>Потеря высоты (м)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance uphill (m)</source>
        <translation>Расстояние подъема (м)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance downhill (m)</source>
        <translation>Расстояние спуска (м)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="801"/>
        <source>Distance flat (m)</source>
        <translation>Расстояние на плоскости (м)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Cadence</source>
        <translation>Каденция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Temperature (C)</source>
        <translation>Температура (C)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Grade (%)</source>
        <translation>Уровень (%)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Grade (degrees)</source>
        <translation>Уровень (градусы)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>Vertical speed (m/s)</source>
        <translation>Вертикальная скорость (м/с)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="802"/>
        <source>3D Speed (km/h)</source>
        <translation>3D Скорость (км/ч)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="803"/>
        <source>Power (W)</source>
        <translation>Мощность (Вт)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="895"/>
        <source>&lt;b&gt;Advanced options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Расширенные параметры&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="848"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="634"/>
        <source>Video speed</source>
        <translation>Скорость видео</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="852"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="639"/>
        <source>If the current video is sped up (timelapse) or slowed down use this field to set the speed.</source>
        <translation>Если текущее видео ускорено (таймлапс) или замедлено, используйте это поле для установки скорости.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="875"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="660"/>
        <source>Fractional times are also allowed (0.25 = 4x slow motion, 5 = 5x timelapse).</source>
        <translation>Также допускается дробное время (0,25 = 4-кратная замедленная съемка, 5 = 5-кратный таймлапс).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="900"/>
        <source>Update speed</source>
        <translation>Скорость обновления</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="905"/>
        <source>Set how many text updates to show per second.
Set to 0 to only print real points (no interpolation).</source>
        <translation>Установите, сколько текстовых обновлений будет отображаться в секунду.
Установите на 0, чтобы печатать только реальные точки (без интерполяции).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="923"/>
        <source>Fractional times are also allowed (0.25 = update every 4 seconds, 5 = 5 updates per second).</source>
        <translation>Также допускается дробное время (0,25 = обновление каждые 4 секунды, 5 = 5 обновлений в секунду).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="933"/>
        <source> per second</source>
        <translation>в секунду</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1770"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="960"/>
        <source>Video start time:</source>
        <translation>Время начала видео:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1775"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="965"/>
        <source>Detected date-time for the video file.</source>
        <translation>Обнаруженная дата-время для видеофайла.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1793"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="983"/>
        <source>GPS start time:</source>
        <translation>Время начала GPS:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1798"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="988"/>
        <source>Detected date-time for the GPS file.</source>
        <translation>Обнаруженная дата-время для файла GPS.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gpsgraphic/ui.qml" line="1809"/>
        <location filename="../src/qml/filters/gpstext/ui.qml" line="999"/>
        <source>This time will be used for synchronization.</source>
        <translation>Это время будет использовано для синхронизации.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_alphaspot/ui.qml" line="599"/>
        <location filename="../src/qml/filters/mask_chromakey/ui.qml" line="111"/>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="259"/>
        <location filename="../src/qml/filters/mask_shape/ui.qml" line="622"/>
        <source>Tip: Mask other video filters by adding filters after this one followed by &lt;b&gt;Mask: Apply&lt;/b&gt;</source>
        <translation>Совет: Замаскируйте другие видеофильтры, добавляя фильтры, перед которыми следует &lt;b&gt;Маска: Применить&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="128"/>
        <source>50 Hz</source>
        <translation>50 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="198"/>
        <source>100 Hz</source>
        <translation>100 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="222"/>
        <source>156 Hz</source>
        <translation>156 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="246"/>
        <source>220 Hz</source>
        <translation>220 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="270"/>
        <source>311 Hz</source>
        <translation>311 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="294"/>
        <source>440 Hz</source>
        <translation>440 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="318"/>
        <source>622 Hz</source>
        <translation>622 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="342"/>
        <source>880 Hz</source>
        <translation>880 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="366"/>
        <source>1250 Hz</source>
        <translation>1250 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="390"/>
        <source>1750 Hz</source>
        <translation>1750 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="414"/>
        <source>2500 Hz</source>
        <translation>2500 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="438"/>
        <source>3500 Hz</source>
        <translation>3500 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="462"/>
        <source>5000 Hz</source>
        <translation>5000 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="486"/>
        <source>10000 Hz</source>
        <translation>10000 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq15band/ui.qml" line="510"/>
        <source>20000 Hz</source>
        <translation>20000 Гц</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="130"/>
        <source>Low</source>
        <translation>Низкий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="188"/>
        <source>Mid</source>
        <translation>Средний</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_eq3band/ui.qml" line="212"/>
        <source>High</source>
        <translation>Высокий</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="87"/>
        <source>Source</source>
        <translation>Источник</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <source>Middle (L+R)</source>
        <translation>Средний (Л+П)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="108"/>
        <source>Side (L-R)</source>
        <translation>Сторона (Л-П)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="117"/>
        <source>Left delay</source>
        <translation>Задержка слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="143"/>
        <source>Left delay gain</source>
        <translation>Усиление задержки слева</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="169"/>
        <source>Right delay</source>
        <translation>Задержка справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="195"/>
        <source>Right delay gain</source>
        <translation>Усиление задержки справа</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_stereoenhance/ui.qml" line="221"/>
        <source>Output gain</source>
        <translation>Выходное усиление</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="103"/>
        <source>New...</source>
        <translation>Новый...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="114"/>
        <source>New Animation File</source>
        <translation>Новый файл анимации</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="124"/>
        <source>Open Animation File</source>
        <translation>Открыть файл анимации</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="134"/>
        <source>Click &lt;b&gt;New...&lt;/b&gt; or &lt;b&gt;Open...&lt;/b&gt; to use this filter</source>
        <translation>Нажмите &lt;b&gt;Создать...&lt;/b&gt; или &lt;b&gt;Открыть...&lt;/b&gt;, чтобы использовать этот фильтр</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="149"/>
        <source>Edit...</source>
        <translation>Изменить...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mask_glaxnimate/ui.qml" line="154"/>
        <source>Reload</source>
        <translation>Перезагрузить</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="124"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="139"/>
        <source>Region To Track</source>
        <translation>Регион для Отслеживания</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="148"/>
        <source>Set the region of interest to track.</source>
        <translation>Установите регион для отслеживания.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="267"/>
        <source>Algorithm</source>
        <translation>Алгоритм</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="270"/>
        <source>Chooses the way (rules) the tracking is calculated.</source>
        <translation>Выбор способа (правила) расчета отслеживания.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tracker/ui.qml" line="348"/>
        <source>Show preview</source>
        <translation>Показать предпросмотр</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="88"/>
        <source>Discontinuity threshold</source>
        <translation>Порог разрыва</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="92"/>
        <source>The threshold to apply a seam to splices</source>
        <translation>Порог для наложения шва на стыки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="128"/>
        <source>Seam applied</source>
        <translation>Шов применяется</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_seam/ui.qml" line="132"/>
        <source>Status indicator showing when a splice has been seamed.</source>
        <translation>Индикатор состояния, показывающий, когда соединение было сшито.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="36"/>
        <source>Fade to White</source>
        <translation>Затухание в белое</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/video_autofade/ui.qml" line="123"/>
        <source>Fade color</source>
        <translation>Затухание цвета</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="181"/>
        <source>Azimuth</source>
        <translation>Азимут</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/ambisonic_encoder/ui.qml" line="225"/>
        <source>Elevation</source>
        <translation>Высота над уровнем моря</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/histeq/ui.qml" line="82"/>
        <location filename="../src/qml/filters/vibrance/ui.qml" line="98"/>
        <source>Intensity</source>
        <translation>Интенсивность</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/subtitle/ui.qml" line="113"/>
        <source>Subtitle Track</source>
        <translation>Дорожка субтитров</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="153"/>
        <source>Horizontal 4:3</source>
        <translation>Горизонтальное 4:3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="158"/>
        <source>Horizontal 16:9</source>
        <translation>Горизонтальное 16:9</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="163"/>
        <source>Square</source>
        <translation>Квадрат</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/reframe/ui.qml" line="170"/>
        <source>Vertical 9:16</source>
        <translation>Вертикальное 9:16</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="140"/>
        <source>Sepia</source>
        <translation>Сепия</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="146"/>
        <source>Thermal</source>
        <translation>Тепловая</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="205"/>
        <source>Color #%1</source>
        <translation>Цвет #%1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="211"/>
        <source>Color: %1
Click to select, drag to change position</source>
        <translation>Цвет:% 1
Нажмите, чтобы выбрать, перетащите, чтобы изменить положение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/gradientmap/ui.qml" line="344"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="159"/>
        <source>Overlap</source>
        <translation>Перекрытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="186"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="294"/>
        <source>Hue Shift</source>
        <translation>Изменение оттенка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="192"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="355"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="518"/>
        <source>Reds</source>
        <translation>Красные</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="218"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="381"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="544"/>
        <source>Yellows</source>
        <translation>Жёлтые</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="244"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="407"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="570"/>
        <source>Greens</source>
        <translation>Зеленые</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="270"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="433"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="596"/>
        <source>Cyans</source>
        <translation>Голубые</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="296"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="459"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="622"/>
        <source>Blues</source>
        <translation>Синие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="322"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="485"/>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="648"/>
        <source>Magentas</source>
        <translation>Фиолетовые</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="349"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="323"/>
        <source>Saturation Scale</source>
        <translation>Шкала Насыщенности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/hslprimaries/ui.qml" line="512"/>
        <location filename="../src/qml/filters/hslrange/ui.qml" line="352"/>
        <source>Lightness Scale</source>
        <translation>Шкала Светлоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_eq_wrap/ui.qml" line="520"/>
        <source>Blur Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="111"/>
        <source>File for zenith correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bigsh0t_zenith_correction/ui.qml" line="209"/>
        <source>Smooth yaw instead of locking it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/strobe/ui.qml" line="116"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ui_av</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="70"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="89"/>
        <source>Amount</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_av.qml" line="126"/>
        <source>Blur alpha</source>
        <translation>Blur alpha</translation>
    </message>
</context>
<context>
    <name>ui_box_blur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="70"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="90"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="119"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_box_blur.qml" line="152"/>
        <source>Blur alpha</source>
        <translation>Blur alpha</translation>
    </message>
</context>
<context>
    <name>ui_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="138"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="169"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="208"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
</context>
<context>
    <name>ui_dance</name>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="71"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="84"/>
        <source>Initial Zoom</source>
        <translation>Начальный масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="88"/>
        <source>The amount to zoom the image before any motion occurs.</source>
        <translation>Масштабирование изображения перед началом движения.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="108"/>
        <source>Oscillation</source>
        <translation>Осцилляция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="112"/>
        <source>Oscillation can be useful to make the image move back and forth during long periods of sound.</source>
        <translation>Осцилляция может быть полезна, чтобы заставить изображение двигаться вперёд и назад в течение длительного периода звучания.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="132"/>
        <source>Zoom</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="136"/>
        <source>The amount that the audio affects the zoom of the image.</source>
        <translation>Влияние аудиоэффектов на масштаб изображения.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="156"/>
        <source>Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="160"/>
        <source>The amount that the audio affects the upward offset of the image.</source>
        <translation>Влияние аудиоэффектов на смещение изображения вверх.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="180"/>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="184"/>
        <source>The amount that the audio affects the downward offset of the image.</source>
        <translation>Влияние аудиоэффектов на смещение изображения вниз.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="204"/>
        <source>Left</source>
        <translation>Влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="208"/>
        <source>The amount that the audio affects the left offset of the image.</source>
        <translation>Влияние аудиоэффектов на смещение изображения влево.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="228"/>
        <source>Right</source>
        <translation>Вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="232"/>
        <source>The amount that the audio affects the right offset of the image.</source>
        <translation>Влияние аудиоэффектов на смещение изображения вправо.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="252"/>
        <source>Clockwise</source>
        <translation>По часовой стрелке</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="256"/>
        <source>The amount that the audio affects the clockwise rotation of the image.</source>
        <translation>Влияние аудиоэффектов на вращение изображения по часовой стрелке.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="267"/>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="291"/>
        <source> deg</source>
        <translation> град.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="276"/>
        <source>Counterclockwise</source>
        <translation>Против часовой стрелки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="280"/>
        <source>The amount that the audio affects the counterclockwise rotation of the image.</source>
        <translation>Влияние аудиоэффектов на вращение изображения против часовой стрелки.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="300"/>
        <source>Low Frequency</source>
        <translation>Низкие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="304"/>
        <source>The low end of the frequency range to be used to influence the image motion.</source>
        <translation>Нижний предел диапазона частот, который будет использоваться для влияния на движение изображения.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="328"/>
        <source>High Frequency</source>
        <translation>Высокие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="332"/>
        <source>The high end of the frequency range to be used to influence the image motion.</source>
        <translation>Верхний предел диапазона частот, который будет использоваться для влияния на движение изображения.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="356"/>
        <source>Threshold</source>
        <translation>Порог</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dance/ui_dance.qml" line="360"/>
        <source>The minimum amplitude of sound that must occur within the frequency range to cause the image to move.</source>
        <translation>Минимальная амплитуда звука, которая должна присутствовать в диапазоне частот, чтобы изображение двигалось.</translation>
    </message>
</context>
<context>
    <name>ui_frei0r</name>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_frei0r.qml" line="65"/>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="97"/>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="100"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="130"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="116"/>
        <source>Blur</source>
        <translation>Размытие</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="81"/>
        <source>Grayscale</source>
        <translation>Оттенки серого</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="123"/>
        <source>Level</source>
        <translation>Уровень</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur_gaussian/ui_frei0r.qml" line="84"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="148"/>
        <source>Amount</source>
        <translation>Количество</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="173"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
</context>
<context>
    <name>ui_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="56"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Shadows (Lift)</source>
        <translation>Тени</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Midtones (Gamma)</source>
        <translation>Полутона (Гамма)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="63"/>
        <source>Highlights (Gain)</source>
        <translation>Яркие участки (Усиление)</translation>
    </message>
</context>
<context>
    <name>ui_lightshow</name>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="79"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="96"/>
        <source>Waveform Color</source>
        <translation>Цвет волны</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="112"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="153"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="194"/>
        <source>Oscillation</source>
        <translation>Осцилляция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="198"/>
        <source>Oscillation can be useful to make the light blink during long periods of sound.</source>
        <translation>Осцилляция может быть полезна, чтобы заставить свет мигать в течение длительного периода звучания.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="218"/>
        <source>Low Frequency</source>
        <translation>Низкие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="222"/>
        <source>The low end of the frequency range to be used to influence the light.</source>
        <translation>Нижний конец диапазона частот, который будет использоваться для воздействия на свет.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="246"/>
        <source>High Frequency</source>
        <translation>Высокие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="250"/>
        <source>The high end of the frequency range to be used to influence the light.</source>
        <translation>Верхний конец частотного диапазона, который будет использоваться для воздействия на свет.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="274"/>
        <source>Threshold</source>
        <translation>Порог</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lightshow/ui_lightshow.qml" line="278"/>
        <source>The minimum amplitude of sound that must occur within the frequency range to cause the light to change.</source>
        <translation>Минимальная амплитуда звука, которая должна возникать в диапазоне частот, чтобы вызвать изменение света.</translation>
    </message>
</context>
<context>
    <name>ui_movit</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="118"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="149"/>
        <source>Radius</source>
        <translation>Радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="163"/>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="121"/>
        <source>Level</source>
        <translation>Уровень</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="95"/>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="139"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="129"/>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="98"/>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="136"/>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="127"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="175"/>
        <source>Highlight blurriness</source>
        <translation>Подсветить размытость</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="201"/>
        <source>Highlight cutoff</source>
        <translation>Подсветить отсечки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="79"/>
        <source>Grayscale</source>
        <translation>Оттенки серого</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="155"/>
        <source>Circle radius</source>
        <translation>Радиус окружности</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="181"/>
        <source>Gaussian radius</source>
        <translation>Радиус Гаусса</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="207"/>
        <source>Correlation</source>
        <translation>Взаимосвязь</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="232"/>
        <source>Noise</source>
        <translation>Шум</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="147"/>
        <source>Outer radius</source>
        <translation>Внешний радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="171"/>
        <source>Inner radius</source>
        <translation>Внутренний радиус</translation>
    </message>
</context>
<context>
    <name>ui_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="137"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="158"/>
        <source>Radius</source>
        <translation>Радиус</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="182"/>
        <source>Feathering</source>
        <translation>Растушевка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="212"/>
        <source>Non-linear feathering</source>
        <translation>Нелинейная растушевка</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="222"/>
        <source>Opacity</source>
        <translation>Непрозрачность</translation>
    </message>
</context>
<context>
    <name>ui_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="103"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="120"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Line</source>
        <translation>Линия</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Bar</source>
        <translation>Панель</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="141"/>
        <source>Segment</source>
        <translation>Сегмент</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="149"/>
        <source>Spectrum Color</source>
        <translation>Цвет спектра</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="165"/>
        <source>Background Color</source>
        <translation>Цвет фона</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="179"/>
        <source>Thickness</source>
        <translation>Толщина</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="199"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="246"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="300"/>
        <source>Fill the area under the spectrum.</source>
        <translation>Заливка области под спектром.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="312"/>
        <source>Mirror the spectrum.</source>
        <translation>Отразить спектр.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="324"/>
        <source>Reverse the spectrum.</source>
        <translation>Обратить спектр.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="329"/>
        <source>Tension</source>
        <translation>Натяжение</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="348"/>
        <source>Segments</source>
        <translation>Сегменты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="371"/>
        <source>Segment Gap</source>
        <translation>Разрыв сегмента</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="394"/>
        <source>Bands</source>
        <translation>Ленты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="413"/>
        <source>Low Frequency</source>
        <translation>Низкие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="417"/>
        <source>The low end of the frequency range of the spectrum.</source>
        <translation>Нижний предел частотного диапазона спектра.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="441"/>
        <source>High Frequency</source>
        <translation>Высокие частоты</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="445"/>
        <source>The high end of the frequency range of the spectrum.</source>
        <translation>Верхний предел частотного диапазона спектра.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spectrum/ui_spectrum.qml" line="469"/>
        <source>Threshold</source>
        <translation>Порог</translation>
    </message>
</context>
<context>
    <name>vui</name>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="213"/>
        <source>Hold Shift while dragging any corner to drag all corners</source>
        <translation>Удерживайте Shift любого угла, чтобы перетащить все углы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="276"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="318"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="360"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/corners/vui.qml" line="402"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="366"/>
        <source>Text size</source>
        <translation>Размер шрифта</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="385"/>
        <source>Text color</source>
        <translation>Цвет текста</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="487"/>
        <source>Collapse Toolbar</source>
        <translation>Свернуть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="487"/>
        <source>Expand Toolbar</source>
        <translation>Развернуть</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="270"/>
        <source>Menu</source>
        <translation>Меню</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="596"/>
        <source>Left</source>
        <translation>Влево</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="607"/>
        <source>Center</source>
        <translation>Центральный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="618"/>
        <source>Right</source>
        <translation>Вправо</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="629"/>
        <source>Justify</source>
        <translation>По ширине</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="640"/>
        <source>Bold</source>
        <translation>Жирный</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="651"/>
        <source>Italic</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="662"/>
        <source>Underline</source>
        <translation>Подчёркнутый</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="812"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="820"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="331"/>
        <location filename="../src/qml/filters/richtext/vui.qml" line="673"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="746"/>
        <source>Insert Table</source>
        <translation>Вставить таблицу</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="686"/>
        <source>Decrease Indent</source>
        <translation>Уменьшить отступ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="695"/>
        <source>Insert Indent</source>
        <translation>Вставить отступ</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="758"/>
        <source>Rows</source>
        <translation>Строки</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="775"/>
        <source>Columns</source>
        <translation>Столбцы</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/richtext/vui.qml" line="791"/>
        <source>Border</source>
        <translation>Граница</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audiolevelgraph/vui.qml" line="26"/>
        <location filename="../src/qml/filters/gpsgraphic/vui.qml" line="26"/>
        <location filename="../src/qml/filters/gradient/vui.qml" line="109"/>
        <location filename="../src/qml/filters/lightshow/vui.qml" line="26"/>
        <location filename="../src/qml/filters/mask_alphaspot/vui.qml" line="108"/>
        <location filename="../src/qml/filters/pillar_echo/vui.qml" line="82"/>
        <location filename="../src/qml/filters/reframe/vui.qml" line="86"/>
        <location filename="../src/qml/filters/spot_remover/vui.qml" line="82"/>
        <location filename="../src/qml/filters/tracker/vui.qml" line="48"/>
        <location filename="../src/qml/filters/waveform/vui.qml" line="26"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Нажмите прямоугольник + удерживайте Shift для перетаскивания</translation>
    </message>
</context>
<context>
    <name>vui_spectrum</name>
    <message>
        <location filename="../src/qml/filters/spectrum/vui_spectrum.qml" line="26"/>
        <source>Click in rectangle + hold Shift to drag</source>
        <translation>Нажмите прямоугольник + удерживайте Shift для перетаскивания</translation>
    </message>
</context>
</TS>
