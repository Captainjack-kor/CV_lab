All translation updates must go through transifex.com.
Pull requests for those will be rejected.
